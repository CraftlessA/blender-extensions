# SPDX-License-Identifier: GPL-3.0-or-later
"""Real static meshes standing in for live meshes that have stopped changing.

Lumen sees a `DynamicMeshComponent` poorly. It has no distance field (support was removed in
5.0), so software Lumen cannot trace it at all, and its surface cache is six cards projected from
its bounding box (`FBaseDynamicMeshSceneProxy::UpdateLumenCardsFromBounds`): fine for a crate,
useless for the inside of a room. In the Surface Cache view mode every live mesh showed pink, and
reflections and bounce light missed them.

A `UStaticMesh` built through the editor's normal pipeline gets a distance field and cards fitted
to its shape. So once an object's geometry has been still for `SETTLE_SECONDS`, it is copied into
a transient static mesh, shown on a `StaticMeshActor` attached to the live actor (so transforms
from Blender still move it), and the dynamic mesh is hidden. The next geometry change swaps back
at once: anything Blender is deforming every frame simply stays dynamic, as Unreal's own skinned
meshes do.

**The cache.** Building costs about 8 ms per thousand triangles (630 ms for 79,200, every time:
the editor's derived-data cache does not shorten it), which a big scene would pay again on every
reconnect. So every mesh that arrives is digested (`bu_link.mesh_digest`, natively), and a
stand-in is built into a saved asset named after its geometry's digest, under `MESH_PACKAGE`.
Anything with the same digest — the next session, a reconnect, a duplicate of the same rock —
loads that asset instead: 40 ms for the same 79,200 triangles, with its distance field from the
derived-data cache. A mesh identical to what its actor already shows does better still: its
geometry and stand-in are left untouched.

**Animated meshes wait longer, and are not cached.** A mesh that changes again before it has
settled is being animated (or edited). Each pause in playback or scrubbing used to give every
bending piece of a character a stand-in 1.5 s later — a 27,000-triangle piece is a 200 ms build,
which no per-tick budget can split — and save it to the cache as a pose that rarely comes back:
a tester's Unreal built 953 in four minutes, at up to six a second, and pruned 610 at the next
start. Such a mesh now waits `ANIMATED_SETTLE_SECONDS`, and its stand-in is built in memory only.

Old entries are pruned when the editor starts (`prune_files`), by deleting files nothing has
loaded yet. Deleting a loaded asset from inside the session (`ObjectTools::ForceDeleteObjects`)
runs a full garbage collection behind a progress dialog, which is no way to tidy a cache.
"""

import json
import os
import re
import time

from . import bu_link_editor, bu_link_material

SETTLE_SECONDS = 1.5
# For a mesh that changed again before it settled: playback paused, a scrub stopped.
ANIMATED_SETTLE_SECONDS = 6.0
# Building is synchronous (the swap waits for the render data, or the object would blink out),
# so it is rationed per tick, and a huge mesh is left dynamic rather than freezing the editor.
# Measured in an offscreen 5.8 editor: 12 triangles 10 ms, 79,200 triangles 922 ms.
BUDGET_SECONDS = 0.02
MAX_TRIANGLES = 100000
TAG = "BU_LiveStatic"
MESH_PACKAGE = "/Game/BU/Live/Meshes"
MESH_FOLDER = os.path.join("BU", "Live", "Meshes")      # under the project's Content folder
INDEX_FILE = os.path.join("BU", "link_mesh_cache.json")  # under the project's Saved folder
# One cached mesh per Blender object name (its newest), for this many most recently used names.
CACHE_NAMES = 2000

try:
    _STATIC  # noqa: B018 - survives importlib.reload on purpose
except NameError:
    _STATIC = {}
_STATIC.setdefault("changed", {})    # object name -> (time its geometry last changed, triangles)
_STATIC.setdefault("standins", {})   # object name -> StaticMeshActor
_STATIC.setdefault("animated", set())  # names that changed again before settling, until promoted
_STATIC.setdefault("digests", {})    # object name -> digest of the geometry it shows, or None
_STATIC.setdefault("meshes", {})     # digest -> StaticMesh built or loaded this session
_STATIC.setdefault("index", None)    # object name -> [digest, last used]; loaded on first use
_STATIC.setdefault("counts", {"built": 0, "cached": 0})  # stand-ins made this session, by source


def note_changed(name, triangles, live_actor=None, now=None, digest=None):
    """The object's geometry just changed: show it dynamic, and consider it again once settled.

    An object that was still (or is new), arriving with geometry whose static mesh is already
    cached, is due at once and counted as no triangles: there is nothing to build, so nothing
    too big to build. One that is mid-animation waits like any other, or a looping animation
    would swap a stand-in in and out every time it passed a cached frame.
    """
    revert(name, live_actor=live_actor)
    now = time.perf_counter() if now is None else now
    was_still = name not in _STATIC["changed"]
    if not was_still:
        _STATIC["animated"].add(name)
    _STATIC["digests"][name] = digest or None
    if digest and was_still and is_cached(digest):
        _STATIC["changed"][name] = (now - SETTLE_SECONDS, 0)
    else:
        _STATIC["changed"][name] = (now, int(triangles or 0))


def shows(name, digest):
    """True when `name` already shows exactly the geometry `digest` describes."""
    return bool(digest) and _STATIC["digests"].get(name) == digest


def asset_name(digest):
    """The cached static mesh's asset name for a digest. Pure."""
    return "SM_BU_" + re.sub(r"[^A-Za-z0-9]", "_", str(digest))


def asset_path(digest):
    name = asset_name(digest)
    return "{0}/{1}.{1}".format(MESH_PACKAGE, name)


def remember(index, name, digest, now, limit=None):
    """Record that `name` now uses `digest`, dropping the least recently used names over the
    limit. Returns the digests nothing refers to any more. Pure; `index` is changed in place."""
    limit = CACHE_NAMES if limit is None else limit
    before = {entry[0] for entry in index.values()}
    index[name] = [digest, now]
    if limit and len(index) > limit:
        for old in sorted(index, key=lambda n: index[n][1])[:len(index) - limit]:
            del index[old]
    after = {entry[0] for entry in index.values()}
    return sorted(before - after)


def stale_files(file_names, index):
    """Cached mesh files (`SM_BU_<digest>.uasset`) the index no longer refers to. Pure."""
    wanted = {asset_name(entry[0]) for entry in index.values()}
    return sorted(f for f in file_names
                  if f.startswith("SM_BU_") and os.path.splitext(f)[0] not in wanted)


def due(changed, now, settle=None, max_triangles=None, animated=(), animated_settle=None):
    """Names whose geometry has been still long enough, oldest first. Those in `animated`
    wait `animated_settle`. Pure."""
    settle = SETTLE_SECONDS if settle is None else settle
    animated_settle = ANIMATED_SETTLE_SECONDS if animated_settle is None else animated_settle
    max_triangles = MAX_TRIANGLES if max_triangles is None else max_triangles
    ready = [(at, name) for name, (at, triangles) in changed.items()
             if now - at >= (animated_settle if name in animated else settle)
             and (not max_triangles or triangles <= max_triangles)]
    return [name for _at, name in sorted(ready)]


def forget(name):
    """The object is gone from Blender."""
    _STATIC["changed"].pop(name, None)
    _STATIC["digests"].pop(name, None)
    _STATIC["animated"].discard(name)
    revert(name, show=False)


def revert(name, show=True, live_actor=None):
    """Remove an object's stand-in and, unless told otherwise, show its dynamic mesh again."""
    standin = _STATIC["standins"].pop(name, None)
    bu_link_editor.destroy(standin)
    if show and standin is not None and live_actor is not None:
        _set_dynamic_visible(live_actor, True)


def reset(live_actors=()):
    """Drop every stand-in, including ones left in the level by an earlier session."""
    import unreal

    _STATIC["changed"].clear()
    _STATIC["animated"].clear()
    _STATIC["standins"].clear()
    _STATIC["digests"].clear()
    for actor in _tagged_standins(unreal):
        bu_link_editor.destroy(actor)
    for actor in live_actors:
        _set_dynamic_visible(actor, True)


def adopt(live_actors):
    """Keep what an earlier connection left: stand-ins whose live actor is in `live_actors`
    (name -> actor), and the digests of what those actors show. Everything else goes.
    Returns how many stand-ins were kept."""
    import unreal

    _STATIC["changed"].clear()
    _STATIC["animated"].clear()
    owned = {}
    for standin in _tagged_standins(unreal):
        try:
            parent = standin.get_attach_parent_actor()
        except Exception:  # noqa: BLE001
            parent = None
        name = next((n for n, actor in live_actors.items()
                     if parent is not None and actor == parent), None)
        if name is None or name in owned:
            bu_link_editor.destroy(standin)
        else:
            owned[name] = standin
    _STATIC["standins"].clear()
    _STATIC["standins"].update(owned)
    for name in [n for n in _STATIC["digests"] if n not in live_actors]:
        del _STATIC["digests"][name]
    for name, actor in live_actors.items():
        _set_dynamic_visible(actor, name not in owned)
    return len(owned)


def pending():
    """True while some object is waiting to settle."""
    return bool(_STATIC["changed"])


def sweep(world=None):
    """Remove stand-ins this session does not own. Returns how many."""
    import unreal

    owned = list(_STATIC["standins"].values())
    removed = 0
    for actor in _tagged_standins(unreal, world):
        if not any(actor is mine or actor == mine for mine in owned):
            if bu_link_editor.destroy(actor):
                removed += 1
    return removed


def _tagged_standins(unreal, world=None):
    try:
        if world is None:
            world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
        return list(unreal.GameplayStatics.get_all_actors_with_tag(world, unreal.Name(TAG)))
    except Exception:  # noqa: BLE001
        return []


def counts():
    """{"standins", "built", "cached"}: stand-ins shown now, and made this session by source."""
    return dict(_STATIC["counts"], standins=len(_STATIC["standins"]))


def has_standin(name):
    return name in _STATIC["standins"]


def set_materials(name, materials):
    standin = _STATIC["standins"].get(name)
    if standin is None:
        return
    component = standin.static_mesh_component
    for index, material in enumerate(materials):
        component.set_material(index, material)


def show_to_camera(name, camera, shadow):
    standin = _STATIC["standins"].get(name)
    if standin is not None:
        bu_link_editor.show_to_camera(standin.static_mesh_component, camera, shadow)


def service(live_actor, folder, now=None, budget=None):
    """Promote settled objects, within the tick's budget. Returns how many were promoted.

    `live_actor(name)` gives the object's DynamicMeshActor, or None if it has gone.
    """
    changed = _STATIC["changed"]
    now = time.perf_counter() if now is None else now
    deadline = time.perf_counter() + (BUDGET_SECONDS if budget is None else budget)
    promoted = 0
    for name in due(changed, now, animated=_STATIC["animated"]):
        del changed[name]
        actor = live_actor(name)
        if actor is None:
            _STATIC["animated"].discard(name)
            continue
        if promote(name, actor, folder):
            promoted += 1
        _STATIC["animated"].discard(name)
        if time.perf_counter() >= deadline:
            break
    return promoted


def promote(name, actor, folder):
    """Swap one live actor's dynamic mesh for a static copy. False if it was left as it is."""
    import unreal

    dynamic = actor.get_dynamic_mesh_component()
    source = dynamic.get_dynamic_mesh()
    if int(source.get_triangle_count()) == 0:
        return False
    materials = [dynamic.get_material(i) for i in range(int(dynamic.get_num_materials()))]

    digest = _STATIC["digests"].get(name)
    mesh = cached_mesh(digest) if digest else None
    _STATIC["counts"]["cached" if mesh is not None else "built"] += 1
    # A pose an animation paused on: built, not saved for a next time that rarely comes.
    keep = bool(digest) and name not in _STATIC["animated"]
    if mesh is None:
        # The mesh's own slots get the saved master, never the link's transient instances: a
        # saved asset cannot refer to them. The component below overrides every slot anyway.
        master = bu_link_material.ensure("plain")
        slots = [master] * len(materials) if master is not None else materials
        mesh = build_cached(digest, source, slots) if keep else build(source, slots)
    if mesh is None:
        return False
    if keep:
        _record(name, digest)

    standin = bu_link_editor.spawn(
        unreal.StaticMeshActor, actor.get_actor_location(), actor.get_actor_rotation())
    if standin is None:
        return False
    standin.set_actor_transform(actor.get_actor_transform(), False, False)
    standin.set_actor_label(actor.get_actor_label() + " (static)")
    standin.set_editor_property("tags", [unreal.Name(TAG)])
    component = standin.static_mesh_component
    component.set_mobility(unreal.ComponentMobility.MOVABLE)
    bu_link_editor.render_only(component)
    component.set_static_mesh(mesh)
    for index, material in enumerate(materials):
        component.set_material(index, material)
    bu_link_editor.show_to_camera(component, *bu_link_editor.camera_flags(dynamic))
    try:
        standin.set_folder_path(unreal.Name(folder))
    except Exception:  # noqa: BLE001 - cosmetic
        pass
    # Attached, so a transform Blender sends to the live actor moves the stand-in with it.
    bu_link_editor.untracked(lambda: standin.attach_to_actor(
        actor, unreal.Name(""), unreal.AttachmentRule.KEEP_WORLD,
        unreal.AttachmentRule.KEEP_WORLD, unreal.AttachmentRule.KEEP_WORLD, False))
    _set_dynamic_visible(actor, False)
    _STATIC["standins"][name] = standin
    return True


def is_cached(digest):
    if not digest:
        return False
    if _usable(_STATIC["meshes"].get(digest)):
        return True
    import unreal

    try:
        return bool(unreal.EditorAssetLibrary.does_asset_exist(asset_path(digest)))
    except Exception:  # noqa: BLE001
        return False


def cached_mesh(digest):
    """The static mesh for `digest` from this session or an earlier one's saved asset, or None."""
    import unreal

    mesh = _STATIC["meshes"].get(digest)
    if _usable(mesh):
        return mesh
    path = asset_path(digest)
    try:
        if not unreal.EditorAssetLibrary.does_asset_exist(path):
            return None
        mesh = unreal.EditorAssetLibrary.load_asset(path)
        if not _usable(mesh):
            return None
    except Exception:  # noqa: BLE001
        return None
    _STATIC["meshes"][digest] = mesh
    return mesh


def build_cached(digest, source, materials):
    """Build into a new saved asset for `digest`, or a transient mesh if no asset can be made."""
    import unreal

    try:
        mesh = unreal.AssetToolsHelpers.get_asset_tools().create_asset(
            asset_name(digest), MESH_PACKAGE, unreal.StaticMesh, None)
    except Exception:  # noqa: BLE001
        mesh = None
    if mesh is None:
        return build(source, materials)
    if build(source, materials, mesh) is None:
        return None
    try:
        unreal.EditorAssetLibrary.save_loaded_asset(mesh, False)
    except Exception as exc:  # noqa: BLE001 - still usable this session
        unreal.log_warning("BU: could not save {0}: {1}".format(asset_path(digest), exc))
    _STATIC["meshes"][digest] = mesh
    return mesh


def _usable(mesh):
    try:
        return mesh is not None and int(mesh.get_num_triangles(0)) > 0
    except Exception:  # noqa: BLE001 - garbage collected
        return False


def _index_path():
    import unreal

    saved = unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_saved_dir())
    return os.path.join(saved, INDEX_FILE)


def _load_index():
    if _STATIC["index"] is None:
        index = {}
        try:
            with open(_index_path(), encoding="utf-8") as handle:
                index = {str(k): [str(v[0]), float(v[1])] for k, v in json.load(handle).items()}
        except (OSError, ValueError, TypeError, IndexError, AttributeError):
            pass
        _STATIC["index"] = index
    return _STATIC["index"]


def _record(name, digest):
    index = _load_index()
    if index.get(name, [None])[0] == digest:
        index[name][1] = time.time()
        return
    remember(index, name, digest, time.time())
    try:
        path = _index_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + ".tmp", "w", encoding="utf-8") as handle:
            json.dump(index, handle)
        os.replace(path + ".tmp", path)
    except OSError:
        pass  # the cache still works this session; it only prunes less precisely


def prune_files():
    """Delete cached mesh files the index no longer refers to. Returns how many.

    Run at editor startup, before anything can have loaded them: a file nothing has loaded is
    only a file, and the asset registry notices it has gone.
    """
    import unreal

    folder = os.path.join(
        unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_content_dir()), MESH_FOLDER)
    try:
        names = os.listdir(folder)
    except OSError:
        return 0
    removed = 0
    for file_name in stale_files(names, _load_index()):
        try:
            os.remove(os.path.join(folder, file_name))
            removed += 1
        except OSError:
            pass
    return removed


def clear_cache():
    """Forget every cached mesh, so stand-ins are built from scratch again.

    The files go at the next editor start; this session keeps what it has already loaded.
    """
    _STATIC["index"] = {}
    _STATIC["meshes"].clear()
    try:
        os.remove(_index_path())
    except OSError:
        pass


def build(source, materials, mesh=None):
    """A static mesh built from a DynamicMesh, with Lumen's cards and distance field.

    Built into `mesh` when given (a saved asset), otherwise into a new transient one.
    """
    import unreal

    if mesh is None:
        mesh = unreal.StaticMesh()
    options = unreal.GeometryScriptCopyMeshToAssetOptions()
    options.set_editor_property("enable_recompute_normals", False)
    options.set_editor_property("enable_remove_degenerates", False)
    options.set_editor_property("replace_materials", True)
    options.set_editor_property("new_materials", materials)
    options.set_editor_property(
        "generate_lightmap_u_vs", unreal.GeometryScriptGenerateLightmapUVOptions.DO_NOT_GENERATE_LIGHTMAP_U_VS)
    # No undo entry per promotion, and one build rather than two: the build settings below
    # trigger it.
    options.set_editor_property("emit_transaction", False)
    options.set_editor_property("defer_mesh_post_edit_change", True)
    _result, outcome = unreal.GeometryScript_AssetUtils.copy_mesh_to_static_mesh(
        source, mesh, options, unreal.GeometryScriptMeshWriteLOD(), True)
    if outcome != unreal.GeometryScriptOutcomePins.SUCCESS:
        return None

    editor = unreal.get_editor_subsystem(unreal.StaticMeshEditorSubsystem)
    settings = editor.get_lod_build_settings(mesh, 0)
    # Blender scenes are full of single planes; a one-sided distance field of a plane is empty.
    settings.set_editor_property("generate_distance_field_as_if_two_sided", True)
    settings.set_editor_property("recompute_normals", False)
    settings.set_editor_property("recompute_tangents", True)
    settings.set_editor_property("generate_lightmap_u_vs", False)
    editor.set_lod_build_settings(mesh, 0, settings)
    # Waits for the render data, which the editor builds asynchronously. Showing the stand-in
    # before then would leave a gap where the object was; the distance field and cards still
    # build in the background afterwards.
    if int(mesh.get_num_triangles(0)) <= 0:
        return None
    return mesh


def _set_dynamic_visible(actor, visible):
    try:
        actor.get_dynamic_mesh_component().set_visibility(bool(visible), False)
    except Exception:  # noqa: BLE001 - the actor may already be gone
        pass

