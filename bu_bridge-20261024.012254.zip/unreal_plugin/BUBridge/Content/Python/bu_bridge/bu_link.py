# SPDX-License-Identifier: GPL-3.0-or-later
"""The Unreal end of BU's real-time link.

Listens on a local socket and turns what Blender sends into live actors: one
`DynamicMeshActor` per Blender object, rebuilt whenever its mesh changes and moved whenever only
its transform does. No assets are created and no Level Sequence is involved — playback is
Blender evaluating a frame and sending the result.

Three decisions shape everything here:

* **All of it runs in an editor tick callback, on the game thread.** Unreal's API is not
  thread-safe, so the socket is non-blocking and each tick does a bounded amount of work —
  some reading, some applying — then returns. A mesh too large to apply inside a frame makes
  that frame long; it never blocks the editor waiting on the network.
* **Actors are transient.** They are a view of Blender's scene, not part of the level: they are
  never saved, never dirty the map, and vanish when the editor closes. Getting a scene *into*
  the level for keeps is still `import_scene`'s job.
* **State lives in module globals and the tick callback is a trampoline.** `bu_bridge.reload()`
  re-executes this module in place; globals that are not reassigned survive it, so a reload
  mid-session keeps the socket and the actors. The registered callback only looks the real tick
  function up by name, so it picks up reloaded code instead of pinning the old function.

Every Unreal API used was confirmed against the UE 5.8 source: `AppendBuffersToMesh` and
`FGeometryScriptSimpleMeshBuffers` (`MeshBasicEditFunctions.h`), `SpawnActorFromClass`'s
`bTransient` (`EditorActorSubsystem.h`), `ExportToDisk` for render targets
(`ImageWriteBlueprintLibrary.cpp`), and `register_slate_post_tick_callback` (`PySlate.cpp`).
Confirmed by reading, not yet by running — see NOTES.md.
"""

import array
import math
import os
import re
import socket
import sys
import tempfile
import time
import traceback

from . import (bu_link_cache, bu_link_drive, bu_link_editor, bu_link_environment, bu_link_export,
               bu_link_graph,
               bu_link_instances,
               bu_link_light, bu_link_material, bu_link_pace, bu_link_static, bu_link_wire,
               bu_names)

ACTOR_TAG = "BU_Live"
NAME_TAG_PREFIX = "BU_Live:"
ACTOR_FOLDER = "BU Live"

# Per-tick limits, in seconds. Reading is cheap and bounded by bytes as well; applying a mesh is
# the expensive part, so at least one message is always applied and then the budget decides.
READ_BUDGET = 0.008
APPLY_BUDGET = 0.025
READ_CHUNK = 1 << 20

# Frames. Blender follows each tick's changes with a "frame_end" message once all of them are on
# their way. Up to the newest one received, everything is applied at once (APPLY_BUDGET aside,
# to this limit), and no picture is rendered while a frame is half applied: a character's body
# and clothes are one frame, not two. An older Blender sends none, and nothing is held. A frame
# open longer than FRAME_WAIT (a big scene arriving) is shown as it fills.
FRAME_APPLY_LIMIT = 0.5
FRAME_WAIT = 0.5
# The messages that change the picture, and so belong to a frame.
SCENE_KINDS = frozenset(("mesh", "xf", "delete", "light", "volume", "mat", "matv",
                         "environment", "drive", "instances"))

# Measured in a live editor: render-to-file-complete is about 9 ms at 1188x836, and both the
# capture and the export return to the game thread in well under a millisecond. 60 is a cap on
# waste, not on what the pipeline can do.
CAPTURE_MIN_INTERVAL = 1.0 / 60.0
# With nothing changing, still refresh: lighting edits happen on the Unreal side and Blender
# cannot know about them.
CAPTURE_IDLE_INTERVAL = 0.2
VIEW_TIMEOUT = 3.0
CAPTURE_STALL = 2.0
# After a change, keep rendering at full rate this long. Lumen's denoisers and temporal AA clean
# up over consecutive frames; at the idle rate a changed picture took seconds to lose its noise
# where the editor viewport, rendering every frame, took a fraction of one.
CONVERGE_SECONDS = 1.0
# How often to look for live actors the link no longer owns: brought back by an undo from before
# it stopped recording undo steps, or copied by hand.
SWEEP_SECONDS = 2.0
FRAME_FILES = 4
# Display gamma of the capture target. An RTF_RGBA8 target reports sRGB but its TargetGamma of 0
# makes the tonemapper write linear values; 2.2 is what Unreal means by "sRGB" here.
TARGET_GAMMA = 2.2
# `BULinkLibrary.GetReadbackFeatures` bit: half-float targets are read as floats, not 8 bits.
READBACK_HALF_FLOAT = 1
# And: the readbacks write a ready word where Blender watches (their ReadyOffset). A picture is
# then announced as it begins, and Blender takes it the moment the render thread has copied it,
# not when this editor's next tick has noticed and its socket said so: 6-7 ms sooner.
READBACK_READY_SIGNAL = 2
# Kept free at the end of every frame slot for those words.
SLOT_READY_BYTES = 64


def ready_offsets(slot_bytes):
    """(the picture's, its depth's) ready word, bytes into a frame slot. Pure."""
    slot_bytes = int(slot_bytes)
    return slot_bytes - 8, slot_bytes - 4
# The depth picture sent with each frame when Blender asks (`"depth": true`), so Blender can draw
# the picture where a view that has moved on since would see it. The frame's own size: each
# pixel the nearest depth of its 3x3 neighbours (`BULinkLibrary.BeginDepthReadback`), so
# dithered glass is whole and an outline moves out by one pixel. A quarter (4x4 blocks) drew
# every outline in 4-pixel steps that crawled while the view moved, and a sixteenth trailed
# wedges off a figure; each grew with the block. See NOTES.
DEPTH_DIVISOR = 1
DEPTH_RENDER_DIVISOR = 1
# Everything a depth-only picture has no use for. The depth is the same without them; the render
# is not (lighting, Lumen and post-processing are most of a frame's cost).
DEPTH_FLAGS_OFF = (
    "PostProcessing", "Lighting", "GlobalIllumination", "LumenGlobalIllumination",
    "LumenReflections", "DynamicShadows", "AmbientOcclusion", "ScreenSpaceAO", "DistanceFieldAO",
    "ScreenSpaceReflections", "ReflectionEnvironment", "Translucency", "Fog", "VolumetricFog",
    "Atmosphere", "Cloud", "Bloom", "TemporalAA", "AntiAliasing", "MotionBlur", "SkyLighting",
    "ContactShadows", "CapsuleShadows", "LightShafts", "Decals", "Particles", "MegaLights",
    "EyeAdaptation", "LocalExposure",
)
# Post-process settings the capture overrides for a linear picture (`_linear_post`):
# (name, value for a linear picture, value when not overridden).
LINEAR_POST = (
    ("expand_gamut", 0.0, 1.0),
    ("local_exposure_highlight_contrast_scale", 1.0, 1.0),
    ("local_exposure_shadow_contrast_scale", 1.0, 1.0),
    ("local_exposure_detail_strength", 1.0, 1.0),
)
# The fixed exposure of a linear picture while Blender's Unreal Camera is off: one Blender unit
# of radiance, W/(m² sr), is 683 nits here (lights, sky and emission are all sent x 683), and
# with the physical camera off a pixel is nits x 2^bias. So -log2(683) hands Blender the values
# Cycles and EEVEE would, and its own Film exposure and view transform take it from there.
# Measured on a white floor under a 1 W/m² sun, and under 100 W point and spot lights: EEVEE
# 0.2546, 0.5046 and 0.5160; Unreal 0.264, 0.523 and 0.544 (its diffuse is a little brighter
# head on). Left on auto, Unreal's eye adaptation undid every change of a light's power.
LINEAR_EXPOSURE_BIAS = -math.log2(683.0)
# Overscan: the capture renders this much more on every side (a fraction of the view's width and
# height) and Blender's draw crops it back off. Screen traces, screen-space reflections and AO,
# contact shadows and temporal AA then have what lies just outside the frame to work with,
# instead of losing it at the edges. Capped so a careless value cannot multiply the render cost.
MAX_OVERSCAN = 0.5
MAX_FOV = 170.0
# How often the link's view is handed to texture streaming, and how long each lasts there.
STREAM_INTERVAL = 0.25
STREAM_SECONDS = 2.0
# `r.DynamicGlobalIlluminationMethod` and `r.ReflectionMethod` values -> the enum member names.
GI_METHODS = {0: "NONE", 1: "LUMEN", 2: "SCREEN_SPACE", 3: "PLUGIN"}
REFLECTION_METHODS = {0: "NONE", 1: "LUMEN", 2: "SCREEN_SPACE"}
# Must match `BULink::Version` in BULinkLibrary.cpp and `NATIVE_VERSION` in Blender's link_shm.
NATIVE_VERSION = 3
# UV maps a mesh may bring (the render one first, then the rest of Blender's): a decal or a
# lightmap UV in Blender is a texture coordinate index here. Said in the hello; Blender sends
# no more.
MAX_UV_CHANNELS = 4
# Console variables the link sets while it runs, and puts back when it stops.
#
# Lumen's radiance cache for translucency reflections painted smooth glass with a blotchy,
# crinkled picture of the room, four times as bright as glass of IOR 1.3 reflects (measured on a
# tester's café windows at night: glass 0.125 against 0.047 with no reflection at all). Without
# it the panes are clean, as in Blender. Not a material setting: Specular, IOR 1, front-layer
# reflections, ray-traced translucency, shadows and the reflection captures all left it as it was.
#
# Without it a translucent surface reflects nothing but the sky: Toy Freddy's glossy eye whites
# (a Blended material) were matte. Lumen's front-layer reflections give the nearest translucent
# surface the reflections an opaque one gets, as EEVEE does.
#
# Texture streaming judges what mips the picture needs from the editor's views; the link's
# capture got lower ones, and fine detail (Toy Freddy's scratches and grime, bump detail) came
# out softer than in Blender. Unreal is the renderer here: every texture in use is loaded whole.
LINK_CVARS = (("r.Lumen.TranslucencyReflections.RadianceCache", 0),
              ("r.Lumen.TranslucencyReflections.FrontLayer.Enable", 1),
              ("r.Streaming.FullyLoadUsedTextures", 1))
# Blender's Render properties -> Unreal. (Ray-traced shadows are each light's own choice now:
# bu_link_light.ray_traced_shadow.)
RENDER_GI = {"LUMEN": "LUMEN", "NONE": "NONE"}
RENDER_REFLECTIONS = {"LUMEN": "LUMEN", "SCREEN_SPACE": "SCREEN_SPACE", "NONE": "NONE"}
# Lumen's ray lighting (`ELumenRayLightingModeOverride`). The project default is the surface
# cache: what a ray hits is lit from a coarse card capture of the scene, which is what made the
# picture feel like screen-space effects. Hit lighting evaluates the material and lights there.
RENDER_RAY_LIGHTING = {"SURFACE_CACHE": "SURFACE_CACHE",
                       "HIT_REFLECTIONS": "HIT_LIGHTING_FOR_REFLECTIONS",
                       "HIT_LIGHTING": "HIT_LIGHTING"}
SCREEN_TRACE_CVARS = ("r.Lumen.ScreenProbeGather.ScreenTraces", "r.Lumen.Reflections.ScreenTraces")
# The capture's post-process settings Blender may set (Render properties > Lighting): name ->
# (type, lowest, highest). Anything else in a message is ignored. One not sent goes back to the
# project's own value, except the surface cache: Unreal halves it for scene captures, and this
# capture is the picture.
LUMEN_POST_SETTINGS = {
    "indirect_lighting_intensity": (float, 0.0, 100.0),
    "lumen_scene_detail": (float, 0.25, 16.0),
    "lumen_scene_lighting_quality": (float, 0.25, 16.0),
    "lumen_scene_view_distance": (float, 1.0, 2097152.0),
    "lumen_scene_lighting_update_speed": (float, 0.5, 16.0),
    "lumen_final_gather_quality": (float, 0.25, 16.0),
    "lumen_final_gather_lighting_update_speed": (float, 0.5, 16.0),
    "lumen_max_trace_distance": (float, 1.0, 2097152.0),
    "lumen_diffuse_color_boost": (float, 1.0, 4.0),
    "lumen_ambient_occlusion_intensity": (float, 0.0, 1.0),
    "lumen_skylight_leaking": (float, 0.0, 1.0),
    "lumen_full_skylight_leaking_distance": (float, 0.1, 100000.0),
    "lumen_surface_cache_resolution": (float, 0.5, 1.0),
    "lumen_reflection_quality": (float, 0.25, 16.0),
    "lumen_max_roughness_to_trace_reflections": (float, 0.0, 1.0),
    "lumen_max_reflection_bounces": (int, 1, 8),
    "lumen_max_refraction_bounces": (int, 0, 64),
}
LUMEN_POST_DEFAULTS = {"lumen_surface_cache_resolution": 1.0}
# Ambient occlusion beside Lumen's own (Blender: Render > Lighting > Ambient Occlusion). Lumen's
# short-range AO reads the screen out to two screen probes (32 pixels) and nothing more; these
# are the console variables Unreal offers beyond it (Renderer/Private/Lumen, 5.8):
#   SSAO: Unreal's classic screen-space AO in its place, with the post-process AO settings
#     (applied to Lumen's GI only while the short-range AO is off: `ShouldRenderAOWithLumenGI`);
#   extra: "for non-physically based art direction", occlusion from anything within a distance
#     of each screen probe, pow(saturate(hit distance / distance), exponent), on Lumen's GI.
# (ShortRangeAO.HardwareRayTracing was offered too, and dropped: it changed nothing measurable.)
AO_SHORT_RANGE_CVAR = "r.Lumen.ScreenProbeGather.ShortRangeAO"
AO_SSAO_CVAR = "r.Lumen.DiffuseIndirect.SSAO"
AO_EXTRA_CVAR = "r.Lumen.ScreenProbeGather.ExtraAmbientOcclusion"
AO_EXTRA_DISTANCE_CVAR = "r.Lumen.ScreenProbeGather.ExtraAmbientOcclusion.MaxDistanceWorldSpace"
AO_EXTRA_EXPONENT_CVAR = "r.Lumen.ScreenProbeGather.ExtraAmbientOcclusion.Exponent"
AO_CVARS = (AO_SHORT_RANGE_CVAR, AO_SSAO_CVAR, AO_EXTRA_CVAR, AO_EXTRA_DISTANCE_CVAR,
            AO_EXTRA_EXPONENT_CVAR)
# SSAO's post-process settings, sent with it; its radius is in world space (centimetres).
SSAO_POST_SETTINGS = {
    "ambient_occlusion_intensity": (float, 0.0, 1.0),
    "ambient_occlusion_radius": (float, 0.1, 100000.0),
    "ambient_occlusion_power": (float, 0.1, 8.0),
}
LIVE_DENOISE_CVAR = "r.PathTracing.TemporalDenoiser.mode"
DLSS_RR_CVAR = "r.NGX.DLSS.DenoiserMode"
# Unreal's own denoiser (NNE) runs Open Image Denoise's networks on the GPU; Balanced unless
# asked. The "Alpha" models, which also denoise the alpha channel, are the project default.
NNE_ASSET_CVAR = "NNEDenoiser.Asset"
NNE_QUALITY = {"FAST": 4, "HIGH": 6}
PATH_TRACING_POST_SETTINGS = {
    "path_tracing_samples_per_pixel": (int, 1, 65536),
    "path_tracing_max_bounces": (int, 0, 100),
    "path_tracing_enable_denoiser": (bool, None, None),
    "path_tracing_max_path_intensity": (float, 1.0, 65504.0),
    "path_tracing_enable_emissive_materials": (bool, None, None),
    "path_tracing_enable_reference_dof": (bool, None, None),
    "path_tracing_enable_reference_atmosphere": (bool, None, None),
}
NATIVE_ERRORS = {
    -1: "no mesh component", -2: "the shared memory could not be opened",
    -3: "the arrays run past the shared memory", -4: "bad counts or offset",
    -5: "a triangle index is out of range", -6: "OpenSubdiv refused its subdivision cage",
    -7: "it has no cage to move",
}


class WholeCageWanted(ValueError):
    """Positions came for a cage this mesh does not have: Blender is asked for all of it."""


class _State(object):
    def __init__(self, port):
        self.port = port
        self.cvars = {}          # console variable -> its value before the link set it
        self.screen_messages_off = False  # Unreal's on-screen warnings hidden (see _render)
        self.listener = None
        self.client = None
        self.decoder = None
        self.inbox = []
        self.outgoing = bytearray()
        self.handle = None
        self.actors = {}
        self.actor_materials = {}
        self.material_root = "/Game"
        self.material_index = None
        self.material_specs = {}
        self.live_materials = {}
        self.view = None
        self.view_time = 0.0
        self.view_dirty = False
        self.scene_dirty = False
        self.capture_actor = None
        self.target = None
        self.target_size = None
        self.target_linear = False
        self.depth_actor = None    # the second capture, for the depth picture
        self.depth_target = None
        self.depth_size = None
        self.post_linear = None    # (linear, fixed exposure) the capture's post-process is set for
        self.camera_post = False   # Blender's Unreal Camera owns exposure (BU's post volume)
        self.render = {}           # Blender's Render properties: gi, reflections, shadows
        self.light_shadows = {}    # light name -> (kind, its own Ray Traced Shadows choice)
        self.capture_busy = False
        self.capture_started = 0.0
        self.capture_last = 0.0
        self.settled = 0           # pictures since the view or scene last changed
        self.frame_applied = 0     # the id of the last of Blender's frames applied (frame_end)
        self.capture_callbacks = []
        self.frame_index = 0
        self.completed = []
        self.last_error = ""
        self.meshes_applied = 0
        self.meshes_cached = 0   # meshes that arrived identical to what their actor shows
        # Frames (see FRAME_WAIT): whether Blender marks them, and since when one is half applied.
        self.frames_marked = False
        self.frame_opened = None


try:
    _STATE  # noqa: B018 - survives importlib.reload on purpose
except NameError:
    _STATE = None

_TICKING = False

# Timings and the saved throttle setting. Kept apart from `_State` so that code reloaded into a
# running session can add to it: an existing `_State` instance only has the fields it was made
# with.
try:
    _PERF  # noqa: B018
except NameError:
    _PERF = {}
for _key, _default in (("throttle_previous", None), ("ticks", []), ("captures", []),
                       ("applies", []), ("phases", []), ("last_report", 0.0), ("skips", []),
                       ("holds", []), ("background", [])):
    _PERF.setdefault(_key, _default)

# Pictures on their way to Blender through shared memory. `readbacks` maps a token to the frame
# message waiting on the render thread; `busy_slots` maps a frame slot to when it was handed
# out, until Blender says it has copied the picture.
try:
    _NATIVE  # noqa: B018
except NameError:
    _NATIVE = {}
for _key, _default in (("readbacks", {}), ("busy_slots", {}), ("token", 0)):
    _NATIVE.setdefault(_key, _default)


def native_version():
    """The version of BU's native module in this editor, or 0 if the plugin has none.

    The plugin works without it — everything falls back to Python and files — so its absence
    is a slower link, not an error.
    """
    import unreal

    library = getattr(unreal, "BULinkLibrary", None)
    if library is None:
        return 0
    try:
        return int(library.get_link_version())
    except Exception:  # noqa: BLE001
        return 0


def _native():
    return native_version() == NATIVE_VERSION


def can_subdivide():
    """Whether this editor's native module subdivides Blender's cages (`ApplySubdivMesh`): told
    to Blender in the hello, which then sends an object ending in Subdivision Surface as its
    cage. Added without a version bump; the function's presence is the feature."""
    if not _native():
        return False
    import unreal

    return hasattr(unreal.BULinkLibrary, "apply_subdiv_mesh")


def can_move_cages():
    """Whether the native module takes a cage's positions alone (`ApplySubdivPositions`)."""
    if not can_subdivide():
        return False
    import unreal

    return hasattr(unreal.BULinkLibrary, "apply_subdiv_positions")


def positions_only(header):
    """Whether a cage message carries only positions, for the cage last sent whole. Pure."""
    subd = header.get("subd")
    return isinstance(subd, dict) and bool(subd.get("positions_only"))


def subdiv_args(header):
    """The counts and settings `ApplySubdivMesh` takes after the mapping and offset, from a
    cage message, or None if it is not one. Pure."""
    subd = header.get("subd")
    if not isinstance(subd, dict):
        return None
    try:
        return (int(subd.get("cage_vertices") or 0), int(subd.get("faces") or 0),
                int(subd.get("corners") or 0), uv_channels(header), bool(header.get("colors")),
                int(subd.get("crease_edges") or 0), int(subd.get("crease_vertices") or 0),
                int(subd.get("packed") or 0))
    except (TypeError, ValueError):
        return None


def subdiv_stats():
    """Cages still refining on workers and cages OpenSubdiv refused, for Blender's statistics."""
    if not can_subdivide():
        return {}
    import unreal

    found = getattr(unreal.BULinkLibrary, "get_subdiv_stats", None)
    if found is None:
        return {}
    stats = found()
    out = {"subdiv_pending": int(stats.x), "subdiv_kept": int(stats.y),
           "subdiv_refused": int(stats.z), "subdiv_builds": int(stats.w)}
    times = getattr(unreal.BULinkLibrary, "get_subdiv_times", None)
    if times is not None:
        out.update(subdiv_times(_SUBDIV_TIMES, times()))
    gpu = getattr(unreal.BULinkLibrary, "get_subdiv_gpu", None)
    if gpu is not None:
        found = gpu()
        sent = int(found.x)
        out["subdiv_gpu"] = sent - _SUBDIV_TIMES.get("gpu", sent)
        out["subdiv_gpu_on"] = bool(found.z)
        _SUBDIV_TIMES["gpu"] = sent
    return out


_SUBDIV_TIMES = {}


def subdiv_times(last, now):
    """Milliseconds a cage took to refine and to write, on average since the last report, from
    the native module's running totals (`GetSubdivTimes`). `last` keeps the totals. Pure."""
    totals = (float(now.x), float(now.y), float(now.z), float(now.w))
    before = last.get("totals", (0.0, 0.0, 0.0, 0.0))
    last["totals"] = totals
    shown = totals[2] - before[2]
    if shown <= 0:
        return {}
    return {"subdiv_eval_ms": round(1000.0 * (totals[0] - before[0]) / shown, 2),
            "subdiv_write_ms": round(1000.0 * (totals[1] - before[1]) / shown, 2),
            "subdiv_shown": int(shown),
            "subdiv_refined": int((totals[3] - before[3]) / shown)}


def _service_subdiv():
    """Show the cages whose subdivision finished on a worker. True if any was shown."""
    if not can_subdivide():
        return False
    import unreal

    return int(unreal.BULinkLibrary.service_subdiv()) > 0


def _reset_native():
    """Forget every shared mapping and picture in flight. Blender makes new ones per session."""
    _NATIVE["readbacks"].clear()
    _NATIVE["busy_slots"].clear()
    if _native():
        import unreal

        try:
            unreal.BULinkLibrary.close_all_mappings()
        except Exception:  # noqa: BLE001
            pass

THROTTLE_PROPERTY = "bThrottleCPUWhenNotForeground"
PERFORMANCE_SETTINGS = "/Script/UnrealEd.Default__EditorPerformanceSettings"
REPORT_SECONDS = 1.0


def _log(text):
    import unreal

    unreal.log("BU link: " + text)


def _warn(text):
    import unreal

    unreal.log_warning("BU link: " + text)


# -- lifecycle -----------------------------------------------------------------------------------

def _trampoline(delta_seconds):
    module = sys.modules.get(__name__)
    if module is not None:
        module._tick(delta_seconds)


def is_running():
    return _STATE is not None


def start(port=bu_link_wire.DEFAULT_PORT):
    """Begin listening for Blender. Safe to call when already running."""
    global _STATE
    import unreal

    port = int(port)
    if _STATE is not None:
        if _STATE.port == port:
            _log("already listening on port {0}".format(port))
            return True
        stop()

    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        # Loopback only: this channel creates and destroys actors, and has no authentication.
        listener.bind(("127.0.0.1", port))
        listener.listen(1)
        listener.setblocking(False)
    except OSError as exc:
        listener.close()
        raise RuntimeError(
            "BU link could not listen on port {0} ({1}). Another editor may already be using "
            "it; change the port in BU's Blender preferences.".format(port, exc))

    state = _State(port)
    state.listener = listener
    state.handle = unreal.register_slate_post_tick_callback(_trampoline)
    _set_cvars(state)
    _STATE = state
    _log("listening on 127.0.0.1:{0}".format(port))
    return True


def stop():
    """Stop listening and close the connection. Live actors are left in place."""
    global _STATE
    state, _STATE = _STATE, None
    if state is None:
        return
    import unreal

    if state.handle is not None:
        try:
            unreal.unregister_slate_post_tick_callback(state.handle)
        except Exception:  # noqa: BLE001
            pass
    for sock in (state.client, state.listener):
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass
    _destroy(state.capture_actor)
    _destroy(getattr(state, "depth_actor", None))
    _restore_cvars(state)
    if state.screen_messages_off:
        _console("EnableAllScreenMessages")
    try:
        bu_link_environment.restore_level()  # the level's own sky, fog and suns, shown again
    except Exception:  # noqa: BLE001
        pass
    _reset_native()
    _rethrottle()
    _log("stopped")


def _set_cvars(state):
    for name, value in LINK_CVARS:
        _set_cvar(state, name, value)


def _set_cvar(state, name, value):
    """Set a console variable for the link's lifetime; its old value comes back at stop."""
    import unreal

    try:
        if name not in state.cvars:
            # A float one read as an int would come back rounded (0.5 -> 0).
            read = (unreal.SystemLibrary.get_console_variable_float_value
                    if isinstance(value, float) else
                    unreal.SystemLibrary.get_console_variable_int_value)
            state.cvars[name] = read(name)
        unreal.SystemLibrary.execute_console_command(None, "{0} {1}".format(name, value))
    except Exception as exc:  # noqa: BLE001 - a missing variable is no reason not to link
        _warn("could not set {0}: {1}".format(name, exc))


def _restore_cvar(state, name):
    import unreal

    if name not in state.cvars:
        return
    value = state.cvars.pop(name)
    try:
        unreal.SystemLibrary.execute_console_command(None, "{0} {1}".format(name, value))
    except Exception:  # noqa: BLE001
        pass


def _restore_cvars(state):
    import unreal

    for name, value in state.cvars.items():
        try:
            unreal.SystemLibrary.execute_console_command(None, "{0} {1}".format(name, value))
        except Exception:  # noqa: BLE001
            pass
    state.cvars.clear()


def clear_cache():
    """Forget the cached static meshes (see `bu_link_static`); their files go at the next start."""
    bu_link_static.clear_cache()


def clear():
    """Remove every actor the link created, including ones from an earlier session."""
    removed = 0
    bu_link_static.reset()
    for actor in _tagged_actors().values():
        if _destroy(actor):
            removed += 1
    if _STATE is not None:
        _STATE.actors.clear()
        _STATE.actor_materials.clear()
        _STATE.scene_dirty = True
    return removed


# -- staying awake -------------------------------------------------------------------------------

def _unthrottle():
    """Stop the editor idling while Blender is connected. Idempotent.

    With "Use Less CPU when in Background" on — the default — an unfocused editor ticks **three
    times a second** (`UEditorEngine::GetMaxTickRate`) and stops rendering its viewports. The
    whole point of this link is to be used with Blender focused, so every mesh and every frame
    was arriving at 3 Hz however fast the code was. Measured: 3.0 ticks/s on, 120 off.

    The setting is changed in memory only, never saved, and put back when Blender disconnects.
    It is reached by its raw property name through the settings object, because the class is not
    exposed to Python by name.
    """
    if _PERF["throttle_previous"] is not None:
        return
    import unreal

    if not _PERF.get("power_throttling_off"):
        _PERF["power_throttling_off"] = True
        if power_throttling_off():
            _log("Windows' power throttling is off for this editor")
    try:
        settings = unreal.find_object(None, PERFORMANCE_SETTINGS)
        previous = bool(settings.get_editor_property(THROTTLE_PROPERTY))
        if previous:
            settings.set_editor_property(THROTTLE_PROPERTY, False)
            _log("'Use Less CPU when in Background' is off while Blender is connected")
        _PERF["throttle_previous"] = previous
    except Exception as exc:  # noqa: BLE001
        _PERF["throttle_previous"] = False  # do not retry every tick
        _warn("could not turn off background throttling ({0}); expect about 3 updates a second "
              "unless Unreal is the focused window. Editor Preferences > Performance > 'Use Less "
              "CPU when in Background'.".format(exc))


# SetProcessInformation's PROCESS_POWER_THROTTLING_STATE (Windows 10 1709 and later).
PROCESS_POWER_THROTTLING = 4
POWER_THROTTLING_EXECUTION_SPEED = 0x1
POWER_THROTTLING_IGNORE_TIMER_RESOLUTION = 0x4


def power_throttling_off():
    """Opt this editor out of Windows' power throttling ("EcoQoS"). True if Windows took it.

    Windows 11 slows a process none of whose windows the user is looking at: its threads go to
    the efficient cores at a low clock, and its timers are coarsened. BU's own editor has no
    window anyone looks at, and any editor feeding Blender is in the background whenever Blender
    is in front. Setting the control bits with a state of 0 says "never throttle", for the life
    of the process.
    """
    if sys.platform != "win32":
        return False
    import ctypes

    class State(ctypes.Structure):
        _fields_ = [("version", ctypes.c_ulong), ("control_mask", ctypes.c_ulong),
                    ("state_mask", ctypes.c_ulong)]

    mask = POWER_THROTTLING_EXECUTION_SPEED | POWER_THROTTLING_IGNORE_TIMER_RESOLUTION
    state = State(1, mask, 0)
    try:
        kernel = ctypes.windll.kernel32
        kernel.GetCurrentProcess.restype = ctypes.c_void_p
        kernel.SetProcessInformation.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p,
                                                 ctypes.c_ulong]
        done = kernel.SetProcessInformation(kernel.GetCurrentProcess(), PROCESS_POWER_THROTTLING,
                                            ctypes.byref(state), ctypes.sizeof(state))
        if not done:
            # Older Windows knows only the execution-speed bit.
            state.control_mask = POWER_THROTTLING_EXECUTION_SPEED
            done = kernel.SetProcessInformation(kernel.GetCurrentProcess(),
                                                PROCESS_POWER_THROTTLING, ctypes.byref(state),
                                                ctypes.sizeof(state))
        return bool(done)
    except (AttributeError, OSError):
        return False


def _rethrottle():
    previous, _PERF["throttle_previous"] = _PERF["throttle_previous"], None
    if not previous:
        return
    import unreal

    try:
        unreal.find_object(None, PERFORMANCE_SETTINGS).set_editor_property(THROTTLE_PROPERTY, True)
        _log("'Use Less CPU when in Background' restored")
    except Exception:  # noqa: BLE001
        pass


def _mean(values):
    return sum(values) / len(values) if values else 0.0


def summarise(perf, now, window=2.0):
    """Recent timings as plain numbers: what Blender's panel shows. Pure, so it is testable."""
    ticks = [t for t in perf["ticks"] if now - t <= window]
    captures = [c for c in perf["captures"] if now - c["at"] <= window]
    written = [c for c in captures if c.get("written") is not None]
    applies = [a for a in perf["applies"] if now - a["at"] <= window]
    span = (ticks[-1] - ticks[0]) if len(ticks) > 1 else 0.0
    found = {
        "tick_hz": round((len(ticks) - 1) / span, 1) if span > 0 else 0.0,
        "frame_hz": round(len(written) / window, 1),
        "render_ms": round(_mean([c["render"] for c in captures]) * 1000, 1),
        "readback_ms": round(_mean([c["export"] for c in captures]) * 1000, 1),
        "write_ms": round(_mean([c["written"] for c in written]) * 1000, 1),
        "apply_ms": round(_mean([a["seconds"] for a in applies]) * 1000, 1),
        "apply_worst_ms": round(max([a["seconds"] for a in applies] or [0.0]) * 1000, 1),
        "applies": len(applies),
        # Deforming meshes written straight into their render buffers (the native fast path).
        "applies_direct": sum(1 for a in applies if a.get("path") == 3),
    }
    # Why ticks with a view rendered no picture, and how long Blender kept a slot.
    for at, reason in perf.get("skips", ()):
        if now - at <= window:
            key = "skip_" + reason
            found[key] = found.get(key, 0) + 1
    parts = [b for b in perf.get("background", ()) if now - b[0] <= window]
    if parts:
        for index, key in enumerate(("bg_textures_ms", "bg_graphs_ms", "bg_standins_ms",
                                     "bg_sweep_ms")):
            found[key] = round(_mean([b[index + 1] for b in parts]) * 1000, 1)
    holds = [h for at, h in perf.get("holds", ()) if now - at <= window]
    if holds:
        found["slot_hold_ms"] = round(_mean(holds) * 1000, 1)
    phases = [p for p in perf.get("phases", ()) if now - p[0] <= window]
    if phases:
        found["scene_ms"] = round(_mean([p[1] for p in phases]) * 1000, 1)
        found["capture_ms"] = round(_mean([p[2] for p in phases]) * 1000, 1)
        found["background_ms"] = round(_mean([p[3] for p in phases]) * 1000, 1)
    # Where the pictures' time went in the native module (frame_timings), over the window.
    timed = [c for c in written if c.get("gpu_wait_ms") is not None]
    if timed:
        for key in ("render_thread_ms", "gpu_wait_ms", "copy_ms"):
            found[key] = round(_mean([c[key] for c in timed]), 1)
    return found


def frame_timings():
    """Where the last picture's time went in the native module, in ms: waiting for the render
    thread (its work on the scene), for the GPU, and copying. Empty without the module."""
    import unreal

    library = getattr(unreal, "BULinkLibrary", None)
    if library is None or not hasattr(library, "get_readback_timings"):
        return {}
    try:
        found = library.get_readback_timings()
        return {"render_thread_ms": round(float(found.x), 1),
                "gpu_wait_ms": round(float(found.y), 1), "copy_ms": round(float(found.z), 1)}
    except Exception:  # noqa: BLE001 - an older module, or one that cannot say
        return {}


def scene_counts(state):
    """What Unreal draws for Blender: live actors (meshes, lights, fog volumes), and the live
    meshes still drawn as dynamic meshes rather than by a static stand-in."""
    import unreal

    dynamic = getattr(unreal, "DynamicMeshActor", None)
    shown = sum(1 for name, actor in list(state.actors.items())
                if dynamic is not None and isinstance(actor, dynamic)
                and not bu_link_static.has_standin(name))
    return {"live_actors": len(state.actors), "dynamic_shown": shown}


def streaming_memory():
    """Texture streaming's pool, the memory the textures in view want, and the shortfall, in
    MB ({} without the native module). Short, textures stay at blurrier mips to fit."""
    import unreal

    library = getattr(unreal, "BULinkLibrary", None)
    if library is None or not hasattr(library, "get_streaming_memory"):
        return {}
    try:
        found = library.get_streaming_memory()
        return {"streaming_pool_mb": round(float(found.x)),
                "streaming_wanted_mb": round(float(found.y)),
                "streaming_short_mb": round(float(found.z))}
    except Exception:  # noqa: BLE001 - an older module, or one that cannot say
        return {}


def stats():
    """Recent timings, for the Python console."""
    return summarise(_PERF, time.perf_counter())


def still_loading():
    """What Unreal is still loading that a still (F12) waits for: textures and node materials
    queued, and shaders compiling (grey until done). Not texture streaming held short of memory,
    which waiting does not fix. As Blender's `link_view.still_loading` reads it from the stats."""
    shaders = bu_link_pace.compiles_left("get_shader_jobs_remaining") or 0
    return bu_link_material.textures_waiting() + bu_link_graph.waiting() + shaders


def _report(state, now):
    _PERF["ticks"].append(now)
    del _PERF["ticks"][:-600]
    if now - _PERF["last_report"] < REPORT_SECONDS:
        return
    _PERF["last_report"] = now
    del _PERF["captures"][:-200]
    del _PERF["applies"][:-200]
    message = summarise(_PERF, now)
    message.update(bu_link_static.counts(), kept=state.meshes_cached,
                   textures_waiting=bu_link_material.textures_waiting(),
                   textures_held=bu_link_material.textures_held(),
                   graphs_waiting=bu_link_graph.waiting(), graphs_held=bu_link_graph.held())
    message.update(bu_link_material.textures_report())
    # For Blender's "still loading" note: shaders still compiling (materials show grey until
    # then), and texture streaming short of memory (textures held blurrier to fit).
    shaders = bu_link_pace.compiles_left("get_shader_jobs_remaining")
    if shaders is not None:
        message["shaders_left"] = shaders
    message.update(streaming_memory())
    message.update(subdiv_stats())
    message.update(scene_counts(state))
    if os.environ.get("BU_CHECK_GPU"):
        message["subdiv_gpu_check"] = _check_subdiv_gpu(state)
    for key, value in frame_timings().items():
        message.setdefault(key, value)  # the last picture's, when the window had none timed
    message["type"] = "stats"
    _queue(state, message)


def _check_subdiv_gpu(state):
    """For tests (BU_CHECK_GPU set in the editor's environment): each mesh whose last frame was
    refined on the GPU, against the same frame refined on the CPU (`CheckSubdivGPU`)."""
    import unreal

    check = getattr(unreal.BULinkLibrary, "check_subdiv_gpu", None)
    found = {}
    for name, actor in list(state.actors.items()):
        try:
            result = check(actor.get_dynamic_mesh_component()) if check else None
        except Exception:  # noqa: BLE001 - not a mesh actor
            continue
        if result is not None and result.z >= 0:
            found[name] = [round(float(result.x), 6), round(float(result.y), 4), int(result.z),
                           round(float(result.w), 6)]
    return found


# -- the tick ------------------------------------------------------------------------------------

def _tick(_delta_seconds):
    global _TICKING
    state = _STATE
    if state is None or _TICKING:
        return
    # Importing a texture pumps Slate, which calls this tick again from inside the material
    # being applied. The nested tick would apply newer messages from the same inbox first, and
    # the older one, finishing last, would win: a stale material on screen.
    _TICKING = True
    try:
        _tick_once(state)
    finally:
        _TICKING = False


def _guarded(state, step, *args):
    """Run one part of the tick; an error is reported (once per message) and the rest of the
    tick still runs. One part raising every tick used to skip everything after it, capture and
    replies included: Unreal applied Blender's meshes but sent nothing back, and the picture
    stopped for good."""
    try:
        return step(*args)
    except Exception as exc:  # noqa: BLE001 - a raising tick callback would spam every frame
        message = "{0}: {1}".format(type(exc).__name__, exc)
        if message != state.last_error:
            state.last_error = message
            # Where it happened, in the log only: a bare "MemoryError:" says nothing about which
            # message or step ran out.
            _warn(message + "\n" + "".join(traceback.format_exception(*sys.exc_info())))
            _queue(state, {"type": "log", "level": "error", "text": message})
        return None


def _scene_step(state):
    _apply(state)
    if _service_subdiv():
        state.scene_dirty = True
    now = time.perf_counter()
    if bu_link_drive.settle(now):
        state.scene_dirty = True
    missing = bu_link_drive.gone(now)
    if missing:
        _queue(state, {"type": "gone", "paths": missing})


def _background_step(state):
    """Work Unreal finishes in the background, after the picture and the replies: a texture
    import or a material compile here took seconds, and the frame Blender waited on waited too."""
    now = time.perf_counter()
    # One texture, and one material built from Blender's nodes, at a time (bu_link_pace): all
    # of a big scene's at once ran Windows out of memory.
    if bu_link_material.service_textures(now):
        state.scene_dirty = True
    textured = time.perf_counter()
    if bu_link_graph.service(now):
        _wear_built_graphs(state, bu_link_graph.take_built())
    graphed = time.perf_counter()
    # Stand-ins are built and saved only once those are in: all three are work Unreal
    # finishes in the background, and a first load is when memory is short.
    if (not bu_link_material.textures_waiting() and not bu_link_graph.waiting()
            and bu_link_static.service(lambda name: _live_actor(state, name), ACTOR_FOLDER)):
        state.scene_dirty = True
    # Textures made this session are saved one at a time once Unreal is idle (none queued, its
    # build done), so the next session finds them without decoding again.
    if not bu_link_material.textures_waiting() and not bu_link_graph.waiting():
        if not bu_link_material.service_saves():
            bu_link_graph.service_saves()
    stood = time.perf_counter()
    _sweep(state, stood)
    # Which of them the background time went to (`summarise`: bg_*_ms).
    _PERF["background"].append((stood, textured - now, graphed - textured, stood - graphed,
                                time.perf_counter() - stood))
    del _PERF["background"][:-600]


def _tick_once(state):
    if state.client is None:
        _guarded(state, _accept, state)
        return
    _guarded(state, _unthrottle)
    _guarded(state, _read, state)
    if state.client is None:
        return  # the read found Blender gone
    # While the user holds an undoable edit open, any actor the link created or removed would
    # become part of their undo step. Messages wait; Blender keeps coalescing.
    scene_open = not ((state.inbox or bu_link_static.pending())
                      and _guarded(state, bu_link_editor.transaction_open))
    began = time.perf_counter()
    if scene_open:
        _guarded(state, _scene_step, state)
        _guarded(state, _flush, state)  # "frame_done" now: Blender starts on its next frame
    applied = time.perf_counter()
    _guarded(state, _poll_shared_frames, state)
    _guarded(state, _service_capture, state)
    captured = time.perf_counter()
    if scene_open:
        _guarded(state, _background_step, state)
    done = time.perf_counter()
    # Where the tick's own time goes (the editor's frame around it is the rest of 1/tick_hz).
    _PERF["phases"].append((done, applied - began, captured - applied, done - captured))
    del _PERF["phases"][:-600]
    if state.client is not None:
        _guarded(state, _report, state, time.perf_counter())
    _guarded(state, _flush, state)


def _accept(state):
    try:
        client, _address = state.listener.accept()
    except (BlockingIOError, InterruptedError):
        return
    client.setblocking(False)
    try:
        client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    except OSError:
        pass
    state.client = client
    state.decoder = bu_link_wire.Decoder()
    state.inbox = []
    state.outgoing = bytearray()
    state.last_error = ""
    state.frame_applied = 0  # this Blender numbers its frames from 1 again
    _log("Blender connected")


def _disconnect(state, reason):
    if state.client is not None:
        try:
            state.client.close()
        except OSError:
            pass
    state.client = None
    state.decoder = None
    state.inbox = []
    state.view = None
    state.capture_busy = False
    bu_link_drive.settle(float("inf"))  # a drag cut short still gets its undo step
    bu_link_material.forget_waiting()
    bu_link_material.save_textures()
    bu_link_graph.forget_waiting()
    bu_link_graph.save_materials()
    bu_link_cache.save_index()
    _reset_native()
    _rethrottle()
    _log("Blender disconnected ({0})".format(reason))


def _read(state):
    deadline = time.perf_counter() + READ_BUDGET
    while state.client is not None:
        try:
            data = state.client.recv(READ_CHUNK)
        except (BlockingIOError, InterruptedError):
            return
        except OSError as exc:
            _disconnect(state, str(exc))
            return
        if not data:
            _disconnect(state, "closed")
            return
        try:
            arrived = state.decoder.feed(data)
        except bu_link_wire.WireError as exc:
            _disconnect(state, str(exc))
            return
        for header, blob in arrived:
            if header.get("type") in CONTROL_KINDS:
                # At once, not behind the meshes: queued, a viewport's keep-alive waited behind
                # megabytes of a heavy frame until Unreal decided nobody was looking and stopped
                # drawing, and a picture slot was not handed back.
                _dispatch(state, header, blob)
            else:
                state.inbox.append((header, blob))
        if time.perf_counter() >= deadline:
            return


def superseded(messages):
    """Drop every mesh/transform/view message that a later one in the same batch replaces.

    Blender coalesces before sending, but several versions of one object can still land in a
    single tick when a frame runs long. Building a mesh only to rebuild it is the most
    expensive mistake available here.
    """
    newest = {}
    for index, (header, _blob) in enumerate(messages):
        kind = header.get("type")
        if kind in ("mesh", "delete", "instances"):
            newest[("object", header.get("name"))] = index
        elif kind == "xf":
            newest[("xf", header.get("name"))] = index
        elif kind == "mat":
            newest[("mat", header.get("name"))] = index
        elif kind == "view":
            newest[("view", None)] = index
        elif kind == "environment":
            newest[("environment", None)] = index
        elif kind == "drive":
            newest[("drive", header.get("path"))] = index

    kept = []
    for index, (header, blob) in enumerate(messages):
        kind = header.get("type")
        if kind in ("mesh", "delete", "instances"):
            key = ("object", header.get("name"))
        elif kind == "xf":
            key = ("xf", header.get("name"))
            # A transform older than a mesh for the same object is already inside that mesh.
            if newest.get(("object", header.get("name")), -1) > index:
                continue
        elif kind == "mat":
            key = ("mat", header.get("name"))
        elif kind == "view":
            key = ("view", None)
        elif kind == "environment":
            key = ("environment", None)
        elif kind == "drive":
            key = ("drive", header.get("path"))
        else:
            kept.append((header, blob))
            continue
        if newest[key] == index:
            kept.append((header, blob))
    return kept


def frame_end(messages):
    """The index of the last "frame_end" message, or -1. Pure."""
    for index in range(len(messages) - 1, -1, -1):
        if messages[index][0].get("type") == "frame_end":
            return index
    return -1


def frame_held(frames_marked, frame_opened, now, wait=None):
    """True while a picture would show a frame half applied. Pure."""
    wait = FRAME_WAIT if wait is None else wait
    return bool(frames_marked) and frame_opened is not None and now - frame_opened < wait


def tail_waits(frames_marked, through, count, since, now, wait=None):
    """Whether the messages after the last whole frame wait for their "frame_end", and since
    when they have. Returns (wait, since). Pure.

    Applied as they came, the next frame's first messages left the scene half a frame on at the
    end of most ticks, and no picture could be rendered then: Ennard's Unreal rendered on 21 of
    97 ticks, waiting on 56. They wait instead, up to FRAME_WAIT (a big scene arriving is shown
    as it fills). An older Blender marks no frames, and nothing waits.
    """
    wait = FRAME_WAIT if wait is None else wait
    if not frames_marked or through >= count - 1:
        return False, None
    since = now if since is None else since
    return now - since < wait, since


def _apply(state):
    if not state.inbox:
        state.tail_since = None
        return
    started = time.perf_counter()
    through = frame_end(state.inbox)
    holding, state.tail_since = tail_waits(
        getattr(state, "frames_marked", False), through, len(state.inbox),
        getattr(state, "tail_since", None), started)
    if holding:
        # Only the whole frames are thinned: a message of the frame still arriving must not
        # replace one in the frame about to be shown.
        head = superseded(state.inbox[:through + 1])
        state.inbox = head + state.inbox[through + 1:]
        through = len(head) - 1
    else:
        state.inbox = superseded(state.inbox)
        through = frame_end(state.inbox)
    deadline = started + APPLY_BUDGET
    applied = 0
    while state.inbox:
        if holding and applied > through:
            break
        header, blob = state.inbox.pop(0)
        _dispatch(state, header, blob)
        applied += 1
        now = time.perf_counter()
        if now - started >= FRAME_APPLY_LIMIT:
            break
        if applied > through and now >= deadline:
            break


# Messages handled as soon as they are read (`_read`): they say nothing about the scene.
CONTROL_KINDS = frozenset(("view", "frame_ack"))


def _dispatch(state, header, blob):
    kind = header.get("type")
    if kind in SCENE_KINDS:
        if getattr(state, "frames_marked", False) and getattr(state, "frame_opened", None) is None:
            state.frame_opened = time.perf_counter()
    if kind == "frame_end":
        state.frames_marked = True
        state.frame_opened = None
        try:
            state.frame_applied = int(header.get("id") or 0)
        except (TypeError, ValueError):
            pass
        # Blender sends its next frame only once it hears this (FRAMES_AHEAD in link.py).
        _queue(state, {"type": "frame_done", "id": header.get("id")})
    elif kind == "mesh":
        try:
            _apply_mesh(state, header, blob)
        except WholeCageWanted:
            # Its tables went with an actor removed meanwhile, say: Blender sends it all again.
            _queue(state, {"type": "resend", "name": header.get("name") or ""})
    elif kind == "instances":
        _apply_instances(state, header, blob)
    elif kind == "xf":
        actor = _live_actor(state, header.get("name"))
        if actor is not None:
            actor.set_actor_transform(_transform(header["matrix"]), False, False)
            state.scene_dirty = True
    elif kind == "delete":
        _remove(state, header.get("name"))
    elif kind == "keep":
        # Blender's first word after a hello: the objects it has. Anything else adopted from an
        # earlier connection belongs to no scene Blender has open now.
        names = set(header.get("names") or ())
        for name in [n for n in state.actors if n not in names]:
            _remove(state, name)
    elif kind == "mat":
        _apply_material(state, header)
    elif kind == "matv":
        _apply_material_values(state, header)
    elif kind == "light":
        _apply_light(state, header)
    elif kind == "export":
        # Blender's "Import from Unreal": write the actors to a glTF for it to import.
        reply = bu_link_export.export(
            header, (ACTOR_TAG, bu_link_static.TAG, bu_link_environment.TAG))
        _log("exported {0} actor(s) for Blender{1}".format(
            reply.get("count", 0), ": " + reply["error"] if reply.get("error") else ""))
        _queue(state, reply)
    elif kind == "drive":
        # An object imported into Blender, moved there: move the actor it came from.
        path = str(header.get("path") or "")
        if bu_link_drive.drive(path, _transform(header["matrix"]), time.perf_counter()):
            state.scene_dirty = True
        else:
            _queue(state, {"type": "gone", "paths": [path]})
    elif kind == "watch":
        bu_link_drive.watch(header.get("paths"))
    elif kind == "environment":
        changed = bu_link_environment.apply(header)
        _apply_render(state, header.get("render") or {})
        state.camera_post = bool(header.get("post"))
        state.scene_dirty = True
        _log("sky, fog and camera: {0}".format(", ".join(changed) or "nothing of BU's"))
    elif kind == "volume":
        _apply_volume(state, header)
    elif kind == "list_assets":
        kind_asked = str(header.get("kind") or "")
        _queue(state, {"type": "assets", "kind": kind_asked,
                       "paths": bu_link_material.project_assets(kind_asked)})
    elif kind == "list_materials":
        # For Blender's "Use Unreal Material": the project's own materials to pick from.
        _queue(state, {"type": "materials", "paths": bu_link_material.project_materials()})
    elif kind == "sync":
        # Messages are handled in order, so answering this one says every mesh before it has
        # been read out of shared memory and Blender may write over them.
        _queue(state, {"type": "synced", "id": header.get("id")})
    elif kind == "frame_ack":
        taken = _NATIVE["busy_slots"].pop(int(header.get("slot") or 0), None)
        if taken is not None:
            now = time.perf_counter()
            _PERF["holds"].append((now, now - taken))
            del _PERF["holds"][:-200]
    elif kind == "view":
        # Blender sends its view again every second only to say it is still looking. Taken as a
        # change, each kept Unreal rendering at full rate (CONVERGE_SECONDS) for good.
        if header != state.view:
            state.view_dirty = True
        state.view = header
        state.view_time = time.perf_counter()
    elif kind == "hello":
        _hello(state, header)


def _remove(state, name):
    bu_link_static.forget(name)
    _destroy(state.actors.pop(name, None))
    state.actor_materials.pop(name, None)
    instancing = _instancing(state)
    for table in instancing.values():
        table.pop(name, None)
    state.scene_dirty = True


def _instancing(state):
    """The link's instance bookkeeping (`bu_link_instances`), made on first use: a `_State` from
    before a reload has none."""
    found = getattr(state, "instancing", None)
    if found is None:
        found = state.instancing = {
            "meshes": {},     # prototype name -> its static mesh
            "digests": {},    # prototype name -> the digest that static mesh was built from
            "materials": {},  # prototype name -> its materials, by Blender name
            "uses": {},       # instances actor name -> prototype name
            "waiting": {},    # instances actor name -> (header, blob) until its prototype is built
        }
    return found


def _apply_instances(state, header, blob):
    """Show an instancer's copies of one prototype: an actor with one Instanced Static Mesh."""
    import unreal

    name = header.get("name") or ""
    proto = header.get("proto") or ""
    if not name:
        return
    instancing = _instancing(state)
    mesh = instancing["meshes"].get(proto)
    if mesh is None:
        # The prototype has no triangles, or is still to come: shown when it is built.
        instancing["waiting"][name] = (header, blob)
        return
    instancing["waiting"].pop(name, None)
    actor = _live_actor(state, name)
    found = bu_link_instances.component(actor) if actor is not None else None
    if actor is not None and found is None:
        _remove(state, name)  # a mesh of that name before
        actor = None
    if actor is None:
        actor = _spawn(state, name, unreal.Actor)
        if actor is None:
            raise RuntimeError("could not spawn an actor for '{0}'".format(name))
        found = bu_link_instances.add_component(actor)
        if found is None:
            _remove(state, name)
            raise RuntimeError("could not give '{0}' an instanced mesh".format(name))
    materials = tuple(instancing["materials"].get(proto) or ("",))
    xforms = bu_link_instances.transforms(blob, int(header.get("count") or 0))
    bu_link_instances.dress(found, mesh, [_find_material(state, m) for m in materials], xforms)
    bu_link_editor.show_to_camera(found, header.get("camera", True) is not False,
                                  header.get("shadow", True) is not False)
    instancing["uses"][name] = proto
    state.actor_materials[name] = materials
    state.instances_applied = getattr(state, "instances_applied", 0) + len(xforms)
    state.scene_dirty = True


def _built_proto(state, name, component, digest, materials):
    """A prototype mesh arrived: build its static mesh, and show everything waiting on it."""
    instancing = _instancing(state)
    instancing["materials"][name] = materials
    if instancing["digests"].get(name) != digest or name not in instancing["meshes"]:
        mesh = bu_link_instances.build_proto(component, digest)
        instancing["digests"][name] = digest
        if mesh is None:
            instancing["meshes"].pop(name, None)
        else:
            instancing["meshes"][name] = mesh
    mesh = instancing["meshes"].get(name)
    if mesh is None:
        return
    for actor_name, proto in list(instancing["uses"].items()):
        if proto != name:
            continue
        actor = _live_actor(state, actor_name)
        found = bu_link_instances.component(actor) if actor is not None else None
        if found is not None:
            if found.get_editor_property("static_mesh") != mesh:
                found.set_static_mesh(mesh)
            bu_link_instances.wear(found, [_find_material(state, m) for m in materials])
            state.actor_materials[actor_name] = materials
    for actor_name, (header, blob) in list(instancing["waiting"].items()):
        if header.get("proto") == name:
            _apply_instances(state, header, blob)


def _wear(actor, materials):
    """Put materials on a link actor, whatever draws it."""
    try:
        dynamic = actor.get_dynamic_mesh_component()
    except AttributeError:
        dynamic = None
    if dynamic is not None:
        dynamic.configure_material_set(materials)
        return
    found = bu_link_instances.component(actor)
    if found is not None:
        bu_link_instances.wear(found, materials)


def _flush(state):
    for message in state.completed:
        _queue(state, message)
    state.completed = []
    if not state.outgoing or state.client is None:
        return
    try:
        sent = state.client.send(state.outgoing)
    except (BlockingIOError, InterruptedError):
        return
    except OSError as exc:
        _disconnect(state, str(exc))
        return
    del state.outgoing[:sent]


def _queue(state, header, blob=b""):
    if state.client is not None:
        state.outgoing += bu_link_wire.pack(header, blob)


# -- messages ------------------------------------------------------------------------------------

def _hello(state, header):
    import unreal

    if header.get("material_root"):
        state.material_root = str(header["material_root"])
        state.material_index = None

    # Adopt whatever an earlier session left behind, so reconnecting updates those actors rather
    # than stacking a second copy of the scene on top of them — and, when Blender's digest says
    # an object is unchanged, keeps its geometry and static stand-in as they are.
    state.actors = _tagged_actors()
    if header.get("clear"):
        bu_link_static.reset(list(state.actors.values()))
    else:
        bu_link_static.adopt(state.actors)
    state.actor_materials = {}
    # Blender describes every material again after a hello, so nothing here is worth keeping.
    state.material_specs = {}
    state.live_materials = {}
    state.material_kinds = {}
    if header.get("clear"):
        for actor in state.actors.values():
            _destroy(actor)
        state.actors = {}
    state.adopted = True  # from here on, a tagged actor the link does not own is a stray
    state.scene_dirty = True

    project = ""
    try:
        project = os.path.splitext(os.path.basename(unreal.Paths.get_project_file_path()))[0]
    except Exception:  # noqa: BLE001
        pass
    native = native_version()
    _queue(state, {"type": "hello", "project": project,
                   "native": native if native == NATIVE_VERSION else 0,
                   "uv_channels": MAX_UV_CHANNELS, "upscalers": upscalers(),
                   "subdiv": 1 if can_subdivide() else 0,
                   "subdiv_positions": 1 if can_move_cages() else 0, "material_values": 1})


def decode_mesh(header, blob):
    """Split a mesh message's blob into per-material groups of plain number arrays.

    Returns a list of `{"slot", "positions", "normals", "uvs", "triangles"}` where each value is
    an `array.array` — floats flat, in the order Blender wrote them. Raises ValueError if the
    blob does not match what the header promises, so a truncated mesh never reaches the engine.
    """
    groups = []
    offset = 0
    channels = uv_channels(header)

    def take(typecode, count):
        nonlocal offset
        values = array.array(typecode)
        size = values.itemsize * count
        if offset + size > len(blob):
            raise ValueError("mesh '{0}' is truncated".format(header.get("name")))
        values.frombytes(blob[offset:offset + size])
        if sys.byteorder != "little":
            values.byteswap()
        offset += size
        return values

    for group in header.get("groups") or []:
        corners = int(group["corners"])
        triangles = int(group["triangles"])
        groups.append({
            "slot": int(group.get("slot", 0)),
            "positions": take("f", corners * 3),
            "normals": take("f", corners * 3),
            "uvs": [take("f", corners * 2) for _ in range(channels)] or None,
            "triangles": take("i", triangles * 3),
        })
    if offset != len(blob):
        raise ValueError("mesh '{0}' has {1} unexpected trailing bytes".format(
            header.get("name"), len(blob) - offset))
    return groups


def _apply_mesh(state, header, blob):
    import unreal

    name = header.get("name") or ""
    started = time.perf_counter()
    shared = header.get("shm")
    groups = [] if shared else decode_mesh(header, blob)

    actor = _live_actor(state, name)
    if actor is not None and (_is_light(actor) or _class_name(actor) == "LocalFogVolume"):
        _remove(state, name)  # a light or fog volume in Blender that has become a mesh
        actor = None
    fresh = actor is None
    if fresh:
        actor = _spawn(state, name)
        if actor is None:
            raise RuntimeError("could not spawn an actor for '{0}'".format(name))

    component = actor.get_dynamic_mesh_component()
    digest = mesh_digest(header, blob, component)
    proto = bool(header.get("proto"))
    path = 0  # how the native module took it: 1 rebuilt, 2 moved in place, 3 written straight in
    if proto and not fresh and _instancing(state)["digests"].get(name) == digest:
        groups = []  # the same prototype again: its static mesh stands
        state.meshes_cached += 1
    elif proto:
        if shared:
            path = _apply_shared_mesh(component, header, shared)
        else:
            mesh = component.get_dynamic_mesh()
            mesh.reset()
    elif not fresh and bu_link_static.shows(name, digest):
        # Identical to what the actor already shows — sent again after a reconnect, a material
        # change or a frame that did not move it: nothing to rebuild, and a stand-in stays put.
        groups = []
        state.meshes_cached += 1
    else:
        bu_link_static.note_changed(name, header.get("triangles"), actor, digest=digest)
        if shared:
            path = _apply_shared_mesh(component, header, shared)
        else:
            mesh = component.get_dynamic_mesh()
            mesh.reset()

    for index, group in enumerate(groups):
        positions, normals, uvs, triangles = (
            group["positions"], group["normals"], group["uvs"], group["triangles"])
        buffers = unreal.GeometryScriptSimpleMeshBuffers()
        buffers.set_editor_property("vertices", [
            unreal.Vector(positions[i], positions[i + 1], positions[i + 2])
            for i in range(0, len(positions), 3)])
        buffers.set_editor_property("normals", [
            unreal.Vector(normals[i], normals[i + 1], normals[i + 2])
            for i in range(0, len(normals), 3)])
        for channel, values in enumerate(uvs or ()):
            buffers.set_editor_property("uv{0}".format(channel), [
                unreal.Vector2D(values[i], values[i + 1]) for i in range(0, len(values), 2)])
        buffers.set_editor_property("triangles", [
            unreal.IntVector(triangles[i], triangles[i + 1], triangles[i + 2])
            for i in range(0, len(triangles), 3)])
        # Defer the component rebuild until the last group, so a four-material mesh is rebuilt
        # once rather than four times.
        defer = index < len(groups) - 1
        # Called as a method on the mesh, not through the function library: the library's Python
        # name is `GeometryScript_MeshEdits` (a ScriptName), not its C++ class name, and guessing
        # that wrong is exactly what the first live run tripped on.
        mesh.append_buffers_to_mesh(buffers, group["slot"], defer)

    # No slots at all is one empty slot: Blender's default surface, as below.
    materials = tuple(header.get("materials") or ("",))
    if state.actor_materials.get(name) != materials:
        state.actor_materials[name] = materials
        component.configure_material_set([_find_material(state, m) for m in materials])
        bu_link_static.set_materials(name, [_find_material(state, m) for m in materials])

    camera, shadow = header.get("camera", True) is not False, header.get("shadow", True) is not False
    bu_link_editor.show_to_camera(component, camera, shadow)
    bu_link_static.show_to_camera(name, camera, shadow)
    actor.set_actor_transform(_transform(header["matrix"]), False, False)
    if proto:
        # Drawn only through the instances made from it.
        component.set_visibility(False, False)
        _built_proto(state, name, component, digest, materials)
    state.meshes_applied += 1
    state.scene_dirty = True
    now = time.perf_counter()
    _PERF["applies"].append({
        "at": now, "seconds": now - started, "name": name, "path": path,
        "corners": int(header.get("vertices") or 0) if shared
        else sum(len(g["positions"]) // 3 for g in groups)})


def uv_channels(header):
    """How many UV maps a mesh message carries. Pure."""
    if not header.get("uv"):
        return 0
    try:
        return max(1, min(MAX_UV_CHANNELS, int(header.get("uv_channels") or 1)))
    except (TypeError, ValueError):
        return 1


def mesh_digest(header, blob=b"", component=None):
    """A digest of a mesh message's geometry and slot count, or None. What the static mesh cache
    is keyed by.

    The slot count is part of it because a stand-in is built with the object's slots. A cube
    baked with none (no materials in Blender) and found again after it gained one was shown
    with its material but cast no shadow.
    """
    found = _geometry_digest(header, blob, component)
    if not found:
        return None
    return "{0}_m{1}".format(found, max(1, len(header.get("materials") or ())))


def _geometry_digest(header, blob=b"", component=None):
    """A digest of a mesh message's geometry alone, or None.

    Taken here, not in Blender: the native module hashes the shared memory it is about to read
    at memory speed (xxHash3, about 1 ms per 250,000 triangles), where Blender's Python could
    only manage BLAKE2b at a gigabyte a second on its main thread — a visible hitch every time
    an edit or a scrub stopped. The socket path hashes the blob it already holds.
    """
    shared = header.get("shm")
    if shared:
        import unreal

        library = getattr(unreal, "BULinkLibrary", None)
        cage = subdiv_args(header)
        if cage is not None and positions_only(header):
            # Only the positions are there; the layout is the one the component was last given.
            if component is None or not can_move_cages():
                return None
            found = library.subdiv_positions_digest(
                component, str(shared.get("name") or ""), int(shared.get("offset") or 0), cage[0])
            return str(found) if found else None
        if cage is not None:
            if not can_subdivide():
                return None
            found = library.subdiv_digest(
                str(shared.get("name") or ""), int(shared.get("offset") or 0), *cage)
            return str(found) if found else None
        if not _native() or not hasattr(library, "mesh_digest"):
            return None  # an older binary: everything still works, nothing is cached
        found = library.mesh_digest(
            str(shared.get("name") or ""), int(shared.get("offset") or 0),
            int(header.get("vertices") or 0), int(header.get("triangles") or 0),
            uv_channels(header), bool(header.get("colors")))
        return str(found) if found else None
    if not blob:
        return None
    import hashlib

    return "{0}_{1}_s{2}".format(hashlib.blake2b(blob, digest_size=16).hexdigest(),
                                 int(header.get("triangles") or 0), len(blob))


def _apply_shared_mesh(component, header, shared):
    """Hand a mesh to the native module, which builds it from shared memory.

    Returns 1 if the mesh was rebuilt, 2 if its vertices were moved in place through Unreal's
    own update, or 3 if they were written straight into its render buffers (the same triangles,
    deformed: an animation playing). Python never sees an element: it passes a name, an offset
    and three counts.
    """
    import unreal

    name = header.get("name") or ""
    if not _native():
        raise RuntimeError(
            "'{0}' was sent through shared memory, but this project's BU plugin has no native "
            "module".format(name))
    cage = subdiv_args(header)
    if cage is not None:
        # A cage: subdivided here, the way Blender would have (4: still refining on a worker,
        # shown by `_service_subdiv` when it is done).
        if not can_subdivide():
            raise RuntimeError("'{0}' was sent as a subdivision cage, but this project's BU "
                               "plugin cannot subdivide".format(name))
        if positions_only(header):
            if not can_move_cages():
                raise WholeCageWanted(name)
            result = int(unreal.BULinkLibrary.apply_subdiv_positions(
                component, str(shared.get("name") or ""), int(shared.get("offset") or 0), cage[0]))
            if result == -7:
                raise WholeCageWanted(name)
        else:
            result = int(unreal.BULinkLibrary.apply_subdiv_mesh(
                component, str(shared.get("name") or ""), int(shared.get("offset") or 0), *cage))
    else:
        result = int(unreal.BULinkLibrary.apply_mesh(
            component, str(shared.get("name") or ""), int(shared.get("offset") or 0),
            int(header.get("vertices") or 0), int(header.get("triangles") or 0),
            uv_channels(header), bool(header.get("colors"))))
    if result < 0:
        raise ValueError("mesh '{0}' was refused: {1}".format(
            name, NATIVE_ERRORS.get(result, "error {0}".format(result))))
    return result


def _transform(values):
    import unreal

    planes = [unreal.Plane(*values[i:i + 4]) for i in range(0, 16, 4)]
    return unreal.Matrix(planes[0], planes[1], planes[2], planes[3]).transform()


# -- actors --------------------------------------------------------------------------------------

def _actor_subsystem():
    import unreal

    return unreal.get_editor_subsystem(unreal.EditorActorSubsystem)


def _alive(actor):
    return bu_link_editor.alive(actor)


def _live_actor(state, name):
    actor = state.actors.get(name)
    if actor is not None and not _alive(actor):
        # Deleted by hand in the editor. Forget it; the next mesh message respawns it.
        del state.actors[name]
        state.actor_materials.pop(name, None)
        return None
    return actor


def _destroy(actor):
    return bu_link_editor.destroy(actor)


def strays(tagged, owned):
    """Tagged live actors the link does not own: (name, actor) pairs to remove. Pure.

    `tagged` is (name, actor) for every actor carrying the link's tags, `owned` the link's own
    name -> actor map. An actor is a stray when its name is unknown or another actor holds it.
    """
    return [(name, actor) for name, actor in tagged if owned.get(name) is not actor]


def _sweep(state, now):
    """Remove live actors the link does not own, every `SWEEP_SECONDS`.

    They appear when an undo from before this version restores an actor the link had deleted,
    or when one is copied in the editor. Left alone they sit frozen beside the real one.
    """
    if now - getattr(state, "last_sweep", 0.0) < SWEEP_SECONDS or not getattr(state, "adopted", False):
        return
    state.last_sweep = now
    import unreal

    world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
    tagged = []
    for actor in unreal.GameplayStatics.get_all_actors_with_tag(world, unreal.Name(ACTOR_TAG)):
        names = [str(tag)[len(NAME_TAG_PREFIX):] for tag in actor.tags
                 if str(tag).startswith(NAME_TAG_PREFIX)]
        tagged.append((names[0] if names else "", actor))
    removed = 0
    for _name, actor in strays(tagged, state.actors):
        if _destroy(actor):
            removed += 1
    removed += bu_link_static.sweep(world)
    if removed:
        state.scene_dirty = True
        _log("removed {0} stray live actor(s)".format(removed))


def _tagged_actors():
    """Every live-link actor in the level, by Blender object name."""
    import unreal

    found = {}
    try:
        # Not EditorActorSubsystem.get_all_level_actors: it leaves out transient actors, which
        # every live actor is, so adopting through it found nothing and each reconnect rebuilt
        # the scene while the sweep removed the old copies.
        world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
        actors = unreal.GameplayStatics.get_all_actors_with_tag(world, unreal.Name(ACTOR_TAG))
    except Exception:  # noqa: BLE001
        return found
    for actor in actors:
        try:
            tags = [str(tag) for tag in actor.tags]
        except Exception:  # noqa: BLE001
            continue
        if ACTOR_TAG not in tags:
            continue
        for tag in tags:
            if tag.startswith(NAME_TAG_PREFIX):
                found[tag[len(NAME_TAG_PREFIX):]] = actor
    return found


def _class_name(actor):
    try:
        name = actor.get_class().get_name()
    except Exception:  # noqa: BLE001
        return ""
    return name if isinstance(name, str) else ""


def _is_light(actor):
    return _class_name(actor).endswith("Light")


def _apply_light(state, header):
    """Create or update the Unreal light standing in for a Blender light."""
    import unreal

    name = header.get("name") or ""
    if not name:
        return
    class_name, _settings = bu_link_light.settings(header)
    actor = _live_actor(state, name)
    if actor is not None and _class_name(actor) != class_name:
        # A mesh before, or another type of light (point to spot): Unreal cannot change an
        # actor's class, so it is replaced.
        _remove(state, name)
        actor = None
    if actor is None:
        actor = _spawn(state, name, getattr(unreal, class_name))
        if actor is None:
            raise RuntimeError("could not spawn a light for '{0}'".format(name))
    if header.get("matrix"):
        actor.set_actor_transform(_transform(header["matrix"]), False, False)
    bu_link_light.apply(actor, header, (state.render or {}).get("shadows"))
    if not hasattr(state, "light_shadows"):
        state.light_shadows = {}
    state.light_shadows[name] = (bu_link_light.light_kind(header),
                                 bu_link_light.shadow_choice(header))
    state.lights_applied = getattr(state, "lights_applied", 0) + 1
    state.scene_dirty = True


def _apply_volume(state, header):
    """Create or update the Local Fog Volume standing in for a Blender volume object."""
    import unreal

    name = header.get("name") or ""
    if not name:
        return
    actor = _live_actor(state, name)
    if actor is not None and _class_name(actor) != "LocalFogVolume":
        _remove(state, name)  # a mesh or a light before
        actor = None
    if actor is None:
        actor = _spawn(state, name, unreal.LocalFogVolume)
        if actor is None:
            raise RuntimeError("could not spawn a fog volume for '{0}'".format(name))
    if header.get("matrix"):
        actor.set_actor_transform(_transform(header["matrix"]), False, False)
    component = actor.get_component_by_class(unreal.LocalFogVolumeComponent)
    for prop, value in bu_link_light.volume_settings(header):
        if isinstance(value, tuple):
            value = unreal.LinearColor(*value, 1.0)
        if component.get_editor_property(prop) != value:
            component.set_editor_property(prop, value)
    state.scene_dirty = True


def _spawn(state, name, actor_class=None):
    import unreal

    actor = bu_link_editor.spawn(actor_class or unreal.DynamicMeshActor)
    if actor is None:
        return None
    actor.set_actor_label(bu_names.sanitize_asset_name(name, fallback="BU_Live"))
    if actor_class is None:
        bu_link_editor.render_only(actor.get_dynamic_mesh_component())
    actor.set_editor_property(
        "tags", [unreal.Name(ACTOR_TAG), unreal.Name(NAME_TAG_PREFIX + name)])
    try:
        actor.set_folder_path(unreal.Name(ACTOR_FOLDER))
    except Exception:  # noqa: BLE001 - cosmetic
        pass
    state.actors[name] = actor
    return actor


# -- materials -----------------------------------------------------------------------------------

def match_material(candidates, asset_names):
    """Pick the imported material for a Blender material, or None.

    Unreal publishes `stone` as `MI_stone`, and usually also as `MI_stone_4_TwoSided` — the one
    actually worth using, since Blender meshes are double-sided by default. The suffix is matched
    exactly rather than by prefix, or `MI_stone` would happily claim `MI_stone_brick`.
    """
    for candidate in candidates:
        pattern = re.compile(
            "^" + re.escape(candidate) + r"(_\d+)?(_TwoSided)?(_VT)?$", re.IGNORECASE)
        matches = [name for name in asset_names if pattern.match(name)]
        if matches:
            matches.sort(key=lambda n: ("twosided" not in n.lower(), len(n), n))
            return matches[0]
    return None


def _materials(state):
    """(descriptions, instances), by Blender material name.

    Created on demand: a `_State` that outlived a `bu_bridge.reload()` only has the fields it was
    made with.
    """
    if getattr(state, "material_specs", None) is None:
        state.material_specs = {}
    if getattr(state, "live_materials", None) is None:
        state.live_materials = {}
    if getattr(state, "material_kinds", None) is None:
        state.material_kinds = {}
    return state.material_specs, state.live_materials


def _imported_material(state, blender_name):
    """The material an earlier BU import made for this Blender material, or None."""
    import unreal

    if state.material_index is None:
        index = {}
        try:
            registry = unreal.AssetRegistryHelpers.get_asset_registry()
            for data in registry.get_assets_by_path(state.material_root, recursive=True):
                class_name = str(data.asset_class_path.asset_name)
                if class_name.startswith("Material"):
                    index[str(data.asset_name)] = data
        except Exception as exc:  # noqa: BLE001
            _warn("could not list materials under {0}: {1}".format(state.material_root, exc))
        state.material_index = index

    chosen = match_material(
        bu_names.material_name_candidates(blender_name), list(state.material_index))
    if chosen is None:
        return None
    try:
        return state.material_index[chosen].get_asset()
    except Exception:  # noqa: BLE001
        return None


def _find_material(state, blender_name):
    """What a live mesh should wear for this Blender material.

    Blender's own values, on a dynamic instance — unless the material uses an image texture, the
    one case a described colour cannot stand in for, where an earlier import's material is
    preferred if there is one. A name with no description at all comes from an add-on that
    predates descriptions, and keeps the old name-only behaviour.
    """
    import unreal

    specs, instances = _materials(state)
    if not blender_name:
        # An empty slot. Unreal would show its grey checker material, with a tiled normal map;
        # Blender shows its default surface, which an empty description already is.
        instance = instances.get("")
        if instance is None:
            world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
            instance = bu_link_material.create(world, {})
            if instance is not None:
                instances[""] = instance
        return instance
    spec = specs.get(blender_name)
    wanted = bu_link_material.identity(spec)
    # An image Blender could not hand over as a file: an earlier import's material, if any.
    found = (spec or {}).get("texture")
    has_file = isinstance(found, dict) and bool(found.get("path"))
    if spec is None or (spec.get("textured") and not has_file
                        and bu_link_material.kind(spec) != "unreal"):
        asset = _imported_material(state, blender_name)
        if asset is not None or spec is None:
            return asset

    instance = instances.get(blender_name)
    if instance is None or state.material_kinds.get(blender_name) != wanted:
        world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
        instance = bu_link_material.create(world, spec)
        if instance is not None:
            instances[blender_name] = instance
            state.material_kinds[blender_name] = wanted
    return instance


def _wear_built_graphs(state, keys):
    """Give the materials whose node wiring was just built their own compiled material: until
    now they wore the plain master (`bu_link_graph.service`)."""
    specs, _instances = _materials(state)
    for name, spec in list(specs.items()):
        if spec.get("graph_key") in keys:
            state.material_kinds.pop(name, None)  # what makes `_apply_material` choose again
            _apply_material(state, spec)


def _apply_material(state, header):
    name = header.get("name") or ""
    if not name:
        return
    specs, instances = _materials(state)
    previous = specs.get(name)
    specs[name] = header

    instance = instances.get(name)
    same_master = (instance is not None
                   and state.material_kinds.get(name) == bu_link_material.identity(header))
    if same_master:
        bu_link_material.apply(instance, header)
    # Choose again wherever the choice could differ: nothing was known about this material when
    # its meshes arrived, or it has gained or lost its texture or cutout since.
    if (not same_master or previous is None
            or bool(previous.get("textured")) != bool(header.get("textured"))):
        for actor_name, materials in list(state.actor_materials.items()):
            if name not in materials:
                continue
            actor = _live_actor(state, actor_name)
            if actor is not None:
                chosen = [_find_material(state, m) for m in materials]
                _wear(actor, chosen)
                bu_link_static.set_materials(actor_name, chosen)
    state.scene_dirty = True


def _apply_material_values(state, header):
    """New values for some of a material's graph parameters: set on its instance as they are.

    Blender sends these when its drivers moved nothing but typed-in values of the translated
    graph, instead of the whole description again (`link.Sync._send_values`).
    """
    name = header.get("name") or ""
    values = header.get("values")
    if not name or not isinstance(values, dict):
        return
    specs, instances = _materials(state)
    spec = specs.get(name)
    if spec is None:
        return  # its description never arrived; the next one carries these too
    spec = bu_link_material.with_values(spec, values)
    specs[name] = spec
    instance = instances.get(name)
    if instance is not None and state.material_kinds.get(name) == bu_link_material.identity(spec):
        bu_link_material.apply_values(instance, spec, values)
    state.scene_dirty = True


# -- the picture sent back to Blender ------------------------------------------------------------

def frame_dir():
    path = os.path.join(tempfile.gettempdir(), "bu_link_frames")
    os.makedirs(path, exist_ok=True)
    return path


def capture_due(now, view_time, view_dirty, scene_dirty, busy, started, last, changed=None,
                eager=False):
    """Whether to render a frame for Blender this tick. Pure, so the pacing is testable.

    `changed` is when the view or scene last changed: for `CONVERGE_SECONDS` after it, frames
    are rendered at full rate so the picture settles as fast as the editor's own. `eager`
    (the path tracer) renders at full rate throughout: it adds a sample a frame, and at the
    idle rate a thousand would take minutes.
    """
    if now - view_time > VIEW_TIMEOUT:
        return False  # nobody is looking
    if busy and now - started < CAPTURE_STALL:
        return False  # the previous frame is still being written
    if now - last < CAPTURE_MIN_INTERVAL:
        return False
    if eager or (changed is not None and now - changed < CONVERGE_SECONDS):
        return True
    return bool(view_dirty or scene_dirty or now - last >= CAPTURE_IDLE_INTERVAL)


def free_frame_slot(busy, slots, now):
    """The first frame slot Blender is not holding, or None. Pure.

    A slot handed out longer ago than `CAPTURE_STALL` is taken back: its acknowledgement was
    lost with a viewport that closed, and waiting for it would stop the picture for good.
    """
    for slot in range(max(0, int(slots))):
        taken = busy.get(slot)
        if taken is None or now - taken > CAPTURE_STALL:
            return slot
    return None


def _poll_shared_frames(state):
    """Announce pictures the render thread has finished copying into shared memory."""
    readbacks = _NATIVE["readbacks"]
    if not readbacks:
        return
    import unreal

    for _ in range(8):
        token = int(unreal.BULinkLibrary.poll_readback())
        if token == 0:
            return
        entry = readbacks.pop(abs(token), None)
        if entry is None:
            continue  # from before a reconnect
        message, timing = entry
        if message.get("type") == "depth":
            # Read before its frame (begun first): the frame learns where its depth is.
            frame = readbacks.get(message["of"])
            if token > 0 and frame is not None:
                frame[0]["depth"] = message["depth"]
            continue
        if token > 0:
            timing["written"] = time.perf_counter() - timing["at"]
            if message.get("type") == "frame":
                timing.update(frame_timings())  # this picture's, for the means in `summarise`
            if message.get("announced"):
                continue  # Blender saw its ready word already
            if "times" in message:
                message["times"]["ready"] = timing["at"] + timing["written"]
                # The native module's own time for it (the newest it read: this one, as they
                # are announced oldest first and one is rarely behind another).
                native = frame_timings()
                if native:
                    message["times"]["native_ms"] = round(sum(native.values()), 1)
            state.completed.append(message)
        else:
            _NATIVE["busy_slots"].pop(message["slot"], None)


def lighting_methods(gi_value, reflection_value, render=None):
    """Project settings values -> (global illumination, reflection) enum member names. Pure.

    `render` (Blender's Render properties) overrides either; "PROJECT" or nothing keeps the
    project's.
    """
    render = render or {}
    gi = GI_METHODS.get(gi_value, "NONE")
    reflection = REFLECTION_METHODS.get(reflection_value, "NONE")
    if render.get("gi") in RENDER_GI:
        gi = RENDER_GI[render["gi"]]
    if render.get("reflections") in RENDER_REFLECTIONS:
        reflection = RENDER_REFLECTIONS[render["reflections"]]
    return gi, reflection


def ray_lighting(render):
    """The `LumenRayLightingModeOverride` member name Blender asked for, or None. Pure."""
    return RENDER_RAY_LIGHTING.get((render or {}).get("ray_lighting"))



def path_tracing(render):
    """Whether Blender asked for Unreal's path tracer. Pure."""
    return (render or {}).get("renderer") == "PATH_TRACER"


def _checked(value, kind, lowest, highest):
    if kind is bool:
        return bool(value)
    try:
        value = kind(value)
    except (TypeError, ValueError):
        return None
    if value != value:  # NaN
        return None
    return min(highest, max(lowest, value))


def post_overrides(render):
    """{post-process setting: value, or None to leave it to the project} for every setting
    Blender can set. Pure."""
    render = render or {}
    asked = render.get("lumen") if isinstance(render.get("lumen"), dict) else {}
    found = {}
    for name, (kind, lowest, highest) in LUMEN_POST_SETTINGS.items():
        value = _checked(asked[name], kind, lowest, highest) if name in asked else None
        found[name] = LUMEN_POST_DEFAULTS.get(name) if value is None else value
    path = render.get("path_tracing") if isinstance(render.get("path_tracing"), dict) else {}
    on = path_tracing(render)
    for name, (kind, lowest, highest) in PATH_TRACING_POST_SETTINGS.items():
        found[name] = (_checked(path[name], kind, lowest, highest)
                       if on and name in path else None)
    ao = _ao(render)
    ssao = ao.get("ssao") if ao.get("contact") == "SSAO" else None
    ssao = ssao if isinstance(ssao, dict) else {}
    for name, (kind, lowest, highest) in SSAO_POST_SETTINGS.items():
        found[name] = _checked(ssao[name], kind, lowest, highest) if name in ssao else None
    found["ambient_occlusion_radius_in_ws"] = (
        True if found["ambient_occlusion_radius"] is not None else None)
    return found


def _ao(render):
    ao = (render or {}).get("ao")
    return ao if isinstance(ao, dict) and not path_tracing(render) else {}


def ao_cvars(render):
    """{console variable: value, or None for the project's own} for Blender's ambient
    occlusion. Pure. Nothing under the path tracer, which has its own."""
    ao = _ao(render)
    contact = ao.get("contact")
    extra = ao.get("extra") if isinstance(ao.get("extra"), dict) else None
    found = {
        # SSAO is applied to Lumen's GI only with the short-range AO off.
        AO_SHORT_RANGE_CVAR: 0 if contact == "SSAO" else None,
        AO_SSAO_CVAR: 1 if contact == "SSAO" else None,
        AO_EXTRA_CVAR: 1 if extra is not None else None,
        AO_EXTRA_DISTANCE_CVAR: None,
        AO_EXTRA_EXPONENT_CVAR: None,
    }
    if extra is not None:
        found[AO_EXTRA_DISTANCE_CVAR] = _checked(extra.get("distance"), float, 1.0, 1000000.0)
        found[AO_EXTRA_EXPONENT_CVAR] = _checked(extra.get("exponent"), float, 0.01, 16.0)
    return found


def _apply_render(state, render):
    """Blender's Render properties: the capture's lighting methods and screen traces."""
    render = dict(render) if isinstance(render, dict) else {}
    if render == state.render:
        return
    scene_shadows = render.get("shadows")
    changed_shadows = scene_shadows != (state.render or {}).get("shadows")
    state.render = render
    if changed_shadows:
        # Every light left to the scene's Shadows choice follows it.
        for name, (kind, choice) in list(getattr(state, "light_shadows", {}).items()):
            actor = _live_actor(state, name)
            if actor is not None and _is_light(actor):
                bu_link_light.set_ray_traced_shadow(
                    actor.get_editor_property("light_component"), kind, choice, scene_shadows)
        state.scene_dirty = True
    if _alive(state.capture_actor):
        import unreal

        _match_project_lighting(
            state.capture_actor.get_component_by_class(unreal.SceneCaptureComponent2D), render)
    for name in SCREEN_TRACE_CVARS:
        if render.get("screen_traces") is False:
            _set_cvar(state, name, 0)
        else:
            _restore_cvar(state, name)
    for name, value in ao_cvars(render).items():
        if value is None:
            _restore_cvar(state, name)
        else:
            _set_cvar(state, name, value)
    # Unreal denoises the path tracer once, at its last sample. Its "online" temporal mode
    # (labelled for debugging) runs the denoiser on every frame instead, with its albedo and
    # normal guides, so the picture is clean while it refines.
    # DLSS Ray Reconstruction: DLSS's network denoises Lumen's (and ray-traced) lighting in place
    # of Unreal's own denoisers. It works only while DLSS is the view's upscaler.
    if render.get("dlss_rr") and not path_tracing(render):
        _set_cvar(state, DLSS_RR_CVAR, 1)
    else:
        _restore_cvar(state, DLSS_RR_CVAR)
    quality = NNE_QUALITY.get(str(render.get("denoise_quality") or "")) if path_tracing(render) else None
    if quality:
        _set_cvar(state, NNE_ASSET_CVAR, quality)
    else:
        _restore_cvar(state, NNE_ASSET_CVAR)
    if path_tracing(render) and render.get("denoise_live"):
        _set_cvar(state, LIVE_DENOISE_CVAR, 2)
    else:
        _restore_cvar(state, LIVE_DENOISE_CVAR)



def set_show_flags(component, flags):
    """A capture's show flags, through Unreal's setter: it also rebuilds the flags the capture
    renders with. Setting the property alone changed only the list, so a capture already
    registered kept rendering with its old flags (the path tracer never came on)."""
    setter = getattr(component, "set_show_flag_settings", None)
    if setter is not None:
        setter(flags)
    else:
        component.set_editor_property("show_flag_settings", flags)


def _match_project_lighting(component, render=None):
    """Give the capture the global illumination and reflections the editor viewport has.

    Unreal turns both off for every scene capture, whatever the project says — "By default,
    Lumen is disabled in scene captures, but can be re-enabled with the post process settings in
    the component" (`SceneCaptureRendering.cpp`). Left like that a mirror reflects only the sky
    light, whose lower half is black, and nothing bounces. The surface cache is likewise halved
    for captures; this one is the picture, so it gets the full one.
    """
    import unreal

    def cvar(name):
        try:
            return int(unreal.SystemLibrary.get_console_variable_int_value(name))
        except Exception:  # noqa: BLE001
            return 0

    gi, reflection = lighting_methods(
        cvar("r.DynamicGlobalIlluminationMethod"), cvar("r.ReflectionMethod"), render)
    settings = component.get_editor_property("post_process_settings")
    settings.set_editor_property("override_dynamic_global_illumination_method", True)
    settings.set_editor_property(
        "dynamic_global_illumination_method", getattr(unreal.DynamicGlobalIlluminationMethod, gi))
    settings.set_editor_property("override_reflection_method", True)
    settings.set_editor_property("reflection_method", getattr(unreal.ReflectionMethod, reflection))
    for name, value in post_overrides(render).items():
        try:
            settings.set_editor_property("override_" + name, value is not None)
            if value is not None:
                settings.set_editor_property(name, value)
        except Exception as exc:  # noqa: BLE001 - an engine without it keeps the project's
            _warn("could not set {0}: {1}".format(name, exc))
    mode = ray_lighting(render)
    try:
        settings.set_editor_property("override_lumen_ray_lighting_mode", mode is not None)
        if mode is not None:
            settings.set_editor_property(
                "lumen_ray_lighting_mode", getattr(unreal.LumenRayLightingModeOverride, mode))
    except Exception as exc:  # noqa: BLE001 - an engine without it keeps the project's
        _warn("could not set Lumen's ray lighting: {0}".format(exc))
    component.set_editor_property("post_process_settings", settings)
    component.set_editor_property("post_process_blend_weight", 1.0)
    # Scene captures are created with temporal AA off ("previous behavior was not exposing ...
    # Temporal AA in scene capture 2d", USceneCaptureComponent2D's constructor). The viewport
    # has it, and it is the last pass that cleans up Lumen's noise; without it the picture in
    # Blender stayed grainy where the viewport was clean.
    # The path tracer is a show flag: it replaces Lumen, shadows and AA for this capture, and
    # accumulates its samples in the capture's own view state while nothing changes.
    flags = [unreal.EngineShowFlagsSetting(show_flag_name="TemporalAA", enabled=True),
             unreal.EngineShowFlagsSetting(show_flag_name="PathTracing",
                                           enabled=path_tracing(render))]
    set_show_flags(component, flags)
    # Scene captures do not ray trace unless asked to (`IsRayTracingAllowedForView`), so in a
    # ray-traced project Lumen falls back to software tracing for the capture — which traces
    # distance fields, and dynamic meshes have none. Every live mesh vanished from Lumen and
    # the capture was left with screen traces only: screen-space GI and reflections, while the
    # viewport showed hardware Lumen. Harmless in a project without ray tracing.
    component.set_editor_property("use_ray_tracing_if_enabled", True)


def overscan_pad(size, overscan, slot_bytes=0, depth_divisor=None):
    """(x, y) pixels added on each side of a `size` picture for this overscan fraction. Pure.

    Whole pixels, rounded down, so the crop lands exactly on the view's own pixels; smaller when
    the bigger picture would not fit a shared-memory frame slot of `slot_bytes` (float RGBA),
    with room after it for its depth picture when `depth_divisor` is given (`depth_layout`).
    """
    try:
        fraction = min(MAX_OVERSCAN, max(0.0, float(overscan or 0.0)))
    except (TypeError, ValueError):
        fraction = 0.0
    width, height = int(size[0]), int(size[1])

    def needs(w, h):
        if not depth_divisor:
            return w * h * 16
        layout = depth_layout((w, h), 1 << 62, depth_divisor)
        return layout["offset"] + layout["width"] * layout["height"] * 4

    if slot_bytes and width * height * 16 > 0:
        # (1 + 2f)² w h (16 + depth) <= slot_bytes, the depth's share a little over its own.
        share = 16.0 + (5.0 / float(depth_divisor) ** 2 if depth_divisor else 0.0)
        fit = (math.sqrt(slot_bytes / float(width * height * share)) - 1.0) / 2.0
        fraction = min(fraction, max(0.0, fit))
    pad_x, pad_y = int(width * fraction), int(height * fraction)
    while slot_bytes and (pad_x or pad_y) and (
            needs(width + 2 * pad_x, height + 2 * pad_y) > slot_bytes):
        pad_x, pad_y = max(0, pad_x - 1), max(0, pad_y - 1)
    return pad_x, pad_y


# The nearest Blender's Clip Start is followed (cm): Blender allows a micrometre.
MIN_NEAR_CM = 0.01


def near_plane(view):
    """The capture's near clipping distance (cm) for Blender's view, or None for Unreal's own
    (an orthographic view, or an older Blender that does not send it). Pure."""
    if "ortho_width" in view:
        return None
    try:
        near = float(view["near"])
    except (KeyError, TypeError, ValueError):
        return None
    return max(MIN_NEAR_CM, near) if near == near else None  # not NaN


def _set_near(component, view):
    """Clip where Blender clips: Unreal's default near plane (10 cm) cut into close-ups that
    Blender's viewport (1 cm) shows whole."""
    near = near_plane(view)
    _set_quietly(component, "override_custom_near_clipping_plane", near is not None)
    if near is not None:
        _set_quietly(component, "custom_near_clipping_plane", near)


def overscan_view(view, size, pad):
    """The capture's field of view (degrees) or ortho width (cm) for an overscanned picture. Pure.

    The horizontal extent grows with the width, so a pixel covers the same angle as without
    overscan and the centre `size` pixels are exactly the view Blender asked for.
    """
    grow = (size[0] + 2 * pad[0]) / float(size[0])
    if "ortho_width" in view:
        return {"ortho_width": float(view["ortho_width"]) * grow}
    half = math.radians(float(view.get("fov", 60.0))) / 2.0
    fov = math.degrees(2.0 * math.atan(math.tan(half) * grow))
    lens = {"fov": min(MAX_FOV, fov)}
    near = near_plane(view)
    if near is not None:
        lens["near"] = near
    return lens


def depth_layout(size, slot_bytes, divisor=None):
    """Where a frame's depth picture goes in its slot, after the colour, or None. Pure.

    {"offset": bytes into the slot, "width", "height", "format": "nearest", "render": [w, h]}:
    one float per pixel, `size` divided by `divisor` (Blender's `depth_divisor`, 1-64;
    `DEPTH_DIVISOR` when it gives none), shrunk from a depth render of `render` pixels with the
    frame's own shape, so the two pictures cover the same view. None when it would not fit.
    """
    try:
        divisor = min(64, max(DEPTH_RENDER_DIVISOR, int(divisor)))
    except (TypeError, ValueError):
        divisor = DEPTH_DIVISOR
    width, height = max(1, int(size[0])), max(1, int(size[1]))
    render_width = max(1, -(-width // DEPTH_RENDER_DIVISOR))
    render_height = max(1, int(round(render_width * height / float(width))))
    out_width = max(1, int(round(width / float(divisor))))
    out_height = max(1, int(round(height / float(divisor))))
    offset = (width * height * 16 + 63) // 64 * 64
    if offset + out_width * out_height * 4 > int(slot_bytes or 0):
        return None
    return {"offset": offset, "width": out_width, "height": out_height, "format": "nearest",
            "render": [render_width, render_height]}


def _capture_depth(state, world, location, rotation, lens, layout):
    """Render the depth picture for this view; its target, or None. Before the frame's own
    render, so that waiting for the frame waits for both."""
    import unreal

    actor = getattr(state, "depth_actor", None)
    if not _alive(actor):
        actor = bu_link_editor.spawn(unreal.SceneCapture2D, location, rotation)
        if actor is None:
            return None
        actor.set_actor_label("BU_Live_Depth")
        component = actor.get_component_by_class(unreal.SceneCaptureComponent2D)
        component.set_editor_property("capture_every_frame", False)
        component.set_editor_property("capture_on_movement", False)
        # Linear depth along the view, in centimetres, in red.
        component.set_editor_property(
            "capture_source", unreal.SceneCaptureSource.SCS_SCENE_DEPTH)
        set_show_flags(component, [
            unreal.EngineShowFlagsSetting(show_flag_name=name, enabled=False)
            for name in DEPTH_FLAGS_OFF])
        state.depth_actor = actor
        state.depth_target = None
    component = actor.get_component_by_class(unreal.SceneCaptureComponent2D)
    small = tuple(layout["render"])
    if getattr(state, "depth_target", None) is None or state.depth_size != small:
        # Half floats: a centimetre at 10 m, 8 cm at 100 m; past 655 m it is infinitely far.
        state.depth_target = unreal.RenderingLibrary.create_render_target2d(
            world, small[0], small[1], unreal.TextureRenderTargetFormat.RTF_RGBA16F)
        state.depth_size = small
        component.set_editor_property("texture_target", state.depth_target)
    if "ortho_width" in lens:
        _set_quietly(component, "projection_type", unreal.CameraProjectionMode.ORTHOGRAPHIC)
        _set_quietly(component, "ortho_width", lens["ortho_width"])
    else:
        _set_quietly(component, "projection_type", unreal.CameraProjectionMode.PERSPECTIVE)
        _set_quietly(component, "fov_angle", lens["fov"])
    _set_near(component, lens)
    actor.set_actor_location_and_rotation(location, rotation, False, False)
    component.capture_scene()
    return state.depth_target


def render_scale(value):
    """The screen percentage Blender asked for (25-100), or None for a plain capture. Pure."""
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    if value != value or value <= 0.0:
        return None
    return min(100.0, max(25.0, value))


def upscalers():
    """The upscaler plugins the native module can render through (["DLSS"] on an RTX card with
    NVIDIA's plugin in the project), or []."""
    import unreal

    library = getattr(unreal, "BULinkLibrary", None)
    if library is None or not hasattr(library, "get_upscalers") or not _native():
        return []
    try:
        return sorted(str(name) for name in library.get_upscalers())
    except Exception:  # noqa: BLE001
        return []


def _console(command):
    import unreal

    try:
        unreal.SystemLibrary.execute_console_command(None, command)
    except Exception:  # noqa: BLE001
        pass


def _render(component, scale, upscaler=None, mode=None, state=None):
    """Render the capture: through the native module's full view when Blender asked for a
    render scale (screen percentage and TSR, which scene captures do not support, or an
    upscaler plugin such as DLSS), else the capture's own CaptureScene."""
    import unreal

    scale = render_scale(scale)
    library = getattr(unreal, "BULinkLibrary", None)
    if scale is not None and library is not None and hasattr(library, "render_capture_view"):
        extra = ((upscaler, str(mode or "")) if upscaler and upscaler in upscalers() else ())
        # A full view, unlike a scene capture, gets Unreal's on-screen warnings drawn into it
        # ("multiple directional lights are competing..."). Hidden while the link renders this way.
        if state is not None and not state.screen_messages_off:
            _console("DisableAllScreenMessages")
            state.screen_messages_off = True
        if library.render_capture_view(component, scale, *extra):
            return
    component.capture_scene()


def wants_linear(view, float_readback):
    """Whether to send the picture before Unreal's tone curve. Pure.

    Blender asks for it (`"colour": "linear"`) when it is to do the colour management itself; it
    needs a native module that reads half-floats, or the floats would be cut to 8 bits.
    """
    return bool(float_readback) and view.get("colour") == "linear"


def capture_source(linear):
    """The capture's source: the picture before the tone curve, or Unreal's finished one.

    Final Color (HDR) has exposure, bloom and the rest of post-processing, in linear Rec.709 —
    Blender's own scene-linear space — but no tone curve and no display encoding.
    """
    import unreal

    if linear:
        return unreal.SceneCaptureSource.SCS_FINAL_COLOR_HDR
    return unreal.SceneCaptureSource.SCS_FINAL_COLOR_LDR


def _linear_post(component, linear, fixed_exposure=False):
    """Turn Unreal's Expand Gamut off for a linear picture, and back to the level's for the other.

    Expand Gamut is applied before the tone curve, so Final Color (HDR) still has it: measured
    on emissive patches, pure green arrived as (-0.24, 1.05, -0.06) and an orange came out more
    saturated, the more so the brighter. With it off every patch was its own value to 2%, pure
    primaries stayed pure, and +1 stop doubled them exactly. Blender's view transform owns
    saturation in this mode.

    Local exposure is in Final Color (HDR) too. A project with Shadow and Highlight Contrast at
    0.8 (the MetaHuman template's) squeezed every patch's distance from mid-grey, in stops, by
    exactly 0.8: 1.0 arrived as 0.74 and 0.05 as 0.068. At 1.0 local exposure does nothing, so
    the contrast is Blender's view transform's alone.

    `fixed_exposure`: Unreal's exposure set to `LINEAR_EXPOSURE_BIAS`, so the picture is in
    Blender's units, as a render engine's is, and no vignette — Blender's renders have none, and
    with overscan it fell on the edges of the bigger picture, so the part Blender keeps came out
    brighter the more overscan there was (6% at 10%, 12% at 25%). Only while Blender's Unreal
    Camera is off: when it is on, its post-process volume decides, and the capture's own override
    would beat it.
    """
    import unreal

    settings = component.get_editor_property("post_process_settings")
    for name, linear_value, other in LINEAR_POST:
        settings.set_editor_property("override_" + name, bool(linear))
        settings.set_editor_property(name, linear_value if linear else other)
    fixed = bool(linear and fixed_exposure)
    for name, value in (("auto_exposure_method", unreal.AutoExposureMethod.AEM_MANUAL),
                        ("auto_exposure_apply_physical_camera_exposure", False),
                        ("auto_exposure_bias", LINEAR_EXPOSURE_BIAS),
                        ("vignette_intensity", 0.0)):
        settings.set_editor_property("override_" + name, fixed)
        if fixed:
            settings.set_editor_property(name, value)
    component.set_editor_property("post_process_settings", settings)


def _float_readback():
    """True when the native module copies half-float render targets without clamping them."""
    import unreal

    if not _native():
        return False
    features = getattr(unreal.BULinkLibrary, "get_readback_features", None)
    try:
        return bool(features is not None and int(features()) & READBACK_HALF_FLOAT)
    except Exception:  # noqa: BLE001
        return False


def _ready_signal():
    """True when the native readbacks write a ready word for Blender (READBACK_READY_SIGNAL)."""
    import unreal

    if not _native():
        return False
    features = getattr(unreal.BULinkLibrary, "get_readback_features", None)
    try:
        return bool(features is not None and int(features()) & READBACK_READY_SIGNAL)
    except Exception:  # noqa: BLE001
        return False


def streaming_view(view):
    """(location, width, horizontal fov) to stream textures for, from a view message. Pure.

    An orthographic view has no field of view; 90 degrees asks for about what a perspective view
    as wide would.
    """
    fov = float(view.get("fov") or 90.0) if "ortho_width" not in view else 90.0
    return tuple(float(v) for v in view["location"]), max(2, int(view["width"])), fov


def _stream_for_view(view, now):
    """Keep texture streaming loading full resolution for what Blender is shown.

    Streaming picks each texture's mip from the editor's own viewports and ignores scene
    captures, so anything only the link's camera looked at stayed blurry: measured on a pillar
    1.5 m from the camera, 13 times the pixel-to-pixel detail once streaming knew the view.
    """
    import unreal

    if now - _NATIVE.get("streamed", 0.0) < STREAM_INTERVAL or not _native():
        return
    library = unreal.BULinkLibrary
    if not hasattr(library, "add_streaming_view"):
        return  # an older binary
    _NATIVE["streamed"] = now
    location, width, fov = streaming_view(view)
    library.add_streaming_view(unreal.Vector(*location), width, fov, STREAM_SECONDS)


def _set_quietly(component, name, value):
    """Set a capture setting that changes picture to picture, without the editor's change
    notifications.

    `set_editor_property` notifies as an edit in the Details panel would, and a component's
    post-edit re-registers it, which destroys a scene capture's view state: its temporal
    history. A zoom changes the field of view every frame, and the first picture after each
    change had no Lumen reflection at all (19 of 20 changes, on a mirror floor): reflections
    blinked on and off through a camera move. The capture reads these when it renders.
    """
    import unreal

    try:
        component.set_editor_property(name, value, unreal.PropertyAccessChangeNotifyMode.NEVER)
    except (TypeError, AttributeError):  # an engine without notify modes
        component.set_editor_property(name, value)


def _skipped(now, reason):
    _PERF["skips"].append((now, reason))
    del _PERF["skips"][:-600]


def _service_capture(state):
    import unreal

    view = state.view
    if view is None:
        return
    now = time.perf_counter()
    _stream_for_view(view, now)
    if frame_held(getattr(state, "frames_marked", False), getattr(state, "frame_opened", None),
                  now):
        _skipped(now, "held")
        return  # the rest of this frame is still on its way
    if state.view_dirty or state.scene_dirty:
        state.changed_at = now
        state.settled = 0
    # A still Blender is rendering (F12) is rendered at full rate until it has what it waits
    # for, as the path tracer is: at the idle rate, settling would take many seconds.
    if not capture_due(now, state.view_time, state.view_dirty, state.scene_dirty,
                       state.capture_busy, state.capture_started, state.capture_last,
                       getattr(state, "changed_at", None),
                       path_tracing(state.render) or bool(view.get("render"))):
        _skipped(now, "not_due")
        return

    editor = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem)
    world = editor.get_editor_world()
    asked = (max(2, int(view["width"])), max(2, int(view["height"])))

    # Decided before rendering: a picture with nowhere to go is a wasted render.
    frames = view.get("frames") if _native() else None
    # What a slot holds for the picture and its depth: all but its ready words.
    usable = max(0, int(frames.get("slot_bytes") or 0) - SLOT_READY_BYTES) if frames else 0
    pad = overscan_pad(asked, view.get("overscan"), usable,
                       (view.get("depth_divisor") or DEPTH_DIVISOR) if view.get("depth") else None)
    size = (asked[0] + 2 * pad[0], asked[1] + 2 * pad[1])
    lens = overscan_view(view, asked, pad)
    slot = None
    if frames and size[0] * size[1] * 16 <= usable:
        slot = free_frame_slot(_NATIVE["busy_slots"], int(frames.get("slots") or 0), now)
        if slot is None:
            _skipped(now, "no_slot")
            return  # Blender still holds every slot; try again next tick
    # Linear only through shared memory, where the floats survive; the file fallback is 8-bit.
    linear = slot is not None and wants_linear(view, _float_readback())
    if state.target is None or state.target_size != size or state.target_linear != linear:
        if linear:
            # Half-float: the picture before the tone curve runs past 1 wherever it is bright.
            state.target = unreal.RenderingLibrary.create_render_target2d(
                world, size[0], size[1], unreal.TextureRenderTargetFormat.RTF_RGBA16F)
        else:
            state.target = unreal.RenderingLibrary.create_render_target2d(
                world, size[0], size[1], unreal.TextureRenderTargetFormat.RTF_RGBA8)
            # Without this the tonemapper writes linear values into the 8-bit target and the
            # exported bytes are the viewport's picture with its gamma missing: dark and harsh.
            # Measured against the editor viewport: 61/255 mean error without, 3/255 with.
            state.target.set_editor_property("target_gamma", TARGET_GAMMA)
        state.target_size = size
        state.target_linear = linear

    location = unreal.Vector(*view["location"])
    rotation = unreal.MathLibrary.make_rot_from_xz(
        unreal.Vector(*view["forward"]), unreal.Vector(*view["up"]))

    if not _alive(state.capture_actor):
        state.capture_actor = bu_link_editor.spawn(unreal.SceneCapture2D, location, rotation)
        if state.capture_actor is None:
            raise RuntimeError("could not spawn the capture camera")
        state.capture_actor.set_actor_label("BU_Live_Camera")
        state.post_linear = None
        component = state.capture_actor.get_component_by_class(unreal.SceneCaptureComponent2D)
        # Rendered on demand below, never on its own: an every-frame capture would render the
        # scene twice per editor frame whether or not Blender wanted a picture.
        component.set_editor_property("capture_every_frame", False)
        component.set_editor_property("capture_on_movement", False)
        # Keeps temporal history between captures, so Lumen and TAA converge instead of
        # restarting from noise on every frame.
        component.set_editor_property("always_persist_rendering_state", True)
        component.set_editor_property(
            "capture_source", unreal.SceneCaptureSource.SCS_FINAL_COLOR_LDR)
        _match_project_lighting(component, state.render)

    component = state.capture_actor.get_component_by_class(unreal.SceneCaptureComponent2D)
    component.set_editor_property("texture_target", state.target)
    component.set_editor_property("capture_source", capture_source(linear))
    post = (linear, linear and not state.camera_post)
    if state.post_linear != post:
        _linear_post(component, *post)
        state.post_linear = post
    if "ortho_width" in lens:
        _set_quietly(component, "projection_type", unreal.CameraProjectionMode.ORTHOGRAPHIC)
        _set_quietly(component, "ortho_width", lens["ortho_width"])
    else:
        _set_quietly(component, "projection_type", unreal.CameraProjectionMode.PERSPECTIVE)
        _set_quietly(component, "fov_angle", lens["fov"])
    _set_near(component, lens)
    state.capture_actor.set_actor_location_and_rotation(location, rotation, False, False)

    if state.view_dirty and view.get("drive_editor"):
        editor.set_level_viewport_camera_info(location, rotation)

    render_started = time.perf_counter()
    # Pictures rendered since the view or the scene last changed, this one included: how far
    # the temporal effects (Lumen, TSR, the path tracer's samples) have settled. Sent with it.
    # A still's (F12) also says what is still loading and which of Blender's frames it holds
    # (`still_report`), so Blender knows exactly when it has the scene as it is; and while
    # something loads its count starts again, as the lighting does on what comes in.
    report = {}
    if view.get("render"):
        loading = still_loading()
        state.settled = 0 if loading else state.settled + 1
        report = {"loading": loading, "applied": state.frame_applied}
    else:
        state.settled += 1
    depth = depth_target = None
    library = getattr(unreal, "BULinkLibrary", None)
    if (slot is not None and view.get("depth") and library is not None
            and hasattr(library, "begin_depth_readback")):
        depth = depth_layout(size, usable, view.get("depth_divisor"))
        if depth is not None:
            depth_target = _capture_depth(state, world, location, rotation, lens, depth)
    _render(component, view.get("render_scale"), view.get("upscaler"), view.get("upscaler_mode"),
            state)
    timing = {"at": render_started, "render": time.perf_counter() - render_started,
              "export": 0.0, "written": None}
    _PERF["captures"].append(timing)

    if slot is not None:
        export_started = time.perf_counter()
        base = slot * int(frames["slot_bytes"])
        signal = _ready_signal()
        colour_ready, depth_ready = ready_offsets(frames["slot_bytes"])
        depth_token = None
        if depth_target is not None:
            _NATIVE["token"] = _NATIVE["token"] % 0x7FFFFFF0 + 1
            depth_token = _NATIVE["token"]
            extra = (base + depth_ready,) if signal else ()
            if unreal.BULinkLibrary.begin_depth_readback(
                    depth_target, str(frames.get("name") or ""), base + depth["offset"],
                    depth_token, depth["width"], depth["height"], *extra):
                _NATIVE["readbacks"][depth_token] = (
                    {"type": "depth", "of": depth_token % 0x7FFFFFF0 + 1, "depth": depth}, timing)
            else:
                depth_token = None
        _NATIVE["token"] = _NATIVE["token"] % 0x7FFFFFF0 + 1
        token = _NATIVE["token"]
        extra = (base + colour_ready,) if signal else ()
        began = unreal.BULinkLibrary.begin_readback(
            state.target, str(frames.get("name") or ""), base, token, *extra)
        timing["export"] = time.perf_counter() - export_started
        if began:
            message = {
                "type": "frame", "slot": slot, "seq": view.get("seq", 0),
                "width": size[0], "height": size[1], "linear": linear,
                "crop": list(pad), "settled": state.settled,
                # perf_counter, one clock for every process on Windows: Blender works out
                # where the picture's delay went (frame_delays).
                "times": {"view": state.view_time, "render": render_started}}
            message.update(report)
            if signal:
                # Said now; Blender takes it when its ready word turns to `token`.
                message["ready"] = {"offset": colour_ready, "token": token}
                if depth_token is not None:
                    message["depth"] = depth
                    message["depth_ready"] = {"offset": depth_ready, "token": depth_token}
                message["announced"] = True
                _queue(state, message)
            _NATIVE["readbacks"][token] = (message, timing)
            _NATIVE["busy_slots"][slot] = now
            # Not `capture_busy`: the slots are the limit, so a second picture can be on its
            # way while Blender is still copying the first. Cleared rather than left alone, or
            # a file export still pending from before the ring was offered would hold every
            # picture back by `CAPTURE_STALL`.
            state.capture_busy = False
            state.capture_started = now
            state.capture_last = now
            state.view_dirty = False
            state.scene_dirty = False
            return
        # The native read could not start (the mapping has gone, most likely). Use the file.

    state.frame_index = (state.frame_index + 1) % FRAME_FILES
    path = os.path.join(frame_dir(), "frame_{0}.bmp".format(state.frame_index)).replace("\\", "/")
    message = {"type": "frame", "path": path, "seq": view.get("seq", 0),
               "width": size[0], "height": size[1], "crop": list(pad), "settled": state.settled}
    message.update(report)
    # Remove what is there first. The names cycle, so the path already holds an older frame —
    # a complete, valid bitmap that Blender would happily show if it looked before the new one
    # landed. Seen on the first live run, where a leftover test image came back as "the frame".
    try:
        os.remove(path)
    except OSError:
        pass

    options = unreal.ImageWriteOptions()
    options.set_editor_property("format", unreal.DesiredImageFormat.BMP)
    options.set_editor_property("overwrite_file", True)

    # Exactly one parameter. `bind_callable` checks the callable against the delegate's
    # signature, so the usual trick of capturing values as defaulted extra arguments makes the
    # bind fail — silently here, since there is a fallback — and every frame was then announced
    # before it had been written. Closed-over names are safe: each call makes a new closure.
    def finished(success):
        state.capture_busy = False
        if success:
            timing["written"] = time.perf_counter() - timing["at"]
            state.completed.append(message)

    announced = False
    try:
        callback = unreal.OnImageWriteComplete()
        callback.bind_callable(finished)
        options.set_editor_property("on_complete", callback)
        # The delegate is only weakly held by the engine; keep it alive until it has fired.
        state.capture_callbacks = state.capture_callbacks[-FRAME_FILES:] + [callback]
        announced = True
    except Exception:  # noqa: BLE001
        pass

    export_started = time.perf_counter()
    unreal.ImageWriteBlueprintLibrary.export_to_disk(state.target, path, options)
    timing["export"] = time.perf_counter() - export_started

    state.capture_busy = announced
    state.capture_started = now
    state.capture_last = now
    state.view_dirty = False
    state.scene_dirty = False
    if not announced:
        # No completion callback available: announce now. Blender checks the file is whole
        # before using it, so an early announcement costs a retry, not a torn frame.
        state.completed.append(message)
