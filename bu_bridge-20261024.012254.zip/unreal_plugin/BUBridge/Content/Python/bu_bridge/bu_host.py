# SPDX-License-Identifier: GPL-3.0-or-later
"""The editor BU starts as Blender's renderer: its level, the link, a status file, quitting.

Blender (`link_host.py`) starts this editor and passes these in its environment:

    BU_HOST_PORT     the port the real-time link listens on
    BU_HOST_PARENT   Blender's process ID; when it ends, so does this editor
    BU_HOST_STATUS   a JSON file rewritten every second: state, shaders left, port
    BU_HOST_QUIT     a file whose appearance asks this editor to close
    BU_HOST_LEVEL    "last": reopen the level last open here, if it was saved; "blank": a new one
    BU_HOST_WINDOW   "1" when the editor has its window: closing then asks about unsaved work

`init_unreal.py` calls `begin()` when BU_HOST_PORT is set; an editor someone opened themselves
never runs any of this.

The order matters. The link starts only once the level is the one open, because opening a
level replaces the world, and with it everything the link had already spawned. And the editor's
own viewports are switched off: nobody sees them, and each one renders the whole scene a second
time beside the link's capture.

The level. The project starts on the engine's tiny `Entry` map, so that startup loads nothing
worth waiting for. Then this editor opens the level that was open when it last ran, if that one
was saved (`Saved/BU/level.txt`, kept up to date while it runs), so a sky or a set dressed in
Unreal's window is still there next time. Otherwise, or with BU_HOST_LEVEL=blank, a new blank
level that nobody has saved. The link's own actors are transient: saving a level never writes
them into it.

A level that crashed the editor while it opened is not opened again: `level_opening.txt` names it
until it has finished opening, and still naming it at the next start means that start never
finished.

Saving needs the window and an editor started without `-unattended`: Unreal cancels every Save
and Save All in an unattended editor (`PromptForCheckoutAndSave` returns "cancelled" before
asking anyone), and lets it close without asking. That is also why BU's first attempt at a level
of its own failed to save (`new_level`, "Failed to save the new level").
"""

import json
import os
import sys
import time

ENV_PORT = "BU_HOST_PORT"
ENV_PARENT = "BU_HOST_PARENT"
ENV_STATUS = "BU_HOST_STATUS"
ENV_QUIT = "BU_HOST_QUIT"
ENV_LEVEL = "BU_HOST_LEVEL"
ENV_WINDOW = "BU_HOST_WINDOW"

# Beside the status file, in the render project's Saved/BU.
LEVEL_FILE = "level.txt"
OPENING_FILE = "level_opening.txt"

TICK_SECONDS = 0.5
STATUS_SECONDS = 1.0
# Engine frames between the startup steps. Nothing is waited on by the clock: the startup level
# is already open when this runs, and the level replaces it before the call that opens it
# returns. (Two fixed two-second waits used to stand here; they were a third of the start.)
# Engine frames, not tick calls: Slate also ticks inside engine frame 0, while the editor is
# still starting, and replacing the level then crashed it (an access violation in UnrealEd).
STEP_FRAMES = 10

_STATE = None


class _State(object):
    def __init__(self, port, parent, status_path, quit_path, start_level="last", window=False):
        self.port = port
        self.parent = parent
        self.status_path = status_path
        self.quit_path = quit_path
        self.start_level = start_level
        self.window = window
        folder = os.path.dirname(status_path) if status_path else ""
        self.level_file = os.path.join(folder, LEVEL_FILE) if folder else ""
        self.opening_file = os.path.join(folder, OPENING_FILE) if folder else ""
        self.remembered = level_to_remember(_read_text(self.level_file))
        self.phase = "loading"
        self.step_frame = None  # the engine frame the current startup step began on
        self.ticks = 0
        self.last_tick = 0.0
        self.last_status = 0.0
        self.handle = None
        self.parent_handle = None
        self.error = ""


def active(environ=None):
    environ = os.environ if environ is None else environ
    return bool(environ.get(ENV_PORT))


def _log(text):
    import unreal

    unreal.log("BU host: " + text)


def _warn(text):
    import unreal

    unreal.log_warning("BU host: " + text)


def _library():
    import unreal

    return getattr(unreal, "BULinkLibrary", None)


def _native(name):
    library = _library()
    return getattr(library, name, None) if library is not None else None


def _read_text(path):
    if not path:
        return ""
    try:
        with open(path, encoding="utf-8") as handle:
            return handle.read().strip()
    except OSError:
        return ""


def _write_text(path, text):
    if not path:
        return
    temporary = path + ".tmp"
    try:
        with open(temporary, "w", encoding="utf-8") as handle:
            handle.write(text + "\n")
        os.replace(temporary, path)
    except OSError:
        pass


def _remove(path):
    if path:
        try:
            os.remove(path)
        except OSError:
            pass


# -- watching Blender ----------------------------------------------------------------------------

def parent_alive(state):
    """False once Blender's process has ended. Windows only; elsewhere always True.

    Not `os.kill(pid, 0)`: on Windows that *terminates* the process. A handle opened once and
    waited on with no timeout says whether that exact process has exited, even if its ID has
    since been given to another one.
    """
    if not state.parent or sys.platform != "win32":
        return True
    import ctypes

    kernel32 = ctypes.windll.kernel32
    if state.parent_handle is None:
        synchronize = 0x00100000
        handle = kernel32.OpenProcess(synchronize, False, int(state.parent))
        if not handle:
            return False  # already gone before we looked
        state.parent_handle = handle
    wait_object_0 = 0
    return kernel32.WaitForSingleObject(state.parent_handle, 0) != wait_object_0


# -- status --------------------------------------------------------------------------------------

def status_record(state, shaders, link_connected, now):
    return {
        "state": state.phase,
        "shaders": int(shaders),
        "port": state.port,
        "pid": os.getpid(),
        "connected": bool(link_connected),
        "error": state.error,
        "level": state.remembered,
        "time": now,
    }


def _write_status(state, now):
    if not state.status_path:
        return
    shaders_left = _native("get_shader_jobs_remaining")
    try:
        shaders = shaders_left() if shaders_left is not None else 0
    except Exception:  # noqa: BLE001
        shaders = 0
    from . import bu_link

    link_state = bu_link._STATE
    record = status_record(state, shaders, link_state is not None and link_state.client is not None,
                           now)
    temporary = state.status_path + ".tmp"
    try:
        with open(temporary, "w", encoding="utf-8") as handle:
            json.dump(record, handle)
        os.replace(temporary, state.status_path)
    except OSError:
        pass


# -- the level and the viewports -----------------------------------------------------------------

def level_to_remember(world_path):
    """The level asset to reopen next time, from the editor world's path; "" for none. Pure.

    "/Game/Maps/Sky.Sky" -> "/Game/Maps/Sky". A level nobody has saved lives under /Temp/, and
    the engine's own (the Entry map BU starts on) under /Engine/: neither is reopened.
    """
    package = str(world_path or "").strip().split(".")[0]
    if not package.startswith("/") or package.count("/") < 2:
        return ""
    if package.startswith(("/Temp/", "/Engine/", "/Script/", "/Memory/")):
        return ""
    return package


def level_to_open(state):
    """The saved level to open at the start, or "" for a blank one.

    Not one that was being opened when the editor last stopped: that start never finished, most
    likely because opening it crashed the editor. A blank level this once, and it is said why.
    """
    if state.start_level != "last":
        return ""
    wanted = state.remembered
    if not wanted:
        return ""
    if level_to_remember(_read_text(state.opening_file)) == wanted:
        _remove(state.opening_file)
        state.error = ("{0} did not finish opening last time, so this start is a blank level. "
                       "Open it from Unreal's window, or save another".format(wanted))
        _warn(state.error)
        return ""
    return wanted


def _load_level(state, path):
    """Open a saved level. False when it is gone or would not open."""
    import unreal

    if not unreal.EditorAssetLibrary.does_asset_exist(path):
        _warn("the level {0} is gone; starting a blank one".format(path))
        return False
    _write_text(state.opening_file, path)
    try:
        # The subsystem's load runs as an unattended script: no "save the open level?" dialog.
        opened = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem).load_level(path)
    finally:
        _remove(state.opening_file)
    if not opened:
        _warn("could not open the level {0}; starting a blank one".format(path))
        return False
    _log("opened {0}, the level open when this editor last ran".format(path))
    return True


def _open_level(state):
    """Open the level the link renders in. Tried once.

    The last saved level, when there is one and BU_HOST_LEVEL allows it; otherwise a new blank
    level, never saved: no landscape to bury things, no sky to fight Blender's. If neither can be
    opened, the link runs in whatever level is open rather than not at all.
    """
    import unreal

    wanted = level_to_open(state)
    if wanted and _load_level(state, wanted):
        return True
    world = unreal.EditorLoadingAndSavingUtils.new_blank_map(False)
    if world is None:
        _warn("could not make a blank level; using the one that is open")
        return False
    return True


def _editor_world():
    import unreal

    return unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()


def _remember_level(state, world_path=None):
    """Note the open level, once it is a saved one, to reopen at the next start."""
    if not state.level_file:
        return
    if world_path is None:
        world = _editor_world()
        world_path = world.get_path_name() if world is not None else ""
    path = level_to_remember(world_path)
    if path and path != state.remembered:
        _write_text(state.level_file, path)
        state.remembered = path
        _log("next time this editor starts in {0}".format(path))


def _on_world_saved(_flags, world, success):
    """Unreal saved a level: remember it at once. A level saved from the "save before closing?"
    question is saved as the editor closes, after the last tick that would have noticed it."""
    state = _STATE
    if state is None or not success or world is None:
        return
    try:
        if world == _editor_world():
            _remember_level(state, world.get_path_name())
    except Exception as exc:  # noqa: BLE001
        _warn("could not note the saved level: {0}".format(exc))


def _watch_saves():
    import unreal

    try:
        unreal.get_editor_subsystem(unreal.LevelEditorSubsystem).on_post_save_world.add_callable(
            _on_world_saved)
        return True
    except Exception as exc:  # noqa: BLE001 - polling the open level still notices most saves
        _warn("could not watch for saved levels: {0}".format(exc))
        return False


def _frame_count(state):
    """The engine's frame number; without one to ask, the ticks counted so far."""
    import unreal

    try:
        return int(unreal.SystemLibrary.get_frame_count())
    except Exception:  # noqa: BLE001
        return state.ticks


def _assets_loading():
    """True while the asset registry's first scan runs: the link's mesh cache looks assets up."""
    import unreal

    try:
        return bool(unreal.AssetRegistryHelpers.get_asset_registry().is_loading_assets())
    except Exception:  # noqa: BLE001 - no registry to ask: nothing to wait for
        return False


def _viewports_realtime(on):
    switch = _native("set_editor_viewports_realtime")
    if switch is None:
        return 0
    try:
        return switch(bool(on))
    except Exception as exc:  # noqa: BLE001
        _warn("could not switch the editor viewports: {0}".format(exc))
        return 0


# -- lifecycle -----------------------------------------------------------------------------------

def _trampoline(delta_seconds):
    module = sys.modules.get(__name__)
    if module is not None:
        module._tick(delta_seconds)


def begin(environ=None):
    """Start hosting, from `init_unreal.py`. Does nothing unless Blender started this editor."""
    global _STATE
    environ = os.environ if environ is None else environ
    if not active(environ) or _STATE is not None:
        return False
    import unreal

    try:
        port = int(environ[ENV_PORT])
    except ValueError:
        _warn("bad {0}: {1!r}".format(ENV_PORT, environ.get(ENV_PORT)))
        return False
    try:
        parent = int(environ.get(ENV_PARENT) or 0)
    except ValueError:
        parent = 0
    start_level = "blank" if str(environ.get(ENV_LEVEL, "")).lower() == "blank" else "last"
    window = str(environ.get(ENV_WINDOW, "")) == "1"
    state = _State(port, parent, environ.get(ENV_STATUS, ""), environ.get(ENV_QUIT, ""),
                   start_level, window)
    state.handle = unreal.register_slate_post_tick_callback(_trampoline)
    _STATE = state
    _log("running as Blender's renderer (link port {0}, Blender pid {1})".format(port, parent))
    _write_status(state, time.time())
    return True


def _tick(_delta_seconds):
    state = _STATE
    if state is None:
        return
    now = time.time()
    stepped = False
    if state.phase in ("loading", "level"):
        # Every tick while starting, the steps count engine frames.
        state.ticks += 1
        frame = _frame_count(state)
        if state.step_frame is None:
            state.step_frame = frame
        stepped = frame - state.step_frame >= STEP_FRAMES
    elif now - state.last_tick < TICK_SECONDS:
        return
    state.last_tick = now
    try:
        if state.phase != "exiting":
            if not parent_alive(state):
                request_exit("Blender closed")
            elif state.quit_path and os.path.exists(state.quit_path):
                request_exit("Blender asked")
            elif state.phase == "loading" and stepped and not _assets_loading():
                state.phase = "level"
                state.step_frame = None
                _watch_saves()
                _open_level(state)
            elif state.phase == "level" and stepped:
                changed = _viewports_realtime(False)
                from . import bu_link

                bu_link.start(state.port)
                state.phase = "ready"
                _log("link listening; {0} editor viewport(s) no longer render".format(changed))
            elif state.phase == "ready" and now - state.last_status >= STATUS_SECONDS:
                _remember_level(state)
    except Exception as exc:  # noqa: BLE001 - a raising tick callback would spam every frame
        message = "{0}: {1}".format(type(exc).__name__, exc)
        if message != state.error:
            state.error = message
            _warn(message)
    if now - state.last_status >= STATUS_SECONDS or state.phase == "exiting":
        state.last_status = now
        _write_status(state, now)


def _close_window():
    """Close as the window's close button does, asking about unsaved work. False if it cannot."""
    close = _native("request_editor_close")
    if close is not None:
        close()
        return True
    # An older compiled module: the same command, run now rather than on the next frame.
    import unreal

    try:
        unreal.SystemLibrary.execute_console_command(None, "CLOSE_SLATE_MAINFRAME")
        return True
    except Exception as exc:  # noqa: BLE001
        _warn("could not close the window the usual way: {0}".format(exc))
        return False


def request_exit(reason):
    """Close this editor: stop the link, then exit.

    With its window shown, the way its close button does, so Unreal asks whether to save what
    was changed in it (and the person can say Cancel and keep working). Without a window there is
    nobody to ask, and nothing could have been changed by hand: it exits without asking.
    """
    state = _STATE
    if state is not None:
        if state.phase == "exiting":
            return
        state.phase = "exiting"
        _write_status(state, time.time())
    _log("closing ({0})".format(reason))
    from . import bu_link

    try:
        bu_link.stop()
    except Exception:  # noqa: BLE001
        pass
    if state is not None and state.window:
        try:
            _remember_level(state)
        except Exception:  # noqa: BLE001
            pass
        if _close_window():
            return
    leave = _native("request_editor_exit")
    if leave is not None:
        leave()
        return
    # No compiled module (another engine version): the editor's own quit would ask to save
    # the level the link filled, and nobody is there to answer.
    os._exit(0)
