# SPDX-License-Identifier: GPL-3.0-or-later
"""What a Blender material looks like, in the few numbers the real-time link sends.

The link does not translate node graphs. It reads the handful of values that decide how a plain
surface looks — base colour, metallic, roughness, specular, emission — from the shader plugged
into the material's output, and Unreal shows exactly those. A value driven by a node rather than
typed in has no single number, so it falls back to the material's Viewport Display setting, which
is the artist's own stand-in for "roughly this".

`textured` says the base colour comes from an image. When that image can be read from a file,
`texture` names the file — Unreal imports it once and shows it — with `nearest` for Blender's
Closest interpolation (pixel art). `mask` is the image driving the surface's Alpha (`cutout`
says there is one), with `channel` "alpha" for its Alpha output or "color" for its brightness.
An image painted or generated in Blender and never saved has no file, so its pixels are written
to one (`pixel_file`). `opacity` is a typed-in Alpha below one: see-through, not a cutout.

`maps` carries the other images: `metallic` and `roughness` (with the `channel` they read — a
packed map through Separate Color says "r", "g" or "b"), `normal` (a tangent-space Normal Map
node, with its `strength`) and `emission` (with the Emission Strength). A data map is sent only
when the image reaches the shader unchanged; through an Invert or a Math node it would be wrong,
so the typed-in value goes instead.

`transmission`, `ior`, `subsurface` (with `subsurface_tint`, and `subsurface_color` for an older
Unreal side), `coat` (with `coat_roughness`), `shader: "glass"` and `alpha_blend` (Render Method: Blended) are what Unreal's surface type is
chosen from; `surface` is the artist's own choice from BU's material panel (`link_surface`), and
`unreal_material` a project material to use instead.
"""

import hashlib
import os
import re
import struct
import tempfile
import zlib

# How far up the node graph to look for an image behind the base colour. Enough for a texture
# behind a mix, a colour ramp and a mapping chain; small enough that a pathological graph costs
# nothing noticeable on the UI thread.
SEARCH_LIMIT = 32
PRECISION = 4


def _round(value):
    return round(float(value), PRECISION)


def _colour(values):
    return [_round(values[0]), _round(values[1]), _round(values[2])]


def _surface_socket(material):
    """The Surface input of the material's active output, or None."""
    tree = getattr(material, "node_tree", None)
    if tree is None:
        return None
    output = None
    for target in ("EEVEE", "ALL", "CYCLES"):
        try:
            output = tree.get_output_node(target)
        except (AttributeError, TypeError):
            output = None
        if output is not None:
            break
    if output is None:
        return None
    return output.inputs.get("Surface")


def _surface_node(material):
    """The shader node feeding the material's active output, or None."""
    surface = _surface_socket(material)
    if surface is None or not surface.is_linked:
        return None
    return surface.links[0].from_node


def _socket(node, *names):
    for name in names:
        socket = node.inputs.get(name)
        if socket is not None:
            return socket
    return None


def _value(node, names, fallback):
    """A typed-in socket value, or `fallback` when the socket is missing or driven by a node."""
    socket = _socket(node, *names)
    if socket is None or socket.is_linked:
        return fallback
    return socket.default_value


def _image_source(socket):
    """(image texture node, name of the output used) nearest behind this socket, or (None, None).

    The output matters for a mask: an image's *Alpha* is its alpha channel, while its *Color*
    plugged into a value socket is converted to brightness — the usual way a black-and-white JPG
    (which has no alpha at all) becomes a cutout.
    """
    if socket is None or not socket.is_linked:
        return None, None
    pending = list(socket.links)
    seen = 0
    while pending and seen < SEARCH_LIMIT:
        link = pending.pop(0)
        node = link.from_node
        seen += 1
        if node.type == "TEX_IMAGE" and getattr(node, "image", None) is not None:
            return node, link.from_socket.name
        for upstream in node.inputs:
            if upstream.is_linked:
                pending.extend(upstream.links)
    return None, None


def _image_node(socket):
    """The nearest image texture node behind this socket, or None."""
    return _image_source(socket)[0]


# What a data map may pass through on its way to the shader and still mean the image's own
# values. Anything else (an Invert, a Math node, a Color Ramp) changes them, and a map shown
# unchanged would be wrong rather than approximate — so the typed-in value is sent instead.
_TRANSPARENT = ("REROUTE",)
_SEPARATE = ("SEPARATE_COLOR", "SEPRGB")
_CHANNEL_OUTPUTS = {"Red": "r", "R": "r", "Green": "g", "G": "g", "Blue": "b", "B": "b"}


def _map_source(socket):
    """(image texture node, channel) feeding this value socket directly, or (None, None).

    `channel` is "alpha" for the image's Alpha, "color" for its Color (Blender converts it to
    brightness), or "r"/"g"/"b" through a Separate Color node — a packed metallic/roughness map.
    """
    if socket is None or not socket.is_linked:
        return None, None
    link = socket.links[0]
    channel = None
    for _ in range(SEARCH_LIMIT):
        node = link.from_node
        if node.type == "TEX_IMAGE":
            if getattr(node, "image", None) is None:
                return None, None
            if channel is None:
                channel = "alpha" if link.from_socket.name == "Alpha" else "color"
            return node, channel
        if node.type in _SEPARATE and channel is None and getattr(node, "mode", "RGB") == "RGB":
            channel = _CHANNEL_OUTPUTS.get(link.from_socket.name)
            if channel is None:
                return None, None
            upstream = _socket(node, "Color", "Image")
        elif node.type in _TRANSPARENT:
            upstream = node.inputs[0] if node.inputs else None
        else:
            return None, None
        if upstream is None or not upstream.is_linked:
            return None, None
        link = upstream.links[0]
    return None, None


def _map(socket):
    """The texture field for a data map behind this socket, with its `channel`, or None."""
    node, channel = _map_source(socket)
    found = texture(node) if node is not None else None
    if found is not None:
        found["channel"] = channel
    return found


def _normal_map(socket):
    """The normal map behind a Normal socket, with its `strength`, or None.

    Only a tangent-space Normal Map node fed straight by an image: object- and world-space maps
    mean something Unreal's tangent-space normal input cannot show. A Bump node in between is
    walked through to its own Normal input; its Height is not carried (Unreal has no height
    input).
    """
    for _ in range(4):
        if socket is None or not socket.is_linked:
            return None
        node = socket.links[0].from_node
        if node.type == "BUMP":
            socket = _socket(node, "Normal")
            continue
        if node.type != "NORMAL_MAP" or getattr(node, "space", "TANGENT") != "TANGENT":
            return None
        image_socket = _socket(node, "Color")
        if image_socket is None or not image_socket.is_linked:
            return None
        image_node = image_socket.links[0].from_node
        if image_node.type != "TEX_IMAGE" or getattr(image_node, "image", None) is None:
            return None
        found = texture(image_node)
        if found is None:
            return None
        found["linear"] = True
        strength = _socket(node, "Strength")
        found["strength"] = _round(strength.default_value
                                   if strength is not None and not strength.is_linked else 1.0)
        return found
    return None


# Shaders `describe` reads directly; anything else may be layered Principled BSDFs.
_SINGLE_SHADERS = ("BSDF_GLASS", "EMISSION", "BSDF_DIFFUSE", "BSDF_GLOSSY", "BSDF_METALLIC")

SURFACES = ("opaque", "masked", "translucent", "glass", "subsurface", "foliage", "clearcoat",
            "unlit")


def auto_surface(spec):
    """The surface these settings imply. Pure.

    Must match Unreal's `bu_link_material.auto_surface`, which makes the actual choice when the
    artist leaves the panel on Auto (`tests/test_link.py` checks the two agree).
    """
    def number(key, fallback):
        try:
            return float(spec.get(key, fallback))
        except (TypeError, ValueError):
            return fallback

    if spec.get("shader") == "glass" or number("transmission", 0.0) > 0.01:
        return "glass"
    if number("opacity", 1.0) < 0.999:
        return "translucent"
    mask = spec.get("mask")
    found = spec.get("texture")
    if (isinstance(mask, dict) and mask.get("path")) or spec.get("alpha_graph") or (
            spec.get("cutout") and isinstance(found, dict) and found.get("path")):
        return "translucent" if spec.get("alpha_blend") else "masked"
    if number("subsurface", 0.0) > 0.01:
        return "subsurface"
    if number("coat", 0.0) > 0.01:
        return "clearcoat"
    return "opaque"


def _uses_image(socket):
    """True when an image texture sits anywhere behind this socket."""
    return _image_node(socket) is not None


# Packed images written out once per session, by (image name, packed size).
_PACKED = {}
# Images written from their pixels: image name -> (epoch, path, stamp). `images_changed` bumps
# the epoch when Blender reports an image edit, and only then are the pixels read again.
_PIXELS = {}
_EPOCH = [0]
EXTENSIONS = {"PNG": ".png", "JPEG": ".jpg", "TARGA": ".tga", "TARGA_RAW": ".tga", "BMP": ".bmp",
              "OPEN_EXR": ".exr", "HDR": ".hdr", "TIFF": ".tif"}
# What Unreal's texture importer reads. Anything else Blender can open — WebP above all, which
# 5.8 refuses ("could not import ... .webp as a texture") — is sent as a PNG of its pixels.
IMPORTABLE = set(EXTENSIONS)


def packed_folder():
    folder = os.path.join(tempfile.gettempdir(), "bu_link_textures")
    os.makedirs(folder, exist_ok=True)
    return folder


def images_changed():
    """Blender reports an image edited (painting, a new generated image): read pixels again."""
    _EPOCH[0] += 1


def png_bytes(rgba):
    """An RGBA8 PNG from an (height, width, 4) uint8 array, top row first. Pure."""
    import numpy as np

    height, width = rgba.shape[:2]
    rows = np.zeros((height, width * 4 + 1), dtype=np.uint8)  # filter byte 0 on every row
    rows[:, 1:] = rgba.reshape(height, width * 4)

    def chunk(kind, data):
        return (struct.pack(">I", len(data)) + kind + data
                + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF))

    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(rows.tobytes(), 1)) + chunk(b"IEND", b""))


def pixel_file(image):
    """(path, stamp) of a PNG holding what Blender shows for this image, or None.

    For an image with no file Unreal can read: generated, painted and not saved, or in a format
    Unreal does not import (WebP). Read with one bulk
    call and written as 8-bit sRGB, which is what Unreal imports a PNG as. The path is stable per
    image, so Unreal re-imports into the same asset, and the stamp is a hash of the content, so
    it re-imports only when the picture really changed.
    """
    import numpy as np

    cached = _PIXELS.get(image.name)
    if cached and cached[0] == _EPOCH[0] and os.path.isfile(cached[1]):
        return cached[1], cached[2]
    width, height = (int(v) for v in image.size)
    channels = int(image.channels)
    if width <= 0 or height <= 0 or channels not in (3, 4):
        return None
    pixels = np.empty(width * height * channels, dtype=np.float32)
    image.pixels.foreach_get(pixels)
    pixels = pixels.reshape(height, width, channels)
    rgba = np.ones((height, width, 4), dtype=np.float32)
    rgba[..., :channels] = pixels
    if image.is_float:
        # Float buffers hold linear values; a PNG holds sRGB.
        linear = np.clip(rgba[..., :3], 0.0, 1.0)
        rgba[..., :3] = np.where(linear <= 0.0031308, linear * 12.92,
                                 1.055 * np.power(linear, 1.0 / 2.4) - 0.055)
    data = png_bytes((np.clip(rgba[::-1], 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8))
    stamp = hashlib.sha1(data).hexdigest()[:16]
    stem = re.sub(r"[^A-Za-z0-9_]", "_", image.name)[:40]
    path = os.path.join(packed_folder(), "pixels_{0}_{1}.png".format(
        stem, hashlib.sha1(image.name.encode("utf-8")).hexdigest()[:8]))
    if not (cached and cached[2] == stamp and os.path.isfile(path)):
        with open(path, "wb") as handle:
            handle.write(data)
    _PIXELS[image.name] = (_EPOCH[0], path, stamp)
    return path, stamp


def image_file(image):
    """A file Unreal can import for this image, or None.

    An image on disk is used where it is. A packed one is written out once, from the original
    file bytes Blender keeps (not re-encoded, so nothing about it changes). A generated,
    painted-and-unsaved or WebP one is written from its pixels (`pixel_file`). Tiles and movies have no
    single picture and return None.
    """
    if image is None or image.source not in ("FILE", "GENERATED"):
        return None
    if (image.source == "GENERATED" or getattr(image, "is_dirty", False)
            or image.file_format not in IMPORTABLE):
        found = pixel_file(image)
        return found[0] if found else None
    packed = getattr(image, "packed_file", None)
    if packed is not None:
        key = (image.name, packed.size)
        written = _PACKED.get(key)
        if written and os.path.isfile(written):
            return written
        data = bytes(packed.data)
        extension = EXTENSIONS.get(image.file_format, os.path.splitext(image.filepath)[1] or ".png")
        digest = hashlib.sha1(data).hexdigest()[:12]
        written = os.path.join(packed_folder(), digest + extension)
        if not os.path.isfile(written):
            with open(written, "wb") as handle:
                handle.write(data)
        _PACKED[key] = written
        return written
    try:
        import bpy

        path = bpy.path.abspath(image.filepath, library=image.library)
    except Exception:  # noqa: BLE001 - outside Blender, or a path Blender cannot resolve
        path = image.filepath
    path = os.path.normpath(path) if path else ""
    return path if path and os.path.isfile(path) else None


def texture(node):
    """{"path", "stamp", "nearest"} for an image texture node with a file, else None.

    `stamp` changes when the file does, so editing the image on disk sends it again.
    """
    image = getattr(node, "image", None)
    path = image_file(image)
    if path is None:
        return None
    painted = _PIXELS.get(image.name)
    if painted and painted[1] == path:
        stamp = painted[2]
    else:
        try:
            info = os.stat(path)
            stamp = "{0}-{1}".format(int(info.st_mtime), info.st_size)
        except OSError:
            return None
    found = {"path": path, "stamp": stamp,
             "nearest": getattr(node, "interpolation", "Linear") == "Closest"}
    if image.colorspace_settings.is_data:
        found["linear"] = True  # Non-Color: Unreal must not decode it as sRGB
    else:
        # Unreal needs it for 16-bit images, which it reads as linear unless told (`bu_link_material`).
        found["colorspace"] = str(image.colorspace_settings.name)
    return found


def _texture_fields(spec, colour_socket, alpha_socket=None):
    node = _image_node(colour_socket)
    spec["textured"] = node is not None
    if node is not None:
        found = texture(node)
        if found is not None:
            spec["texture"] = found
    # The mask is whatever image drives Alpha — the colour image or another one — read from
    # its alpha channel or its brightness, depending on which output is plugged in.
    mask_node, output = _image_source(alpha_socket)
    mask = texture(mask_node) if mask_node is not None else None
    if mask is not None:
        mask["channel"] = "alpha" if output == "Alpha" else "color"
        spec["mask"] = mask
    spec["cutout"] = mask is not None


def _node_fields(spec, material, shader, emission_strength, layers=None):
    """The node graphs behind the shader's inputs, translated for Unreal (`link_nodes`)."""
    settings = getattr(material, "bu_link", None)
    mode = str(getattr(settings, "nodes", "TRANSLATE") or "TRANSLATE")
    if mode == "OFF":
        return
    try:
        from . import link_nodes
    except ImportError:  # loaded by path in the plain-CPython tests
        import link_nodes
    covered = set()
    if mode == "BAKE":
        # Baked inputs are plain maps; any not baked yet are translated meanwhile.
        try:
            from . import link_bake
        except ImportError:  # loaded by path in the plain-CPython tests
            import link_bake
        covered = link_bake.apply(spec, material)
        if "EmissiveColor" in covered:
            spec["maps"]["emission"]["strength"] = _round(emission_strength)
        if "Opacity" in covered:
            spec["alpha_graph"] = True
    fields, failed = link_nodes.translate(material, shader, skip=covered, layers=layers)
    if failed:
        spec["graph_skipped"] = failed
    if not fields:
        return
    scaled = fields.pop("graph_emission_scaled", False)
    spec.update(fields)
    channels = fields["graph"]["out"]
    if "Opacity" in channels:
        spec["alpha_graph"] = True
    if "EmissiveColor" in channels:
        # A driven strength is already multiplied into the graph's colour.
        spec["emission_strength"] = 1.0 if scaled else _round(emission_strength)


def _choice_fields(spec, material):
    """The surface the artist picked in BU's material panel (`link_surface`), if any."""
    settings = getattr(material, "bu_link", None)
    surface = str(getattr(settings, "surface", "AUTO") or "AUTO").lower()
    if surface == "unreal":
        path = str(getattr(settings, "unreal_material", "") or "").strip()
        if path:
            spec["surface"] = "unreal"
            spec["unreal_material"] = path
    elif surface in SURFACES:
        spec["surface"] = surface
    if getattr(settings, "refraction", False) is True:
        spec["refraction"] = True


def describe(material, sources=None):
    """A material -> the dict sent to Unreal (without its name).

    `sources`, a dict, is filled with where each typed-in graph value was read from
    (`link_nodes.socket_source`, by parameter name), which the spec itself does not carry.
    """
    spec = _describe(material)
    found = spec.pop("graph_sources", None)
    if sources is not None and found:
        sources.update(found)
    return spec


def _describe(material):
    spec = {
        "color": [0.8, 0.8, 0.8],
        "metallic": 0.0,
        "roughness": 0.5,
        "specular": 0.5,
        "emission": [0.0, 0.0, 0.0],
        "textured": False,
    }
    if material is None:
        return spec

    display = tuple(material.diffuse_color)[:3]
    spec["color"] = _colour(display)
    spec["metallic"] = _round(material.metallic)
    spec["roughness"] = _round(material.roughness)
    _choice_fields(spec, material)
    # Blended (rather than Dithered) is Blender 4.2+'s "really see-through": an image's alpha
    # then means translucency, not a cutout.
    if getattr(material, "surface_render_method", "DITHERED") == "BLENDED":
        spec["alpha_blend"] = True
        if not getattr(material, "use_transparency_overlap", True):
            # Transparency Overlap off: only the nearest surface is drawn, not the far side
            # behind it (an eyeball's inside).
            spec["front_only"] = True

    node = _surface_node(material)
    if node is None:
        return spec
    try:
        from . import link_nodes
    except ImportError:  # loaded by path in the plain-CPython tests
        import link_nodes
    layers = None
    if node.type in ("BSDF_TRANSPARENT", "HOLDOUT"):
        # Nothing to see (a particle emitter's box, a hidden helper): clipped away entirely. A
        # holdout cuts a hole in Blender's picture, which Unreal's cannot have.
        spec["opacity"] = 0.0
        spec.setdefault("surface", "masked")
        return spec
    if node.type in link_nodes.LEAF_INPUTS and node.type != "EMISSION":
        # One shader on its own: one layer, so its wired inputs are translated as a
        # Principled BSDF's are.
        layers = ("bsdf", node, ())
    elif node.type != "BSDF_PRINCIPLED" and node.type not in _SINGLE_SHADERS:
        # Mixed Principled BSDFs (decals, grime layers), maybe inside node groups: the base
        # one describes the surface, and the inputs that differ are translated through the
        # mixes (`link_nodes`). Glass, Diffuse, Emission and the like mix in too (a beacon's
        # glow faded into its glass).
        layers = link_nodes.surface_layers(material)
        if layers is not None:
            node = link_nodes.base_layer(layers)
            spec["layers"] = len(link_nodes._leaves(layers))
            lens = link_nodes.see_through_glass(layers)
            if lens is not None:
                # Glass mixed by fixed amounts with what is mostly see-through (Lefty's eye
                # lens: half Glass, half a dark metal at Alpha 0.25): that glass alone. Mixed
                # into one Unreal surface, the metal's colour and metalness covered the whole
                # lens, a pale mirror where Blender's is clear.
                layers = lens
                node = lens[1]
            if link_nodes.clear_gloss(material):
                spec["clear_gloss"] = True
        else:
            # Not drawn as Blender draws it: said so, rather than left plain grey unexplained.
            spec["graph_skipped"] = {"Surface": "{0} ({1}) is not translated".format(
                node.name, getattr(node, "bl_label", node.type))}
            return spec

    if node.type == "BSDF_PRINCIPLED":
        _texture_fields(spec, _socket(node, "Base Color"), _socket(node, "Alpha"))
        alpha = _socket(node, "Alpha")
        if alpha is not None and not alpha.is_linked and float(alpha.default_value) < 0.999:
            spec["opacity"] = _round(max(0.0, float(alpha.default_value)))
        spec["color"] = _colour(_value(node, ("Base Color",), display))
        spec["metallic"] = _round(_value(node, ("Metallic",), material.metallic))
        spec["roughness"] = _round(_value(node, ("Roughness",), material.roughness))
        spec["specular"] = _round(min(1.0, max(0.0, _value(
            node, ("Specular IOR Level", "Specular"), 0.5))))
        glow = _value(node, ("Emission Color", "Emission"), (0.0, 0.0, 0.0))
        strength = float(_value(node, ("Emission Strength",), 0.0))
        spec["emission"] = _colour([channel * strength for channel in tuple(glow)[:3]])
        maps = {}
        for key, names in (("metallic", ("Metallic",)), ("roughness", ("Roughness",))):
            found = _map(_socket(node, *names))
            if found is not None:
                maps[key] = found
        normal = _normal_map(_socket(node, "Normal"))
        if normal is not None:
            maps["normal"] = normal
        glow_node = _image_node(_socket(node, "Emission Color", "Emission"))
        glow_map = texture(glow_node) if glow_node is not None else None
        if glow_map is not None and strength > 0.0:
            glow_map["strength"] = _round(strength)
            maps["emission"] = glow_map
        if maps:
            spec["maps"] = maps
        for key, names in (("transmission", ("Transmission Weight", "Transmission")),
                           ("subsurface", ("Subsurface Weight", "Subsurface")),
                           ("coat", ("Coat Weight", "Coat"))):
            amount = float(_value(node, names, 0.0))
            if amount > 0.0:
                spec[key] = _round(amount)
            elif key == "coat" and getattr(_socket(node, *names), "is_linked", False):
                # A coat amount from nodes: a coated surface, the graph giving the amount.
                spec[key] = 1.0
        if spec.get("transmission"):
            spec["ior"] = _round(_value(node, ("IOR",), 1.5))
        if spec.get("coat"):
            spec["coat_roughness"] = _round(_value(node, ("Coat Roughness",), 0.03))
        # Sheen: a soft layer that brightens grazing angles (Ennard's powdery mask). Unreal's
        # Fuzz, on Substrate. Wired, its amount comes from the graph.
        sheen = _socket(node, "Sheen Weight")
        if sheen is not None and (sheen.is_linked or float(sheen.default_value) > 0.0):
            spec["sheen"] = 1.0 if sheen.is_linked else _round(float(sheen.default_value))
            spec["sheen_roughness"] = _round(_value(node, ("Sheen Roughness",), 0.5))
            spec["sheen_tint"] = _colour(_value(node, ("Sheen Tint",), (1.0, 1.0, 1.0)))
        _node_fields(spec, material, node, strength, layers)
        if spec.get("subsurface"):
            radius = tuple(_value(node, ("Subsurface Radius",), (1.0, 0.2, 0.1)))[:3]
            largest = max(radius) or 1.0
            # Blender scatters the base colour, texture and all, further in some channels than
            # others (the radius). Unreal's master multiplies its own base colour by this tint.
            # `subsurface_color`, the unplugged colour tinted, is for an older Unreal side: on a
            # textured material it was white or grey, and the skin scattered white.
            spec["subsurface_tint"] = _colour([r / largest for r in radius])
            spec["subsurface_color"] = _colour(
                [c * r / largest for c, r in zip(spec["color"], radius)])
    elif node.type == "BSDF_GLASS":
        _texture_fields(spec, _socket(node, "Color"))
        spec["shader"] = "glass"
        spec["color"] = _colour(_value(node, ("Color",), display))
        spec["metallic"] = 0.0
        spec["roughness"] = _round(_value(node, ("Roughness",), 0.0))
        spec["ior"] = _round(_value(node, ("IOR",), 1.5))
        spec["transmission"] = 1.0
        _node_fields(spec, material, node, 0.0, layers)
    elif node.type == "EMISSION":
        glow = _value(node, ("Color",), display)
        strength = float(_value(node, ("Strength",), 1.0))
        spec["color"] = [0.0, 0.0, 0.0]
        spec["emission"] = _colour([channel * strength for channel in tuple(glow)[:3]])
        # An image in the Color (the cafe's menu boards) glows as that image, as a Principled's
        # Emission Color map does; anything more than a plain image goes through the graph.
        glow_node = _image_node(_socket(node, "Color"))
        glow_map = texture(glow_node) if glow_node is not None else None
        if glow_map is not None and strength > 0.0:
            glow_map["strength"] = _round(strength)
            spec["maps"] = {"emission": glow_map}
        _node_fields(spec, material, node, strength, layers)
    elif node.type in ("BSDF_DIFFUSE", "BSDF_TRANSLUCENT"):
        # Translucent: light through a thin sheet (paper, a leaf). Unreal's nearest is a plain
        # diffuse surface; the light coming through from behind is lost.
        _texture_fields(spec, _socket(node, "Color"))
        spec["color"] = _colour(_value(node, ("Color",), display))
        spec["metallic"] = 0.0
        spec["roughness"] = 1.0
        spec["specular"] = 0.0
        _node_fields(spec, material, node, 0.0, layers)
    elif node.type in ("BSDF_GLOSSY", "BSDF_ANISOTROPIC", "BSDF_METALLIC"):
        _texture_fields(spec, _socket(node, "Color", "Base Color"))
        spec["color"] = _colour(_value(node, ("Color", "Base Color"), display))
        spec["metallic"] = 1.0
        spec["roughness"] = _round(_value(node, ("Roughness",), material.roughness))
        _node_fields(spec, material, node, 0.0, layers)
    elif node.type in ("BSDF_HAIR_PRINCIPLED", "BSDF_HAIR"):
        # A hair shader on a mesh: a rough surface of the hair's colour (`link_nodes`).
        from_colour = (node.type == "BSDF_HAIR"
                       or getattr(node, "parametrization", "COLOR") == "COLOR")
        if from_colour:
            _texture_fields(spec, _socket(node, "Color"))
            spec["color"] = _colour(_value(node, ("Color",), display))
        else:
            spec["color"] = _colour(link_nodes.hair_colour(node))
        spec["metallic"] = 0.0
        spec["roughness"] = _round(_value(node, ("Roughness", "RoughnessU"), 0.3))
        spec["specular"] = _round(link_nodes.leaf_input(node, "Specular IOR Level"))
        _node_fields(spec, material, node, 0.0, layers)
    elif node.type == "BSDF_REFRACTION":
        _texture_fields(spec, _socket(node, "Color"))
        spec["shader"] = "glass"
        spec["color"] = _colour(_value(node, ("Color",), display))
        spec["metallic"] = 0.0
        spec["roughness"] = _round(_value(node, ("Roughness",), 0.0))
        spec["ior"] = _round(_value(node, ("IOR",), 1.5))
        spec["transmission"] = 1.0
        _node_fields(spec, material, node, 0.0, layers)
    return spec
