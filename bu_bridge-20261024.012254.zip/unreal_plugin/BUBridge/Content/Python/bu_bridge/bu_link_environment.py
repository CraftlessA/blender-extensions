# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender's sky, fog and camera settings as Unreal actors, for the real-time link.

Blender sends one `environment` message (its `link_lighting.describe_environment`) whenever its
World or BU's Sky & Fog or Camera settings change. This module keeps BU's own actors in step
with it: each is spawned when asked for, updated in place, and removed when switched off.

* **Sky from the World** — a sky dome (a large sphere, `M_BU_SkyDome_v1`, flagged *Is Sky*)
  showing the World's colour or HDRI, and a Sky Light with real-time capture, which captures
  that dome. The scene is therefore lit by the very picture it shows, as in Blender. The HDRI
  is looked up by view direction (equirectangular, as Blender's Environment Texture), so the
  dome has no parallax and no size to outgrow. Values arrive in nits (W/(m² sr) x 683, as the
  lights are converted).
* **Physical sky** — Unreal's Sky Atmosphere and a real-time Sky Light; the Blender sun, flagged
  *Atmosphere Sun*, sets its colour and time of day.
* **Clouds** — a Volumetric Cloud with a dynamic instance of the engine's own cloud material
  (`m_SimpleVolumetricCloud_Inst`), its coverage, density, size and colour set from Blender
  (`cloud_settings`). The real-time Sky Light captures them, so they dim the ground as well as
  shading it through the sun's cloud shadows. Blender has nothing like them: Unreal only.
* **Height fog** — an Exponential Height Fog, with volumetric fog if asked.
* **Camera** — an unbound Post Process Volume at high priority, so the editor viewport and
  the picture in Blender expose alike.

While BU's sky or fog is on, the level's own can be hidden (`set_is_temporarily_hidden_in_editor`:
the editor's H key, never saved), and shown again when BU's is switched off. Only actors that
were visible are hidden, so nothing the user hid is ever shown by BU.

BU's actors are transient and tagged `BU_Env` (not the live meshes' tag, so the stray-actor
sweep leaves them alone), and Import from Unreal leaves them out.
"""

import math

from . import bu_link_editor, bu_link_material

TAG = "BU_Env"
ROLE_PREFIX = "BU_Env:"
FOLDER = "BU Live"
SKY_MATERIAL_NAME = "M_BU_SkyDome_v1"
DOME_MESH = "/Engine/BasicShapes/Sphere.Sphere"
LINEAR_DEFAULTS = bu_link_material.LINEAR_DEFAULTS
# The engine sphere is 1 m across: 10 km across, centred on the origin. The look-up ignores
# where the dome is, so only its being behind everything matters.
DOME_SCALE = 10000.0
SKY_GROUPS = ("SkyLight", "SkyAtmosphere")
CLOUD_GROUPS = ("VolumetricCloud",)
CLOUD_MATERIAL = "/Engine/EngineSky/VolumetricClouds/m_SimpleVolumetricCloud_Inst"
# The engine material's own values, which Blender's 1s stand for. Measured looking up at a
# physical sky: coverage -0.5 is a clear sky, -0.2 (the default) scattered cumulus, 0.1 mostly
# cloud and 0.4 overcast; density 0.002 is wispy and 0.03 solid; a global scale of 64 instead of
# 256 makes the same clouds a quarter the size.
CLOUD_COVERAGE_CLEAR = -0.5
CLOUD_COVERAGE_OVERCAST = 0.4
CLOUD_DENSITY = 0.008
CLOUD_SCALE = 256.0
# The material's wind: direction and drift in RGB, speed in alpha (default 1/3). Stopped: the
# picture only re-renders after a change, so drifting clouds jumped to somewhere new with every
# edit (half the sky's pixels changed between two captures 12 s apart; 0.4% stopped).
CLOUD_WIND_STILL = (1.0, 1.0, 0.5, 0.0)
SKY_NAME_HINTS = ("SkySphere", "Sky_Sphere", "HDRIBackdrop")
FOG_GROUPS = ("ExponentialHeightFog",)
SUN_GROUPS = ("DirectionalLight",)
POST_PRIORITY = 10000.0
# Unreal's manual exposure with the physical camera off is exp2(bias); EV100 E means a scale of
# 1 / (1.2 x 2^E) (the standard calibration Unreal's physical camera uses).
EV_CALIBRATION = math.log2(1.2)

try:
    _ENV  # noqa: B018 - survives importlib.reload on purpose
except NameError:
    _ENV = {}
for _key, _default in (("actors", {}), ("hidden", {}), ("dome_material", None)):
    _ENV.setdefault(_key, _default)


def _number(value, fallback=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return fallback


def _colour(value, fallback=(1.0, 1.0, 1.0)):
    try:
        values = [max(0.0, float(v)) for v in value][:3]
    except (TypeError, ValueError):
        return tuple(fallback)
    return tuple(values) if len(values) == 3 else tuple(fallback)


def srgb_byte(value):
    """A linear 0-1 value as an sRGB byte. Pure."""
    value = min(1.0, max(0.0, float(value)))
    encoded = value * 12.92 if value <= 0.0031308 else 1.055 * value ** (1.0 / 2.4) - 0.055
    return int(round(encoded * 255.0))


def plan(spec):
    """What BU's actors should be for an environment message. Pure.

    Returns {"sky_light", "atmosphere", "dome", "fog", "post": settings or None,
    "hide": {"sky", "fog", "suns": bool}}.
    """
    spec = spec or {}
    sky = str(spec.get("sky") or "OFF").upper()
    found = {"sky_light": None, "atmosphere": None, "dome": None, "clouds": None, "fog": None,
             "post": None}
    if sky in ("WORLD", "PHYSICAL"):
        found["sky_light"] = {"intensity": max(0.0, _number(spec.get("sky_intensity"), 1.0)),
                              "lower_black": bool(spec.get("lower_black"))}
    if sky == "PHYSICAL":
        found["atmosphere"] = {}
    if sky == "WORLD":
        texture = spec.get("sky_texture") or None
        found["dome"] = {"color": _colour(spec.get("sky_color"), (0.05, 0.05, 0.05)),
                         "texture": texture,
                         "strength": max(0.0, _number(spec.get("sky_strength"), 683.0)),
                         "rotation": _number(spec.get("sky_rotation"))}
    if spec.get("clouds"):
        found["clouds"] = cloud_settings(spec.get("clouds"))
    if spec.get("fog"):
        fog = {"fog_density": max(0.0, _number(spec.get("fog_density"), 0.02)),
               "fog_height_falloff": max(0.001, _number(spec.get("fog_falloff"), 0.2)),
               "fog_inscattering_luminance": _colour(spec.get("fog_color"), (0.45, 0.55, 0.7)),
               "fog_max_opacity": min(1.0, max(0.0, _number(spec.get("fog_opacity"), 1.0))),
               "start_distance": max(0.0, _number(spec.get("fog_start"))) * 100.0,
               "enable_volumetric_fog": bool(spec.get("volumetric")),
               "height_cm": _number(spec.get("fog_height")) * 100.0}
        if spec.get("volumetric"):
            fog.update({
                "volumetric_fog_scattering_distribution": min(0.9, max(-0.9, _number(
                    spec.get("vol_scattering"), 0.2))),
                "volumetric_fog_albedo": _colour(spec.get("vol_albedo")),
                "volumetric_fog_extinction_scale": max(0.1, _number(spec.get("vol_extinction"), 1.0)),
                "volumetric_fog_distance": max(100.0, _number(spec.get("vol_distance"), 60.0) * 100.0),
            })
        found["fog"] = fog
    if spec.get("post"):
        found["post"] = post_settings(spec)
    hide_sky = bool(sky in ("WORLD", "PHYSICAL") and spec.get("hide_level_sky", True))
    found["hide"] = {
        "sky": hide_sky,
        # BU's own clouds replace the level's, or two layers would overlap.
        "clouds": bool(hide_sky or spec.get("clouds")),
        "fog": bool(spec.get("fog") and spec.get("hide_level_fog", True)),
        "suns": bool(spec.get("hide_level_suns")),
    }
    return found


def cloud_settings(clouds):
    """The Volumetric Cloud's component settings (km) and material parameters. Pure."""
    clouds = clouds if isinstance(clouds, dict) else {}
    coverage = min(1.0, max(0.0, _number(clouds.get("coverage"), 1.0 / 3.0)))
    return {
        "layer_bottom_altitude": max(0.0, _number(clouds.get("bottom"), 5000.0)) / 1000.0,
        "layer_height": max(0.1, _number(clouds.get("thickness"), 10000.0) / 1000.0),
        "scalars": {
            "Cloud_GlobalCoverage": CLOUD_COVERAGE_CLEAR + coverage * (
                CLOUD_COVERAGE_OVERCAST - CLOUD_COVERAGE_CLEAR),
            "Cloud_GlobalDensity": CLOUD_DENSITY * max(0.0, _number(clouds.get("density"), 1.0)),
            "Layout_CloudGlobalScale": CLOUD_SCALE * max(0.05, _number(clouds.get("size"), 1.0)),
        },
        "vectors": {"Cloud_AlbedoColor": _colour(clouds.get("colour"), (0.98, 0.98, 0.98)) + (1.0,),
                    "Layout_WindControls": CLOUD_WIND_STILL},
    }


def post_settings(spec):
    """[(post-process setting, value)] for the camera part of a message. Pure.

    Each is applied with its `override_` flag set. Enum values are member names.
    """
    compensation = _number(spec.get("compensation"))
    found = []
    if str(spec.get("exposure") or "AUTO").upper() == "MANUAL":
        found.append(("auto_exposure_method", ("AutoExposureMethod", "AEM_MANUAL")))
        found.append(("auto_exposure_apply_physical_camera_exposure", False))
        found.append(("auto_exposure_bias",
                      compensation - _number(spec.get("ev100"), 10.0) - EV_CALIBRATION))
    else:
        found.append(("auto_exposure_bias", compensation))
    for key, name, fallback, low, high in (
            ("bloom", "bloom_intensity", 0.675, 0.0, 8.0),
            ("vignette", "vignette_intensity", 0.4, 0.0, 1.0),
            ("grain", "film_grain_intensity", 0.0, 0.0, 1.0),
            ("motion_blur", "motion_blur_amount", 0.5, 0.0, 1.0),
            ("white_temp", "white_temp", 6500.0, 1500.0, 15000.0)):
        found.append((name, min(high, max(low, _number(spec.get(key), fallback)))))
    for key, name in (("saturation", "color_saturation"), ("contrast", "color_contrast")):
        value = min(2.0, max(0.0, _number(spec.get(key), 1.0)))
        found.append((name, ("Vector4", value)))
    return found


# -- actors ----------------------------------------------------------------------------------------

def _world():
    import unreal

    return unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()


def _adopt():
    """BU's environment actors left by an earlier session of this editor."""
    import unreal

    if _ENV["actors"]:
        return
    try:
        actors = unreal.GameplayStatics.get_all_actors_with_tag(_world(), unreal.Name(TAG))
    except Exception:  # noqa: BLE001
        return
    for actor in actors:
        for tag in actor.tags:
            text = str(tag)
            if text.startswith(ROLE_PREFIX):
                _ENV["actors"][text[len(ROLE_PREFIX):]] = actor


def _actor(role, class_name):
    """BU's actor for a role, spawned if missing."""
    import unreal

    actor = _ENV["actors"].get(role)
    if bu_link_editor.alive(actor):
        return actor
    actor = bu_link_editor.spawn(getattr(unreal, class_name))
    if actor is None:
        raise RuntimeError("could not spawn the {0} for BU's {1}".format(class_name, role))
    actor.set_actor_label("BU_" + role)
    actor.set_editor_property("tags", [unreal.Name(TAG), unreal.Name(ROLE_PREFIX + role)])
    try:
        actor.set_folder_path(unreal.Name(FOLDER))
    except Exception:  # noqa: BLE001 - cosmetic
        pass
    _ENV["actors"][role] = actor
    return actor


def _remove(role):
    actor = _ENV["actors"].pop(role, None)
    if actor is not None:
        bu_link_editor.destroy(actor)
        return True
    return False


def _set(target, name, value):
    if target.get_editor_property(name) != value:
        target.set_editor_property(name, value)


def apply(spec):
    """Bring BU's environment actors in line with a message. Returns what changed, for the log."""
    import unreal

    _adopt()
    wanted = plan(spec)
    changed = []

    settings = wanted["sky_light"]
    if settings is None:
        if _remove("SkyLight"):
            changed.append("sky light off")
    else:
        actor = _actor("SkyLight", "SkyLight")
        light = actor.get_component_by_class(unreal.SkyLightComponent)
        light.set_mobility(unreal.ComponentMobility.MOVABLE)
        _set(light, "source_type", unreal.SkyLightSourceType.SLS_CAPTURED_SCENE)
        _set(light, "real_time_capture", True)
        _set(light, "lower_hemisphere_is_black", settings["lower_black"])
        light.set_intensity(settings["intensity"])
        changed.append("sky light")

    if wanted["atmosphere"] is None:
        if _remove("SkyAtmosphere"):
            changed.append("atmosphere off")
    else:
        _actor("SkyAtmosphere", "SkyAtmosphere")
        changed.append("atmosphere")

    dome = wanted["dome"]
    if dome is None:
        if _remove("SkyDome"):
            changed.append("sky dome off")
    else:
        _apply_dome(dome)
        changed.append("sky dome")

    clouds = wanted["clouds"]
    if clouds is None:
        if _remove("Clouds"):
            changed.append("clouds off")
    else:
        _apply_clouds(clouds)
        changed.append("clouds")

    fog = wanted["fog"]
    if fog is None:
        if _remove("HeightFog"):
            changed.append("fog off")
    else:
        actor = _actor("HeightFog", "ExponentialHeightFog")
        actor.set_actor_location(unreal.Vector(0.0, 0.0, fog["height_cm"]), False, True)
        component = actor.get_component_by_class(unreal.ExponentialHeightFogComponent)
        for name, value in fog.items():
            if name == "height_cm":
                continue
            if name == "fog_inscattering_luminance":
                value = unreal.LinearColor(*value, 1.0)
            elif name == "volumetric_fog_albedo":
                # An FColor, which Unreal reads as sRGB.
                r, g, b = [srgb_byte(c) for c in value]
                value = unreal.Color(r=r, g=g, b=b, a=255)
            _set(component, name, value)
        changed.append("fog")

    post = wanted["post"]
    if post is None:
        if _remove("PostProcess"):
            changed.append("camera off")
    else:
        actor = _actor("PostProcess", "PostProcessVolume")
        _set(actor, "unbound", True)
        _set(actor, "priority", POST_PRIORITY)
        _set(actor, "blend_weight", 1.0)
        found = actor.get_editor_property("settings")
        for name, value in post:
            if isinstance(value, tuple) and value[0] == "Vector4":
                value = unreal.Vector4(value[1], value[1], value[1], 1.0)
            elif isinstance(value, tuple):
                value = getattr(getattr(unreal, value[0]), value[1])
            found.set_editor_property("override_" + name, True)
            found.set_editor_property(name, value)
        actor.set_editor_property("settings", found)
        changed.append("camera")

    _hide_level(wanted["hide"])
    return changed


def _apply_clouds(clouds):
    import unreal

    actor = _actor("Clouds", "VolumetricCloud")
    component = actor.get_component_by_class(unreal.VolumetricCloudComponent)
    component.set_layer_bottom_altitude(clouds["layer_bottom_altitude"])
    component.set_layer_height(clouds["layer_height"])
    instance = component.get_editor_property("material")
    if not isinstance(instance, unreal.MaterialInstanceDynamic):
        parent = unreal.load_asset(CLOUD_MATERIAL)
        if parent is None:
            raise RuntimeError("the engine's cloud material is missing: " + CLOUD_MATERIAL)
        instance = unreal.MaterialLibrary.create_dynamic_material_instance(_world(), parent)
        component.set_material(instance)
    for name, value in clouds["scalars"].items():
        instance.set_scalar_parameter_value(name, value)
    for name, value in clouds["vectors"].items():
        instance.set_vector_parameter_value(name, unreal.LinearColor(*value))


def _apply_dome(dome):
    import unreal

    actor = _actor("SkyDome", "StaticMeshActor")
    component = actor.get_component_by_class(unreal.StaticMeshComponent)
    mesh = unreal.load_asset(DOME_MESH)
    if component.get_editor_property("static_mesh") != mesh:
        component.set_static_mesh(mesh)
        actor.set_actor_scale3d(unreal.Vector(DOME_SCALE, DOME_SCALE, DOME_SCALE))
        component.set_mobility(unreal.ComponentMobility.MOVABLE)
        # Behind everything, and nothing else: no shadow (it would put out the sun), no Lumen
        # or ray-traced surface (it would light the scene twice), no collision.
        for name, value in (("cast_shadow", False), ("affect_dynamic_indirect_lighting", False),
                            ("affect_distance_field_lighting", False),
                            ("visible_in_ray_tracing", False),
                            ("visible_in_real_time_sky_captures", True)):
            try:
                component.set_editor_property(name, value)
            except Exception:  # noqa: BLE001
                pass
        try:
            component.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
        except Exception:  # noqa: BLE001
            pass
    material = ensure_sky_material()
    instance = component.get_material(0)
    if not isinstance(instance, unreal.MaterialInstanceDynamic) or instance.get_editor_property(
            "parent") != material:
        instance = component.create_dynamic_material_instance(0, material)
    instance.set_vector_parameter_value("SkyColor", unreal.LinearColor(*dome["color"], 1.0))
    texture = None
    if dome["texture"]:
        texture = bu_link_material.load_texture(dome["texture"], role="hdr", wait=True)
    instance.set_scalar_parameter_value("UseTexture", 1.0 if texture is not None else 0.0)
    if texture is not None:
        instance.set_texture_parameter_value("SkyTexture", texture)
    instance.set_scalar_parameter_value("TextureStrength", dome["strength"])
    instance.set_scalar_parameter_value("Rotation", dome["rotation"])


def ensure_sky_material():
    """The sky dome's material: the World's colour or HDRI, by view direction. Built once."""
    import unreal

    path = "{0}/{1}".format(bu_link_material.PACKAGE, SKY_MATERIAL_NAME)
    if unreal.EditorAssetLibrary.does_asset_exist(path):
        found = unreal.EditorAssetLibrary.load_asset(path)
        if found is not None:
            return found
    material = unreal.AssetToolsHelpers.get_asset_tools().create_asset(
        SKY_MATERIAL_NAME, bu_link_material.PACKAGE, unreal.Material, unreal.MaterialFactoryNew())
    failed = build_sky_material(unreal, material)
    if failed:
        unreal.log_warning("BU: {0}: could not connect {1}".format(SKY_MATERIAL_NAME,
                                                                   ", ".join(failed)))
    unreal.MaterialEditingLibrary.recompile_material(material)
    unreal.EditorAssetLibrary.save_loaded_asset(material, only_if_is_dirty=False)
    return material


def build_sky_material(unreal, material):
    """Wire the dome's graph. Returns the connections that failed.

    The direction looked along is -CameraVector. Blender's equirectangular look-up is
    u = -atan2(y, x) / 2pi + 0.5, v = atan2(z, |xy|) / pi + 0.5 (v up). Unreal's Y is Blender's
    -Y and its texture V runs down, so u = atan2(y, x) / 2pi + 0.5 - rotation / 2pi and
    v = 0.5 - asin(z) / pi.
    """
    library = unreal.MaterialEditingLibrary
    failed = []
    position = {"y": -800}

    def new(cls_name, inputs=(), **props):
        position["y"] += 110
        found = library.create_material_expression(material, getattr(unreal, cls_name), -1600,
                                                   position["y"])
        for key, value in props.items():
            found.set_editor_property(key, value)
        names = list(library.get_material_expression_input_names(found) or [])
        for index, source in enumerate(inputs):
            if source is None:
                continue
            expression, output = source if isinstance(source, tuple) else (source, "")
            if not library.connect_material_expressions(expression, output, found, names[index]):
                failed.append("{0}.{1}".format(cls_name, names[index]))
        return found

    def param(cls_name, name, value):
        return new(cls_name, parameter_name=name, default_value=value)

    view = new("MaterialExpressionMultiply", [new("MaterialExpressionCameraVectorWS")],
               const_b=-1.0)
    x = new("MaterialExpressionComponentMask", [view], r=True, g=False, b=False, a=False)
    y = new("MaterialExpressionComponentMask", [view], r=False, g=True, b=False, a=False)
    z = new("MaterialExpressionComponentMask", [view], r=False, g=False, b=True, a=False)
    angle = new("MaterialExpressionArctangent2", [y, x])
    rotation = param("MaterialExpressionScalarParameter", "Rotation", 0.0)
    turned = new("MaterialExpressionSubtract", [angle, rotation])
    u = new("MaterialExpressionAdd", [new("MaterialExpressionMultiply", [turned],
                                          const_b=1.0 / (2.0 * math.pi))], const_b=0.5)
    v = new("MaterialExpressionAdd", [new("MaterialExpressionMultiply",
                                          [new("MaterialExpressionArcsine", [z])],
                                          const_b=-1.0 / math.pi)], const_b=0.5)
    uv = new("MaterialExpressionAppendVector", [u, v])
    sample = new("MaterialExpressionTextureSampleParameter2D", [uv], parameter_name="SkyTexture",
                 sampler_type=unreal.MaterialSamplerType.SAMPLERTYPE_LINEAR_COLOR)
    default = bu_link_material.linear_default()
    if default is not None:
        sample.set_editor_property("texture", default)
    else:
        failed.append("SkyTexture default (no linear texture found)")
    strength = param("MaterialExpressionScalarParameter", "TextureStrength", 683.0)
    lit = new("MaterialExpressionMultiply", [(sample, "RGB"), strength])
    colour = param("MaterialExpressionVectorParameter", "SkyColor",
                   unreal.LinearColor(0.05, 0.05, 0.05, 1.0))
    use = param("MaterialExpressionScalarParameter", "UseTexture", 0.0)
    emissive = new("MaterialExpressionLinearInterpolate", [(colour, "RGB"), lit, use])
    if not library.connect_material_property(emissive, "",
                                             unreal.MaterialProperty.MP_EMISSIVE_COLOR):
        failed.append("EmissiveColor")
    material.set_editor_property("shading_model", unreal.MaterialShadingModel.MSM_UNLIT)
    material.set_editor_property("two_sided", True)
    material.set_editor_property("is_sky", True)
    return failed


# -- the level's own ---------------------------------------------------------------------------

def group_of(class_name):
    """Which group of the level's lighting an actor class belongs to, or None. Pure."""
    if class_name in SKY_GROUPS or any(hint in class_name for hint in SKY_NAME_HINTS):
        return "sky"
    if class_name in CLOUD_GROUPS:
        return "clouds"
    if class_name in FOG_GROUPS:
        return "fog"
    if class_name in SUN_GROUPS:
        return "suns"
    return None


def _hide_level(hide):
    import unreal

    for group, wanted in hide.items():
        hidden = _ENV["hidden"].setdefault(group, [])
        if not wanted:
            for actor in hidden:
                if bu_link_editor.alive(actor):
                    actor.set_is_temporarily_hidden_in_editor(False)
            hidden[:] = []
            continue
        subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
        for actor in subsystem.get_all_level_actors() or []:
            try:
                tags = [str(tag) for tag in actor.tags]
                class_name = actor.get_class().get_name()
            except Exception:  # noqa: BLE001
                continue
            if TAG in tags or "BU_Live" in tags or group_of(class_name) != group:
                continue
            if actor in hidden or actor.is_temporarily_hidden_in_editor():
                continue  # hidden by BU already, or by the user: theirs to show
            actor.set_is_temporarily_hidden_in_editor(True)
            hidden.append(actor)


def restore_level():
    """Show everything BU hid. Called when the link stops."""
    _hide_level({group: False for group in list(_ENV["hidden"])})
