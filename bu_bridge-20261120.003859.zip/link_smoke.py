# SPDX-License-Identifier: GPL-3.0-or-later
"""Smoke and fire: a simulation's grids, worked out as Cycles shades them, for Unreal.

A gas simulation's domain (a Fluid modifier, Domain, Gas: Blender's Quick Smoke and Quick Fire)
is a box whose material is only a volume, so the link took it for a fog box (`link_lighting.
describe_volume`) and filled it evenly at the material's typed-in Density: a solid cube where
Cycles shows a plume. Cycles reads the simulation's grids instead, by name: Principled Volume's
Density Attribute ("density"), Color Attribute and Temperature Attribute ("temperature"), and
any Attribute or Volume Info node in the graph ("flame", "heat", ...).

So the grids are read here (`read_fluid`: the evaluated domain's, as Cycles gets them, in 10 ms
for 27 x 27 x 48 cells) and the material worked out on them per cell (`shade`), with Cycles' own
Principled Volume:

    density   = Density x density attribute
    colour    = Color x colour attribute
    emission  = Emission Color x Emission Strength
              + Blackbody Tint x sigma x mix(1, T^4, Blackbody Intensity) x blackbody(T),
                T = Temperature x temperature attribute, sigma = 5.670373e-14 / pi
    extinction and albedo as Unreal's fog takes them (`bu_link_fog.extinction`)

A wired input is worked out on the grids too (`GridChain`: `link_flatten`'s nodes, with the
Attribute and Volume Info nodes answering per cell): a Color Ramp on the flame, a Math on the
density. What cannot be worked out keeps its typed-in value and is named (`failed`).

Sent as one 3D texture of half floats, x fastest (`pack`): emission RGB and extinction per
metre, and a second of albedo when the colour varies. Unreal draws it as a Heterogeneous Volume
(`bu_link_smoke`), whose own local units are the grid's cells: Y is flipped here for Unreal's
axes, as `link_mesh.matrix_to_unreal` flips the object.

A Volume object (an OpenVDB file: Add > Volume > Import OpenVDB, an EmberGen or Houdini cache)
goes the same way, its grids read from the file through Blender's own `openvdb` module
(`read_vdb`) and shaded by its material, or by Cycles' default volume when it has none.
"""

import math

from . import link_flatten

# Blender's fluid grids by attribute name, as Cycles finds them on a domain.
FLUID_GRIDS = {"density": "density_grid", "flame": "flame_grid",
               "temperature": "temperature_grid", "heat": "heat_grid", "color": "color_grid"}
# Cycles' Principled Volume: sigma of the Stefan-Boltzmann law, as it scales blackbody emission.
STEFAN_BOLTZMANN = 5.670373e-8 * 1e-6 / math.pi
# The most cells sent (a 256^3 grid); a finer one is averaged down by twos until it fits.
MAX_CELLS = 256 ** 3
# The most cells read from a VDB file's grid (each one dense in memory while it is shaded).
MAX_READ_CELLS = 512 ** 3
# A VDB grid read as colour by these names (Houdini's Cd), as Cycles' Color Attribute finds it.
COLOUR_NAMES = ("color", "Cd")


class Unreadable(Exception):
    """A Volume object whose grids cannot be read here; the message says why."""


def domain(obj):
    """The Fluid modifier of a gas simulation's domain, or None."""
    for modifier in getattr(obj, "modifiers", ()):
        if modifier.type == "FLUID" and modifier.fluid_type == "DOMAIN":
            settings = modifier.domain_settings
            if settings is not None and settings.domain_type == "GAS":
                return modifier
    return None


def has_grids(obj):
    """A gas simulation's domain, or a Volume object (a VDB file): drawn from its grids."""
    if obj.type == "VOLUME":
        return True
    return obj.type == "MESH" and domain(obj) is not None


def read_fluid(evaluated):
    """{attribute name: array} of a domain's grids now, (z, y, x) or (z, y, x, 3) for colour,
    and the resolution (x, y, z); ({}, None) before the simulation has anything."""
    import numpy as np

    modifier = domain(evaluated)
    if modifier is None:
        return {}, None
    settings = modifier.domain_settings
    res = tuple(int(v) for v in settings.domain_resolution)
    cells = res[0] * res[1] * res[2]
    if cells <= 0:
        return {}, None
    grids = {}
    for name, prop in FLUID_GRIDS.items():
        try:
            values = np.asarray(getattr(settings, prop), dtype=np.float32)
        except Exception:  # noqa: BLE001 - a grid this simulation does not keep
            continue
        if values.size == cells:
            grids[name] = values.reshape(res[2], res[1], res[0])
        elif values.size == cells * 4 and name == "color":
            grids[name] = values.reshape(res[2], res[1], res[0], 4)[..., :3]
    return grids, res


def _openvdb():
    try:
        import openvdb
    except ImportError:
        try:
            import pyopenvdb as openvdb
        except ImportError:
            return None
    return openvdb


def index_matrix(transform):
    """A VDB grid's index-to-object transform as a 4 x 4 matrix (a linear one; Blender reads only
    those). A cell's centre is its whole index."""
    from mathutils import Matrix

    origin = transform.indexToWorld((0.0, 0.0, 0.0))
    axes = [transform.indexToWorld(axis) for axis in ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0),
                                                     (0.0, 0.0, 1.0))]
    found = Matrix.Identity(4)
    for column, axis in enumerate(axes):
        for row in range(3):
            found[row][column] = axis[row] - origin[row]
    for row in range(3):
        found[row][3] = origin[row]
    return found


def _vector(grid):
    return "vec3" in str(getattr(grid, "valueTypeName", "")).lower()


def _dense(grid, low, shape):
    """A grid's values over `shape` (x, y, z) cells from index `low`, as (z, y, x) or
    (z, y, x, 3)."""
    import numpy as np

    vector = _vector(grid)
    values = np.zeros(tuple(shape) + ((3,) if vector else ()), dtype=np.float32)
    grid.copyToArray(values, ijk=tuple(int(v) for v in low))
    return values.transpose((2, 1, 0, 3) if vector else (2, 1, 0))


def _resampled(grid, matrix, reference, low, shape):
    """A grid whose transform differs from the reference grid's, at the reference's cells:
    the nearest of its own cells to each one's centre (0 outside it)."""
    import numpy as np

    own_low, own_high = grid.evalActiveVoxelBoundingBox()
    own_shape = [b - a + 1 for a, b in zip(own_low, own_high)]
    if min(own_shape) <= 0 or own_shape[0] * own_shape[1] * own_shape[2] > MAX_READ_CELLS:
        return None
    own = _dense(grid, own_low, own_shape)
    to_own = np.asarray(matrix.inverted() @ reference, dtype=np.float64)
    z, y, x = np.meshgrid(np.arange(shape[2]) + low[2], np.arange(shape[1]) + low[1],
                          np.arange(shape[0]) + low[0], indexing="ij")
    points = np.stack([x, y, z, np.ones_like(x)], axis=-1).reshape(-1, 4) @ to_own.T
    index = np.rint(points[:, :3]).astype(np.int64) - np.asarray(own_low)
    inside = np.all((index >= 0) & (index < np.asarray(own_shape)), axis=1)
    index = np.clip(index, 0, np.asarray(own_shape) - 1)
    values = own[index[:, 2], index[:, 1], index[:, 0]]
    values[~inside] = 0.0
    return values.reshape((shape[2], shape[1], shape[0]) + own.shape[3:])


# {object name: ((path, modified, size), grids, res, matrix, low, high)}: a file read once.
_VDB_READ = {}


def vdb_path(evaluated):
    """The VDB file a Volume object shows on this frame, or ""."""
    import bpy

    volume = evaluated.data
    grids = getattr(volume, "grids", None)
    path = getattr(grids, "frame_filepath", "") or getattr(volume, "filepath", "")
    if not path:
        return ""
    return bpy.path.abspath(path, library=getattr(volume, "library", None))


def read_vdb(evaluated):
    """A Volume object's grids from its VDB file: ({name: (z, y, x) or (z, y, x, 3) array},
    res (x, y, z), index-to-object Matrix, low, high in index units). Raises `Unreadable`."""
    import os

    import numpy as np

    path = vdb_path(evaluated)
    if not path:
        raise Unreadable("no VDB file (a volume made by modifiers or nodes is not read)")
    if not os.path.isfile(path):
        raise Unreadable("its VDB file is not on disk: " + path)
    stamp = (path, os.path.getmtime(path), os.path.getsize(path))
    held = _VDB_READ.get(evaluated.name)
    if held is not None and held[0] == stamp:
        return held[1:]
    openvdb = _openvdb()
    if openvdb is None:
        raise Unreadable("this Blender has no openvdb Python module")
    try:
        found = openvdb.readAll(path)
    except Exception as exc:  # noqa: BLE001 - a file openvdb cannot read
        raise Unreadable("openvdb could not read {0}: {1}".format(path, exc))
    grids = found[0] if isinstance(found, tuple) else found
    usable = [g for g in grids
              if str(getattr(g, "valueTypeName", "")).lower() in ("float", "double", "half",
                                                                   "vec3s", "vec3d")]
    if not usable:
        raise Unreadable("its VDB file has no float grids")
    named = {g.name: g for g in usable}
    reference = named.get("density") or next((g for g in usable if not _vector(g)), usable[0])
    low, high = reference.evalActiveVoxelBoundingBox()
    shape = [b - a + 1 for a, b in zip(low, high)]
    if min(shape) <= 0:
        raise Unreadable("its grids are empty")
    if shape[0] * shape[1] * shape[2] > MAX_READ_CELLS:
        raise Unreadable("{0} x {1} x {2} cells is more than BU reads (512^3)".format(*shape))
    matrix = index_matrix(reference.transform)
    out = {}
    for grid in usable:
        own = index_matrix(grid.transform)
        same = all(abs(own[r][c] - matrix[r][c]) < 1e-6 for r in range(4) for c in range(4))
        values = _dense(grid, low, shape) if same else _resampled(grid, own, matrix, low, shape)
        if values is None:
            continue
        out[grid.name] = np.ascontiguousarray(values, dtype=np.float32)
        if grid.name in COLOUR_NAMES and values.ndim == 4:
            out.setdefault("color", out[grid.name])  # as Volume Info's Color finds it
    res = tuple(int(v) for v in shape)
    corners = ([v - 0.5 for v in low], [v + 0.5 for v in high])
    _VDB_READ[evaluated.name] = (stamp, out, res, matrix) + corners
    return out, res, matrix, corners[0], corners[1]


def read(evaluated):
    """What a smoke volume is drawn from: (grids, res (x, y, z), placement Matrix, metric
    Matrix, low, high), the box [low, high] in the placement's own units; grids {} when there is
    nothing simulated yet. `metric` measures a cell as Cycles takes its density: in world metres,
    or in the volume's own units when its Volume Space is Object. Raises `Unreadable`."""
    if evaluated.type == "VOLUME":
        grids, res, local, low, high = read_vdb(evaluated)
        placement = evaluated.matrix_world @ local
        space = getattr(getattr(evaluated.data, "render", None), "space", "OBJECT")
        return grids, res, placement, local if space == "OBJECT" else placement, low, high
    grids, res = read_fluid(evaluated)
    low, high = box(evaluated)
    return grids, res, evaluated.matrix_world, evaluated.matrix_world, low, high


class _Socket(object):
    is_linked = False
    enabled = True

    def __init__(self, name, kind, value):
        self.name = self.identifier = name
        self.type = kind
        self.default_value = value


class _Inputs(list):
    def get(self, name, fallback=None):
        return next((s for s in self if s.name == name), fallback)


class DefaultVolume(object):
    """Cycles' own volume for a Volume object with no material: a Principled Volume at its
    defaults, its density from the "density" grid."""

    type = "PRINCIPLED_VOLUME"
    phase = "HENYEY_GREENSTEIN"
    name = "Principled Volume"

    def __init__(self):
        self.inputs = _Inputs([
            _Socket("Color", "RGBA", (0.5, 0.5, 0.5, 1.0)),
            _Socket("Color Attribute", "STRING", ""),
            _Socket("Density", "VALUE", 1.0),
            _Socket("Density Attribute", "STRING", "density"),
            _Socket("Anisotropy", "VALUE", 0.0),
            _Socket("Absorption Color", "RGBA", (0.0, 0.0, 0.0, 1.0)),
            _Socket("Emission Strength", "VALUE", 0.0),
            _Socket("Emission Color", "RGBA", (1.0, 1.0, 1.0, 1.0)),
            _Socket("Blackbody Intensity", "VALUE", 0.0),
            _Socket("Blackbody Tint", "RGBA", (1.0, 1.0, 1.0, 1.0)),
            _Socket("Temperature", "VALUE", 1000.0),
            _Socket("Temperature Attribute", "STRING", "temperature")])


def volume_node(obj):
    """The volume node a smoke volume is shaded by: its material's, Cycles' default for a Volume
    object with none, or None (a material that is not a volume Unreal can draw)."""
    from . import link_lighting

    material = obj.material_slots[0].material if obj.material_slots else None
    if material is None:
        return DefaultVolume() if obj.type == "VOLUME" else None
    return link_lighting._volume_shader(material, True)


def box(evaluated):
    """(low, high) of the domain's box in its own space: the evaluated mesh, which an adaptive
    domain shrinks to where the smoke is, as its grid."""
    corners = [tuple(c) for c in evaluated.bound_box]
    return ([min(c[i] for c in corners) for i in range(3)],
            [max(c[i] for c in corners) for i in range(3)])


class GridChain(link_flatten.Chain):
    """`link_flatten`'s nodes worked out on every cell of the grids: an Attribute or Volume Info
    node answers with the grid of that name, flattened (one value, or colour, per cell)."""

    def __init__(self, grids, cells):
        link_flatten.Chain.__init__(self)
        self.grids = grids
        self.cells = cells
        self.pixels = True  # values per cell, not one value

    def grid(self, name):
        import numpy as np

        found = self.grids.get(name)
        if found is None:
            return None
        if found.ndim == 4:
            return link_flatten.Value("c", found.reshape(self.cells, 3))
        return link_flatten.Value("f", found.reshape(self.cells))

    def _node_attribute(self, node, socket):
        import numpy as np

        found = self.grid(getattr(node, "attribute_name", ""))
        if found is None:
            # Cycles gives 0 for an attribute the volume does not have.
            found = link_flatten.Value("f", np.zeros(self.cells, dtype=np.float32))
        if socket.identifier == "Fac":
            return link_flatten.Value("f", found.as_kind("f") if found.kind == "c"
                                      else found.data)
        if socket.identifier == "Alpha":
            return link_flatten.Value("f", np.ones(self.cells, dtype=np.float32))
        return link_flatten.Value("c", found.as_kind("c"))

    def _node_volume_info(self, node, socket):
        import numpy as np

        name = {"Color": "color", "Density": "density", "Flame": "flame",
                "Temperature": "temperature"}.get(socket.identifier, socket.identifier.lower())
        found = self.grid(name)
        if found is None:
            zero = np.zeros(self.cells, dtype=np.float32)
            return link_flatten.Value("c" if socket.type == "RGBA" else "f",
                                      np.zeros((self.cells, 3), np.float32)
                                      if socket.type == "RGBA" else zero)
        return found


def _input(node, name):
    return node.inputs.get(name)


def _evaluate(chain, node, name, kind, fallback, failed):
    """An input of the volume node per cell (or one value), through the graph when wired."""
    import numpy as np

    socket = _input(node, name)
    if socket is None:
        return np.asarray(fallback, dtype=np.float32)
    try:
        return np.asarray(chain.socket(socket, kind), dtype=np.float32)
    except link_flatten.Unsupported as exc:
        failed[name] = str(exc)
    except Exception as exc:  # noqa: BLE001 - a node set up in a way not foreseen
        failed[name] = str(exc)
    value = socket.default_value
    if kind == "c":
        return np.asarray(tuple(value)[:3], dtype=np.float32)
    return np.asarray(float(value), dtype=np.float32)


def _attribute(node, name):
    socket = _input(node, name)
    return str(getattr(socket, "default_value", "") or "") if socket is not None else ""


def shade(node, grids, res):
    """Cycles' volume shading on every cell: (extinction per metre (n,), albedo (n, 3) or (3,),
    emission (n, 3), {input: why not worked out}). Pure but for reading `node`."""
    import numpy as np

    cells = res[0] * res[1] * res[2]
    chain = GridChain(grids, cells)
    failed = {}
    kind = node.type
    density = _evaluate(chain, node, "Density", "f", 1.0, failed)
    colour = _evaluate(chain, node, "Color", "c", (1.0, 1.0, 1.0), failed)
    absorption = np.ones(3, dtype=np.float32)
    emission = np.zeros(3, dtype=np.float32)
    if kind == "PRINCIPLED_VOLUME":
        for attribute, scale in ((_attribute(node, "Density Attribute"), "density"),
                                 (_attribute(node, "Color Attribute"), "colour")):
            found = chain.grid(attribute) if attribute else None
            if found is None:
                continue  # Cycles: an attribute the volume lacks leaves the input as it is
            if scale == "density":
                density = density * found.as_kind("f")
            else:
                colour = colour * found.as_kind("c")
        absorption = _evaluate(chain, node, "Absorption Color", "c", (0.0, 0.0, 0.0), failed)
        strength = _evaluate(chain, node, "Emission Strength", "f", 0.0, failed)
        glow = _evaluate(chain, node, "Emission Color", "c", (1.0, 1.0, 1.0), failed)
        emission = glow * np.asarray(strength)[..., None]
        blackbody = _evaluate(chain, node, "Blackbody Intensity", "f", 0.0, failed)
        if np.any(blackbody > 1e-9):
            temperature = _evaluate(chain, node, "Temperature", "f", 1000.0, failed)
            attribute = _attribute(node, "Temperature Attribute")
            found = chain.grid(attribute) if attribute else None
            if found is not None:
                temperature = temperature * np.maximum(found.as_kind("f"), 0.0)
            temperature = np.maximum(np.broadcast_to(temperature, (cells,)), 0.0)
            fourth = temperature ** 4
            intensity = STEFAN_BOLTZMANN * (1.0 + (fourth - 1.0) * blackbody)
            tint = _evaluate(chain, node, "Blackbody Tint", "c", (1.0, 1.0, 1.0), failed)
            light = link_flatten.blackbody(np.maximum(temperature, 1.0))
            # Cycles: below 800 K a fixed deep red, very dim (sigma T^4 is tiny there).
            emission = emission + tint * intensity[..., None] * light
    elif kind == "VOLUME_ABSORPTION":
        absorption = colour * colour
        colour = np.zeros(3, dtype=np.float32)
    colour = np.maximum(colour, 0.0)
    total = colour + np.clip(1.0 - colour, 0.0, 1.0) * np.clip(
        1.0 - np.sqrt(np.maximum(absorption, 0.0)), 0.0, 1.0)
    average = total.mean(axis=-1)
    extinction = np.maximum(np.broadcast_to(density, (cells,)), 0.0) * average
    albedo = np.clip(colour / np.maximum(average, 1e-6)[..., None], 0.0, 1.0)
    emission = np.maximum(np.broadcast_to(emission, (cells, 3)), 0.0)
    return extinction.astype(np.float32), albedo.astype(np.float32), \
        emission.astype(np.float32), failed


def _halve(field):
    """A (z, y, x, c) field averaged down by twos (odd sides keep their last cell)."""
    import numpy as np

    z, y, x = field.shape[:3]
    pad = [(0, z % 2), (0, y % 2), (0, x % 2)] + [(0, 0)] * (field.ndim - 3)
    field = np.pad(field, pad, mode="edge")
    z, y, x = field.shape[:3]
    return field.reshape(z // 2, 2, y // 2, 2, x // 2, 2, *field.shape[3:]).mean(axis=(1, 3, 5))


def pack(extinction, albedo, emission, res, max_cells=None):
    """(main, albedo or None, res) as Unreal reads them: (z, y, x, 4) half floats, emission
    RGB and extinction, Y flipped for Unreal's axes; albedo only when it varies by cell. A grid
    over `max_cells` (`MAX_CELLS`: Render > Lighting > Volumes > Grid Detail) is averaged down
    first, and `res` is what was sent."""
    import numpy as np

    x, y, z = res
    main = np.empty((z, y, x, 4), dtype=np.float32)
    main[..., :3] = emission.reshape(z, y, x, 3)
    main[..., 3] = extinction.reshape(z, y, x)
    varies = albedo.ndim == 2 and float(np.ptp(albedo, axis=0).max()) > 1e-3
    tint = albedo.reshape(z, y, x, 3) if varies else None
    limit = MAX_CELLS if max_cells is None else max(1, int(max_cells))
    while main.shape[0] * main.shape[1] * main.shape[2] > limit:
        main = _halve(main)
        tint = _halve(tint) if tint is not None else None
    res = (main.shape[2], main.shape[1], main.shape[0])
    main = np.ascontiguousarray(main[:, ::-1]).astype(np.float16)
    if tint is not None:
        padded = np.ones(tint.shape[:3] + (4,), dtype=np.float32)
        padded[..., :3] = tint
        tint = np.ascontiguousarray(padded[:, ::-1]).astype(np.float16)
    return main, tint, res


def uniform_albedo(albedo):
    """The one albedo of a volume whose colour does not vary (its mean where it does)."""
    import numpy as np

    values = albedo if albedo.ndim == 1 else albedo.mean(axis=0)
    return [round(float(v), 6) for v in values]


def matrix(placement, low, high, res):
    """The 16-float matrix (Unreal's) of a Heterogeneous Volume whose local units are the
    grid's cells, centred: the box [low, high] in `placement`'s own units, each axis scaled to
    its cell size in centimetres."""
    from mathutils import Matrix

    from . import link_mesh

    centre = [(a + b) / 2.0 for a, b in zip(low, high)]
    found = placement @ Matrix.Translation(centre)
    for column in range(3):
        size = max(high[column] - low[column], 1e-6)
        for row in range(3):
            found[row][column] *= size / res[column] * 100.0
    return link_mesh.matrix_to_unreal(found)


def cell_metres(metric, low, high, res):
    """The mean size of a cell, measured by `metric` (`read`): a local unit of the volume, in
    which Unreal's ray march takes its extinction and emission."""
    scale = metric.to_scale()
    sizes = [abs(scale[i]) * max(high[i] - low[i], 1e-6) / res[i] for i in range(3)]
    return sum(sizes) / 3.0
