# SPDX-License-Identifier: GPL-3.0-or-later
"""Unreal's lighting, set from Blender: per-light settings, the sky, fog, fog volumes, the camera.

Blender's own lights already come across (`link_light`), converted from watts. This module
covers what Unreal has that Blender does not, and what the link left to the level:

* **Per light** (Light properties → *BU — Unreal Light*): an intensity in Unreal's own units
  instead of the converted watts, indirect, volumetric, specular and diffuse scales, source
  length and soft radius, falloff, the attenuation radius, contact and volumetric shadows,
  lighting channels, an IES profile, a light function, a rect light's source texture and barn
  door length, and for a sun: atmosphere sun, cloud shadows, shadow distance and cascades, and
  light shafts. Sent with the light, as `unreal` (`describe_light`).
* **Sky and fog** (World properties → *BU — Unreal Sky & Fog*): the World as Unreal's sky, either
  its colour or HDRI on a sky dome that a real-time Sky Light captures (so it lights the scene
  as it does in Blender), or Unreal's physical Sky Atmosphere lit by the Blender sun. Plus
  Exponential Height Fog with volumetric fog. The level's own sky, fog and suns can be hidden
  meanwhile — temporarily, never saved.
* **Clouds** (the same panel): Unreal's Volumetric Cloud, with the engine's cloud material —
  coverage, density, size, colour, base height and thickness. Blender has no clouds to read, so
  these are Unreal's alone; a sun's Cloud Shadows (on by default) lets them shade the ground.
* **Camera** (Render properties → *BU — Unreal Camera*): exposure (auto or a fixed EV100,
  optionally following Blender's own Exposure), bloom, vignette, grain, motion blur, white
  balance, saturation and contrast, on BU's own unbound post-process volume.
* **Fog volumes**: a mesh whose material has only a Volume shader becomes a Local Fog Volume
  instead of a mesh (`describe_volume`).

Sky, fog and camera travel as one `environment` message (`describe_environment`), sent when it
changes. Everything is off until asked for: a level's own lighting is left alone by default.
"""

import hashlib
import math
import os

import bpy

try:
    from . import link_material, link_mesh
except ImportError:  # loaded by path in the plain-CPython tests
    import link_material
    import link_mesh

PRECISION = 4
WATTS_TO_NITS = 683.0
HDRI_MAX_WIDTH = 4096
# A Local Fog Volume is a sphere of 5 m times the actor's largest scale (Unreal's
# `ULocalFogVolumeComponent::GetBaseVolumeSize`).
FOG_VOLUME_BASE_M = 5.0
# Its density falls off as 1 - d²/r² from the centre; through the centre that averages 2/3, so
# a uniform Blender density D gives the same optical depth there at 1.5 D.
FOG_VOLUME_PEAK = 1.5

_HDRI = {}  # image name -> (signature, texture field)


def _round(value):
    return round(float(value), PRECISION)


def _colour(value):
    return [_round(c) for c in tuple(value)[:3]]


def _asset_changed(_self, context):
    from . import link

    link.lighting_changed()


def _upscaling_changed(self, context):
    """Upscaling travels with the view; DLSS's Ray Reconstruction with the lighting."""
    _view_changed(self, context)
    if getattr(self, "dlss_rr", False):
        _asset_changed(self, context)


def _view_changed(_self, context):
    """A setting that travels with the view: redraw the Unreal viewports, which send it."""
    from . import link_view

    for area in link_view.active_viewports(context.window_manager):
        area.tag_redraw()


def _search(kind):
    def search(_self, _context, edit_text):
        from . import link

        words = (edit_text or "").lower().split()
        found = [path for path in link.unreal_assets(kind)
                 if all(word in path.lower() for word in words)]
        return found[:500]
    return search


# -- per light -----------------------------------------------------------------------------------

UNITS = (("CANDELAS", "Candelas", "Unreal's default for point, spot and rect lights"),
         ("LUMENS", "Lumens", "Total light output, whatever the cone"),
         ("EV", "EV", "Exposure value at ISO 100"),
         ("UNITLESS", "Unitless", "Unreal's older, unitless intensity"))


RAY_TRACED_SHADOW_CHOICES = (
    ("AUTO", "Use Scene", "The scene's Shadows choice (Render Properties > Unreal > Lighting)"),
    ("ON", "On", "Ray traced: soft shadows from the light's size, as in Blender. Needs a "
                 "ray-tracing GPU, and costs frame time"),
    ("OFF", "Off", "Unreal's virtual shadow maps: fast, but an area light's shadow comes out "
                   "hard and a spot's lets light through"))


class BU_LinkLightUnreal(bpy.types.PropertyGroup):
    use_intensity: bpy.props.BoolProperty(
        name="Unreal Intensity", default=False, update=_asset_changed,
        description="Set the intensity in Unreal's units, instead of converting Blender's watts")
    intensity: bpy.props.FloatProperty(
        name="Intensity", default=10.0, min=0.0, soft_max=100000.0, update=_asset_changed,
        description="In the units below (lux for a sun)")
    units: bpy.props.EnumProperty(
        name="Units", items=UNITS, default="CANDELAS", update=_asset_changed,
        description="Unreal uses Unitless whenever Inverse Squared Falloff is off")
    indirect: bpy.props.FloatProperty(
        name="Indirect", default=1.0, min=0.0, soft_max=8.0, update=_asset_changed,
        description="Scales this light's bounce lighting (Lumen) and indirect light")
    volumetric: bpy.props.FloatProperty(
        name="Volumetric Scattering", default=1.0, min=0.0, soft_max=8.0, update=_asset_changed,
        description="How strongly this light shows in volumetric fog")
    specular: bpy.props.FloatProperty(name="Specular", default=1.0, min=0.0, soft_max=4.0,
                                      update=_asset_changed,
                                      description="Scales this light's highlights")
    diffuse: bpy.props.FloatProperty(name="Diffuse", default=1.0, min=0.0, soft_max=4.0,
                                     update=_asset_changed,
                                     description="Scales this light's diffuse lighting")
    source_length: bpy.props.FloatProperty(
        name="Source Length", default=0.0, min=0.0, soft_max=10.0, unit="LENGTH",
        update=_asset_changed, description="Stretches a point or spot light into a tube")
    soft_radius: bpy.props.FloatProperty(
        name="Soft Source Radius", default=0.0, min=0.0, soft_max=5.0, unit="LENGTH",
        update=_asset_changed, description="Softens the light's shadows and highlights further")
    inverse_square: bpy.props.BoolProperty(
        name="Inverse Squared Falloff", default=True, update=_asset_changed,
        description="Physical falloff. Off uses the Falloff Exponent instead")
    falloff_exponent: bpy.props.FloatProperty(name="Falloff Exponent", default=8.0, min=0.0,
                                              soft_max=16.0, update=_asset_changed)
    attenuation: bpy.props.FloatProperty(
        name="Attenuation Radius", default=0.0, min=0.0, soft_max=500.0, unit="LENGTH",
        update=_asset_changed,
        description="Where the light stops. 0 works it out from the intensity (or Custom Distance)")
    volumetric_shadow: bpy.props.BoolProperty(name="Volumetric Shadow", default=True,
                                              update=_asset_changed)
    contact_shadow: bpy.props.FloatProperty(
        name="Contact Shadow Length", default=0.0, min=0.0, max=1.0, update=_asset_changed,
        description="Screen-space contact shadows, as a fraction of the screen")
    affects_world: bpy.props.BoolProperty(name="Affects World", default=True,
                                          update=_asset_changed)
    affect_reflection: bpy.props.BoolProperty(name="Affects Reflections", default=True,
                                              update=_asset_changed)
    affect_gi: bpy.props.BoolProperty(name="Affects Global Illumination", default=True,
                                      update=_asset_changed)
    affect_translucent: bpy.props.BoolProperty(
        name="Affects Translucency", default=True, update=_asset_changed,
        description="Whether this light lights glass and other see-through surfaces. Blender's "
                    "Ray Visibility > Transmission turns it off too")
    channels: bpy.props.BoolVectorProperty(
        name="Lighting Channels", size=3, default=(True, False, False), update=_asset_changed,
        description="Unreal lighting channels 0, 1 and 2: lights only light meshes sharing one")
    ray_traced_shadows: bpy.props.EnumProperty(
        name="Ray Traced Shadows", items=RAY_TRACED_SHADOW_CHOICES, default="AUTO",
        update=_asset_changed,
        description="Whether this light's shadows are ray traced (soft, as in Blender) or "
                    "Unreal's shadow maps (fast, harder)")
    samples_per_pixel: bpy.props.IntProperty(
        name="Samples Per Pixel", default=1, min=1, max=64, soft_max=16, update=_asset_changed,
        description="Rays per pixel for this light's ray-traced shadows. More is smoother soft "
                    "shadows, with less noise, and costs GPU time")
    ies: bpy.props.StringProperty(
        name="IES Profile", search=_search("ies"), update=_asset_changed,
        description="An IES light profile from the Unreal project")
    ies_brightness: bpy.props.BoolProperty(name="Use IES Brightness", default=False,
                                           update=_asset_changed)
    ies_scale: bpy.props.FloatProperty(name="IES Brightness Scale", default=1.0, min=0.0,
                                       update=_asset_changed)
    light_function: bpy.props.StringProperty(
        name="Light Function", search=_search("light_function"), update=_asset_changed,
        description="A light function material from the Unreal project")
    source_texture: bpy.props.StringProperty(
        name="Source Texture", search=_search("texture"), update=_asset_changed,
        description="A texture shown on a rect light's surface and coloured into its light")
    barn_door_length: bpy.props.FloatProperty(name="Barn Door Length", default=0.2, min=0.0,
                                              soft_max=2.0, unit="LENGTH",
                                              update=_asset_changed)
    atmosphere_sun: bpy.props.BoolProperty(
        name="Atmosphere Sun", default=True, update=_asset_changed,
        description="This sun lights Unreal's Sky Atmosphere and sets the sky's colour")
    atmosphere_index: bpy.props.IntProperty(name="Atmosphere Index", default=0, min=0, max=1,
                                            update=_asset_changed)
    cloud_shadows: bpy.props.BoolProperty(
        name="Cloud Shadows", default=True, update=_asset_changed,
        description="Unreal's volumetric clouds (World → Unreal Sky & Fog → Clouds) shade "
                    "the ground under them")
    soft_angle: bpy.props.FloatProperty(name="Soft Source Angle", default=0.0, min=0.0,
                                        max=math.radians(10.0), subtype="ANGLE",
                                        update=_asset_changed)
    shadow_distance: bpy.props.FloatProperty(
        name="Shadow Distance", default=200.0, min=1.0, soft_max=2000.0, unit="LENGTH",
        update=_asset_changed, description="How far the sun's dynamic shadows reach")
    cascades: bpy.props.IntProperty(name="Shadow Cascades", default=3, min=0, max=10,
                                    update=_asset_changed)
    light_shafts: bpy.props.BoolProperty(name="Light Shafts", default=False,
                                         update=_asset_changed,
                                         description="Bloom rays from the sun's disc")
    shaft_bloom: bpy.props.FloatProperty(name="Shaft Bloom", default=0.2, min=0.0, soft_max=2.0,
                                         update=_asset_changed)


def describe_light(light):
    """The light's Unreal-only settings, for its message (`unreal`). Pure, given a Light."""
    settings = getattr(light, "bu_unreal", None)
    if settings is None:
        return {}
    kind = str(light.type)
    found = {
        "indirect": _round(settings.indirect), "volumetric": _round(settings.volumetric),
        "specular": _round(settings.specular), "diffuse": _round(settings.diffuse),
        "volumetric_shadow": bool(settings.volumetric_shadow),
        "contact_shadow": _round(settings.contact_shadow),
        "affects_world": bool(settings.affects_world),
        "affect_reflection": bool(settings.affect_reflection),
        "affect_gi": bool(settings.affect_gi),
        "affect_translucent": bool(settings.affect_translucent),
        "channels": [bool(c) for c in settings.channels],
        "ray_traced_shadows": settings.ray_traced_shadows,
        "samples_per_pixel": int(settings.samples_per_pixel),
        "light_function": settings.light_function,
    }
    if settings.use_intensity:
        found["intensity"] = _round(settings.intensity)
        if kind != "SUN":
            found["units"] = settings.units
    if kind == "SUN":
        found.update({
            "atmosphere_sun": bool(settings.atmosphere_sun),
            "atmosphere_index": int(settings.atmosphere_index),
            "cloud_shadows": bool(settings.cloud_shadows),
            "soft_angle": _round(settings.soft_angle),
            "shadow_distance": _round(settings.shadow_distance),
            "cascades": int(settings.cascades),
            "light_shafts": bool(settings.light_shafts),
            "shaft_bloom": _round(settings.shaft_bloom),
        })
        return found
    found.update({
        "ies": settings.ies,
        "ies_brightness": bool(settings.ies_brightness),
        "ies_scale": _round(settings.ies_scale),
    })
    if settings.attenuation > 0.0:
        found["attenuation"] = _round(settings.attenuation)
    if kind == "AREA":
        # Unreal's rect light has no soft radius or falloff choice: always inverse squared.
        found["barn_door_length"] = _round(settings.barn_door_length)
        found["source_texture"] = settings.source_texture
    else:
        found["source_length"] = _round(settings.source_length)
        found["soft_radius"] = _round(settings.soft_radius)
        found["inverse_square"] = bool(settings.inverse_square)
        found["falloff_exponent"] = _round(settings.falloff_exponent)
    return found


# -- the world: sky and fog ---------------------------------------------------------------------

SKY_MODES = (
    ("OFF", "Leave the Level's", "Unreal keeps its own sky light and sky"),
    ("AUTO", "Auto", "A Sky Texture node means Unreal's physical sky; anything else, the World"),
    ("WORLD", "From the World", "The World's colour or HDRI, shown as the sky and lighting the "
                                "scene through a real-time Sky Light"),
    ("PHYSICAL", "Physical Sky", "Unreal's Sky Atmosphere, lit by the Blender sun, with a "
                                 "real-time Sky Light"),
)


class BU_LinkWorldUnreal(bpy.types.PropertyGroup):
    sky: bpy.props.EnumProperty(name="Sky", items=SKY_MODES, default="OFF",
                                update=_asset_changed)
    sky_intensity: bpy.props.FloatProperty(
        name="Sky Light Intensity", default=1.0, min=0.0, soft_max=10.0, update=_asset_changed,
        description="Scales the light the sky gives the scene")
    lower_black: bpy.props.BoolProperty(
        name="Black Lower Hemisphere", default=False, update=_asset_changed,
        description="No sky light from below the horizon, as if standing on dark ground")
    fog: bpy.props.BoolProperty(name="Height Fog", default=False, update=_asset_changed,
                                description="Unreal's Exponential Height Fog")
    fog_density: bpy.props.FloatProperty(name="Density", default=0.02, min=0.0, soft_max=0.5,
                                         precision=3, update=_asset_changed)
    fog_falloff: bpy.props.FloatProperty(
        name="Height Falloff", default=0.2, min=0.001, soft_max=2.0, update=_asset_changed,
        description="How quickly the fog thins with height")
    fog_height: bpy.props.FloatProperty(name="Base Height", default=0.0, unit="LENGTH",
                                        update=_asset_changed)
    fog_color: bpy.props.FloatVectorProperty(
        name="Colour", subtype="COLOR", size=3, min=0.0, soft_max=1.0,
        default=(0.45, 0.55, 0.7), update=_asset_changed)
    fog_opacity: bpy.props.FloatProperty(name="Max Opacity", default=1.0, min=0.0, max=1.0,
                                         update=_asset_changed)
    fog_start: bpy.props.FloatProperty(name="Start Distance", default=0.0, min=0.0,
                                       unit="LENGTH", update=_asset_changed)
    volumetric: bpy.props.BoolProperty(
        name="Volumetric Fog", default=False, update=_asset_changed,
        description="Fog lit by each light, with shafts and shadows")
    vol_scattering: bpy.props.FloatProperty(name="Scattering Distribution", default=0.2,
                                            min=-0.9, max=0.9, update=_asset_changed)
    vol_albedo: bpy.props.FloatVectorProperty(name="Albedo", subtype="COLOR", size=3, min=0.0,
                                              max=1.0, default=(1.0, 1.0, 1.0),
                                              update=_asset_changed)
    vol_extinction: bpy.props.FloatProperty(name="Extinction Scale", default=1.0, min=0.1,
                                            soft_max=10.0, update=_asset_changed)
    vol_distance: bpy.props.FloatProperty(name="View Distance", default=60.0, min=1.0,
                                          soft_max=500.0, unit="LENGTH", update=_asset_changed)
    clouds: bpy.props.BoolProperty(
        name="Clouds", default=False, update=_asset_changed,
        description="Unreal's volumetric clouds: lit by the sun and the sky, casting shadows "
                    "(the sun's Cloud Shadows) and lighting the scene through the Sky Light. "
                    "Seen in Unreal only; Blender has no clouds to match")
    cloud_coverage: bpy.props.FloatProperty(
        name="Coverage", default=1.0 / 3.0, min=0.0, max=1.0, subtype="FACTOR",
        update=_asset_changed, description="How much of the sky is cloud: 0 clear, 1 overcast")
    cloud_density: bpy.props.FloatProperty(
        name="Density", default=1.0, min=0.0, soft_max=4.0, update=_asset_changed,
        description="How thick each cloud is: low is wispy, high is solid and dark underneath")
    cloud_size: bpy.props.FloatProperty(
        name="Size", default=1.0, min=0.05, soft_max=4.0, update=_asset_changed,
        description="The scale of the cloud pattern: smaller makes many small puffs")
    cloud_colour: bpy.props.FloatVectorProperty(
        name="Colour", subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.98, 0.98, 0.98),
        update=_asset_changed, description="The clouds' albedo")
    cloud_bottom: bpy.props.FloatProperty(
        name="Base Height", default=5000.0, min=0.0, soft_max=20000.0, unit="LENGTH",
        update=_asset_changed, description="Height of the cloud layer's base above the ground")
    cloud_thickness: bpy.props.FloatProperty(
        name="Thickness", default=10000.0, min=100.0, soft_max=20000.0, unit="LENGTH",
        update=_asset_changed, description="How deep the cloud layer is")
    hide_level_sky: bpy.props.BoolProperty(
        name="Hide the Level's Sky", default=True, update=_asset_changed,
        description="While BU's sky is on, hide the level's own Sky Light, Sky Atmosphere and "
                    "clouds (temporarily, never saved)")
    hide_level_fog: bpy.props.BoolProperty(
        name="Hide the Level's Fog", default=True, update=_asset_changed,
        description="While BU's fog is on, hide the level's own height fog")
    hide_level_suns: bpy.props.BoolProperty(
        name="Hide the Level's Suns", default=False, update=_asset_changed,
        description="Hide the level's own directional lights, so the Blender sun is the only one")


def sky_source(world):
    """What the World shows: {"mode": "COLOR"|"HDRI"|"SKY", "color", "strength", ...}. Pure-ish."""
    found = {"mode": "COLOR", "color": [0.05, 0.05, 0.05], "strength": 1.0}
    if world is None:
        return found
    found["color"] = _colour(world.color)
    tree = world.node_tree if getattr(world, "use_nodes", False) else None
    if tree is None:
        return found
    output = None
    for target in ("EEVEE", "ALL", "CYCLES"):
        try:
            output = tree.get_output_node(target)
        except (AttributeError, TypeError):
            output = None
        if output is not None:
            break
    surface = output.inputs.get("Surface") if output is not None else None
    if surface is None or not surface.is_linked:
        return found
    background = surface.links[0].from_node
    if background.type != "BACKGROUND":
        return found
    found["strength"] = _round(background.inputs["Strength"].default_value)
    colour = background.inputs["Color"]
    if not colour.is_linked:
        found["color"] = _colour(colour.default_value)
        return found
    source = colour.links[0].from_node
    while source.type == "REROUTE" and source.inputs[0].is_linked:
        source = source.inputs[0].links[0].from_node
    if source.type == "TEX_SKY":
        found["mode"] = "SKY"
    elif source.type == "TEX_ENVIRONMENT" and source.image is not None:
        found["mode"] = "HDRI"
        found["image"] = source.image
        found["rotation"] = _round(_env_rotation(source))
    return found


def _env_rotation(node):
    """The Z rotation a Mapping node in front of an Environment Texture applies, in radians."""
    vector = node.inputs.get("Vector")
    if vector is None or not vector.is_linked:
        return 0.0
    mapping = vector.links[0].from_node
    if mapping.type != "MAPPING":
        return 0.0
    rotation = mapping.inputs.get("Rotation")
    angle = float(rotation.default_value[2]) if rotation is not None else 0.0
    # Point and Vector rotate the direction looked up; Texture rotates the texture instead.
    return -angle if mapping.vector_type == "TEXTURE" else angle


def write_linear_exr(path, pixels):
    """Scene-linear RGBA rows (Blender's order, bottom row first) to a float EXR, unchanged.

    Not `Image.save()`: Blender 5.2 writes a float image's EXR as sRGB display colour (0.1 is
    saved as 0.349, tagged `srgb_rec709_display`). Blender reads its own tag back, so it looked
    right there; Unreal takes the numbers as linear, and the cafe's dark sky came out about
    nine times too bright. OpenImageIO writes exactly what it is given.
    """
    import numpy as np
    import OpenImageIO as oiio

    rows = np.ascontiguousarray(np.flipud(np.asarray(pixels, dtype=np.float32))[..., :3])
    height, width = rows.shape[:2]
    spec = oiio.ImageSpec(width, height, 3, "float")
    spec.attribute("oiio:ColorSpace", "lin_rec709_scene")
    spec.attribute("compression", "zip")
    out = oiio.ImageOutput.create(path)
    if out is None or not out.open(path, spec):
        raise OSError("could not write {0}: {1}".format(path, oiio.geterror()))
    try:
        if not out.write_image(rows):
            raise OSError("could not write {0}: {1}".format(path, out.geterror()))
    finally:
        out.close()


def hdri_file(image):
    """The World's HDRI as a float EXR Unreal can import as a 2D texture: a texture field.

    An EXR file on disk, unchanged and small enough, is sent as it is. Anything else (a .hdr,
    which Unreal would import as a cube map; a packed, generated or painted image; an 8K map)
    is written out: its pixels read directly, 8-bit sRGB ones made linear, at most
    `HDRI_MAX_WIDTH` wide.
    """
    import numpy as np

    width, height = (int(v) for v in image.size)
    signature = (image.filepath, width, height, image.source,
                 bool(getattr(image, "is_dirty", False)), link_material._EPOCH[0])
    cached = _HDRI.get(image.name)
    if cached and cached[0] == signature and os.path.isfile(cached[1]["path"]):
        return cached[1]
    source = bpy.path.abspath(image.filepath) if image.filepath else ""
    if (image.source == "FILE" and source.lower().endswith(".exr") and os.path.isfile(source)
            and not image.packed_file and not getattr(image, "is_dirty", False)
            and width <= HDRI_MAX_WIDTH):
        path = source
    else:
        if width < 1 or height < 1:
            raise ValueError("the World's image '{0}' has no pixels".format(image.name))
        digest = hashlib.sha1(repr((image.name, image.filepath)).encode("utf-8")).hexdigest()[:10]
        path = os.path.join(link_material.packed_folder(), "sky_{0}.exr".format(digest))
        pixels = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(pixels)
        if not image.is_float and image.colorspace_settings.name.lower().startswith("srgb"):
            rgb = pixels.reshape(-1, 4)[:, :3]
            rgb[:] = np.where(rgb <= 0.04045, rgb / 12.92, ((rgb + 0.055) / 1.055) ** 2.4)
        if width > HDRI_MAX_WIDTH:
            target = bpy.data.images.new("BU_sky_export", width, height, alpha=False,
                                         float_buffer=True)
            try:
                target.pixels.foreach_set(pixels)
                width, height = HDRI_MAX_WIDTH, max(1, int(height * HDRI_MAX_WIDTH / width))
                target.scale(width, height)
                pixels = np.empty(width * height * 4, dtype=np.float32)
                target.pixels.foreach_get(pixels)
            finally:
                bpy.data.images.remove(target)
        write_linear_exr(path, pixels.reshape(height, width, 4))
    with open(path, "rb") as handle:
        stamp = hashlib.sha1(handle.read()).hexdigest()[:16]
    field = {"path": path, "stamp": stamp}
    _HDRI[image.name] = (signature, field)
    return field


def describe_world(world, level_sky=True):
    """The sky and fog part of the environment message.

    `level_sky` False: the Unreal level has no sky of its own to leave (BU's own hidden editor
    opens a blank one), so "Leave the Level's" would mean black outside every window. There the
    World is the sky unless the user picked otherwise.
    """
    settings = getattr(world, "bu_unreal", None) if world is not None else None
    if settings is None:
        return {"sky": "OFF", "fog": False}
    source = sky_source(world)
    mode = settings.sky
    if mode == "OFF" and not level_sky:
        mode = "AUTO"
    if mode == "AUTO":
        mode = "PHYSICAL" if source["mode"] == "SKY" else "WORLD"
    found = {"sky": mode, "fog": bool(settings.fog),
             "hide_level_sky": bool(settings.hide_level_sky),
             "hide_level_fog": bool(settings.hide_level_fog),
             "hide_level_suns": bool(settings.hide_level_suns)}
    if mode != "OFF":
        found["sky_intensity"] = _round(settings.sky_intensity)
        found["lower_black"] = bool(settings.lower_black)
    if mode == "WORLD":
        # Radiance in W/(m² sr) to Unreal's nits, as the lights are converted.
        found["sky_color"] = [_round(c * source["strength"] * WATTS_TO_NITS)
                              for c in source["color"]]
        if source["mode"] == "HDRI":
            found["sky_texture"] = hdri_file(source["image"])
            found["sky_strength"] = _round(source["strength"] * WATTS_TO_NITS)
            found["sky_rotation"] = source["rotation"]
    if settings.clouds:
        found["clouds"] = {
            "coverage": _round(settings.cloud_coverage),
            "density": _round(settings.cloud_density),
            "size": _round(settings.cloud_size),
            "colour": _colour(settings.cloud_colour),
            "bottom": _round(settings.cloud_bottom),
            "thickness": _round(settings.cloud_thickness),
        }
    if settings.fog:
        found.update({
            "fog_density": _round(settings.fog_density),
            "fog_falloff": _round(settings.fog_falloff),
            "fog_height": _round(settings.fog_height),
            "fog_color": _colour(settings.fog_color),
            "fog_opacity": _round(settings.fog_opacity),
            "fog_start": _round(settings.fog_start),
            "volumetric": bool(settings.volumetric),
        })
        if settings.volumetric:
            found.update({
                "vol_scattering": _round(settings.vol_scattering),
                "vol_albedo": _colour(settings.vol_albedo),
                "vol_extinction": _round(settings.vol_extinction),
                "vol_distance": _round(settings.vol_distance),
            })
    return found


# -- the camera -----------------------------------------------------------------------------------

class BU_LinkCameraUnreal(bpy.types.PropertyGroup):
    enabled: bpy.props.BoolProperty(
        name="Control Unreal's Camera", default=False, update=_asset_changed,
        description="Exposure and post-processing from here, on BU's own post-process volume")
    exposure: bpy.props.EnumProperty(
        name="Exposure", default="AUTO", update=_asset_changed,
        items=(("AUTO", "Auto", "Unreal adapts to the brightness of the picture"),
               ("MANUAL", "Manual", "A fixed exposure, so changing the lights changes the "
                                    "picture's brightness, as in Blender")))
    ev100: bpy.props.FloatProperty(
        name="EV100", default=10.0, soft_min=-5.0, soft_max=20.0, update=_asset_changed,
        description="Exposure value at ISO 100: about 15 for sunlight, 8 indoors, 3 at night")
    compensation: bpy.props.FloatProperty(name="Compensation", default=0.0, soft_min=-10.0,
                                          soft_max=10.0, update=_asset_changed,
                                          description="Brighter or darker, in stops")
    follow_blender: bpy.props.BoolProperty(
        name="Add Blender's Exposure", default=True, update=_asset_changed,
        description="Add Color Management → Exposure to the compensation")
    bloom: bpy.props.FloatProperty(name="Bloom", default=0.675, min=0.0, soft_max=8.0,
                                   update=_asset_changed)
    vignette: bpy.props.FloatProperty(name="Vignette", default=0.4, min=0.0, max=1.0,
                                      update=_asset_changed)
    grain: bpy.props.FloatProperty(name="Film Grain", default=0.0, min=0.0, max=1.0,
                                   update=_asset_changed)
    motion_blur: bpy.props.FloatProperty(name="Motion Blur", default=0.5, min=0.0, max=1.0,
                                         update=_asset_changed)
    white_temp: bpy.props.FloatProperty(name="White Balance", default=6500.0, min=1500.0,
                                        max=15000.0, update=_asset_changed)
    saturation: bpy.props.FloatProperty(name="Saturation", default=1.0, min=0.0, max=2.0,
                                        update=_asset_changed)
    contrast: bpy.props.FloatProperty(name="Contrast", default=1.0, min=0.0, max=2.0,
                                      update=_asset_changed)


def describe_camera(scene):
    settings = getattr(scene, "bu_unreal", None)
    if settings is None or not settings.enabled:
        return {"post": False}
    compensation = settings.compensation
    if settings.follow_blender:
        compensation += float(scene.view_settings.exposure)
    found = {"post": True, "exposure": settings.exposure,
             "compensation": _round(compensation), "bloom": _round(settings.bloom),
             "vignette": _round(settings.vignette), "grain": _round(settings.grain),
             "motion_blur": _round(settings.motion_blur),
             "white_temp": _round(settings.white_temp),
             "saturation": _round(settings.saturation), "contrast": _round(settings.contrast)}
    if settings.exposure == "MANUAL":
        found["ev100"] = _round(settings.ev100)
    return found


# -- the renderer -------------------------------------------------------------------------------

GI_CHOICES = (("PROJECT", "Project Default", "Whatever the Unreal project uses"),
              ("LUMEN", "Lumen", "Unreal's real-time global illumination: light bounces"),
              ("NONE", "None", "Direct light and the sky only"))
REFLECTION_CHOICES = (("PROJECT", "Project Default", "Whatever the Unreal project uses"),
                      ("LUMEN", "Lumen", "Lumen reflections, with what is off screen"),
                      ("SCREEN_SPACE", "Screen Space", "Only what is on screen reflects"),
                      ("NONE", "None", "The sky only"))
RAY_LIGHTING_CHOICES = (
    ("PROJECT", "Project Default", "Whatever the Unreal project uses"),
    ("SURFACE_CACHE", "Surface Cache", "Lumen's fastest: what rays hit is lit from a coarse cache "
                                       "of the scene, so reflections and bounce light are blurry "
                                       "approximations"),
    ("HIT_REFLECTIONS", "Hit Lighting for Reflections",
     "Reflections lit properly where each ray lands; bounce light from the cache"),
    ("HIT_LIGHTING", "Hit Lighting", "Reflections and bounce light lit properly where each ray "
                                     "lands, closest to a path tracer. The most GPU time"))
# Numbered so a saved choice keeps its meaning: 1 was "Lumen, Ray Traced", dropped because it
# changed nothing measurable (a file that chose it reads as Lumen's own).
CONTACT_AO_CHOICES = (
    ("SSAO", "Screen Space (SSAO)",
     "Unreal's classic screen-space ambient occlusion in place of Lumen's, with its own "
     "intensity and distance: the dark lines in creases and where things touch", 2),
    ("LUMEN", "Lumen", "Lumen's own short-range occlusion, read from what is on screen out to "
                       "about 32 pixels (Unreal's default). Faint", 0),
)
SHADOW_CHOICES = (("PROJECT", "Project Default",
                   "Whatever the Unreal project uses, except spot lights, which always ray trace "
                   "theirs: Unreal's shadow maps let a third of a spot's light through"),
                  ("VIRTUAL", "Shadow Maps", "Unreal's virtual shadow maps for every light: fast, "
                                             "but an area light's shadow comes out hard and a "
                                             "spot's lets light through"),
                  ("RAY_TRACED", "Ray Traced", "Soft shadows from each light's size, as in "
                                               "Blender. Needs a ray-tracing GPU, and costs "
                                               "frame time"))

RENDERER_CHOICES = (
    ("LUMEN", "Real-Time", "Unreal's real-time lighting: Lumen global illumination and "
                           "reflections, shadow maps or ray-traced shadows"),
    ("PATH_TRACER", "Path Tracer", "Unreal's path tracer: every bounce traced, as Cycles does. "
                                   "Noisy while the view or scene changes, then refines to "
                                   "the sample count. Needs a ray-tracing GPU"))

UPSCALER_CHOICES = (
    ("NONE", "Off", "Unreal renders every pixel of the picture"),
    ("TSR", "TSR", "Unreal's Temporal Super Resolution: renders fewer pixels and rebuilds the "
                   "rest from earlier frames"),
    ("DLSS", "DLSS", "NVIDIA DLSS: an AI model rebuilds the picture from fewer pixels, or "
                     "smooths it at full size (DLAA). Needs an NVIDIA RTX card and NVIDIA's DLSS "
                     "plugin in BU's Unreal"))
# Blender's DLSS mode -> the name of DLSS's own quality setting.
DLSS_MODES = (
    ("DLAA", "DLAA", "Every pixel rendered; DLSS only smooths edges and detail. The sharpest",
     "DLAA"),
    ("QUALITY", "Quality", "About two thirds of the width and height rendered", "Quality"),
    ("BALANCED", "Balanced", "About 58% of the width and height rendered", "Balanced"),
    ("PERFORMANCE", "Performance", "Half the width and height rendered", "Performance"),
    ("ULTRA_PERFORMANCE", "Ultra Performance", "A third of the width and height rendered",
     "UltraPerformance"),
)
DLSS_MODE_NAMES = {row[0]: row[3] for row in DLSS_MODES}
# Unreal's denoiser runs Intel's Open Image Denoise networks (Blender's) on the GPU.
PT_DENOISE_QUALITY = (
    ("HIGH", "High", "The largest network: the most detail kept (Blender's default)"),
    ("BALANCED", "Balanced", "Unreal's default"),
    ("FAST", "Fast", "The smallest network"))


def upscaling(scene):
    """The view message's upscaler fields: {} for none. Pure.

    TSR and DLSS go through BU's native render (a full view rather than a scene capture), which
    takes a screen percentage; DLSS picks its own from its mode. Not for the path tracer, which
    renders every pixel itself."""
    settings = getattr(scene, "bu_render", None)
    if settings is None or getattr(settings, "renderer", "LUMEN") == "PATH_TRACER":
        return {}
    kind = getattr(settings, "upscaler", "NONE")
    if kind == "TSR":
        return {"render_scale": _round(float(settings.tsr_percentage))}
    if kind == "DLSS":
        return {"render_scale": 100.0, "upscaler": "DLSS",
                "upscaler_mode": DLSS_MODE_NAMES.get(settings.dlss_mode, "DLAA")}
    return {}


def dlss_note():
    """Why DLSS will not be used, once Unreal has said which upscalers it has; "" otherwise."""
    from . import link

    found = getattr(link._STATE, "upscalers", None)
    if found is None or "DLSS" in found:
        return ""
    return "BU's Unreal has no DLSS here: TSR is used"


# Advanced Lumen settings: (property, Unreal post-process setting, Unreal's default, factor from
# the property's unit to Unreal's). Sent only when they differ from Unreal's default, so the
# project's own value stands otherwise. Distances are metres here, centimetres there.
LUMEN_GI_SETTINGS = (
    ("indirect_intensity", "indirect_lighting_intensity", 1.0, 1.0),
    ("lumen_scene_detail", "lumen_scene_detail", 1.0, 1.0),
    ("lumen_scene_lighting_quality", "lumen_scene_lighting_quality", 1.0, 1.0),
    ("lumen_scene_view_distance", "lumen_scene_view_distance", 200.0, 100.0),
    ("lumen_scene_update_speed", "lumen_scene_lighting_update_speed", 1.0, 1.0),
    ("final_gather_quality", "lumen_final_gather_quality", 1.0, 1.0),
    ("final_gather_update_speed", "lumen_final_gather_lighting_update_speed", 1.0, 1.0),
    ("max_trace_distance", "lumen_max_trace_distance", 200.0, 100.0),
    ("diffuse_color_boost", "lumen_diffuse_color_boost", 1.0, 1.0),
    ("lumen_ao", "lumen_ambient_occlusion_intensity", 1.0, 1.0),
    ("skylight_leaking", "lumen_skylight_leaking", 0.0, 1.0),
    ("skylight_leaking_distance", "lumen_full_skylight_leaking_distance", 10.0, 100.0),
    # Unreal halves the surface cache for scene captures; BU's capture is the picture, so the
    # Unreal side asks for the full one unless told otherwise.
    ("surface_cache_resolution", "lumen_surface_cache_resolution", 1.0, 1.0),
)
LUMEN_REFLECTION_SETTINGS = (
    ("reflection_quality", "lumen_reflection_quality", 1.0, 1.0),
    ("max_roughness", "lumen_max_roughness_to_trace_reflections", 0.4, 1.0),
    ("reflection_bounces", "lumen_max_reflection_bounces", 1, 1),
    ("refraction_bounces", "lumen_max_refraction_bounces", 0, 1),
)
# The path tracer's settings: always sent while it is the renderer.
PATH_TRACER_SETTINGS = (
    ("pt_samples", "path_tracing_samples_per_pixel"),
    ("pt_bounces", "path_tracing_max_bounces"),
    ("pt_denoise", "path_tracing_enable_denoiser"),
    ("pt_max_intensity", "path_tracing_max_path_intensity"),
    ("pt_emissive", "path_tracing_enable_emissive_materials"),
    ("pt_reference_dof", "path_tracing_enable_reference_dof"),
    ("pt_reference_atmosphere", "path_tracing_enable_reference_atmosphere"),
)


class BU_LinkRenderUnreal(bpy.types.PropertyGroup):
    renderer: bpy.props.EnumProperty(
        name="Renderer", items=RENDERER_CHOICES, default="LUMEN", update=_asset_changed,
        description="How Unreal renders the picture")
    shadows: bpy.props.EnumProperty(
        name="Shadows", items=SHADOW_CHOICES, default="PROJECT", update=_asset_changed,
        description="How every light casts its shadows, unless the light's own Ray Traced "
                    "Shadows (Light Properties > Unreal Light) says On or Off")
    gi: bpy.props.EnumProperty(name="Global Illumination", items=GI_CHOICES, default="PROJECT",
                               update=_asset_changed)
    reflections: bpy.props.EnumProperty(name="Reflections", items=REFLECTION_CHOICES,
                                        default="PROJECT", update=_asset_changed)
    ray_lighting: bpy.props.EnumProperty(
        name="Ray Lighting", items=RAY_LIGHTING_CHOICES, default="HIT_LIGHTING",
        update=_asset_changed,
        description="How Lumen lights what its rays hit. Unreal's default, the surface cache, "
                    "is what makes reflections and bounce light look approximate")
    screen_traces: bpy.props.BoolProperty(
        name="Screen Traces", default=True, update=_asset_changed,
        description="Let Lumen reuse what is already on screen before tracing rays. Faster, "
                    "but what is off screen or hidden behind something drops out. Off traces "
                    "everything")
    upscaler: bpy.props.EnumProperty(
        # TSR by default: at full size a mid-range card gave a tester's every scene a picture
        # every 50 ms or so, and TSR at 67% made it smooth.
        name="Upscaling", items=UPSCALER_CHOICES, default="TSR", update=_upscaling_changed,
        description="Render fewer pixels and rebuild the picture, for speed, or smooth it at "
                    "full size")
    tsr_percentage: bpy.props.FloatProperty(
        name="Resolution", default=67.0, min=25.0, max=100.0, subtype="PERCENTAGE",
        update=_view_changed,
        description="Share of the picture's width and height Unreal renders before TSR "
                    "rebuilds the rest")
    dlss_mode: bpy.props.EnumProperty(
        name="Mode", items=[row[:3] for row in DLSS_MODES], default="DLAA",
        update=_view_changed, description="How many pixels Unreal renders before DLSS")
    dlss_rr: bpy.props.BoolProperty(
        name="Ray Reconstruction", default=False, update=_asset_changed,
        description="DLSS also denoises Lumen's global illumination and reflections, in place "
                    "of Unreal's own denoisers. Some GPU time")
    overscan: bpy.props.FloatProperty(
        name="Overscan", default=10.0, min=0.0, max=50.0, subtype="PERCENTAGE",
        update=_view_changed,
        description="Render this much more round every edge of the view and crop it off, so "
                    "screen traces, screen-space reflections, ambient occlusion and contact "
                    "shadows can see what is just outside the frame. Costs pixels: 10% renders "
                    "1.44 times as many")

    # -- Lumen global illumination, advanced (Unreal's post-process settings) --
    indirect_intensity: bpy.props.FloatProperty(
        name="Indirect Intensity", default=1.0, min=0.0, soft_max=4.0, update=_asset_changed,
        description="Scales all bounce light")
    lumen_scene_detail: bpy.props.FloatProperty(
        name="Scene Detail", default=1.0, min=0.25, soft_max=4.0, update=_asset_changed,
        description="How small an object Lumen still keeps in its scene. Higher keeps small "
                    "parts (eyes, lids, trim) lit and bouncing light")
    lumen_scene_lighting_quality: bpy.props.FloatProperty(
        name="Scene Lighting Quality", default=1.0, min=0.25, soft_max=2.0, update=_asset_changed,
        description="Quality of the lighting Lumen caches on surfaces")
    lumen_scene_view_distance: bpy.props.FloatProperty(
        name="Scene View Distance", default=200.0, min=0.01, soft_max=20000.0, unit="LENGTH",
        update=_asset_changed, description="How far from the camera Lumen's scene reaches")
    lumen_scene_update_speed: bpy.props.FloatProperty(
        name="Scene Update Speed", default=1.0, min=0.5, soft_max=4.0, update=_asset_changed,
        description="How fast the cached surface lighting follows changes")
    final_gather_quality: bpy.props.FloatProperty(
        name="Final Gather Quality", default=1.0, min=0.25, soft_max=2.0, max=8.0,
        update=_asset_changed,
        description="Rays gathered per pixel for bounce light: less noise and leaking, more GPU")
    final_gather_update_speed: bpy.props.FloatProperty(
        name="Final Gather Update Speed", default=1.0, min=0.5, soft_max=4.0, update=_asset_changed,
        description="How fast the bounce light follows changes; slower is smoother")
    max_trace_distance: bpy.props.FloatProperty(
        name="Max Trace Distance", default=200.0, min=0.01, soft_max=20000.0, unit="LENGTH",
        update=_asset_changed, description="How far a bounce-light ray looks")
    diffuse_color_boost: bpy.props.FloatProperty(
        name="Diffuse Color Boost", default=1.0, min=1.0, max=4.0, update=_asset_changed,
        description="Brightens the colour surfaces pass on when light bounces off them")
    lumen_ao: bpy.props.FloatProperty(
        name="Ambient Occlusion", default=1.0, min=0.0, max=1.0, update=_asset_changed,
        description="How much Lumen's short-range occlusion darkens creases")
    skylight_leaking: bpy.props.FloatProperty(
        name="Skylight Leaking", default=0.0, min=0.0, max=1.0, update=_asset_changed,
        description="Lets this share of the sky light into enclosed spaces")
    skylight_leaking_distance: bpy.props.FloatProperty(
        name="Skylight Leaking Distance", default=10.0, min=0.001, soft_max=20.0, unit="LENGTH",
        update=_asset_changed, description="Distance over which the leaking reaches full")
    surface_cache_resolution: bpy.props.FloatProperty(
        name="Surface Cache Resolution", default=1.0, min=0.5, max=1.0, update=_asset_changed,
        description="Resolution of Lumen's surface cache")

    # -- Lumen reflections, advanced --
    reflection_quality: bpy.props.FloatProperty(
        name="Quality", default=1.0, min=0.25, soft_max=2.0, max=8.0, update=_asset_changed,
        description="Rays for reflections: less noise, more GPU")
    max_roughness: bpy.props.FloatProperty(
        name="Max Roughness to Trace", default=0.4, min=0.0, max=1.0, update=_asset_changed,
        description="Surfaces rougher than this reflect from Lumen's cheaper diffuse estimate "
                    "instead of traced rays")
    reflection_bounces: bpy.props.IntProperty(
        name="Max Reflection Bounces", default=1, min=1, max=8, update=_asset_changed,
        description="Reflections seen in reflections")
    refraction_bounces: bpy.props.IntProperty(
        name="Max Refraction Bounces", default=0, min=0, max=64, update=_asset_changed,
        description="Bounces through refracting glass")

    # -- ambient occlusion (`describe_ao`) --
    contact_ao: bpy.props.EnumProperty(
        name="Contact AO", items=CONTACT_AO_CHOICES, default="SSAO", update=_asset_changed,
        description="The fine occlusion in creases and where things touch, which Lumen's "
                    "bounce light is too coarse to show")
    ssao_intensity: bpy.props.FloatProperty(
        name="Intensity", default=0.5, min=0.0, max=1.0, update=_asset_changed,
        description="How dark SSAO makes occluded places (Unreal's default 0.5)")
    ssao_distance: bpy.props.FloatProperty(
        name="Distance", default=1.0, min=0.001, soft_max=5.0, max=1000.0, unit="LENGTH",
        update=_asset_changed,
        description="How far away something still occludes, as EEVEE's AO distance")
    ssao_power: bpy.props.FloatProperty(
        name="Power", default=2.0, min=0.1, max=8.0, update=_asset_changed,
        description="Contrast of SSAO: higher keeps it to the darkest creases (Unreal's default 2)")
    extra_ao: bpy.props.BoolProperty(
        name="Extra AO", default=False, update=_asset_changed,
        description="More occlusion on Lumen's bounce light, from anything within a distance, "
                    "for a look rather than for accuracy (Unreal's "
                    "r.Lumen.ScreenProbeGather.ExtraAmbientOcclusion). Broad and soft: it is "
                    "worked out per screen probe, not per pixel")
    extra_ao_distance: bpy.props.FloatProperty(
        name="Distance", default=5.0, min=0.01, soft_max=20.0, max=10000.0, unit="LENGTH",
        update=_asset_changed,
        description="Surfaces closer than this occlude, more the closer they are "
                    "(Unreal's default 5 m)")
    extra_ao_strength: bpy.props.FloatProperty(
        name="Strength", default=2.0, min=0.01, soft_max=4.0, max=16.0, update=_asset_changed,
        description="How quickly occlusion fades with distance: higher is darker. Unreal's "
                    "exponent for it (Unreal's default 0.5 is hard to see)")

    # -- F12 (`link_view.render_still`): Blender's own, not sent --
    still_warmup: bpy.props.IntProperty(
        name="Warm-Up Frames", default=64, min=1, soft_max=256, max=4096,
        description="Frames Unreal renders of the camera, with nothing changing or loading, "
                    "before F12 keeps one. Lumen's lighting and TSR's anti-aliasing build up "
                    "over frames: fewer is faster, but can be noisier, darker in corners or "
                    "softer. The path tracer waits for its samples instead")

    # -- the path tracer --
    pt_samples: bpy.props.IntProperty(
        name="Samples", default=512, min=1, soft_max=4096, max=65536, update=_asset_changed,
        description="Samples per pixel. The picture refines until it has them all, starting "
                    "again whenever the view or scene changes")
    pt_bounces: bpy.props.IntProperty(
        name="Max Bounces", default=32, min=0, max=100, update=_asset_changed,
        description="How many times a ray may bounce")
    pt_denoise: bpy.props.BoolProperty(
        name="Denoise", default=True, update=_asset_changed,
        description="Clean up the remaining noise")
    pt_denoise_live: bpy.props.BoolProperty(
        name="Denoise While Refining", default=True, update=_asset_changed,
        description="Denoise every frame, not only once all the samples are in: a clean "
                    "picture at once, for some frame time")
    pt_denoise_quality: bpy.props.EnumProperty(
        name="Denoise Quality", items=PT_DENOISE_QUALITY, default="HIGH", update=_asset_changed,
        description="Which of Open Image Denoise's networks cleans the finished picture (the "
                    "same ones Blender uses, on the GPU). While refining, Unreal uses its "
                    "Balanced one")
    pt_max_intensity: bpy.props.FloatProperty(
        name="Max Path Intensity", default=24.0, min=1.0, max=65504.0, update=_asset_changed,
        description="Clamps very bright paths, which removes fireflies at the cost of some "
                    "energy (Clamping in Cycles)")
    pt_emissive: bpy.props.BoolProperty(
        name="Emissive Materials", default=True, update=_asset_changed,
        description="Glowing materials light the scene")
    pt_reference_dof: bpy.props.BoolProperty(
        name="Reference Depth of Field", default=False, update=_asset_changed,
        description="Trace depth of field instead of the post-process blur")
    pt_reference_atmosphere: bpy.props.BoolProperty(
        name="Reference Atmosphere", default=False, update=_asset_changed,
        description="Trace the sky atmosphere instead of its approximation")


def _changed_settings(settings, table):
    """{Unreal setting: value in Unreal's units} for the table's properties not at Unreal's
    default. Pure."""
    found = {}
    for prop, name, default, factor in table:
        value = getattr(settings, prop, default)
        if isinstance(default, int) and not isinstance(default, bool):
            if int(value) != default:
                found[name] = int(value) * int(factor)
        elif abs(float(value) - float(default)) > 1e-6:
            found[name] = _round(float(value) * factor)
    return found


def describe_ao(settings):
    """Ambient occlusion beyond Lumen's own, for the `render` message: {} when there is none.
    Pure. Distances go in centimetres."""
    if settings is None:
        return {}
    ao = {}
    # Anything but SSAO (Lumen, or the dropped Ray Traced in an older file) is Lumen's own.
    contact = str(getattr(settings, "contact_ao", "") or "")
    if contact == "SSAO":
        ao["contact"] = contact
        ao["ssao"] = {"ambient_occlusion_intensity": _round(settings.ssao_intensity),
                      "ambient_occlusion_radius": _round(settings.ssao_distance * 100.0),
                      "ambient_occlusion_power": _round(settings.ssao_power)}
    if getattr(settings, "extra_ao", False):
        ao["extra"] = {"distance": _round(settings.extra_ao_distance * 100.0),
                       "exponent": _round(settings.extra_ao_strength)}
    return ao


def describe_render(scene):
    """How Unreal should light the picture: only what differs from the project. Pure."""
    settings = getattr(scene, "bu_render", None)
    found = {}
    for name in ("gi", "reflections", "ray_lighting", "shadows"):
        value = str(getattr(settings, name, "PROJECT") or "PROJECT")
        if value != "PROJECT":
            found[name] = value
    if settings is not None and not settings.screen_traces:
        found["screen_traces"] = False
    if settings is None:
        return found
    lumen = _changed_settings(settings, LUMEN_GI_SETTINGS + LUMEN_REFLECTION_SETTINGS)
    if lumen:
        found["lumen"] = lumen
    ao = describe_ao(settings)
    if ao and getattr(settings, "renderer", "LUMEN") != "PATH_TRACER":
        found["ao"] = ao
    if getattr(settings, "renderer", "LUMEN") == "PATH_TRACER":
        found["renderer"] = "PATH_TRACER"
        path = {}
        for prop, name in PATH_TRACER_SETTINGS:
            value = getattr(settings, prop)
            path[name] = value if isinstance(value, (bool, int)) else _round(value)
        found["path_tracing"] = path
        if settings.pt_denoise and settings.pt_denoise_quality != "BALANCED":
            found["denoise_quality"] = settings.pt_denoise_quality
        if settings.pt_denoise and settings.pt_denoise_live:
            found["denoise_live"] = True
    elif getattr(settings, "upscaler", "NONE") == "DLSS" and settings.dlss_rr:
        found["dlss_rr"] = True
    return found


def describe_environment(scene, level_sky=True):
    """The whole `environment` message body for a scene."""
    found = describe_world(scene.world, level_sky)
    found.update(describe_camera(scene))
    found["render"] = describe_render(scene)
    return found


def environment_active(spec):
    return bool(spec.get("sky", "OFF") != "OFF" or spec.get("fog") or spec.get("post")
                or spec.get("clouds") or spec.get("hide_level_suns") or spec.get("render"))


# -- fog volumes --------------------------------------------------------------------------------

def _volume_shader(material, with_surface=False):
    """The volume node of a fog-volume material, or None. `with_surface` also takes one whose
    surface is wired too (a box shown as Wire or Bounds, whose surface the viewport never draws)."""
    if material is None or not getattr(material, "use_nodes", False) or material.node_tree is None:
        return None
    tree = material.node_tree
    output = None
    for target in ("EEVEE", "ALL", "CYCLES"):
        try:
            output = tree.get_output_node(target)
        except (AttributeError, TypeError):
            output = None
        if output is not None:
            break
    if output is None:
        return None
    surface, volume = output.inputs.get("Surface"), output.inputs.get("Volume")
    if surface is None or volume is None or not volume.is_linked:
        return None
    if surface.is_linked and not with_surface:
        return None
    node = volume.links[0].from_node
    return node if node.type in ("PRINCIPLED_VOLUME", "VOLUME_SCATTER", "VOLUME_ABSORPTION") \
        else None


def outline_only(obj):
    """True for an object shown as Wire or Bounds: Blender's viewport draws no surface for it, in
    Rendered shading too (a fog box, a particle emitter's cube)."""
    return getattr(obj, "display_type", "TEXTURED") in ("WIRE", "BOUNDS")


def is_volume(obj):
    """A mesh whose material is only a volume, or one shown as Wire or Bounds whose material has
    a volume: a fog volume, not a surface."""
    if obj.type != "MESH" or not obj.material_slots:
        return False
    return _volume_shader(obj.material_slots[0].material, outline_only(obj)) is not None


def _socket(node, name, fallback):
    socket = node.inputs.get(name)
    return socket.default_value if socket is not None else fallback


def describe_volume(obj):
    """A fog-volume object -> (16-float matrix for Unreal, settings)."""
    node = _volume_shader(obj.material_slots[0].material, True)
    density = float(_socket(node, "Density", 1.0))
    found = {"density": _round(density * FOG_VOLUME_PEAK),
             "anisotropy": _round(_socket(node, "Anisotropy", 0.0))}
    if node.type == "VOLUME_ABSORPTION":
        found["albedo"] = [0.0, 0.0, 0.0]
    else:
        found["albedo"] = _colour(_socket(node, "Color", (1.0, 1.0, 1.0)))
    emission = [0.0, 0.0, 0.0]
    if node.type == "PRINCIPLED_VOLUME":
        strength = float(_socket(node, "Emission Strength", 0.0))
        emission = [_round(c * strength) for c in tuple(_socket(
            node, "Emission Color", (1.0, 1.0, 1.0)))[:3]]
    found["emission"] = emission
    # The volume is a sphere of FOG_VOLUME_BASE_M times the largest scale: fit the object's
    # bounding box's largest half-extent, centred on the box.
    corners = [tuple(c) for c in obj.bound_box]
    low = [min(c[i] for c in corners) for i in range(3)]
    high = [max(c[i] for c in corners) for i in range(3)]
    centre = [(a + b) / 2.0 for a, b in zip(low, high)]
    world = obj.matrix_world
    scale = [world.col[i].xyz.length for i in range(3)]
    radius = max((high[i] - low[i]) / 2.0 * scale[i] for i in range(3))
    location = world @ _vector(centre)
    rotation = world.to_quaternion().to_matrix().to_4x4()
    size = max(radius, 1e-4) / FOG_VOLUME_BASE_M
    matrix = rotation.copy()
    for row in range(3):
        for column in range(3):
            matrix[row][column] *= size
    matrix.translation = location
    return link_mesh.matrix_to_unreal(matrix), found


def _vector(values):
    from mathutils import Vector

    return Vector(values)


# -- panels ---------------------------------------------------------------------------------------

ENGINE_ID = "BU_UNREAL"  # link_view.ENGINE_ID, without importing the GPU side here


class BU_PT_link_light(bpy.types.Panel):
    bl_label = "Unreal Light"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "data"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return isinstance(getattr(context, "light", None), bpy.types.Light)

    def draw(self, context):
        from . import link

        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        light = context.light
        settings = light.bu_unreal
        kind = light.type
        sun = kind == "SUN"
        if context.engine == ENGINE_ID:
            # EEVEE's Shadow panel is hidden for Unreal (its jitter and resolution are EEVEE's
            # own); whether the light casts shadows still comes from here.
            layout.prop(light, "use_shadow", text="Cast Shadows")

        header, body = layout.panel("bu_light_intensity", default_closed=False)
        header.label(text="Intensity")
        if body:
            body.prop(settings, "use_intensity", text="Unreal Units")
            col = body.column()
            col.active = settings.use_intensity
            col.prop(settings, "intensity", text="Lux" if sun else "Intensity")
            if not sun:
                col.prop(settings, "units")

        header, body = layout.panel("bu_light_shape", default_closed=True)
        header.label(text="Sun" if sun else "Shape & Falloff")
        if body:
            if sun:
                body.prop(settings, "soft_angle")
                body.prop(settings, "atmosphere_sun")
                col = body.column()
                col.active = settings.atmosphere_sun
                col.prop(settings, "atmosphere_index")
                body.prop(settings, "cloud_shadows")
                body.prop(settings, "light_shafts")
                col = body.column()
                col.active = settings.light_shafts
                col.prop(settings, "shaft_bloom")
            elif kind == "AREA":
                body.prop(settings, "barn_door_length")
                body.prop(settings, "attenuation")
            else:
                body.prop(settings, "source_length")
                body.prop(settings, "soft_radius")
                body.prop(settings, "attenuation")
                body.prop(settings, "inverse_square")
                col = body.column()
                col.active = not settings.inverse_square
                col.prop(settings, "falloff_exponent")

        header, body = layout.panel("bu_light_shadows", default_closed=False)
        header.label(text="Shadows")
        if body:
            body.prop(settings, "ray_traced_shadows")
            col = body.column()
            col.active = settings.ray_traced_shadows != "OFF"
            col.prop(settings, "samples_per_pixel")
            if settings.ray_traced_shadows == "AUTO":
                scene = getattr(context.scene, "bu_render", None)
                if scene is not None:
                    names = dict((key, label) for key, label, _tip in SHADOW_CHOICES)
                    body.label(text="Scene: " + names.get(scene.shadows, scene.shadows),
                               icon="SCENE_DATA")
            body.prop(settings, "volumetric_shadow")
            body.prop(settings, "contact_shadow")
            if sun:
                body.prop(settings, "shadow_distance")
                body.prop(settings, "cascades")

        header, body = layout.panel("bu_light_contribution", default_closed=True)
        header.label(text="Contribution")
        if body:
            for name in ("diffuse", "specular", "indirect", "volumetric"):
                body.prop(settings, name)
            col = body.column(heading="Affects")
            col.prop(settings, "affects_world", text="World")
            col.prop(settings, "affect_reflection", text="Reflections")
            col.prop(settings, "affect_gi", text="Global Illumination")
            col.prop(settings, "affect_translucent", text="Translucency")
            row = body.row(heading="Channels")
            row.prop(settings, "channels", text="")

        header, body = layout.panel("bu_light_assets", default_closed=True)
        header.label(text="Unreal Assets")
        if body:
            if not sun:
                body.prop(settings, "ies", icon="LIGHT_SPOT")
                col = body.column()
                col.active = bool(settings.ies)
                col.prop(settings, "ies_brightness")
                col.prop(settings, "ies_scale")
            body.prop(settings, "light_function", icon="MATERIAL")
            if kind == "AREA":
                body.prop(settings, "source_texture", icon="TEXTURE")
            body.operator(BU_OT_link_list_assets.bl_idname, icon="FILE_REFRESH")
            if not link.is_running():
                body.label(text="Start the link to pick Unreal assets", icon="INFO")


class BU_PT_link_world(bpy.types.Panel):
    bl_label = "Unreal Sky & Fog"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "world"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return getattr(context, "world", None) is not None

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        world = context.world
        settings = world.bu_unreal
        layout.prop(settings, "sky")
        if settings.sky != "OFF":
            source = sky_source(world)
            mode = settings.sky
            if mode == "AUTO":
                mode = "PHYSICAL" if source["mode"] == "SKY" else "WORLD"
            if mode == "WORLD":
                text = {"HDRI": "The World's HDRI", "COLOR": "The World's colour",
                        "SKY": "The World's colour (a Sky Texture needs Physical Sky)"}
                layout.label(text=text.get(source["mode"], ""), icon="WORLD")
            else:
                layout.label(text="Sky Atmosphere, lit by the Blender sun", icon="LIGHT_SUN")
            layout.prop(settings, "sky_intensity")
            layout.prop(settings, "lower_black")
            layout.prop(settings, "hide_level_sky")
        layout.separator()
        layout.prop(settings, "clouds")
        if settings.clouds:
            col = layout.column()
            for name in ("cloud_coverage", "cloud_density", "cloud_size", "cloud_colour",
                         "cloud_bottom", "cloud_thickness"):
                col.prop(settings, name)
            if settings.sky == "OFF":
                col.label(text="Lit best by a Physical Sky", icon="INFO")
        layout.separator()
        layout.prop(settings, "fog")
        if settings.fog:
            col = layout.column()
            for name in ("fog_density", "fog_falloff", "fog_height", "fog_color", "fog_opacity",
                         "fog_start", "hide_level_fog"):
                col.prop(settings, name)
            col.prop(settings, "volumetric")
            sub = col.column()
            sub.active = settings.volumetric
            for name in ("vol_scattering", "vol_albedo", "vol_extinction", "vol_distance"):
                sub.prop(settings, name)
        layout.separator()
        layout.prop(settings, "hide_level_suns")
        layout.label(text="Volume-only materials become Local Fog Volumes", icon="INFO")


class _RenderPanel:
    """A Render properties panel of the Unreal engine's own."""
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "render"
    COMPAT_ENGINES = {ENGINE_ID}

    @classmethod
    def poll(cls, context):
        return context.engine in cls.COMPAT_ENGINES


class BU_PT_render_lighting(_RenderPanel, bpy.types.Panel):
    bl_label = "Lighting"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        settings = context.scene.bu_render
        layout.prop(settings, "renderer")
        if settings.renderer == "PATH_TRACER":
            layout.prop(settings, "pt_samples")
            layout.prop(settings, "pt_bounces")
            layout.prop(settings, "pt_denoise")
            col = layout.column()
            col.active = settings.pt_denoise
            col.prop(settings, "pt_denoise_quality")
            col.prop(settings, "pt_denoise_live")
        else:
            layout.prop(settings, "gi")
            layout.prop(settings, "reflections")
            layout.prop(settings, "ray_lighting")
            layout.prop(settings, "shadows")
            layout.prop(settings, "screen_traces")
            layout.prop(settings, "upscaler")
            if settings.upscaler == "TSR":
                layout.prop(settings, "tsr_percentage")
            elif settings.upscaler == "DLSS":
                layout.prop(settings, "dlss_mode")
                layout.prop(settings, "dlss_rr")
                note = dlss_note()
                if note:
                    layout.label(text=note, icon="INFO")
        layout.prop(settings, "overscan")


class _LightingSubPanel(_RenderPanel):
    bl_parent_id = "BU_PT_render_lighting"
    bl_options = {"DEFAULT_CLOSED"}
    PROPS = ()
    RENDERER = "LUMEN"

    @classmethod
    def poll(cls, context):
        settings = getattr(context.scene, "bu_render", None)
        return (context.engine in cls.COMPAT_ENGINES and settings is not None
                and settings.renderer == cls.RENDERER)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        for prop in self.PROPS:
            layout.prop(context.scene.bu_render, prop)


class BU_PT_render_lumen_gi(_LightingSubPanel, bpy.types.Panel):
    bl_label = "Global Illumination"
    PROPS = tuple(row[0] for row in LUMEN_GI_SETTINGS if row[0] != "lumen_ao")


class BU_PT_render_ao(_LightingSubPanel, bpy.types.Panel):
    bl_label = "Ambient Occlusion"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        settings = context.scene.bu_render
        layout.prop(settings, "contact_ao")
        if settings.contact_ao == "SSAO":
            layout.prop(settings, "ssao_intensity")
            layout.prop(settings, "ssao_distance")
            layout.prop(settings, "ssao_power")
        else:
            layout.prop(settings, "lumen_ao", text="Intensity")
        layout.separator()
        layout.prop(settings, "extra_ao")
        column = layout.column()
        column.active = settings.extra_ao
        column.prop(settings, "extra_ao_distance")
        column.prop(settings, "extra_ao_strength")


class BU_PT_render_lumen_reflections(_LightingSubPanel, bpy.types.Panel):
    bl_label = "Reflections"
    PROPS = tuple(row[0] for row in LUMEN_REFLECTION_SETTINGS)


class BU_PT_render_path_tracer(_LightingSubPanel, bpy.types.Panel):
    bl_label = "Path Tracer"
    RENDERER = "PATH_TRACER"
    PROPS = ("pt_max_intensity", "pt_emissive", "pt_reference_dof", "pt_reference_atmosphere")


class BU_PT_link_camera(_RenderPanel, bpy.types.Panel):
    bl_label = "Camera"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.prop(context.scene.bu_unreal, "enabled", text="")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        settings = context.scene.bu_unreal
        layout.active = settings.enabled
        layout.prop(settings, "exposure")
        if settings.exposure == "MANUAL":
            layout.prop(settings, "ev100")
        layout.prop(settings, "compensation")
        layout.prop(settings, "follow_blender")
        col = layout.column()
        for name in ("bloom", "vignette", "grain", "motion_blur", "white_temp", "saturation",
                     "contrast"):
            col.prop(settings, name)


class BU_OT_link_list_assets(bpy.types.Operator):
    bl_idname = "bu.link_list_assets"
    bl_label = "Refresh Unreal Assets"
    bl_description = "Ask Unreal for its IES profiles, light functions and textures"

    @classmethod
    def poll(cls, context):
        from . import link

        return link.is_running()

    def execute(self, context):
        from . import link

        for kind in ("ies", "light_function", "texture"):
            link.request_unreal_assets(kind, force=True)
        return {"FINISHED"}


_classes = (BU_LinkLightUnreal, BU_LinkWorldUnreal, BU_LinkCameraUnreal, BU_LinkRenderUnreal,
            BU_OT_link_list_assets, BU_PT_link_light, BU_PT_link_world, BU_PT_render_lighting,
            BU_PT_render_lumen_gi, BU_PT_render_ao, BU_PT_render_lumen_reflections,
            BU_PT_render_path_tracer, BU_PT_link_camera)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Light.bu_unreal = bpy.props.PointerProperty(type=BU_LinkLightUnreal)
    bpy.types.World.bu_unreal = bpy.props.PointerProperty(type=BU_LinkWorldUnreal)
    bpy.types.Scene.bu_unreal = bpy.props.PointerProperty(type=BU_LinkCameraUnreal)
    bpy.types.Scene.bu_render = bpy.props.PointerProperty(type=BU_LinkRenderUnreal)


def unregister():
    del bpy.types.Scene.bu_render
    del bpy.types.Scene.bu_unreal
    del bpy.types.World.bu_unreal
    del bpy.types.Light.bu_unreal
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
