# SPDX-License-Identifier: GPL-3.0-or-later
"""Loading and indexing the BU sidecar manifest on the Unreal side."""

import json
import os

SUFFIX = ".bu.json"
SUPPORTED_VERSION = 1


class Manifest(object):
    """A loaded BU manifest, indexed for lookup by imported asset."""

    def __init__(self, data, path=""):
        self.data = data
        self.path = path

        # One texture can be reachable under several filenames (Blender may rename,
        # pack or synthesise the file), so flatten every candidate into one index.
        self._by_key = {}
        for texture in data.get("textures", []):
            for key in texture.get("match_keys") or [texture.get("key", "")]:
                if key:
                    self._by_key[key.lower()] = texture
            # Also index the bare stem, since Unreal sanitises asset names.
            stem = os.path.splitext(texture.get("key", ""))[0].lower()
            if stem:
                self._by_key.setdefault(stem, texture)

        self._cameras = {c["object_name"]: c for c in data.get("cameras", [])}

    # -- construction --------------------------------------------------------

    @classmethod
    def load(cls, path):
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)

        version = data.get("bu_manifest_version")
        if version != SUPPORTED_VERSION:
            raise ValueError(
                "BU manifest version {0} is not supported (expected {1})".format(
                    version, SUPPORTED_VERSION
                )
            )
        return cls(data, path)

    @classmethod
    def find_for_usd(cls, usd_path):
        """Locate the sidecar that belongs to a USD file, if it is there."""
        candidate = os.path.splitext(usd_path)[0] + SUFFIX
        if os.path.exists(candidate):
            return cls.load(candidate)
        return None

    # -- lookup --------------------------------------------------------------

    def texture_for(self, *candidates):
        """Resolve a texture entry from any of several names.

        Callers pass whatever they have -- the resolved source filename from
        AssetImportData, the Unreal asset name, the prim name -- and the first hit wins.
        """
        for candidate in candidates:
            if not candidate:
                continue
            base = os.path.basename(str(candidate)).lower()
            hit = self._by_key.get(base)
            if hit:
                return hit
            hit = self._by_key.get(os.path.splitext(base)[0])
            if hit:
                return hit
        return None

    def camera(self, name):
        return self._cameras.get(name)

    # -- convenience accessors ----------------------------------------------

    @property
    def scene(self):
        return self.data.get("scene", {})

    @property
    def textures(self):
        return self.data.get("textures", [])

    @property
    def cameras(self):
        return self.data.get("cameras", [])

    @property
    def camera_cuts(self):
        return self.data.get("camera_cuts", [])

    @property
    def animation(self):
        return self.data.get("animation", {})

    @property
    def warnings(self):
        return self.data.get("warnings", [])

    @property
    def fps(self):
        return float(self.scene.get("fps", 24.0))

    @property
    def frame_start(self):
        return int(self.scene.get("frame_start", 1))

    @property
    def frame_end(self):
        return int(self.scene.get("frame_end", 1))
