# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender's hair as Unreal grooms (`link_hair` on Blender's side).

Each particle system's strands arrive in shared memory and are built into a transient groom
asset by the native module (`ApplyGroom`), shown by a GroomActor of the link's own at the
emitter's transform. The strands carry their colour and roughness (worked out in Blender at
each root), which BU's one hair material reads (Hair Attributes), so every system shares it.

The material is Unreal's Hair shading model, used with hair strands; with Substrate on Unreal
turns it into a Substrate hair BSDF itself. Hair renders without ray tracing (its own raster
pipeline), so a card without it shows the fur too.
"""

PACKAGE = "/Game/BU/Materials"
# Raised when `_build` wires the material differently: a new asset, not a stale one.
GRAPH = 1
MATERIAL = "M_BU_Hair_{0}".format(GRAPH)

_MATERIAL = {}


def can_groom():
    """Whether this editor builds grooms: the Groom plugin's classes and the native call."""
    try:
        import unreal
    except ImportError:
        return False
    library = getattr(unreal, "BULinkLibrary", None)
    return (library is not None and hasattr(library, "apply_groom")
            and hasattr(unreal, "GroomActor"))


def ensure_material():
    """BU's hair material, built on first use. None if it cannot be made."""
    import unreal

    from . import bu_link_material

    if "material" in _MATERIAL:
        return _MATERIAL["material"]
    path = "{0}/{1}.{1}".format(PACKAGE, MATERIAL)
    library = unreal.EditorAssetLibrary
    material = library.load_asset(path) if library.does_asset_exist(path) else None
    if material is None:
        material = unreal.AssetToolsHelpers.get_asset_tools().create_asset(
            MATERIAL, PACKAGE, unreal.Material, unreal.MaterialFactoryNew())
        if material is None:
            unreal.log_error("BU: could not create " + path)
            _MATERIAL["material"] = None
            return None
        failed = _build(unreal, material, bu_link_material._quiet)
        if failed:
            unreal.log_warning("BU: {0}: could not set {1}".format(MATERIAL, ", ".join(failed)))
        bu_link_material.compile_material(unreal, material)
        library.save_loaded_asset(material, only_if_is_dirty=False)
        unreal.log("BU: created " + MATERIAL)
    _MATERIAL["material"] = material
    return material


def _build(unreal, material, quiet):
    edit = unreal.MaterialEditingLibrary
    failed = []
    try:
        quiet(material, "shading_model", unreal.MaterialShadingModel.MSM_HAIR, unreal)
    except Exception as exc:  # noqa: BLE001
        failed.append("shading_model ({0})".format(exc))
    usage = getattr(unreal.MaterialUsage, "MATUSAGE_HAIR_STRANDS", None)
    try:
        if usage is not None:
            edit.set_material_usage(material, usage)
        else:
            quiet(material, "used_with_hair_strands", True, unreal)
    except Exception as exc:  # noqa: BLE001
        failed.append("hair strands usage ({0})".format(exc))
    attributes = edit.create_material_expression(
        material, unreal.MaterialExpressionHairAttributes, -400, 0)
    for output, prop in (("BaseColor", unreal.MaterialProperty.MP_BASE_COLOR),
                         ("Roughness", unreal.MaterialProperty.MP_ROUGHNESS)):
        if not edit.connect_material_property(attributes, output, prop):
            failed.append(output)
    return failed


def apply(state, header, live_actor, spawn, transform):
    """Show one system's hair: its GroomActor (made on first use) at the emitter's transform,
    the strands built from shared memory. Returns the native call's code, or None."""
    import unreal

    name = header.get("name") or ""
    shared = header.get("shm") or {}
    if not name or not shared or not can_groom():
        return None
    actor = live_actor(state, name)
    if actor is not None and not isinstance(actor, unreal.GroomActor):
        actor = None
    if actor is None:
        actor = spawn(state, name, unreal.GroomActor)
        if actor is None:
            return None
    actor.set_actor_transform(transform(header["matrix"]), False, False)
    component = actor.get_editor_property("groom_component")
    result = int(unreal.BULinkLibrary.apply_groom(
        component, str(shared.get("name") or ""), int(shared.get("offset") or 0),
        int(header.get("strands") or 0), int(header.get("points") or 0)))
    if result < 0:
        raise ValueError("hair '{0}' was refused: {1}".format(name, ERRORS.get(
            result, "error {0}".format(result))))
    material = ensure_material()
    if material is not None:
        try:
            component.set_material(0, material)
        except Exception:  # noqa: BLE001
            pass
    return result


ERRORS = {-1: "no groom component", -2: "shared memory is gone", -3: "the strands run past "
          "the end of shared memory", -4: "bad strand or point counts",
          -8: "Unreal could not build the groom"}
