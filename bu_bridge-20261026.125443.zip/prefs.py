# SPDX-License-Identifier: GPL-3.0-or-later
"""Add-on preferences, mostly for the live-export round trip."""

import os
import tempfile

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty


def get(context=None):
    """Return BU's preferences, or None if the add-on is not registered as an extension."""
    context = context or bpy.context
    try:
        return context.preferences.addons[__package__].preferences
    except (KeyError, AttributeError):
        return None


def default_live_dir():
    return os.path.join(tempfile.gettempdir(), "bu_live")


def _sync_inbox(preferences):
    """Start or stop the save-request poll the moment the checkbox changes."""
    from . import agent

    if preferences.agent_inbox:
        agent.start()
    else:
        agent.stop()


class BU_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    unreal_dir: StringProperty(
        name="Unreal Install",
        description=(
            "Folder containing Engine/ (e.g. C:/Program Files/Epic Games/UE_5.8). "
            "Leave empty to search the usual locations"
        ),
        subtype="DIR_PATH",
        default="",
    )
    content_path: StringProperty(
        name="Content Path",
        description="Where live exports are imported to inside Unreal",
        default="/Game/BU/Live",
    )
    live_dir: StringProperty(
        name="Live Export Folder",
        description="Where the USD and its textures are written for live exports",
        subtype="DIR_PATH",
        default="",
    )
    live_format: EnumProperty(
        name="Live Format",
        description="USD flavour written by live export",
        items=(
            ("USDC", "Binary (.usdc)", "Compact crate file — faster for large scenes"),
            ("USDA", "Text (.usda)", "Human-readable ASCII — inspectable and diffable"),
        ),
        default="USDC",
    )
    reload_first: BoolProperty(
        name="Reload BU in Unreal First",
        description=(
            "Unreal caches Python modules for the whole editor session, so without this an "
            "updated BU appears to do nothing"
        ),
        default=True,
    )
    pixel_art_preset: BoolProperty(
        name="Pixel Art Preset",
        description=(
            "Make nearest-filtered textures uncompressed and mip-free, so block artefacts and "
            "distance blur do not creep back in. Costs memory"
        ),
        default=False,
    )
    discovery_timeout: FloatProperty(
        name="Discovery Timeout",
        description="Seconds to wait for a running Unreal Editor to answer",
        default=3.0,
        min=0.5,
        max=30.0,
    )
    multicast_group: StringProperty(
        name="Multicast Endpoint",
        description=(
            "Only change if you changed it in Unreal's Python settings. Default 239.0.0.1:6766"
        ),
        default="",
    )
    bind_address: StringProperty(
        name="Bind Address",
        description="Multicast bind address; must match Unreal's Python settings. Default 127.0.0.1",
        default="",
    )
    link_port: IntProperty(
        name="Real-Time Link Port",
        description="Local TCP port the real-time link uses. Unreal listens on 127.0.0.1 only",
        default=47823,
        min=1024,
        max=65535,
    )
    link_unreal: EnumProperty(
        name="Unreal for the Link",
        description="Which Unreal Editor the real-time link renders with",
        items=(
            ("MANAGED", "BU's Own (Hidden)",
             "BU starts its own Unreal Editor with no window, on a small project it keeps for "
             "this, and closes it when the link stops or Blender quits. Unreal never needs "
             "opening"),
            ("OPEN", "An Open Editor",
             "Connect to an Unreal Editor you have open, with BU's plugin in its project"),
        ),
        default="MANAGED",
    )
    render_project_dir: StringProperty(
        name="Render Project Folder",
        description=(
            "Where BU keeps the Unreal project its own editor renders with, one per engine "
            "version. Leave empty for the default"
        ),
        subtype="DIR_PATH",
        default="",
    )
    dlss_dir: StringProperty(
        name="DLSS Plugin",
        description=(
            "NVIDIA's DLSS plugin for Unreal, unpacked (the folder of NVIDIA's download, or its "
            "Plugins folder). BU copies what runs into its render project for Render > Lighting "
            "> Upscaling > DLSS. Not needed if the engine has DLSS installed from Fab"
        ),
        subtype="DIR_PATH",
        default="",
    )
    show_unreal_window: BoolProperty(
        name="Show Unreal's Window",
        description=(
            "Let BU's own editor open its window, for looking inside it or adding to its level "
            "(a sky from Fab, say: save the level there to keep it). Costs GPU time: the editor "
            "draws its own interface as well"
        ),
        default=False,
    )
    unreal_start_level: EnumProperty(
        name="Start In",
        description="The level BU's own editor opens when it starts",
        items=(
            ("LAST", "Last Saved Level",
             "The level that was open when BU's editor last ran, if it had been saved (in "
             "Unreal's window, with Show Unreal's Window on). Otherwise a new blank level"),
            ("BLANK", "Blank Level",
             "Always a new, empty level that is never saved: nothing of Unreal's own in the "
             "picture"),
        ),
        default="LAST",
    )
    ui_mode: EnumProperty(
        name="Settings",
        description="How many of Unreal's settings the Render properties show. Kept for you, "
                    "in every file",
        items=(
            ("SIMPLE", "Simple", "A few choices (Viewport, F12, Materials), each setting many of "
                                 "Unreal's settings"),
            ("ADVANCED", "All", "Every Unreal setting BU has: lighting, Lumen, ambient "
                                "occlusion, reflections, scalability and console variables"),
        ),
        default="SIMPLE",
    )
    material_format: EnumProperty(
        name="Material Format",
        description=(
            "How BU's editor stores materials for lighting (Substrate's G-buffer). Applies the "
            "next time BU starts Unreal; the first start after a change recompiles shaders, "
            "which can take a while"
        ),
        items=(
            ("ADAPTIVE", "Full (Sheen)",
             "Every layer of a material is kept, so sheen (Unreal's Fuzz) and glints show. "
             "Lumen can look grainy on some surfaces, such as rough metal in a dark room"),
            ("BLENDABLE", "Simple (Less Grain)",
             "Each material is folded into Unreal's older one-layer shading: Lumen is far less "
             "grainy, but sheen and glints are lost, and subsurface is much weaker (harder "
             "skin, little light through thin parts)"),
        ),
        default="ADAPTIVE",
    )
    cache_limit_gb: FloatProperty(
        name="Cache Limit (GB)",
        description=(
            "BU's editor saves every texture and node material Blender sends, so a scene opens "
            "faster the next time. Each time it starts, what has not been used for 30 days is "
            "deleted, then the least recently used until the textures fit in this"
        ),
        default=4.0,
        min=0.0,
        soft_max=50.0,
        precision=1,
    )
    link_max_triangles: IntProperty(
        name="Real-Time Triangle Limit",
        description=(
            "Objects with more triangles than this are left out of the real-time link, and "
            "named in the panel. 0 sends everything"
        ),
        default=300000,
        min=0,
    )
    agent_inbox: BoolProperty(
        name="Allow Save Requests",
        description=(
            "Let a script outside Blender ask this session to save itself, so headless exports "
            "cannot read a stale .blend. Saves to the file's existing path only — never "
            "save-as, never a different file. No network port is opened"
        ),
        default=True,
        update=lambda self, _ctx: _sync_inbox(self),
    )

    def resolved_live_dir(self):
        return bpy.path.abspath(self.live_dir) if self.live_dir else default_live_dir()

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True

        column = layout.column()
        column.prop(self, "unreal_dir")
        column.prop(self, "content_path")
        column.prop(self, "live_dir")
        if not self.live_dir:
            column.label(text="Using: " + default_live_dir(), icon="INFO")

        column = layout.column(heading="Live Export")
        column.prop(self, "live_format")
        column.prop(self, "reload_first")
        column.prop(self, "pixel_art_preset")
        column.prop(self, "discovery_timeout")

        box = layout.box()
        box.label(text="Unreal setup for live export", icon="INFO")
        box.label(text="Edit > Project Settings  (NOT Edit > Plugins)")
        box.label(text='Search "remote execution", or Plugins > Python in the sidebar')
        box.label(text='Tick "Enable Remote Execution?" - applies immediately, no restart')
        box.label(text="Then copy BU's unreal_python into <Project>/Content/Python")

        column = layout.column()
        column.prop(self, "multicast_group")
        column.prop(self, "bind_address")

        column = layout.column(heading="Real-Time Link")
        column.prop(self, "link_unreal")
        if self.link_unreal == "MANAGED":
            from . import link_host

            column.prop(self, "render_project_dir")
            if not self.render_project_dir:
                column.label(text="Using: " + link_host.default_project_root(), icon="INFO")
            column.prop(self, "show_unreal_window")
            column.prop(self, "unreal_start_level")
            folder = link_host.render_project_folder(
                bpy.path.abspath(self.unreal_dir) if self.unreal_dir else "",
                bpy.path.abspath(self.render_project_dir) if self.render_project_dir else "")
            column.label(text=link_host.start_level_line(folder, self.unreal_start_level),
                         icon="WORLD")
            column.prop(self, "material_format")
            host = link_host.HOST
            if host.alive() and host.material_format and host.material_format != self.material_format:
                column.label(text="Applies the next time Unreal starts", icon="INFO")
            column.prop(self, "dlss_dir")
            column.prop(self, "cache_limit_gb")
            row = column.row()
            row.label(text=link_host.cache_line(folder, self.cache_limit_gb), icon="DISK_DRIVE")
            row.operator(BU_OT_clear_render_cache.bl_idname, text="Clear")
        else:
            column.prop(self, "link_port")
        column.prop(self, "link_max_triangles")

        column = layout.column(heading="Automation")
        column.prop(self, "agent_inbox")
        if self.agent_inbox:
            from . import agent

            column.label(text="Inbox: " + agent.inbox_dir(), icon="FILE_FOLDER")


class BU_OT_clear_render_cache(bpy.types.Operator):
    """Delete the textures, meshes and node materials BU's editor saved to load scenes faster.
    They are made again as scenes are opened. Only while BU's editor is closed"""

    bl_idname = "bu.clear_render_cache"
    bl_label = "Clear BU's Render Cache"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        from . import link_host

        if link_host.HOST.alive():
            cls.poll_message_set("Stop BU's Unreal first: it may have them open")
            return False
        return True

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        from . import link_host

        preferences = get(context)
        folder = link_host.render_project_folder(
            bpy.path.abspath(preferences.unreal_dir) if preferences and preferences.unreal_dir
            else "",
            bpy.path.abspath(preferences.render_project_dir)
            if preferences and preferences.render_project_dir else "")
        if not folder:
            self.report({"WARNING"}, "No render project to clear")
            return {"CANCELLED"}
        removed, freed = link_host.clear_cache(folder)
        self.report({"INFO"}, "Removed {0} file(s), {1:.1f} GB".format(removed, freed / 2.0 ** 30))
        return {"FINISHED"}


def register():
    bpy.utils.register_class(BU_OT_clear_render_cache)
    bpy.utils.register_class(BU_Preferences)


def unregister():
    bpy.utils.unregister_class(BU_Preferences)
    bpy.utils.unregister_class(BU_OT_clear_render_cache)
