# SPDX-License-Identifier: GPL-3.0-or-later
"""Undo Blender's view transform, so Unreal's picture is shown as Unreal rendered it.

Used only with *Colour: Unreal* (or a plugin without half-float readback). By default Unreal
sends linear light instead and Blender's own colour management finishes it (`link_view`).

A render engine's `view_draw` writes **scene-linear** colour, and Blender then applies the
scene's view transform (AgX by default) on the way to the screen. Unreal's frame is already
finished — tone-mapped and sRGB-encoded — so drawn naively it is tone-mapped twice. Measured in
a real viewport: pure red arrived as (219, 57, 33) and mid-grey 128 as 170.

Drawing from an overlay callback instead avoids the transform and gives exact colour, but it
lands *on top of* the grid, selection outlines and object gizmos, which is most of the reason to
show the picture inside Blender at all.

So the frame is pushed through the **inverse** of the view transform first, and Blender's
forward transform then cancels it. The inverse comes from the same OpenColorIO config Blender is
using, baked once into a small 3D lookup table that the draw shader samples — no per-frame cost.

Not undone: the view's custom curves and white balance, which OpenColorIO does not own. With
either enabled the picture is shifted by exactly that adjustment.
"""

import os

import numpy as np

LUT_SIZE = 48
# Inverting a tone curve near white can ask for very large scene values. Blender's viewport
# buffer is half-float; this keeps the table well inside it.
MAX_SCENE_VALUE = 1000.0


def srgb_to_linear(values):
    """The piecewise sRGB decode. Exact inverse of Blender's *Standard* view on an sRGB display."""
    values = np.asarray(values, dtype=np.float32)
    low = values / np.float32(12.92)
    high = np.power((np.maximum(values, 0.0) + np.float32(0.055)) / np.float32(1.055),
                    np.float32(2.4))
    return np.where(values <= 0.04045, low, high).astype(np.float32)


def lattice(size=LUT_SIZE):
    """Every display colour on a size^3 grid, laid out blue-major so red varies fastest.

    That is the order a 3D texture is uploaded in: x (red) fastest, then y (green), then z (blue).
    """
    axis = np.linspace(0.0, 1.0, size, dtype=np.float32)
    blue, green, red = np.meshgrid(axis, axis, axis, indexing="ij")
    return np.stack([red, green, blue], axis=-1).reshape(-1, 3)


def config_path():
    """The OpenColorIO config Blender itself is using."""
    override = os.environ.get("OCIO")
    if override and os.path.isfile(override):
        return override
    try:
        import bpy

        root = bpy.utils.system_resource("DATAFILES")
        path = os.path.join(root, "colormanagement", "config.ocio")
        return path if os.path.isfile(path) else ""
    except Exception:  # noqa: BLE001
        return ""


def _processors(path, display, view, look):
    """(inverse CPU processor, forward CPU processor), or None if OpenColorIO cannot do it."""
    try:
        import PyOpenColorIO as ocio
    except ImportError:
        return None
    try:
        config = ocio.Config.CreateFromFile(path)
        steps = []
        if look and look != "None":
            try:
                config.getLook(look).getName()
                steps.append(ocio.LookTransform(
                    src=ocio.ROLE_SCENE_LINEAR, dst=ocio.ROLE_SCENE_LINEAR, looks=look))
            except Exception:  # noqa: BLE001 - an unknown look is skipped, not fatal
                pass
        steps.append(ocio.DisplayViewTransform(
            src=ocio.ROLE_SCENE_LINEAR, display=display, view=view))
        group = ocio.GroupTransform(steps)
        inverse = config.getProcessor(group, ocio.TRANSFORM_DIR_INVERSE).getDefaultCPUProcessor()
        forward = config.getProcessor(group, ocio.TRANSFORM_DIR_FORWARD).getDefaultCPUProcessor()
        return inverse, forward
    except Exception:  # noqa: BLE001
        return None


def build_lut(display="sRGB", view="Standard", look="None", exposure=0.0, gamma=1.0,
              size=LUT_SIZE, path=None):
    """Display colour -> the scene-linear colour that Blender will turn back into it.

    Returns `(table, exact)`: `table` is float32 of shape (size^3, 4), ready for a 3D texture;
    `exact` is False when OpenColorIO was unavailable and the plain sRGB decode was used
    instead, which is only right for the Standard view.
    """
    colours = lattice(size)
    # Blender applies gamma last (display = transformed ^ (1 / gamma)), so it is undone first.
    if gamma and abs(gamma - 1.0) > 1e-6:
        colours = np.power(colours, np.float32(gamma))

    processors = _processors(path if path is not None else config_path(), display, view, look)
    if processors is not None:
        scene = np.ascontiguousarray(colours, dtype=np.float32)
        processors[0].applyRGB(scene)
        exact = True
    else:
        scene = srgb_to_linear(colours)
        exact = False

    # ...and exposure first (scene * 2^exposure), so it is undone last.
    if exposure:
        scene = scene / np.float32(2.0 ** exposure)

    scene = np.nan_to_num(scene, nan=0.0, posinf=MAX_SCENE_VALUE, neginf=0.0)
    scene = np.clip(scene, 0.0, MAX_SCENE_VALUE).astype(np.float32)
    table = np.ones((scene.shape[0], 4), dtype=np.float32)
    table[:, :3] = scene
    return table, exact


def forward(colours, display="sRGB", view="Standard", look="None", path=None):
    """Blender's view transform applied to scene-linear colours. For tests; None if unavailable."""
    processors = _processors(path if path is not None else config_path(), display, view, look)
    if processors is None:
        return None
    out = np.ascontiguousarray(colours, dtype=np.float32).reshape(-1, 3).copy()
    processors[1].applyRGB(out)
    return out


def sample(table, colours, size=LUT_SIZE):
    """Trilinear lookup, the way the GPU samples the table. For tests."""
    colours = np.clip(np.asarray(colours, dtype=np.float64).reshape(-1, 3), 0.0, 1.0)
    grid = table[:, :3].reshape(size, size, size, 3).astype(np.float64)  # [blue][green][red]
    position = colours * (size - 1)
    base = np.minimum(np.floor(position).astype(int), size - 2)
    fraction = position - base
    result = np.zeros_like(colours)
    for db in (0, 1):
        for dg in (0, 1):
            for dr in (0, 1):
                weight = (
                    (fraction[:, 0] if dr else 1 - fraction[:, 0])
                    * (fraction[:, 1] if dg else 1 - fraction[:, 1])
                    * (fraction[:, 2] if db else 1 - fraction[:, 2])
                )
                result += weight[:, None] * grid[base[:, 2] + db, base[:, 1] + dg, base[:, 0] + dr]
    return result


def settings_key(scene):
    """What the table depends on. A change in any of these means rebuilding it."""
    view = scene.view_settings
    return (
        scene.display_settings.display_device,
        view.view_transform,
        view.look,
        round(float(view.exposure), 4),
        round(float(view.gamma), 4),
    )
