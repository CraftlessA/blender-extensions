# SPDX-License-Identifier: GPL-3.0-or-later
"""Applies Blender's texture filtering to imported Unreal textures.

This is the whole reason BU exists. `UsdUVTexture` has no filter attribute in the USD
schema, and UE's USD importer never touches `Texture->Filter` -- it only sets sRGB,
compression, LOD group and the address modes. So every nearest-neighbour texture arrives
in Unreal blurred, which ruins voxel and pixel art. We fix it here from the manifest.

Address modes and sRGB *do* survive the USD round-trip, so we only re-assert them when
the manifest disagrees with what landed.
"""

import os

import unreal

from . import bu_link_material, bu_manifest

FILTER_ENUM = {
    "Nearest": unreal.TextureFilter.TF_NEAREST,
    "Bilinear": unreal.TextureFilter.TF_BILINEAR,
    "Trilinear": unreal.TextureFilter.TF_TRILINEAR,
    "Default": unreal.TextureFilter.TF_DEFAULT,
}

ADDRESS_ENUM = {
    "Wrap": unreal.TextureAddress.TA_WRAP,
    "Clamp": unreal.TextureAddress.TA_CLAMP,
    "Mirror": unreal.TextureAddress.TA_MIRROR,
}


def _source_names(texture):
    """Every name this texture might be findable by in the manifest."""
    names = [texture.get_name()]
    import_data = texture.get_editor_property("asset_import_data")
    if import_data:
        try:
            names.extend(import_data.extract_filenames())
        except Exception:  # noqa: BLE001 - editor API, be forgiving
            pass
    return names


def apply_to_texture(texture, manifest, pixel_art_preset=False):
    """Push manifest settings onto one texture. Returns a change description or None."""
    entry = manifest.texture_for(*_source_names(texture))
    if entry is None:
        return None

    wanted = entry.get("unreal", {})
    changes = []

    target_filter = FILTER_ENUM.get(wanted.get("filter", "Default"))
    if target_filter is not None and texture.get_editor_property("filter") != target_filter:
        texture.set_editor_property("filter", target_filter)
        changes.append("filter={0}".format(wanted.get("filter")))

    for prop, key in (("address_x", "address_x"), ("address_y", "address_y")):
        target = ADDRESS_ENUM.get(wanted.get(key, "Wrap"))
        if target is None:
            continue
        try:
            if texture.get_editor_property(prop) != target:
                texture.set_editor_property(prop, target)
                changes.append("{0}={1}".format(prop, wanted.get(key)))
        except Exception:  # noqa: BLE001 - not every UTexture subclass has these
            pass

    srgb = bool(wanted.get("srgb", True))
    if texture.get_editor_property("srgb") != srgb:
        texture.set_editor_property("srgb", srgb)
        changes.append("srgb={0}".format(srgb))

    # A 16-bit image is read as linear whatever the sRGB box says; tell Unreal it is sRGB.
    files = [n for n in _source_names(texture) if os.path.isfile(str(n))]
    if files:
        encoding = bu_link_material.source_encoding(files[0], linear=not srgb)
        colour = bu_link_material._source_colour(texture, encoding)
        if colour is not None:
            texture.set_editor_property("source_color_settings", colour)
            changes.append("source encoding={0}".format(encoding or "none"))

    # Nearest filtering usually means pixel art, where DXT block artefacts and mip blur
    # are exactly what you were trying to avoid. Opt-in, because it costs memory.
    if pixel_art_preset and wanted.get("filter") == "Nearest":
        texture.set_editor_property(
            "compression_settings", unreal.TextureCompressionSettings.TC_EDITOR_ICON
        )
        texture.set_editor_property(
            "mip_gen_settings", unreal.TextureMipGenSettings.TMGS_NO_MIPMAPS
        )
        changes.append("pixel-art preset (uncompressed, no mips)")

    if changes:
        unreal.EditorAssetLibrary.save_loaded_asset(texture, only_if_is_dirty=False)
    return ", ".join(changes) if changes else None


def apply_to_path(content_path, manifest, pixel_art_preset=False):
    """Apply manifest texture settings across everything under a content path."""
    applied, skipped = 0, 0

    for asset_path in unreal.EditorAssetLibrary.list_assets(content_path, recursive=True):
        asset = unreal.EditorAssetLibrary.load_asset(asset_path)
        if not isinstance(asset, unreal.Texture):
            continue

        result = apply_to_texture(asset, manifest, pixel_art_preset)
        if result:
            applied += 1
            unreal.log("BU: {0} -> {1}".format(asset.get_name(), result))
        else:
            skipped += 1

    unreal.log(
        "BU: texture pass complete — {0} updated, {1} unchanged or unmatched".format(
            applied, skipped
        )
    )
    return applied, skipped


def apply_from_file(content_path, manifest_path, pixel_art_preset=False):
    manifest = bu_manifest.Manifest.load(manifest_path)
    return apply_to_path(content_path, manifest, pixel_art_preset)
