# SPDX-License-Identifier: GPL-3.0-or-later
"""Keeping the textures and node materials the link saves from filling the disk.

Every image Blender sends is saved as a texture asset (`bu_link_material.TEXTURE_PACKAGE`) and
every node wiring as a compiled material (`bu_link_graph.PACKAGE`), so that opening a scene again
does not import and compile them again. Nothing ever removed them: the render project only grew
(4 GB of textures in four days of one user's scenes; a tester noticed it filling their disk).

So each use is remembered (`INDEX_FILE`: file name -> when last used), and when the editor
starts, before anything can have loaded them (as `bu_link_static.prune_files` does for meshes),
files not used for `MAX_AGE_DAYS` go, then the least recently used until the folders fit in the
limit Blender passes (`ENV_LIMIT`, gigabytes, from BU's preferences). A file's own time counts as
a use too: it is written when the asset is made or remade, and files from before the index have
nothing else. Live actors are transient, never saved in a level, so nothing saved refers to them.
"""

import json
import os
import time

# (folder under Content, file name prefix): only BU's own assets are ever deleted.
FOLDERS = ((os.path.join("BU", "Live", "Textures"), "T_BU_"),
           (os.path.join("BU", "Materials", "Graphs"), "M_BU_Graph_"))
INDEX_FILE = os.path.join("BU", "link_asset_use.json")  # under the project's Saved folder
ENV_LIMIT = "BU_CACHE_GB"
DEFAULT_LIMIT_GB = 4.0
MAX_AGE_DAYS = 30

try:
    _USED  # noqa: B018 - survives importlib.reload on purpose
except NameError:
    _USED = {}  # asset name -> when this session first used it


def note_used(name, now=None):
    """Remember that the asset called `name` (no extension) was used now."""
    if name and name not in _USED:
        _USED[name] = time.time() if now is None else now


def plan(files, used, now, limit_bytes, max_age_seconds):
    """Which files to delete: [(name, size, mtime)] and {asset name: last used} -> names, the
    least recently used first. Unused for longer than `max_age_seconds`, then the oldest until
    the rest fit in `limit_bytes` (None: no limit). Pure."""
    entries = []
    for name, size, mtime in files:
        last = max(float(used.get(os.path.splitext(name)[0], 0.0)), float(mtime))
        entries.append((last, name, int(size)))
    entries.sort()
    doomed = [name for last, name, _size in entries if now - last > max_age_seconds]
    gone = set(doomed)
    kept = [(name, size) for _last, name, size in entries if name not in gone]
    total = sum(size for _name, size in kept)
    for name, size in kept:
        if limit_bytes is None or total <= limit_bytes:
            break
        doomed.append(name)
        total -= size
    return doomed


def limit_bytes(environ=None):
    """The limit Blender asked for, in bytes; the default when it said nothing sensible."""
    environ = os.environ if environ is None else environ
    try:
        gigabytes = float(environ.get(ENV_LIMIT, DEFAULT_LIMIT_GB))
    except (TypeError, ValueError):
        gigabytes = DEFAULT_LIMIT_GB
    if gigabytes != gigabytes or gigabytes < 0:  # NaN or negative
        gigabytes = DEFAULT_LIMIT_GB
    return int(gigabytes * 2 ** 30)


def _paths():
    import unreal

    content = unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_content_dir())
    saved = unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_saved_dir())
    return content, os.path.join(saved, INDEX_FILE)


def _load(path):
    try:
        with open(path, encoding="utf-8") as handle:
            data = json.load(handle)
        return {str(k): float(v) for k, v in data.items()}
    except (OSError, ValueError, TypeError, AttributeError):
        return {}


def save_index():
    """Write this session's uses into the index (on disconnect and after pruning)."""
    try:
        _content, path = _paths()
        index = _load(path)
        for name, when in _USED.items():
            index[name] = max(index.get(name, 0.0), when)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        temporary = path + ".tmp"
        with open(temporary, "w", encoding="utf-8") as handle:
            json.dump(index, handle)
        os.replace(temporary, path)
    except Exception:  # noqa: BLE001 - a cache index is never worth an error
        pass


def prune_files(now=None, environ=None):
    """At editor start: delete BU's saved textures and node materials past their age or over
    the limit. Returns (files removed, bytes freed)."""
    now = time.time() if now is None else now
    content, index_path = _paths()
    index = _load(index_path)
    limit = limit_bytes(environ)
    removed = freed = 0
    for folder, prefix in FOLDERS:
        directory = os.path.join(content, folder)
        files = []
        try:
            names = os.listdir(directory)
        except OSError:
            continue
        for name in names:
            if not (name.startswith(prefix) and name.endswith(".uasset")):
                continue
            try:
                found = os.stat(os.path.join(directory, name))
            except OSError:
                continue
            files.append((name, found.st_size, found.st_mtime))
        # Textures and materials each get the limit: materials are a few MB, textures the rest.
        for name in plan(files, index, now, limit, MAX_AGE_DAYS * 86400):
            path = os.path.join(directory, name)
            try:
                size = os.path.getsize(path)
                os.remove(path)
            except OSError:
                continue
            removed += 1
            freed += size
            index.pop(os.path.splitext(name)[0], None)
    if removed:
        try:
            temporary = index_path + ".tmp"
            with open(temporary, "w", encoding="utf-8") as handle:
                json.dump(index, handle)
            os.replace(temporary, index_path)
        except OSError:
            pass
    return removed, freed
