# SPDX-License-Identifier: GPL-3.0-or-later
"""Put everything an armature moves on its skeleton for the duration of an export.

Only with Armatures on (`export_skeletal`; off by default). Blender's USD exporter then writes
UsdSkel, which Unreal turns into one SkeletalMesh, a Skeleton and an AnimSequence per armature.
Two things stop that working on its own:

- **Parts parented to bones.** An animatronic is built of rigid pieces parented straight to
  bones, with no Armature modifier and no weights (Springtrap: 513 meshes and 111 curves, 15
  skinned meshes). The exporter writes those as loose transforms, not as part of the skeleton.
- **Modifiers.** The exporter writes a skinned mesh as it is before its modifiers, so a part's
  Subdivision or Geometry Nodes are lost (a subdivided cube came out with its 8 corners).

So each part gets a stand-in for the export: its geometry worked out at the rest pose with its
modifiers (at render levels when exporting for render), parented to the armature, with a single
Armature modifier. A part parented to a bone is weighted fully to that bone; a skinned mesh keeps
its own weights. Measured on a test rig, the stand-in lands where the bone parent put the part on
every frame. The original is hidden and its name lent to the stand-in, the same discipline as
`curves.converted`, and everything is put back in a `finally`.

Left as they are, with the reason in the manifest:
- a part that also moves on its own (keyed, driven or constrained): one bone cannot carry both;
- a mesh with shape keys under modifiers other than Subdivision: a stand-in would lose them. A
  skinned one still goes on the skeleton as Blender writes it, keys and all, without the others.
  Under Subdivision alone the keys are subdivided with the mesh (Catmull-Clark is linear in the
  points, so a key's subdivided offset is exact) and keep their animation and drivers;
- a part parented to a bone that also has an Armature modifier.
"""

import contextlib

# Lent to the original while its stand-in borrows the name. Recognisable if one ever leaks.
_PARKED_SUFFIX = "__bu_unskinned"
# The curve stand-ins `curves.converted` makes park their original under this suffix.
_CURVE_SUFFIX = "__bu_original"
_GEOMETRY = ("MESH", "CURVE", "SURFACE", "FONT", "META")


def _armature_modifiers(obj, evaluation_mode):
    flag = "show_render" if evaluation_mode == "RENDER" else "show_viewport"
    return [m for m in getattr(obj, "modifiers", ())
            if m.type == "ARMATURE" and getattr(m, flag) and m.object is not None
            and m.object.type == "ARMATURE"]


def _moves_on_its_own(obj):
    """Keyed, driven or constrained itself, not only through its parent bone."""
    if len(getattr(obj, "constraints", ())) and any(c.enabled for c in obj.constraints):
        return True
    anim = obj.animation_data
    if anim is None:
        return False
    paths = []
    if anim.action is not None:
        for slot_curves in _action_paths(anim):
            paths.append(slot_curves)
    for track in anim.nla_tracks:
        if not track.mute and track.strips:
            return True
    paths.extend(d.data_path for d in anim.drivers)
    return any(p.startswith(("location", "rotation", "scale", "delta_", "matrix"))
               for p in paths)


def _action_paths(anim):
    """The data paths an object's action animates (layered actions in Blender 4.4+ too)."""
    action = anim.action
    found = []
    try:
        for curve in action.fcurves:
            found.append(curve.data_path)
    except AttributeError:
        pass
    for layer in getattr(action, "layers", ()):
        for strip in layer.strips:
            slot = getattr(anim, "action_slot", None)
            try:
                bag = strip.channelbag(slot) if slot is not None else None
            except Exception:  # noqa: BLE001
                bag = None
            for curve in getattr(bag, "fcurves", ()) if bag is not None else ():
                found.append(curve.data_path)
    return found


def _hidden(obj, evaluation_mode):
    """Hidden from this export: by its own flag or a collection above it."""
    from . import capture

    flag = "hide_render" if evaluation_mode == "RENDER" else "hide_viewport"
    if getattr(obj, flag, False):
        return True
    return capture._visibility_culprit(obj, evaluation_mode) is not None


def plan(scene, evaluation_mode="RENDER"):
    """What goes on a skeleton, without changing anything.

    Returns (bound, kept): `bound` is a list of dicts {holder, source, armature, bone} where
    `holder` is the object whose name the export uses (a curve's stand-in, or the part itself)
    and `source` the object its geometry and rig come from; `bone` is None for a skinned mesh.
    `kept` is a list of (name, reason) left as they are."""
    import bpy

    bound, kept = [], []
    in_scene = set(o.name for o in scene.objects)
    for holder in scene.objects:
        if holder.type not in _GEOMETRY or holder.name.endswith((_CURVE_SUFFIX, _PARKED_SUFFIX)):
            continue
        if holder.type != "MESH":
            continue  # a curve `curves.converted` did not turn into a mesh: written as curves
        source = bpy.data.objects.get(holder.name + _CURVE_SUFFIX) or holder
        if _hidden(holder, evaluation_mode):
            continue
        parent = source.parent
        by_bone = (parent is not None and parent.type == "ARMATURE"
                   and source.parent_type == "BONE" and source.parent_bone
                   and source.parent_bone in parent.data.bones)
        skins = _armature_modifiers(source, evaluation_mode)
        if not by_bone and not skins:
            continue
        armature = parent if by_bone else skins[0].object
        if armature.name not in in_scene or _hidden(armature, evaluation_mode):
            kept.append((holder.name, "its armature {0} is not exported".format(armature.name)))
            continue
        if by_bone and skins:
            kept.append((holder.name, "parented to a bone and skinned as well"))
            continue
        if len(set(m.object.name for m in skins)) > 1:
            kept.append((holder.name, "skinned to more than one armature"))
            continue
        if any(m.type == "PARTICLE_SYSTEM" for m in getattr(source, "modifiers", ())) and                 not getattr(source, "show_instancer_for_render" if evaluation_mode == "RENDER"
                            else "show_instancer_for_viewport", True):
            continue  # an emitter that does not render (its particles' Show Emitter off)
        if _moves_on_its_own(source):
            kept.append((holder.name, "it also moves on its own (keys, drivers or constraints)"))
            continue
        keys = source.data.shape_keys if source.type == "MESH" else None
        if keys is not None and not _keys_bakeable(source, evaluation_mode):
            if by_bone:
                kept.append((holder.name, "it has shape keys under modifiers other than "
                                          "Subdivision"))
            # Skinned with shape keys: Blender writes it on the skeleton itself, keys and all.
            continue
        bound.append({"holder": holder, "source": source, "armature": armature,
                      "bone": source.parent_bone if by_bone else None,
                      "keys": keys is not None})
    return bound, kept


def _keys_bakeable(obj, evaluation_mode):
    """Whether its shape keys can be worked out through its modifiers: only Subdivision (and
    the Armature, nothing at the rest pose) in its stack, and no key limited to a group."""
    flag = "show_render" if evaluation_mode == "RENDER" else "show_viewport"
    for modifier in obj.modifiers:
        if getattr(modifier, flag) and modifier.type not in ("SUBSURF", "ARMATURE"):
            return False
    keys = obj.data.shape_keys
    if not keys.use_relative:
        return False
    return not any(block.vertex_group for block in keys.key_blocks)


@contextlib.contextmanager
def _render_levels(objects, evaluation_mode):
    """Evaluate `objects` as a render would: each modifier as shown in renders, Subdivision at
    its Render levels (under Simplify's render limit). The viewport depsgraph is the only one a
    script can evaluate, so its settings borrow the render's for the bake."""
    import bpy

    changed = []
    if evaluation_mode == "RENDER":
        render = bpy.context.scene.render
        for obj in objects:
            for modifier in getattr(obj, "modifiers", ()):
                changed.append((modifier, "show_viewport", modifier.show_viewport))
                modifier.show_viewport = modifier.show_render
                if modifier.type == "SUBSURF":
                    levels = modifier.render_levels
                    if render.use_simplify:
                        levels = min(levels, render.simplify_subdivision_render)
                    changed.append((modifier, "levels", modifier.levels))
                    modifier.levels = levels
        simplify = (render, "simplify_subdivision", render.simplify_subdivision)
        if render.use_simplify:
            changed.append(simplify)
            render.simplify_subdivision = render.simplify_subdivision_render
    try:
        yield
    finally:
        for owner, name, value in reversed(changed):
            try:
                setattr(owner, name, value)
            except Exception:  # noqa: BLE001
                pass


def _bake(entries, context, evaluation_mode):
    """Each entry's geometry at the rest pose with its modifiers, and where it is then.
    Adds "mesh" and "rest" to each entry; one that cannot be evaluated gets neither."""
    import bpy

    armatures = {e["armature"] for e in entries}
    positions = [(a.data, a.data.pose_position) for a in armatures]
    sources = [e["source"] for e in entries]
    shown = [(o, o.hide_viewport) for o in sources]
    keyed = [e for e in entries if e.get("keys")]
    alone = [(e["source"], e["source"].show_only_shape_key, e["source"].active_shape_key_index)
             for e in keyed]
    try:
        for data, _position in positions:
            data.pose_position = "REST"
        for obj, _hidden_flag in shown:
            obj.hide_viewport = False
        for obj, _alone, _index in alone:
            # The basis alone: the keys' current values are not the shape at rest.
            obj.show_only_shape_key = True
            obj.active_shape_key_index = 0
        with _render_levels(sources, evaluation_mode):
            context.view_layer.update()
            depsgraph = context.evaluated_depsgraph_get()
            for entry in entries:
                try:
                    evaluated = entry["source"].evaluated_get(depsgraph)
                    mesh = bpy.data.meshes.new_from_object(
                        evaluated, preserve_all_data_layers=True, depsgraph=depsgraph)
                except Exception:  # noqa: BLE001 - nothing to evaluate
                    mesh = None
                if mesh is not None and len(mesh.vertices) == 0:
                    bpy.data.meshes.remove(mesh)
                    mesh = None
                if mesh is not None:
                    entry["mesh"] = mesh
                    entry["rest"] = evaluated.matrix_world.copy()
            _bake_keys([e for e in keyed if "mesh" in e], context)
    finally:
        for obj, was_alone, index in alone:
            obj.show_only_shape_key = was_alone
            obj.active_shape_key_index = index
        for data, position in positions:
            data.pose_position = position
        for obj, flag in shown:
            obj.hide_viewport = flag
        context.view_layer.update()


def _bake_keys(entries, context):
    """Each shape key shown alone, through the modifiers, into entry["key_points"] as (block,
    flat coordinates on the worked-out basis). A key is relative to its own reference key (the
    eyes' pupils to "Basis Old"), so its offset is taken from that key's worked-out shape. An
    entry whose point count changes keeps no keys."""
    import numpy as np

    most = max((len(e["source"].data.shape_keys.key_blocks) for e in entries), default=0)
    # A muted key shown alone shows the basis, and a key can be relative to a muted one (the
    # eyes' "Basis Old"): unmuted for the bake, the mute itself goes onto the stand-in.
    muted = [(b, b.mute) for e in entries for b in e["source"].data.shape_keys.key_blocks]
    for block, _was in muted:
        block.mute = False
    try:
        _bake_each_key(entries, context, most)
    finally:
        for block, was in muted:
            block.mute = was


def _bake_each_key(entries, context, most):
    import numpy as np

    for entry in entries:
        entry["key_points"] = []
    for index in range(1, most):
        due = [e for e in entries if index < len(e["source"].data.shape_keys.key_blocks)
               and e["key_points"] is not None]
        if not due:
            continue
        for entry in due:
            entry["source"].active_shape_key_index = index
        context.view_layer.update()
        depsgraph = context.evaluated_depsgraph_get()
        for entry in due:
            evaluated = entry["source"].evaluated_get(depsgraph)
            mesh = evaluated.to_mesh()
            try:
                count = len(mesh.vertices)
                if count != len(entry["mesh"].vertices):
                    entry["key_points"] = None
                    continue
                points = np.empty(count * 3, dtype=np.float32)
                mesh.vertices.foreach_get("co", points)
            finally:
                evaluated.to_mesh_clear()
            block = entry["source"].data.shape_keys.key_blocks[index]
            entry["key_points"].append((block, points))
    for entry in entries:
        if entry["key_points"] is None:
            entry["key_points"] = []
            continue
        keys = entry["source"].data.shape_keys
        basis = np.empty(len(entry["mesh"].vertices) * 3, dtype=np.float32)
        entry["mesh"].vertices.foreach_get("co", basis)
        shapes = {keys.reference_key.name: basis}
        shapes.update((block.name, points) for block, points in entry["key_points"])
        entry["key_points"] = [
            (block, basis + (points - shapes.get(block.relative_key.name, basis)))
            for block, points in entry["key_points"]]


def _add_keys(stand_in, source, key_points):
    """The baked keys on the stand-in, with the original's values, animation and drivers."""
    original = source.data.shape_keys
    stand_in.shape_key_add(name=original.reference_key.name, from_mix=False)
    for block, points in key_points:
        made = stand_in.shape_key_add(name=block.name, from_mix=False)
        made.data.foreach_set("co", points)
        made.slider_min, made.slider_max = block.slider_min, block.slider_max
        made.value, made.mute = block.value, block.mute
    anim = original.animation_data
    if anim is None:
        return
    keys = stand_in.data.shape_keys
    copied = keys.animation_data_create()
    if anim.action is not None:
        copied.action = anim.action
        slot = getattr(anim, "action_slot", None)
        if slot is not None and hasattr(copied, "action_slot"):
            try:
                copied.action_slot = slot
            except Exception:  # noqa: BLE001
                pass
    for driver in anim.drivers:
        copied.drivers.from_existing(src_driver=driver)


def _skin_weights(stand_in, armature):
    """A skinned stand-in's weights as Unreal will read them, Blender's way: groups of bones
    that do not deform are dropped (Blender's Armature modifier ignores them), and points no
    deforming bone weights (Blender leaves them where they are; through USD they fall to the
    skeleton's origin, a spike in Unreal) go fully to the bone weighting most of the mesh.
    Returns how many points were given a bone."""
    import numpy as np

    bones = armature.data.bones
    for group in list(stand_in.vertex_groups):
        bone = bones.get(group.name)
        if bone is not None and not bone.use_deform:
            stand_in.vertex_groups.remove(group)
    deforming = {g.index: g.name for g in stand_in.vertex_groups if g.name in bones}
    if not deforming:
        return 0
    mesh = stand_in.data
    totals = np.zeros(len(mesh.vertices))
    per_group = dict.fromkeys(deforming, 0.0)
    for vertex in mesh.vertices:
        for element in vertex.groups:
            if element.group in deforming:
                totals[vertex.index] += element.weight
                per_group[element.group] += element.weight
    unweighted = np.flatnonzero(totals <= 0.0)
    if len(unweighted):
        most = max(per_group, key=per_group.get)
        stand_in.vertex_groups[deforming[most]].add(unweighted.tolist(), 1.0, "REPLACE")
    return len(unweighted)


def _materials(stand_in, source):
    """Materials linked to the object, not its data, follow it onto the stand-in."""
    for index, slot in enumerate(source.material_slots):
        if index >= len(stand_in.material_slots):
            break
        if slot.link == "OBJECT":
            stand_in.material_slots[index].link = "OBJECT"
            stand_in.material_slots[index].material = slot.material


@contextlib.contextmanager
def bound(context, enabled=True, evaluation_mode="RENDER"):
    """Swap what each armature moves for stand-ins on its skeleton, then put the scene back.

    Yields {"bound": [(name, armature, bone or None)], "kept": [(name, reason)],
    "unweighted": [(name, points given the mesh's main bone)]}."""
    import bpy

    info = {"bound": [], "kept": [], "unweighted": []}
    if not enabled:
        yield info
        return
    entries, kept = plan(context.scene, evaluation_mode)
    info["kept"] = kept
    made = []      # (stand_in, mesh)
    parked = []    # (holder, name, hide_render, hide_viewport)
    try:
        if entries:
            _bake(entries, context, evaluation_mode)
        for entry in entries:
            holder, source, armature = entry["holder"], entry["source"], entry["armature"]
            mesh = entry.get("mesh")
            if mesh is None:
                info["kept"].append((holder.name, "no geometry at the rest pose"))
                continue
            name = holder.name
            stand_in = bpy.data.objects.new(name + "_bu_skin", mesh)
            made.append((stand_in, mesh))
            for collection in holder.users_collection:
                collection.objects.link(stand_in)
            stand_in.parent = armature
            stand_in.matrix_world = entry["rest"]
            _materials(stand_in, source)
            if entry["bone"] is not None:
                # Rigid: every point fully on its bone, nothing else that could pull it.
                stand_in.vertex_groups.clear()
                group = stand_in.vertex_groups.new(name=entry["bone"])
                group.add(range(len(mesh.vertices)), 1.0, "REPLACE")
            else:
                given = _skin_weights(stand_in, armature)
                if given:
                    info["unweighted"].append((name, given))
            if entry.get("key_points"):
                _add_keys(stand_in, source, entry["key_points"])
            modifier = stand_in.modifiers.new("BU armature", "ARMATURE")
            modifier.object = armature
            parked.append((holder, name, holder.hide_render, holder.hide_viewport))
            holder.hide_render = True
            if evaluation_mode != "RENDER":
                holder.hide_viewport = True
            holder.name = name + _PARKED_SUFFIX
            stand_in.name = name
            info["bound"].append((name, armature.name, entry["bone"]))
        if made:
            context.view_layer.update()
        yield info
    finally:
        for entry in entries:
            mesh = entry.get("mesh")
            if mesh is not None and not any(mesh is m for _o, m in made):
                try:
                    bpy.data.meshes.remove(mesh)
                except Exception:  # noqa: BLE001
                    pass
        for stand_in, mesh in made:
            try:
                if mesh.shape_keys is not None:
                    stand_in.shape_key_clear()  # its Key would outlive the mesh
            except Exception:  # noqa: BLE001
                pass
            try:
                bpy.data.objects.remove(stand_in, do_unlink=True)
            except Exception:  # noqa: BLE001
                pass
            try:
                bpy.data.meshes.remove(mesh)
            except Exception:  # noqa: BLE001
                pass
        for holder, name, hide_render, hide_viewport in parked:
            try:
                holder.name = name
                holder.hide_render = hide_render
                holder.hide_viewport = hide_viewport
            except Exception:  # noqa: BLE001
                pass
