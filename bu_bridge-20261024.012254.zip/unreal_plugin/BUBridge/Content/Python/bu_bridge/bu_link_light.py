# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender's lights as Unreal lights, for the real-time link.

Blender sends a light's own settings, untranslated (Blender's `link_light`); everything that
converts lives here, in `settings`, which is pure and tested.

**Units.** Blender's light power is radiometric: watts for point, spot and area lights, W/m² for
the sun. Unreal's is photometric: candelas for local lights, lux for the sun. At 683 lm/W, the
luminous efficacy that defines the candela:

    point, spot   cd  = W x 683 / 4pi    radiated evenly over the sphere (a Blender spot is a
                                         masked point light: its cone does not concentrate it)
    area          cd  = W x 683 / 2pi    a one-sided Lambertian emitter is W x 683 / pi face on,
                                         but Unreal's rect light shines twice its candelas: a
                                         grey sphere 4 m from one read 2.1x Cycles' in Lumen and
                                         2.0-2.2x in the path tracer, where a point light read
                                         1.02-1.05x. Halved, it matches.
    sun           lux = W/m² x 683

Emission and the sky are sent in nits on the same scale (x 683), and a picture Blender colour
manages is exposed so one nit is 1/683 of Blender's radiance (`bu_link.LINEAR_EXPOSURE_BIAS`):
there the brightness matches Blender's own. Under Unreal's colour management, Unreal's exposure
(auto, or the Unreal Camera's) decides it.

**Direction.** Blender lights shine down their local -Z, Unreal's along local +X. Blender sends a
matrix already rotated to Unreal's convention (`link_light.light_matrix`), so the actor's transform
is used as it is, and transform-only updates are the same 16 floats as a mesh's.

**Falloff.** Blender's lights reach forever; Unreal's stop at an attenuation radius. Unless the
light has a Custom Distance, it is where the light falls below `FADE_LUX`, kept between 10 m and
250 m — far enough not to be seen, near enough not to touch the whole level.

**Spot shadows are ray traced.** In BU's capture, a spot light's rasterized shadow (virtual
shadow maps) let about a third of the light through: under a table lit by one spot, the floor in
its shadow read 0.070 against 0.208 with shadows off, where Cycles has 0. A point light's shadow,
from the same place, was black (1.4% of the lit floor), and so was the spot's with ray-traced
shadows (1.4%) — Unreal's own default spot leaked too, and no virtual shadow map setting changed
it. So spots ask for ray-traced shadows themselves (`ray_traced_shadow`), whatever the project
says. Each light can choose for itself in its Unreal Light panel (Ray Traced Shadows: Automatic,
On, Off), with Unreal's Samples Per Pixel for the ray-traced ones: more is less noise in a
large light's soft shadow. Without a ray-tracing GPU Unreal ignores the request and rasterizes.

**Unreal-only settings.** BU's *Unreal Light* panel in Blender adds what Blender's lights do not
have, sent as `unreal` (`properties` maps them onto the component): an intensity in Unreal's
own units, indirect/volumetric/specular/diffuse scales, source length and soft radius, falloff,
an attenuation radius, contact and volumetric shadows, what the light affects, lighting
channels, an IES profile, a light function, a rect light's source texture and barn doors, and a
sun's atmosphere, cloud, cascade and light-shaft settings.
"""

import math

LUMENS_PER_WATT = 683.0
FADE_LUX = 0.5
MIN_REACH_CM = 1000.0
MAX_REACH_CM = 25000.0
CM_PER_M = 100.0
# Unreal's spot cone stops at 80 degrees from the axis.
MAX_CONE = 80.0
CLASSES = {"POINT": "PointLight", "SPOT": "SpotLight", "AREA": "RectLight",
           "SUN": "DirectionalLight"}
UNITS = ("CANDELAS", "LUMENS", "EV", "UNITLESS", "NITS")
# Blender's name -> (component property, conversion), by which lights have it.
_SCALE = float
_CM = "cm"
_DEGREES = "degrees"
COMMON_PROPERTIES = {
    "indirect": ("indirect_lighting_intensity", _SCALE),
    "volumetric": ("volumetric_scattering_intensity", _SCALE),
    "specular": ("specular_scale", _SCALE),
    "diffuse": ("diffuse_scale", _SCALE),
    "volumetric_shadow": ("cast_volumetric_shadow", bool),
    "contact_shadow": ("contact_shadow_length", _SCALE),
    "affects_world": ("affects_world", bool),
    "affect_reflection": ("affect_reflection", bool),
    "affect_gi": ("affect_global_illumination", bool),
    "affect_translucent": ("affect_translucent_lighting", bool),
    "samples_per_pixel": ("samples_per_pixel", int),
}
# Blender's ray visibility and influence (`visibility`: 0-1 per kind of ray) -> the Unreal
# setting nearest each. A "transmission" an older Blender side sends is ignored: Unreal's only
# setting for it, whether the light lights translucent surfaces at all, is not what it means.
VISIBILITY_SCALES = (("diffuse", "diffuse_scale"), ("glossy", "specular_scale"),
                     ("volume", "volumetric_scattering_intensity"))
LOCAL_PROPERTIES = {
    "source_length": ("source_length", _CM),
    "soft_radius": ("soft_source_radius", _CM),
    "inverse_square": ("use_inverse_squared_falloff", bool),
    "falloff_exponent": ("light_falloff_exponent", _SCALE),
    "ies_brightness": ("use_ies_brightness", bool),
    "ies_scale": ("ies_brightness_scale", _SCALE),
    "barn_door_length": ("barn_door_length", _CM),
}
SUN_PROPERTIES = {
    "atmosphere_sun": ("atmosphere_sun_light", bool),
    "atmosphere_index": ("atmosphere_sun_light_index", int),
    "cloud_shadows": ("cast_cloud_shadows", bool),
    "soft_angle": ("light_source_soft_angle", _DEGREES),
    "shadow_distance": ("dynamic_shadow_distance_movable_light", _CM),
    "cascades": ("dynamic_shadow_cascades", int),
    "light_shafts": ("enable_light_shaft_bloom", bool),
    "shaft_bloom": ("bloom_scale", _SCALE),
}
# Blender's name -> (component property, asset class name). An empty path clears it.
ASSET_PROPERTIES = {
    "ies": ("ies_texture", "TextureLightProfile"),
    "light_function": ("light_function_material", "MaterialInterface"),
    "source_texture": ("source_texture", "Texture"),
}


def _number(value, fallback=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return fallback


def _colour(value):
    try:
        values = [max(0.0, float(v)) for v in value][:3]
    except (TypeError, ValueError):
        return (1.0, 1.0, 1.0)
    return tuple(values) if len(values) == 3 else (1.0, 1.0, 1.0)


def light_kind(spec):
    """POINT, SPOT, AREA or SUN; an unknown type is a point light. Pure."""
    kind = str((spec or {}).get("light") or "POINT").upper()
    return kind if kind in CLASSES else "POINT"


def reach(candelas, custom_m=None):
    """Attenuation radius in cm for a local light of this intensity. Pure."""
    if custom_m is not None and _number(custom_m) > 0.0:
        return _number(custom_m) * CM_PER_M
    distance = math.sqrt(max(0.0, candelas) / FADE_LUX) * CM_PER_M
    return min(MAX_REACH_CM, max(MIN_REACH_CM, distance))


def settings(spec):
    """(Unreal actor class name, {setting: value}) for a light message. Pure."""
    spec = spec or {}
    kind = light_kind(spec)
    energy = max(0.0, _number(spec.get("energy")))
    found = {
        "color": _colour(spec.get("color")),
        "cast_shadows": bool(spec.get("shadow", True)),
    }
    if spec.get("temperature") is not None:
        found["temperature"] = _number(spec.get("temperature"), 6500.0)
    if kind == "SUN":
        found["intensity"] = energy * LUMENS_PER_WATT
        found["source_angle"] = math.degrees(max(0.0, _number(spec.get("angle"), 0.00918)))
        _overrides(kind, spec, found)
        return CLASSES[kind], found
    if kind == "AREA":
        candelas = energy * LUMENS_PER_WATT / (2.0 * math.pi)  # see Units, above
        size_x = max(0.0, _number(spec.get("size_x"), 1.0)) * CM_PER_M
        size_y = max(0.0, _number(spec.get("size_y"), spec.get("size_x") or 1.0)) * CM_PER_M
        # Blender's area extends along its local X and Y. After `light_matrix` turns -Z into
        # Unreal's forward (+X), Blender's Y is Unreal's Y (source width) and Blender's X is
        # Unreal's Z (source height).
        found["source_width"] = size_y
        found["source_height"] = size_x
        spread = math.degrees(_number(spec.get("spread"), math.pi))
        if spread < 179.0:
            found["barn_door_angle"] = max(0.0, min(90.0, spread / 2.0))
    else:
        candelas = energy * LUMENS_PER_WATT / (4.0 * math.pi)
        found["source_radius"] = max(0.0, _number(spec.get("radius"))) * CM_PER_M
        if kind == "SPOT":
            outer = min(MAX_CONE, max(1.0, math.degrees(_number(spec.get("spot_size"),
                                                                math.radians(45.0))) / 2.0))
            blend = min(1.0, max(0.0, _number(spec.get("spot_blend"), 0.15)))
            found["outer_cone_angle"] = outer
            found["inner_cone_angle"] = outer * (1.0 - blend)
    found["intensity"] = candelas
    found["attenuation_radius"] = reach(candelas, spec.get("distance"))
    _overrides(kind, spec, found)
    return CLASSES[kind], found


def ray_traced_shadow(kind, choice=None, scene=None):
    """The `CastRayTracedShadow` member for a light of this kind, from its own Ray Traced
    Shadows choice (ON, OFF, or AUTO: use the scene's) and the scene's Shadows choice
    (PROJECT, VIRTUAL, RAY_TRACED). Pure."""
    if choice == "ON" or (choice not in ("ON", "OFF") and scene == "RAY_TRACED"):
        return "ENABLED"
    if choice == "OFF" or scene == "VIRTUAL":
        return "DISABLED"
    # The project's choice, except a spot: its shadow maps let a third of its light through.
    return "ENABLED" if kind == "SPOT" else "USE_PROJECT_SETTING"


def _overrides(kind, spec, found):
    """Intensity in Unreal's units, and an attenuation radius, from the Unreal Light panel."""
    extra = (spec or {}).get("unreal") or {}
    if extra.get("intensity") is not None:
        found["intensity"] = max(0.0, _number(extra.get("intensity")))
        if kind != "SUN":
            units = str(extra.get("units") or "CANDELAS").upper()
            found["units"] = units if units in UNITS else "CANDELAS"
    if kind != "SUN" and _number(extra.get("attenuation")) > 0.0:
        found["attenuation_radius"] = _number(extra.get("attenuation")) * CM_PER_M


def properties(spec):
    """[(component property, value)] for the light's Unreal-only settings. Pure.

    Assets come back as (property, ("asset", class name, path)) for `apply` to load.
    """
    spec = spec or {}
    kind = light_kind(spec)
    extra = spec.get("unreal") or {}
    tables = [COMMON_PROPERTIES]
    tables.append(SUN_PROPERTIES if kind == "SUN" else LOCAL_PROPERTIES)
    found = []
    for table in tables:
        for key, (name, convert) in sorted(table.items()):
            if key not in extra or extra[key] is None:
                continue
            if key == "barn_door_length" and kind != "AREA":
                continue
            if key == "source_length" and kind == "AREA":
                continue
            value = extra[key]
            if convert is _CM:
                value = max(0.0, _number(value)) * CM_PER_M
            elif convert is _DEGREES:
                value = math.degrees(_number(value))
            elif convert is bool:
                value = bool(value)
            elif convert is int:
                value = int(_number(value))
            else:
                value = _number(value)
            found.append((name, value))
    channels = extra.get("channels")
    if channels is not None:
        flags = [bool(c) for c in list(channels)[:3]] + [False] * 3
        found.append(("lighting_channels", tuple(flags[:3])))
    for key, (name, class_name) in sorted(ASSET_PROPERTIES.items()):
        if key not in extra:
            continue
        if key == "ies" and kind == "SUN":
            continue
        if key == "source_texture" and kind != "AREA":
            continue
        found.append((name, ("asset", class_name, str(extra.get(key) or ""))))
    return _with_visibility(found, spec.get("visibility") or {})


def _with_visibility(found, visibility):
    """`found` with Blender's ray visibility folded into the Unreal panel's own values. Pure."""
    if not visibility:
        return found
    values = dict(found)
    for key, name in VISIBILITY_SCALES:
        if key in visibility:
            values[name] = _number(values.get(name, 1.0)) * max(0.0, _number(visibility[key]))
    return list(values.items())


def set_ray_traced_shadow(light, kind, choice=None, scene=None):
    """Give a light component the shadow method `ray_traced_shadow` picks."""
    import unreal

    wanted = getattr(unreal.CastRayTracedShadow, ray_traced_shadow(kind, choice, scene))
    try:
        if light.get_editor_property("cast_raytraced_shadow") != wanted:
            light.set_editor_property("cast_raytraced_shadow", wanted)
    except Exception as exc:  # noqa: BLE001 - a build without the property
        unreal.log_warning("BU: ray-traced shadow setting not applied: {0}".format(exc))


def volume_settings(spec):
    """[(LocalFogVolumeComponent property, value)] for a Blender fog volume. Pure.

    Blender's density is an extinction per metre throughout the box; Unreal's radial fog peaks
    at the centre (Blender already scaled it to match there) and has no height fog here.
    Colours are (r, g, b) tuples.
    """
    spec = spec or {}
    return [("radial_fog_extinction", max(0.0, _number(spec.get("density"), 1.0))),
            ("height_fog_extinction", 0.0),
            ("fog_albedo", _colour(spec.get("albedo"))),
            ("fog_emissive", tuple(max(0.0, _number(c)) for c in list(
                spec.get("emission") or (0.0, 0.0, 0.0))[:3])),
            ("fog_phase_g", min(0.99, max(-0.99, _number(spec.get("anisotropy")))))]


def shadow_choice(spec):
    """A light message's own Ray Traced Shadows choice, or None. Pure."""
    return ((spec or {}).get("unreal") or {}).get("ray_traced_shadows")


def apply(actor, spec, scene_shadows=None):
    """Set an Unreal light actor from a light message (`scene_shadows`: the scene's Shadows)."""
    import unreal

    _class_name, found = settings(spec)
    light = actor.get_editor_property("light_component")
    set_ray_traced_shadow(light, light_kind(spec), shadow_choice(spec), scene_shadows)
    light.set_mobility(unreal.ComponentMobility.MOVABLE)
    if hasattr(light, "set_intensity_units"):
        light.set_intensity_units(getattr(unreal.LightUnits, found.get("units", "CANDELAS")))
    light.set_intensity(found["intensity"])
    light.set_light_color(unreal.LinearColor(*found["color"], 1.0), True)
    light.set_cast_shadows(found["cast_shadows"])
    light.set_use_temperature("temperature" in found)
    if "temperature" in found:
        light.set_temperature(found["temperature"])
    setters = {
        "attenuation_radius": "set_attenuation_radius",
        "source_radius": "set_source_radius",
        "outer_cone_angle": "set_outer_cone_angle",
        "inner_cone_angle": "set_inner_cone_angle",
        "source_width": "set_source_width",
        "source_height": "set_source_height",
        "barn_door_angle": "set_barn_door_angle",
        "source_angle": "set_light_source_angle",
    }
    for key, setter in setters.items():
        if key in found and hasattr(light, setter):
            getattr(light, setter)(found[key])
    for name, value in properties(spec):
        if name == "lighting_channels":
            channels = unreal.LightingChannels()
            for index, flag in enumerate(value):
                channels.set_editor_property("channel{0}".format(index), flag)
            value = channels
        elif isinstance(value, tuple) and value and value[0] == "asset":
            value = unreal.load_asset(value[2]) if value[2] else None
        try:
            if light.get_editor_property(name) != value:
                light.set_editor_property(name, value)
        except Exception as exc:  # noqa: BLE001 - a property this light or build lacks
            unreal.log_warning("BU: light setting {0} not applied: {1}".format(name, exc))
