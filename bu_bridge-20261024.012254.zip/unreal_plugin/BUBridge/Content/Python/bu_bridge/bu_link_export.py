# SPDX-License-Identifier: GPL-3.0-or-later
"""Unreal's actors into Blender: a one-shot glTF export, asked for over the link.

Blender sends `{"type": "export", "scope": "selected" | "level", "path": ...}` and Unreal writes
the actors to that glTF with its own exporter (the glTF Exporter plugin, on by default), then
answers `export_done`. Blender imports the file.

glTF because it carries what a Fab or Megascans asset is made of — mesh, UVs, and a PBR material
— and Unreal's exporter *bakes* any material, however many nodes it has, down to base colour,
metallic/roughness and normal textures. It also lands where the link would put it: an actor at
Unreal (100, 200, 300) imports at Blender (1, -2, 3), one metre per hundred centimetres, which
was checked on a real export rather than assumed.

Only geometry is exported: lights, cameras and sequences are switched off, since this is for
bringing assets across, and BU's own live actors are left out — they *are* Blender's objects.
A Nanite mesh exports at its fallback (LOD 0) unless `source_model` is asked for.

Materials are baked at `texture_size` (1024 unless asked). The exporter's own default sizes
each bake by the largest texture the material uses, and a Fab or Megascans material has 4K or
8K ones: three maps of 8K, PNG-encoded, per material, held the editor still for a long time.
The export runs under a progress dialog, so the editor at least says what it is doing.

The reply lists each exported actor's label, path and location. Blender uses them to tie each
imported object to its actor, which it then moves (`bu_link_drive`).
"""

import os

from . import bu_link_editor

# Tags on actors the link created; never exported back to where they came from.
LINK_TAGS = ("BU_Live", "BU_LiveStatic")
SCOPES = ("selected", "level")
TEXTURE_SIZES = (256, 512, 1024, 2048, 4096)
DEFAULT_TEXTURE_SIZE = 1024


def _tags(actor):
    try:
        return [str(tag) for tag in actor.tags]
    except Exception:  # noqa: BLE001
        return []


def exportable(actors, link_tags=LINK_TAGS):
    """The actors worth exporting: not the link's own. Pure, given actors with `.tags`."""
    return [actor for actor in actors
            if actor is not None and not any(tag in link_tags for tag in _tags(actor))]


def _candidates(scope):
    import unreal

    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    if scope == "level":
        return list(subsystem.get_all_level_actors() or [])
    return list(subsystem.get_selected_level_actors() or [])


def texture_size(value):
    """A bake size the exporter takes, nearest to what was asked. Pure."""
    try:
        value = int(value)
    except (TypeError, ValueError):
        return DEFAULT_TEXTURE_SIZE
    return min(TEXTURE_SIZES, key=lambda size: abs(size - value))


def describe(actor):
    """What Blender needs to find this actor's imported object. Pure, given an actor."""
    location = actor.get_actor_location()
    return {"label": str(actor.get_actor_label()), "path": str(actor.get_path_name()),
            "location": [float(location.x), float(location.y), float(location.z)]}


def options(source_model=False, size=DEFAULT_TEXTURE_SIZE):
    import unreal

    found = unreal.GLTFExportOptions()
    try:
        found.set_editor_property("default_material_bake_size", unreal.GLTFMaterialBakeSize(
            x=texture_size(size), y=texture_size(size), auto_detect=False))
    except Exception:  # noqa: BLE001 - an exporter without that option
        pass
    for name, value in (("export_lights", False), ("export_cameras", False),
                        ("export_level_sequences", False), ("export_animation_sequences", False),
                        ("export_source_model", bool(source_model))):
        try:
            found.set_editor_property(name, value)
        except Exception:  # noqa: BLE001 - an exporter without that option
            pass
    return found


def export(header, link_tags=LINK_TAGS):
    """Run one export request. Returns the reply for Blender."""
    import unreal

    scope = str(header.get("scope") or "selected")
    path = str(header.get("path") or "")
    reply = {"type": "export_done", "scope": scope, "path": path, "count": 0}
    if scope not in SCOPES or not path.lower().endswith((".gltf", ".glb")):
        reply["error"] = "bad export request"
        return reply
    if not hasattr(unreal, "GLTFExporter"):
        reply["error"] = "Unreal's glTF Exporter plugin is off (Edit > Plugins > glTF Exporter)"
        return reply
    actors = exportable(_candidates(scope), link_tags)
    if not actors:
        reply["error"] = ("nothing selected in Unreal" if scope == "selected"
                          else "the level has nothing to export")
        return reply
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
    settings = options(header.get("source_model"), header.get("texture_size"))

    def work():
        with unreal.ScopedSlowTask(1, "Exporting {0} actor(s) for Blender…".format(len(actors))) as task:
            task.make_dialog(False)
            task.enter_progress_frame(1)
            return unreal.GLTFExporter.export_to_gltf(world, path, settings, set(actors))

    messages = bu_link_editor.untracked(work)
    reply["count"] = len(actors)
    reply["actors"] = [describe(actor) for actor in actors]
    errors = [str(m) for m in (getattr(messages, "errors", None) or [])]
    warnings = [str(m) for m in (getattr(messages, "warnings", None) or [])]
    if errors:
        reply["error"] = errors[0]
    if warnings:
        reply["warnings"] = warnings[:5]
    if not os.path.isfile(path) and "error" not in reply:
        reply["error"] = "Unreal wrote no file"
    return reply
