# SPDX-License-Identifier: GPL-3.0-or-later
"""Unreal's picture inside Blender's viewport.

Registered as a **render engine**, because that is what "show another renderer's image in the
3D viewport" is in Blender: switch a viewport to Rendered with the engine set to *Unreal (BU
Live)* and Blender calls `view_draw`, then composites its own overlays — selection outlines,
gizmos, the grid — on top. A draw-handler overlay would have to choose between covering those
and being covered by the scene.

Colour: `view_draw` output is scene-linear and Blender view-transforms it afterwards. By default
(`COLOUR_BLENDER`) Unreal sends exactly that — its picture before its own tone curve, as linear
half-floats — so Blender's View Transform, Look, Exposure, Curves and White Balance all apply as
they do to Cycles or EEVEE. With `COLOUR_UNREAL`, or from a plugin without float readback, the
frame is Unreal's finished display colour, and `link_color`'s inverse table undoes Blender's
transform so the two cancel: one extra texture lookup in the draw shader.

Blender is the camera. Each time the view moves, `view_draw` sends its pose; Unreal renders from
exactly there and reports where it wrote the frame. That makes camera sync a property of the
design rather than a feature: there is only one camera, and it is this one.

Each picture arrives three or four screen refreshes after the view it was rendered for, while
Blender draws its grid, outlines and gizmos for the view as it is now; moving the view, the
picture swam behind them. So every picture is drawn *reprojected*: moved to where the current
view would see it. With Follow Depth, Unreal sends a depth picture with each frame, and the
picture is drawn as a mesh from the current view (`mesh_point`, the draw's mesh pass): each pixel
moves by its own distance, so turning, orbiting, panning and zooming all line up, and only what
the old picture could not see (behind an edge that has moved) is a guess until the next picture
(`fill_levels`). Otherwise the scene is taken as one plane through the view's pivot
(`warp_matrix`): exact for a turn, and at the pivot's distance for the rest.

The math (`view_params`, `warp_matrix`) and the frame reader (`read_bmp`) use numpy only, so
they are tested without a GPU.
"""

import collections
import math
import os
import time

import numpy as np

try:
    from . import link_color, link_mesh
except ImportError:  # loaded by path in the tests
    import link_color
    import link_mesh

ENGINE_ID = "BU_UNREAL"

# Longest edge of the image Unreal is asked for. Full is the viewport's own size (up to 2560):
# anything smaller is stretched to fill the viewport, and a 960-pixel picture in a 1920-pixel
# viewport kept 0.39 of the fine detail EEVEE showed on Freddy's face (full size: 1.19). The
# size is not where the frame time goes: 7.7 ms of GPU at 960 against 8.5 at 1600, of about 24.
MAX_EDGE = {"LOW": 640, "MEDIUM": 960, "HIGH": 1600, "FULL": 2560}

# Who does the colour management of Unreal's picture (WindowManager.bu_link_colour).
COLOUR_BLENDER = "BLENDER"
COLOUR_UNREAL = "UNREAL"

# How a picture is bent to the view while the camera has moved on from it
# (WindowManager.bu_link_view_bend). Follow Depth moves each pixel by its own distance: near and
# far things stay on their outlines, but what the move reveals is stretched until the next
# picture. Flat moves the whole picture as one sheet: nothing stretches, but near things sit a
# little off their outlines, and the new picture lands with a bigger jump. Off draws it unmoved.
BEND_DEPTH = "DEPTH"
BEND_FLAT = "FLAT"
BEND_OFF = "OFF"


def bend_plan(mode):
    """`(bend at all, by depth)` for a bend setting; an unknown one is Off, the default. Pure.

    Off by default: a tester found it the only one with neither stretching nor jitter. Its cost,
    the picture trailing Blender's overlays while the view moves, shrinks with the delay.
    """
    if mode == BEND_DEPTH:
        return True, True
    if mode == BEND_FLAT:
        return True, False
    return False, False


def exposure_scale(scene):
    """What a linear frame is multiplied by before Blender's view transform sees it.

    With the Unreal Camera's "Add Blender's Exposure" on, Unreal already brightened the frame by
    Blender's Exposure, and Blender is about to apply it again: this takes Unreal's copy back out,
    so Unreal's own viewport still follows Blender's Exposure and the picture here gets it once.
    """
    settings = getattr(scene, "bu_unreal", None)
    if settings is None or not settings.enabled or not settings.follow_blender:
        return 1.0
    return 2.0 ** -float(scene.view_settings.exposure)


def view_params(view_matrix, window_matrix, width, height, is_perspective=True):
    """Blender's viewport camera, expressed for an Unreal SceneCapture.

    Returns location (cm), forward and up unit vectors, and either a horizontal `fov` in degrees
    or an `ortho_width` in cm — all in Unreal's axes. A perspective view also has its `near`
    clipping distance in cm: the viewport's Clip Start, or the camera's.
    """
    view = np.array([list(row) for row in view_matrix], dtype=np.float64).reshape(4, 4)
    projection = np.array([list(row) for row in window_matrix], dtype=np.float64).reshape(4, 4)
    camera = np.linalg.inv(view)

    # A Blender camera looks down its own -Z with +Y up.
    location = camera[:3, 3]
    forward = -camera[:3, 2]
    up = camera[:3, 1]

    def unit(vector):
        length = float(np.linalg.norm(vector))
        return vector / length if length > 1e-12 else vector

    params = {
        "location": [float(v) for v in link_mesh.points_to_unreal([location])[0]],
        "forward": [float(v) for v in link_mesh.directions_to_unreal([unit(forward)])[0]],
        "up": [float(v) for v in link_mesh.directions_to_unreal([unit(up)])[0]],
        "width": int(width),
        "height": int(height),
    }

    scale_x = float(projection[0, 0]) or 1.0
    scale_y = float(projection[1, 1]) or 1.0
    if is_perspective:
        # Horizontal, because that is what SceneCaptureComponent2D.FOVAngle means.
        params["fov"] = math.degrees(2.0 * math.atan(1.0 / scale_x))
        # Off centre: panning or zooming in the camera view, or the camera's lens shift. The
        # view's middle lies at (x, y) / distance = (P[0][2] / P[0][0], P[1][2] / P[1][1]);
        # a field of view alone left that out, and the picture slid off Blender's overlays.
        centre = (float(projection[0, 2]) / scale_x, float(projection[1, 2]) / scale_y)
        if abs(centre[0]) > 1e-7 or abs(centre[1]) > 1e-7:
            params["centre"] = [centre[0], centre[1]]
        # Blender's perspective: z_clip = (f + n) / (n - f) z + 2 f n / (n - f), so
        # n = P[2][3] / (P[2][2] - 1) (also when the far plane is at infinity).
        denominator = float(projection[2, 2]) - 1.0
        if abs(denominator) > 1e-12:
            near = float(projection[2, 3]) / denominator
            if near > 0.0:
                params["near"] = near * link_mesh.SCALE
    else:
        params["ortho_width"] = (2.0 / scale_x) * link_mesh.SCALE
        # Off centre, orthographic: the same picture from a camera moved sideways, exactly.
        aside = (-float(projection[0, 3]) / scale_x, -float(projection[1, 3]) / scale_y)
        if abs(aside[0]) > 1e-9 or abs(aside[1]) > 1e-9:
            moved = location + unit(camera[:3, 0]) * aside[0] + unit(up) * aside[1]
            params["location"] = [float(v) for v in link_mesh.points_to_unreal([moved])[0]]
    return params


def fit_size(width, height, max_edge):
    """Scale a region down so its longest edge fits `max_edge`, keeping aspect and even sizes."""
    width, height = max(int(width), 2), max(int(height), 2)
    longest = max(width, height)
    if longest > max_edge:
        factor = max_edge / float(longest)
        width, height = int(round(width * factor)), int(round(height * factor))
    return max(2, width - width % 2), max(2, height - height % 2)


def signature(params):
    """A view rounded far enough that sub-pixel jitter is not a new view."""
    values = (
        [round(v, 2) for v in params["location"]]
        + [round(v, 4) for v in params["forward"]]
        + [round(v, 4) for v in params["up"]]
        + [params["width"], params["height"],
           round(params.get("fov", 0.0), 3), round(params.get("ortho_width", 0.0), 2),
           round(params.get("near", 0.0), 3)]
        + [round(v, 5) for v in params.get("centre", (0.0, 0.0))]
    )
    return tuple(values)


def read_bmp(path):
    """Read an uncompressed 24- or 32-bit BMP. Returns `(width, height, rgba)` or None.

    `rgba` is float32, flat, bottom row first (the order a GPU texture wants). Returns None for a
    file that is missing, still being written, or not one of the two layouts Unreal produces —
    the caller simply tries again, so a half-written frame costs one tick rather than an error.
    """
    try:
        size = os.path.getsize(path)
        if size < 54:
            return None
        with open(path, "rb") as handle:
            data = handle.read()
    except OSError:
        return None

    if data[:2] != b"BM" or len(data) < 54:
        return None
    declared = int.from_bytes(data[2:6], "little")
    offset = int.from_bytes(data[10:14], "little")
    width = int.from_bytes(data[18:22], "little", signed=True)
    height = int.from_bytes(data[22:26], "little", signed=True)
    bits = int.from_bytes(data[28:30], "little")
    compression = int.from_bytes(data[30:34], "little")

    # 0 is BI_RGB, 3 is BI_BITFIELDS, which 32-bit writers use for plain BGRA.
    if bits not in (24, 32) or compression not in (0, 3) or width <= 0 or height == 0:
        return None

    rows = abs(height)
    channels = bits // 8
    stride = (width * channels + 3) & ~3
    if len(data) < offset + stride * rows or (declared and len(data) < declared):
        return None  # still being written

    pixels = np.frombuffer(data, dtype=np.uint8, count=stride * rows, offset=offset)
    pixels = pixels.reshape(rows, stride)[:, : width * channels].reshape(rows, width, channels)
    if height < 0:
        pixels = pixels[::-1]  # stored top-down; flip to bottom-up

    rgba = np.empty((rows, width, 4), dtype=np.float32)
    rgba[:, :, 0] = pixels[:, :, 2]
    rgba[:, :, 1] = pixels[:, :, 1]
    rgba[:, :, 2] = pixels[:, :, 0]
    rgba[:, :, :3] *= np.float32(1.0 / 255.0)
    # Alpha is forced opaque: a scene capture's alpha channel holds inverse opacity or nothing
    # useful, and honouring it makes the frame vanish against the viewport background.
    rgba[:, :, 3] = 1.0
    return width, rows, rgba.reshape(-1)


# -- state shared with link.py -----------------------------------------------------------------

upload_ms = 0.0       # cost of the last GPU texture upload, for the panel
_send = None          # callable(header) installed by link.py while a link is up
_frame = None         # (sequence, width, height, rgba, linear, crop) — the newest frame
linear_frames = None  # whether the last frame was scene-linear (None: no frame yet), for the panel
_frame_serial = 0
_view_serial = 0
_last_view = None     # the header last sent, for the keep-alive
_frame_seq = None     # the view (its `seq`) the newest frame was rendered for, when known
# What each recent view sent was, as projection @ view: the newest frame is drawn moved from
# its own view to the current one. A view is sent each redraw while moving: a second's worth.
SENT_VIEWS_KEPT = 240
# Depth (cm, Unreal's) past which a pixel is taken as infinitely far: the sky, and anything past
# what a half float holds.
DEPTH_FAR_CM = 60000.0
# Follow Depth (the draw's mesh pass, `mesh_point`): the depth picture drawn as a mesh, a vertex
# at each depth texel, seen from the current view with a depth test. Whatever is nearest wins,
# and each pixel moves by its own distance, a balloon string or a garland as surely as a wall.
# A 2x2 of depth texels more than EDGE_RATIO apart is an outline (`mesh_outline`): once a move
# stretches one past OPEN_STRETCH times its size in any direction (`mesh_stretched`; a sideways
# move shears a garland's outline without growing it), the mesh is left open there rather than
# smeared from the near thing to what is behind it, and the opening (what the old picture never
# saw) is filled from round it, the farther side preferred (`fill_levels`, FILL_LEVELS levels,
# each half the last, then `fill_push` back down): a soft guess until the next picture. (Each
# pixel's ray used to be walked across the old picture instead, stepping between depth texels:
# thin things fell between the steps, and the room tore into streaks round every string and
# chair leg, however many steps.)
# MESH_FAR is the depth test's value for the sky.
EDGE_RATIO = 1.25
OPEN_STRETCH = 2.0
FILL_LEVELS = 10
MESH_FAR = 0.999999
_sent_views = collections.OrderedDict()
_sent_lenses = {}     # and the `depth_lens` of each one's projection
_sent_times = {}      # and when it was sent (perf_counter), for the picture delay
on_rendered = None    # callable() installed by link.py: a viewport has just switched to Rendered
status = None         # callable() -> str installed by link.py: what to say while there is no picture
loading = None        # callable() -> [str] installed by link.py: what is still loading (loading_lines)
working = None        # callable() -> bool installed by link.py: Unreal's stats still arrive


def set_sender(sender):
    global _send, _frame, _last_view, linear_frames, _frame_seq
    _send = sender
    if sender is None:
        _frame = None
        _last_view = None
        linear_frames = None
        _frame_seq = None
        _sent_views.clear()
        _sent_lenses.clear()
        _sent_times.clear()


def remember_view(seq, view_matrix, window_matrix):
    """Keep what view `seq` was, for drawing its picture once the view has moved on."""
    projection = np.array(window_matrix, dtype=np.float64)
    _sent_views[seq] = projection @ np.array(view_matrix, dtype=np.float64)
    _sent_lenses[seq] = depth_lens(projection)
    _sent_times[seq] = time.perf_counter()
    while len(_sent_views) > SENT_VIEWS_KEPT:
        gone = _sent_views.popitem(last=False)[0]
        _sent_lenses.pop(gone, None)
        _sent_times.pop(gone, None)


def delay_parts(sent, times, arrived):
    """Where a picture's delay went, in ms, or None without the times. Pure.

    `sent` is when Blender sent its view; `times` the picture's own stamps from Unreal (when it
    read that view, began rendering it, and found it copied into shared memory); `arrived` when
    Blender had it. One clock: perf_counter is the system's on Windows, the same in each process.
    """
    if sent is None or not times or any(times.get(k) is None for k in ("view", "render", "ready")):
        return None
    parts = {
        "to_unreal": times["view"] - sent,
        "until_render": times["render"] - times["view"],
        "render": times["ready"] - times["render"],
        "to_blender": arrived - times["ready"],
    }
    parts = {k: round(v * 1000.0, 1) for k, v in parts.items()}
    parts["total"] = round((arrived - sent) * 1000.0, 1)
    if times.get("native_ms") is not None:
        # Of "render": the GPU's and the copy's part; the rest is Unreal noticing it was done.
        parts["native"] = float(times["native_ms"])
    return parts


def warp_matrix(old, new, pivot, forward):
    """The 3x3 map from the current view's normalised device coordinates to those of the view a
    picture was rendered for, or None to draw it as it is. Pure.

    `old` and `new` are projection @ view (4x4). The scene is taken as the plane through `pivot`
    facing along `forward` (the view's own pivot and direction): a pixel of the new view is
    where its ray meets that plane, seen from the old view. Rays and planes are projective, so
    the whole map is one homography, solved from the four corners.
    """
    old = np.asarray(old, dtype=np.float64)
    new = np.asarray(new, dtype=np.float64)
    if np.allclose(old, new, rtol=0.0, atol=1e-9):
        return np.eye(3)
    try:
        inverse = np.linalg.inv(new)
    except np.linalg.LinAlgError:
        return None
    pivot = np.asarray(pivot, dtype=np.float64)
    normal = np.asarray(forward, dtype=np.float64)
    found = []
    for x, y in ((-1.0, -1.0), (1.0, -1.0), (1.0, 1.0), (-1.0, 1.0)):
        near = inverse @ (x, y, -1.0, 1.0)
        far = inverse @ (x, y, 1.0, 1.0)
        if abs(near[3]) < 1e-12 or abs(far[3]) < 1e-12:
            return None
        near, far = near[:3] / near[3], far[:3] / far[3]
        ray = far - near
        facing = float(ray @ normal)
        if abs(facing) < 1e-12:
            return None
        along = float((pivot - near) @ normal) / facing
        if along <= 0.0:
            return None  # the pivot is behind this view: there is no plane in front to borrow
        point = near + ray * along
        seen = old @ np.append(point, 1.0)
        if seen[3] <= 1e-9:
            return None  # behind the old view: turned too far to borrow its picture
        found.append(((x, y), (seen[0] / seen[3], seen[1] / seen[3])))
    rows, values = [], []
    for (x, y), (u, v) in found:
        rows.append((x, y, 1.0, 0.0, 0.0, 0.0, -u * x, -u * y))
        values.append(u)
        rows.append((0.0, 0.0, 0.0, x, y, 1.0, -v * x, -v * y))
        values.append(v)
    try:
        h = np.linalg.solve(np.array(rows), np.array(values))
    except np.linalg.LinAlgError:
        return None
    return np.append(h, 1.0).reshape(3, 3)


def frame_warp(seq, new, pivot, forward):
    """`warp_matrix` for the picture of view `seq` drawn in view `new`; None when unknown."""
    old = _sent_views.get(seq) if seq is not None else None
    if old is None:
        return None
    return warp_matrix(old, new, pivot, forward)


def inverse_depth(depth_cm):
    """Unreal's depth (cm along the view) -> 1 / depth in Blender units, 0 for the sky. Pure.

    The inverse because it is what interpolates correctly across a surface on screen, and what
    stays finite for the sky.
    """
    depth_cm = np.asarray(depth_cm, dtype=np.float32)
    # Divided whole, then the unusable zeroed: a third of the time of dividing the usable
    # alone, which matters at a full-size depth picture every frame.
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        found = np.divide(np.float32(link_mesh.SCALE), depth_cm, dtype=np.float32)
    found[~((depth_cm > 0.0) & (depth_cm < DEPTH_FAR_CM))] = 0.0
    return found


def depth_lens(projection):
    """(A, B, C, D) of a projection: a point at depth z is clip z = A z + B, clip w = C z + D.

    Blender's projections have no x or y in their last two rows, so a pixel's clip position is
    (ndc * w, A z + B, w): what the draw shader rebuilds from a depth picture. Pure.
    """
    p = np.asarray(projection, dtype=np.float64)
    return (-float(p[2][2]), float(p[2][3]), -float(p[3][2]), float(p[3][3]))


def clip_start(lens):
    """A perspective view's clip start from its `depth_lens`, or 0 for an orthographic one. Pure.

    Clip z is A z + B and w is z, and at the clip start z / w is -1.
    """
    a, b, c, _d = (float(v) for v in lens)
    if c == 0.0 or a + 1.0 == 0.0:
        return 0.0
    return -b / (a + 1.0)


def mesh_params(old, new, crop, lens, near, rest=1.0):
    """The mesh pass's uniform buffer, laid out as its `BUMeshParams` (std140). Pure.

    `old` and `new`: projection @ view of the view the picture was rendered for and of the
    current one; `crop`: (u0, v0, u1, v1), the view inside the overscanned picture, which the
    depth picture covers whole; `lens`: the old view's `depth_lens`; `near`: the current view's
    `clip_start`, which scales the depth test; `rest`: depth texels per viewport pixel while the
    view has not moved (the fewer of across and down), which an outline's stretch is measured
    against (`mesh_stretched`).
    """
    move = np.asarray(new, dtype=np.float64) @ np.linalg.inv(np.asarray(old, dtype=np.float64))
    # GLSL matrices are stored a column at a time.
    return np.concatenate((
        move.T.reshape(-1), np.asarray(crop, dtype=np.float64),
        np.asarray(lens, dtype=np.float64),
        (float(near), EDGE_RATIO, float(rest), 0.0))).astype(np.float32)


def mesh_point(old, new, crop, lens, near, at, s):
    """Where the mesh pass puts the old picture's place `at` (texture coordinates across the
    whole overscanned picture) whose 1/depth is `s`: (x, y) in the current view's NDC and its
    depth-test value (smaller is nearer), or None behind the current view. Pure: the mesh
    pass's vertex shader, for the tests.

    The point is rebuilt from its old screen place and depth, divided by that depth so that the
    sky (s = 0) is a direction rather than a point at infinity: (ndc (C + D s), A + B s, C + D s)
    is the old clip position over the depth (`lens` is the old view's `depth_lens`). `new` times
    the inverse of `old` takes it to the current view, still over the old depth; there the
    current depth is w / s, and the depth test's value MESH_FAR - `near` / that depth lies
    between -1 and 1 for anything past half the clip start.
    """
    u0, v0, u1, v1 = (float(c) for c in crop)
    x = (float(at[0]) - u0) / (u1 - u0) * 2.0 - 1.0
    y = (float(at[1]) - v0) / (v1 - v0) * 2.0 - 1.0
    a, b, c, d = (float(v) for v in lens)
    w = c + d * float(s)
    move = np.asarray(new, dtype=np.float64) @ np.linalg.inv(np.asarray(old, dtype=np.float64))
    h = move @ np.array((x * w, y * w, a + b * float(s), w))
    if h[3] <= 1e-12:
        return None
    return float(h[0] / h[3]), float(h[1] / h[3]), MESH_FAR - float(near) * float(s) / float(h[3])


def mesh_outline(a, b, c, d):
    """Whether a 2x2 of depth texels (their 1/depths) straddles an outline. Pure.

    There the mesh would join a near thing to what is behind it; stretched by a move
    (OPEN_STRETCH), the mesh pass leaves it open instead.
    """
    found = (float(a), float(b), float(c), float(d))
    return max(found) > min(found) * EDGE_RATIO + 1e-5


def mesh_stretched(across, down, rest):
    """Whether the mesh pass draws a 2x2 stretched past OPEN_STRETCH times its size at `rest`
    (`mesh_params`) in some direction. Pure: the mesh pass's fragment shader, for the tests.

    `across` and `down`: how far through the depth picture (in texels) one viewport pixel to
    the right and one up go there. Their matrix's smaller singular value is the fewest texels a
    pixel crosses in any direction: the most stretched. (Its area alone misses a shear: a
    sideways move slides a garland's near edge along the wall behind it, area unchanged.)
    """
    ax, ay = (float(v) for v in across)
    dx, dy = (float(v) for v in down)
    square = ax * ax + ay * ay + dx * dx + dy * dy
    det = abs(ax * dy - ay * dx)
    largest = math.sqrt(max(0.5 * (square + math.sqrt(max(square * square - 4.0 * det * det,
                                                              0.0))), 1e-30))
    return det / largest * OPEN_STRETCH < float(rest)


def fill_levels(rgba, levels=FILL_LEVELS):
    """The fill pyramid the draw builds from its mesh pass (`_fill_shader`). Pure.

    `rgba`: the mesh pass's picture, rows x columns x 4: colour and the current view's 1/depth,
    -1 where the mesh was left open. Returns `levels` arrays, each half the size of the one before
    (rounded up, the edge repeated where the size is odd): each texel the average colour of those
    of the four under it that are drawn and no nearer than the farthest of them by EDGE_RATIO,
    and that farthest 1/depth; (0, 0, 0, -1) where none is drawn. What a move opens was behind
    what is in front, so the farther side is what fills it.
    """
    current = np.asarray(rgba, dtype=np.float32)
    found = []
    for _ in range(levels):
        rows, columns = current.shape[:2]
        half_rows, half_columns = (rows + 1) // 2, (columns + 1) // 2
        picked = current[np.minimum(np.arange(half_rows * 2), rows - 1)][
            :, np.minimum(np.arange(half_columns * 2), columns - 1)]
        blocks = picked.reshape(half_rows, 2, half_columns, 2, 4).transpose(
            0, 2, 1, 3, 4).reshape(half_rows, half_columns, 4, 4)
        drawn = blocks[..., 3] >= 0.0
        far = np.where(drawn, blocks[..., 3], np.inf).min(axis=2)
        take = drawn & (blocks[..., 3] <= far[..., None] * EDGE_RATIO + 1e-6)
        count = take.sum(axis=2)
        colour = (blocks[..., :3] * take[..., None]).sum(axis=2) / np.maximum(count, 1)[..., None]
        current = np.concatenate(
            (colour, np.where(count > 0, far, -1.0)[..., None]), axis=2).astype(np.float32)
        found.append(current)
    return found


def _drawn_bilinear(level, u, v):
    """`level` (rows x columns x 4) read bilinear at texture coordinates `u`, `v` (arrays) over
    its drawn texels (alpha >= 0) no nearer than the farthest of the four by EDGE_RATIO:
    (colour sums, weights, that farthest 1/depth). Pure.

    The farthest, because what is being filled was behind: beside a near thing's edge, a
    plain bilinear read would carry the near thing's colour into the opening.
    """
    rows, columns = level.shape[:2]
    x = np.asarray(u, dtype=np.float64) * columns - 0.5
    y = np.asarray(v, dtype=np.float64) * rows - 0.5
    x0, y0 = np.floor(x).astype(int), np.floor(y).astype(int)
    fx, fy = x - x0, y - y0
    corners = []
    far = np.full(x.shape, np.inf)
    for dy in (0, 1):
        for dx in (0, 1):
            texel = level[np.clip(y0 + dy, 0, rows - 1), np.clip(x0 + dx, 0, columns - 1)]
            corners.append((texel, (fx if dx else 1.0 - fx) * (fy if dy else 1.0 - fy)))
            far = np.where(texel[..., 3] >= 0.0, np.minimum(far, texel[..., 3]), far)
    colour = np.zeros(x.shape + (3,))
    total = np.zeros(x.shape)
    for texel, weight in corners:
        weight = weight * ((texel[..., 3] >= 0.0) & (texel[..., 3] <= far * EDGE_RATIO + 1e-6))
        colour += texel[..., :3] * weight[..., None]
        total += weight
    return colour, total, far


def fill_push(levels):
    """The fill pyramid's way back down (`_push_shader`). Pure.

    From the top of `fill_levels`, each level's undrawn texels take the level above it read
    bilinear over the farthest of what that has drawn (`_drawn_bilinear`), with that 1/depth,
    and count as drawn from then on: an opening blends smoothly into what is behind round it
    instead of showing one level's blocks. Returns the levels so filled, the top as it was; the
    first is what the draw reads (`fill_colour`).
    """
    filled = [levels[-1]]
    for level in reversed(levels[:-1]):
        rows, columns = level.shape[:2]
        v, u = np.mgrid[0:rows, 0:columns]
        colour, total, far = _drawn_bilinear(filled[0], (u + 0.5) / columns, (v + 0.5) / rows)
        took = (level[..., 3] < 0.0) & (total > 1e-4)
        found = level.copy()
        found[took, :3] = colour[took] / total[took][:, None]
        found[took, 3] = far[took]
        filled.insert(0, found)
    return filled


def fill_colour(filled, uv, otherwise=None):
    """The colour the draw gives a place its mesh pass left open, at `uv` (0 to 1 across the
    view): the first of `fill_push`'s levels read bilinear over the farthest of its drawn
    texels; `otherwise` where nothing round it is drawn. Pure: the composite shader's fill."""
    colour, total, _far = _drawn_bilinear(filled[0], float(uv[0]), float(uv[1]))
    return colour / total if total > 1e-4 else otherwise


def draw_params(h, crop, extra):
    """The plain draw's uniform buffer, laid out as its `BUDrawParams` (std140). Pure.

    `h`: the 3x3 plane warp (`warp_matrix`), made a 4x4 that leaves z alone; `crop`: (u0, v0,
    u1, v1); `extra`: the exposure scale, or the lookup table's size.
    """
    h = np.asarray(h, dtype=np.float64)
    warp = np.array(((h[0][0], h[0][1], 0.0, h[0][2]),
                     (h[1][0], h[1][1], 0.0, h[1][2]),
                     (0.0, 0.0, 1.0, 0.0),
                     (h[2][0], h[2][1], 0.0, h[2][2])))
    # GLSL matrices are stored a column at a time.
    return np.concatenate((warp.T.reshape(-1), np.asarray(crop, dtype=np.float64),
                           (float(extra), 0.0, 0.0, 0.0))).astype(np.float32)


def crop_of(value, width, height):
    """Unreal's overscan as (x, y) pixels to leave off each side, or (0, 0) if unusable. Pure."""
    try:
        x, y = (max(0, int(v)) for v in list(value or (0, 0))[:2])
    except (TypeError, ValueError):
        return (0, 0)
    if 2 * x >= int(width) or 2 * y >= int(height):
        return (0, 0)
    return (x, y)


def crop_coords(width, height, crop):
    """The texture coordinates of the picture inside an overscanned frame. Pure.

    ((u0, v0), (u1, v0), (u1, v1), (u0, v1)), in the order the draw's corners go.
    """
    u0 = crop[0] / float(width)
    v0 = crop[1] / float(height)
    return ((u0, v0), (1.0 - u0, v0), (1.0 - u0, 1.0 - v0), (u0, 1.0 - v0))


def upscaling(scene):
    """The upscaler fields for the view message (Render > Lighting > Upscaling)."""
    from . import link_lighting

    return link_lighting.upscaling(scene)


def overscan(scene):
    """The overscan fraction to ask Unreal for (Render → Lighting → Overscan)."""
    settings = getattr(scene, "bu_render", None)
    return round(float(getattr(settings, "overscan", 0.0) or 0.0) / 100.0, 4)


def accept_frame(path, width=0, height=0, crop=None, seq=None, report=None):
    """Load a frame Unreal has finished writing. Returns True if it was usable.

    `width` and `height`, when given, are what Unreal said it rendered. A readable bitmap of any
    other size is a different frame that happened to be at this path, and is refused. `crop`:
    the overscan to leave off each side. `seq` and `report`: the view it was rendered for and
    what it says about itself (`still_report`), kept for a still being rendered
    (`render_still`).
    """
    global _frame, _frame_serial, linear_frames, _frame_seq
    loaded = read_bmp(path)
    if loaded is None:
        return False
    if width and height and (loaded[0], loaded[1]) != (int(width), int(height)):
        return False
    _frame_serial += 1
    _frame = (_frame_serial,) + loaded + (False, crop_of(crop, loaded[0], loaded[1]), None)
    _frame_seq = None
    linear_frames = False
    _keep_for_render(seq, loaded[0], loaded[1], loaded[2], False, crop, report)
    return True


def _keep_for_render(seq, width, height, rgba, linear, crop, report):
    """Keep a picture of the still being rendered, its pixels in an array of their own: the
    shared one is written again by the next picture while the render thread may still be
    reading. Only a picture that could be the still has them copied (`report`: `still_report`,
    settled far enough); the warm-up's are counted and dropped, as each copy is the whole
    picture again on Blender's main thread."""
    global _render_frame
    view = _render_view
    if view is None or seq is None or int(seq) != view.get("seq"):
        return
    if _render_average is not None and report is not None and report.get("jitter") is not None:
        # A moved sample (`bu_link.aa_samples`): the still is their average, once all are in.
        pixels = average_sample(_render_average, rgba, int(report.get("settled", 0)))
    else:
        wanted = (_render_keep_all or report is None
                  or int(report.get("settled", 0)) >= _render_needed)
        pixels = np.array(rgba, dtype=np.float32) if wanted else None
    _render_frame = (_frame_serial, int(width), int(height), pixels,
                     bool(linear), crop_of(crop, width, height), report)


def average_sample(average, rgba, settled):
    """Add one of a still's moved pictures to `average` ({"samples", "after", "sum", "count"}):
    their mean once it has `samples` of them, else None. Pictures `settled` no further than
    `after` (the warm-up; or something changed in Unreal, which counts again from 0) start it
    again. Equal weights: Unreal spreads the moves as the pixel filter weighs them. Pure (it
    changes `average`)."""
    if settled <= average["after"]:
        average["sum"], average["count"] = None, 0
        return None
    picture = np.asarray(rgba, dtype=np.float32)
    if average["sum"] is None or average["sum"].shape != picture.shape:
        average["sum"], average["count"] = picture.astype(np.float32, copy=True), 1
    else:
        average["sum"] += picture
        average["count"] += 1
    if average["count"] < average["samples"]:
        return None
    return average["sum"] / np.float32(average["count"])


_shared = None        # one buffer reused for every frame taken from shared memory


def shared_depth(view, offset, width, height, depth):
    """The depth picture Unreal put after a frame in its slot, as (width, height, 1/depth), or
    None when there is none, it does not fit, or it is not the nearest-depth kind.

    One float per pixel, the nearest depth (cm) round it (`format` "nearest"): the frame's own
    size from a current Unreal side, a quarter from an older one. An older one still sent
    single samples, which tore and speckled; it is ignored, and the picture is moved by the
    plane alone.
    """
    try:
        start = offset + int(depth["offset"])
        depth_width, depth_height = int(depth["width"]), int(depth["height"])
        kind = depth.get("format")
    except (TypeError, KeyError, ValueError, AttributeError):
        return None
    count = depth_width * depth_height
    if (kind != "nearest" or depth_width <= 0 or depth_height <= 0
            or start < offset + width * height * 16 or start + count * 4 > len(view)):
        return None
    found = view[start:start + count * 4].view(np.float32).reshape(depth_height, depth_width)
    return depth_width, depth_height, inverse_depth(found).reshape(-1)


FRAME_READY = "ready"
FRAME_FAILED = "failed"
FRAME_WAITING = "waiting"


def _word(view, offset):
    offset = int(offset)
    if offset < 0 or offset + 4 > len(view):
        return None
    return int(view[offset:offset + 4].view(np.int32)[0])


def frame_state(view, offset, header):
    """Whether a picture Unreal announced in shared memory is there to take. Pure.

    One announced as it began carries `ready`: its word in the slot (at `offset` + its offset)
    turns to its token when the native module has copied the picture, or to -token if that
    failed. One announced only when done (an Unreal without the ready word) is ready.
    """
    ready = header.get("ready")
    if not ready:
        return FRAME_READY
    word = _word(view, offset + int(ready.get("offset", -1)))
    token = int(ready.get("token") or 0)
    if token and word == token:
        return FRAME_READY
    if token and word == -token:
        return FRAME_FAILED
    return FRAME_WAITING


def frame_depth(view, offset, header):
    """The depth layout to take with a ready picture, or None when it did not arrive. Pure.

    The depth is read before its picture, so it is done by then, unless it failed."""
    depth = header.get("depth")
    ready = header.get("depth_ready")
    if not depth or not ready:
        return depth
    token = int(ready.get("token") or 0)
    return depth if token and _word(view, offset + int(ready.get("offset", -1))) == token else None


def accept_shared(view, offset, width, height, linear=False, crop=None, seq=None, depth=None,
                  report=None):
    """Take a frame Unreal wrote into shared memory. Returns True if it was usable.

    The frame is already float RGBA, bottom row first — what a GPU texture wants — so this is
    one copy out of the slot. The copy is what lets the slot go straight back to Unreal instead
    of being held until every viewport has drawn. `linear`: scene-linear colour before Unreal's
    tone curve, rather than Unreal's finished display colour. `report`: as `accept_frame`.
    """
    global _frame, _frame_serial, _shared, linear_frames, _frame_seq
    width, height = int(width), int(height)
    count = width * height * 4
    if count <= 0 or offset < 0 or offset + count * 4 > len(view):
        return False
    if _shared is None or len(_shared) != count:
        _shared = np.empty(count, dtype=np.float32)
    np.copyto(_shared, view[offset:offset + count * 4].view(np.float32))
    _frame_serial += 1
    _frame = (_frame_serial, width, height, _shared, bool(linear), crop_of(crop, width, height),
              shared_depth(view, offset, width, height, depth) if depth else None)
    _frame_seq = int(seq) if seq is not None else None
    linear_frames = bool(linear)
    _keep_for_render(seq, width, height, _shared, linear, crop, report)
    return True


def resend_view():
    """Keep-alive: tell Unreal the viewport, or the still being rendered, is still looked at."""
    view = _render_view if _render_view is not None else _last_view
    if _send is not None and view is not None:
        _send(view)


# -- F12: a still Unreal renders for Blender (`render_still`) ---------------------------------
#
# The scene camera is sent as one more view, at the output resolution and marked `render`, and
# Unreal renders it at full rate. Each picture says how many pictures have gone by since the
# view or the scene last changed with nothing loading (`settled`), how much is still loading,
# and the last of Blender's frames it holds (`still_report`). The still is the first picture
# that holds everything Blender has sent, with nothing on its way or loading, once the warm-up
# has gone by (Render > Render (F12) > Warm-Up Frames: Lumen and TSR clean up over consecutive
# frames), or for the path tracer one past its samples (a sample a picture).
RENDER_SETTLE = 12
STILL_AA_SAMPLES = 12  # F12's Anti-Aliasing Samples to start with
# An older Unreal side sends no report: its loading comes in the stats, once a second, so a
# still waits this long with nothing loading before it is taken.
RENDER_IDLE_SECONDS = 1.5
# Waiting for Unreal to start (F12 with no link starts BU's own), and for pictures to come.
RENDER_START_SECONDS = 900.0
RENDER_STALL_SECONDS = 30.0
# But while Unreal still says it is working (its stats, once a second), a slow picture is waited
# for this long: a heavy scene at DLAA and Cinematic quality took 3 to 12 s a frame, and the 30
# seconds ran out while it was rendering. Esc still cancels.
RENDER_SLOW_SECONDS = 600.0
# The most a picture through shared memory can hold, colour as float RGBA, beside its ready words.
RENDER_SLOT_RESERVE = 64

_render_view = None   # the view message of the still being rendered, or None
_render_frame = None  # its newest picture: (serial, width, height, rgba, linear, crop, report),
                      # rgba None until one could be the still (`_keep_for_render`)
_render_needed = 0    # settled pictures the still waits for
_render_keep_all = False  # keep every picture's pixels: the still counts them itself
_render_average = None  # a still's anti-aliasing samples being averaged (`average_sample`)
_render_epoch = 0     # counts finished stills: each makes the viewports send their own view again
last_still = None     # where the last still's time went (`render_still`), for the panel
redraw_wanted = False  # a still ended: link.py redraws the viewports from the main thread
start_wanted = False  # a still found no link: link.py's watcher starts BU's Unreal for it
final_wanted = None   # when a still last asked for the render's subdivision (`link.final_subdivision`)
final_on = False      # and the link has switched the scene to it
FINAL_WAIT_SECONDS = 10.0  # a still waits at most this long for the switch
start_refused = ""    # and why it could not, for the still to report
# An animation render (Ctrl+F12): each frame asks link.py's watcher, on the main thread, to move
# the live scene to that frame (`frame_wanted`: serial, scene name, frame, subframe), and waits
# for it to say it did (`frame_shown`: that serial). `animating`: when a frame last asked, so
# the watcher looks in often while an animation renders. `holding_viewports`: from the first
# frame until link.py's watcher sees the render end, the viewports' own views wait.
frame_wanted = None
frame_shown = None
animating = 0.0
holding_viewports = False
_frame_serial = 0
FRAME_MOVE_SECONDS = 60.0
busy = None           # callable() -> str installed by link.py: what is still on its way, or ""
frame_room = None     # callable(width, height) -> "" or why not, installed by link.py: slots that
                      # hold a still this big (link.frame_room)
pump = None           # callable() installed by link.py: its timer's work, for a still rendered
                      # on the main thread (a script's render), where timers wait


class RenderError(Exception):
    """A still Unreal cannot render, with what to tell the user."""


class RenderStopped(Exception):
    """The user cancelled the still."""


def render_size(render):
    """The output size in pixels for scene.render's resolution and percentage. Pure."""
    scale = float(render.resolution_percentage) / 100.0
    return int(render.resolution_x * scale), int(render.resolution_y * scale)


def render_fits(width, height, slot_bytes):
    """Whether a `width` x `height` still fits one shared-memory picture slot. Pure."""
    return 2 <= width and 2 <= height and width * height * 16 <= slot_bytes - RENDER_SLOT_RESERVE


def render_view_message(view_matrix, projection, width, height, perspective, colour, scaled,
                        cinematic=False, aa_samples=1, aa_filter=1.5, volume=None):
    """The view message for a still from a camera. Pure.

    No overscan and no depth picture: the still is exactly the camera's frame. `colour`:
    COLOUR_BLENDER asks for scene-linear colour, as a render engine's result is; `scaled`: the
    upscaler fields (`upscaling`), so the still is rendered as the viewport is. `cinematic`:
    Unreal renders it with Movie Render Queue's Game Overrides (`bu_link.cinematic_cvars`).
    `aa_samples` over 1: that many pictures after the warm-up, each moved within a pixel
    filter `aa_filter` pixels wide, to be averaged (`bu_link.aa_samples`); a perspective
    camera's only. `volume`: (steps, pixels) for Unreal's volumetric fog grid while the still
    renders (`bu_link.cinematic_cvars`). Unreal's editor camera is left where it is.
    """
    params = view_params(view_matrix, projection, width, height, perspective)
    if colour == COLOUR_BLENDER:
        params["colour"] = "linear"
    params["overscan"] = 0.0
    params["depth"] = False
    params.update(scaled)
    params["render"] = True
    if cinematic:
        params["cinematic"] = True
    if perspective and int(aa_samples or 1) > 1:
        params["aa_samples"] = int(aa_samples)
        params["aa_filter"] = round(float(aa_filter), 4)
    if volume:
        params["volume_steps"] = int(volume[0])
        params["volume_pixels"] = int(volume[1])
    params["drive_editor"] = False
    return params


def filter_size(scene):
    """The scene's pixel filter width in pixels, as Cycles reads it (Film > Pixel Filter), or
    the render settings' (EEVEE's) without Cycles' settings; 1.5, both defaults, without
    either."""
    for owner, name in ((getattr(scene, "cycles", None), "filter_width"),
                        (getattr(scene, "render", None), "filter_size")):
        try:
            value = float(getattr(owner, name))
        except (TypeError, ValueError, AttributeError):
            continue
        if value > 0.0:
            return value
    return 1.5


def dof_message(fstop, focus, lens, fov, blades=0):
    """A view's `dof` field: a camera's depth of field for Unreal's (`bu_link.dof_post`), or
    None. `fstop`; `focus`: the focus distance in metres; `lens`: the focal length in mm; `fov`:
    the view's horizontal field of view in degrees; `blades`: the aperture's (0, round).

    Unreal works out the focal length from the view's field of view and its sensor width
    (`ComputeFocalLengthFromFov`), so the sensor sent is the width the view's field of view
    spans at Blender's focal length: then Unreal's lens is Blender's, and its blur, a thin
    lens's as Cycles' is, the same size in the picture. Pure."""
    try:
        fstop, focus, lens, fov = float(fstop), float(focus), float(lens), float(fov)
    except (TypeError, ValueError):
        return None
    if fstop <= 0.0 or lens <= 0.0 or not 0.0 < fov < 180.0:
        return None
    return {"fstop": round(fstop, 4),
            "focus": round(max(focus, 1e-5) * link_mesh.SCALE, 3),
            "sensor": round(2.0 * lens * math.tan(math.radians(fov) / 2.0), 4),
            "blades": int(blades or 0)}


def focus_distance(camera):
    """A camera object's focus distance in metres, as Blender works it out
    (`BKE_camera_object_dof_distance`): along the camera's view to its focus object (the bone's
    head, given one of an armature), else the distance it is set to."""
    from mathutils import Vector

    dof = camera.data.dof
    target = dof.focus_object
    if target is None:
        return float(dof.focus_distance)
    matrix = target.matrix_world
    position = matrix.translation
    bone = getattr(dof, "focus_subtarget", "")
    if bone and target.type == "ARMATURE" and target.pose is not None:
        pose_bone = target.pose.bones.get(bone)
        if pose_bone is not None:
            position = matrix @ pose_bone.head
    view = (camera.matrix_world.to_3x3() @ Vector((0.0, 0.0, -1.0))).normalized()
    return max(abs(view.dot(position - camera.matrix_world.translation)), 1e-5)


def camera_dof(camera, fov):
    """The `dof` field for a view through `camera` (an object) with a horizontal field of view
    of `fov` degrees, or None: no camera, no depth of field, or not a perspective one."""
    data = camera.data if camera is not None and camera.type == "CAMERA" else None
    if data is None or data.type != "PERSP" or not data.dof.use_dof or not fov:
        return None
    dof = dof_message(data.dof.aperture_fstop, focus_distance(camera), data.lens, fov,
                      data.dof.aperture_blades)
    if dof is not None:
        try:
            from . import link_lighting
        except ImportError:  # loaded by path in the plain-CPython tests
            import link_lighting
        dof.update(link_lighting.describe_lens(data))  # Camera properties > Unreal Lens
        if "squeeze" not in dof:
            dof.update(aperture_ratio(data.dof.aperture_ratio, dof["fstop"]))
    return dof


# Unreal's widest anamorphic squeeze (`bu_link.dof_post` keeps it to 1..2).
MAX_SQUEEZE = 2.0


def aperture_ratio(ratio, fstop):
    """Blender's aperture Ratio as Unreal's anamorphic squeeze: {} for a round aperture, else
    {"squeeze", "fstop"}. Pure.

    Cycles narrows the aperture across by the ratio (2: half as wide, as tall), so bokeh is a
    tall oval and the blur across half as wide. Unreal's squeeze keeps the blur across and
    makes it taller by the squeeze (its sensor taller, `FPhysicalCocModel`): its f-stop times
    the ratio brings both back to Cycles'. Past Unreal's widest squeeze the blur across is
    still Cycles', up and down a little less; under 1 (wide ovals) Unreal has no squeeze for
    it, and the aperture stays round. sq020's camera had a ratio of 2: its foreground was
    blurred twice as wide as Cycles'."""
    try:
        ratio, fstop = float(ratio), float(fstop)
    except (TypeError, ValueError):
        return {}
    if not ratio > 1.0 + 1e-4 or fstop <= 0.0:
        return {}
    return {"squeeze": round(min(ratio, MAX_SQUEEZE), 4), "fstop": round(fstop * ratio, 4)}


def render_needs(samples=None, warmup=RENDER_SETTLE):
    """Pictures of the still's view, nothing changing, to wait for: the warm-up, or for the
    path tracer (`samples` per pixel, one a picture) one past its samples. At least one. Pure."""
    if samples:
        return int(samples) + 1
    return max(1, int(warmup))


def still_report(header):
    """What a picture says about itself for a still, from its frame message: {"settled"}, and
    from a current Unreal side "loading" (what it still had to load as it rendered it) and
    "applied" (the last of Blender's frames it held); None from one that says nothing. Pure."""
    report = {}
    for key in ("settled", "loading", "applied"):
        try:
            if header.get(key) is not None:
                report[key] = int(header[key])
        except (TypeError, ValueError):
            pass
    try:
        jitter = header.get("jitter")
        if jitter is not None:
            report["jitter"] = (float(jitter[0]), float(jitter[1]))
    except (TypeError, ValueError, IndexError):
        pass
    return report if "settled" in report else None


def reports_itself(report):
    """Whether a picture's report says what it was loading and which frame it holds. Pure."""
    return report is not None and "applied" in report and "loading" in report


def still_settled(report, counted, needed):
    """How many pictures the still has settled for: Unreal's count, which starts again whenever
    something changes or loads there, or `counted` (pictures Blender saw with nothing on its
    way) without one, or once that is twice what is needed: something Unreal counts as a
    change may keep happening. Pure."""
    if report is None or counted >= 2 * needed:
        return counted
    return int(report.get("settled", 0))


def still_done(report, reason, settled, needed, quiet):
    """Whether this picture is the still. `reason`: what is still on its way ("" for nothing);
    `quiet`: seconds that has been so. A picture that reports itself is checked as it is; an
    older Unreal's waits RENDER_IDLE_SECONDS more for its loading report. Pure."""
    if reason or settled < needed:
        return False
    return reports_itself(report) or quiet >= RENDER_IDLE_SECONDS


def still_timing(begun, phases, warmup, frames, done, what="Warm-up"):
    """Where a still's time went, for the panel: [(what, seconds)], what Blender waited on
    first, then the warm-up. `phases`: {what: seconds} of waiting, in the order met. Pure."""
    rows = [(kind, seconds) for kind, seconds in phases.items() if seconds >= 0.005]
    rows.append(("{0}: {1} frame{2}".format(what, frames, "" if frames == 1 else "s"), warmup))
    # No rate when the warm-up went by while Blender waited on something else (an edit sent).
    return {"total": done - begun, "rows": rows,
            "fps": frames / warmup if warmup >= 0.05 and frames > 1 else None}


def write_pass(render_pass, pixels):
    """Put (pixels, 4) float32 into a render result's pass. `foreach_set` copies the array in
    one go (2 ms at 1920 x 1080); assigning it to `rect` went through it a number at a time
    (3.4 s), and was most of what an F12 took."""
    flat = np.ascontiguousarray(pixels, dtype=np.float32).reshape(-1)
    try:
        render_pass.rect.foreach_set(flat)
    except (AttributeError, TypeError):  # a Blender without it: slow, but there
        render_pass.rect = flat.reshape(-1, 4).tolist()


def finish_timing(timing, now):
    """Add turning Unreal's picture into Blender's render result to a still's timing, once the
    result is written. Pure (it changes `timing`)."""
    if timing and "done" in timing and "started" in timing:
        timing["rows"].append(("Result", now - timing["done"]))
        timing["total"] = now - timing["started"]


def phase_of(reason):
    """A wait's kind, without its count ("Compiling shaders: 12 left" is "Compiling
    shaders"), so the time of each kind adds up. Pure."""
    return reason.split(":")[0].strip() or reason


def still_loading(stats):
    """What Unreal is still loading that waiting will finish, as `loading_lines` says it, or
    []. Not what waiting will not: textures held blurrier for memory, or failed ones. Pure."""
    if not stats:
        return []
    keys = ("textures_waiting", "graphs_waiting", "shaders_left", "textures_names")
    return loading_lines({key: stats[key] for key in keys if key in stats})


def render_pixels(rgba, width, height, crop=(0, 0), linear=True, scale=1.0, table=None):
    """A picture from Unreal as a render result's pixels. Pure.

    (pixels, 4) float32, bottom row first as Blender's are, the overscan left off, opaque.
    `linear`: scene-linear already, multiplied by `scale` (`exposure_scale`); otherwise Unreal's
    finished display colour, turned back through `table` (`link_color.build_lut`) into what
    Blender's view transform turns into that colour again, as the viewport does.
    """
    image = np.asarray(rgba, dtype=np.float32).reshape(int(height), int(width), 4)
    x, y = crop_of(crop, width, height)
    image = image[y:int(height) - y, x:int(width) - x]
    out = np.empty(image.shape, dtype=np.float32)
    if linear or table is None:
        out[..., :3] = image[..., :3] * np.float32(scale)
    else:
        size = int(round(len(table) ** (1.0 / 3.0)))
        out[..., :3] = link_color.sample(table, image[..., :3], size).reshape(
            image.shape[:2] + (3,))
    out[..., 3] = 1.0
    np.nan_to_num(out, copy=False, nan=0.0, posinf=link_color.MAX_SCENE_VALUE, neginf=0.0)
    return out.reshape(-1, 4)


def _begin_render(view, needed=RENDER_SETTLE, averaged=0):
    """Send the still's view; frames for it are kept (`_render_frame`) until `_end_render`,
    with their pixels once `needed` pictures have settled, or the mean of the last `averaged`
    of them (`average_sample`)."""
    global _render_view, _render_frame, _view_serial, _render_needed, _render_keep_all
    global _render_average
    _view_serial += 1
    message = dict(view, type="view", seq=_view_serial)
    _render_frame = None
    _render_needed = int(needed)
    _render_keep_all = False
    _render_average = ({"samples": int(averaged), "after": int(needed) - int(averaged),
                        "sum": None, "count": 0} if averaged and averaged > 1 else None)
    _render_view = message
    if _send is not None:
        _send(message)
    return message


def _end_render():
    """The viewports have the link again: each sends its own view on its next draw."""
    global _render_view, _render_frame, _render_epoch, redraw_wanted, _frame, _render_average
    seq = _render_view.get("seq") if _render_view is not None else None
    _render_view = None
    _render_frame = None
    _render_average = None
    _render_epoch += 1
    if seq is not None and _frame_seq == seq:
        _frame = None  # the camera's picture, not the viewport's: a moment of "waiting" instead
    redraw_wanted = True


def _want_final(engine, on_main):
    """Ask the link for the scene with the render's subdivision (`link.final_subdivision`) and
    wait until it has switched: the still then waits for what that sends (`busy`)."""
    global final_wanted
    final_wanted = time.perf_counter()
    began = final_wanted
    while not final_on and time.perf_counter() - began < FINAL_WAIT_SECONDS:
        if on_main:
            if pump is not None:
                pump()
        else:
            _render_wait(engine, "Subdividing for the render")
            time.sleep(0.02)
        final_wanted = time.perf_counter()


def _render_wait(engine, text, fraction=None):
    if engine.test_break():
        raise RenderStopped()
    engine.update_stats("", "Unreal: " + text)
    if fraction is not None:
        engine.update_progress(fraction)


def show_frame(engine, scene):
    """For an animation render, on its own thread: have the main thread move the live scene to
    the frame being rendered (`frame_wanted`) and wait until it has. What moved then goes to
    Unreal as in playback, and the still waits for Unreal to hold it (`busy`)."""
    global frame_wanted, animating, _frame_serial, holding_viewports
    _frame_serial += 1
    serial = _frame_serial
    frame = int(scene.frame_current)
    animating = time.perf_counter()
    holding_viewports = True
    frame_wanted = (serial, scene.name, frame, float(scene.frame_subframe))
    began = time.perf_counter()
    while frame_shown != serial:
        _render_wait(engine, "frame {0}".format(frame))
        if time.perf_counter() - began > FRAME_MOVE_SECONDS:
            raise RenderError("Blender did not move the live scene to frame {0}".format(frame))
        time.sleep(0.005)
        animating = time.perf_counter()


def wait_for_still(engine, view, needed, started, on_main, what="Warm-up", averaged=0):
    """Send the still's view and wait for the picture that is the still: (serial, width,
    height, rgba, linear, crop, report), or RenderError / RenderStopped. Its timing goes to
    `last_still`. `started`: when the render began (Unreal's start counts); `on_main`: the
    render holds Blender's main thread, which then does the link's work here (`pump`).
    `averaged`: the last of the `needed` pictures are anti-aliasing samples, averaged."""
    global last_still, _render_keep_all
    # Where the time goes, for the panel (`last_still`): starting Unreal, each kind of wait
    # (`phase_of`), and the warm-up, from when nothing was left to wait for.
    phases = {}
    begun = time.perf_counter()
    if begun - started >= 0.005:
        phases["Starting Unreal"] = begun - started
    _begin_render(view, needed, averaged)
    try:
        idle_since = None
        heard = last = begun
        seen = None
        counted = 0
        while True:
            if on_main and pump is not None:
                pump()
            if _send is None:
                raise RenderError("The link to Unreal closed: " + (status() if status else ""))
            now = time.perf_counter()
            frame = _render_frame
            report = frame[6] if frame is not None else None
            # Unreal's report with each picture: Blender's own frames it holds, what it is still
            # loading. Without one, the stats say what loads (`render_busy`).
            reason = busy(report, begun) if busy is not None else ""
            if frame is not None and frame[0] != seen:
                seen, heard = frame[0], now
                counted = 0 if reason else counted + 1
            if reason:
                idle_since = None
                kind = phase_of(reason)
                phases[kind] = phases.get(kind, 0.0) + (now - last)
            elif idle_since is None:
                idle_since = now
            last = now
            settled = still_settled(report, counted, needed)
            quiet = now - idle_since if idle_since is not None else 0.0
            if frame is not None and still_done(report, reason, settled, needed, quiet):
                if frame[3] is not None:
                    break
                _render_keep_all = True  # counted here: the next picture comes with its pixels
            if (now - heard > RENDER_STALL_SECONDS and not reason
                    and (now - heard > RENDER_SLOW_SECONDS
                         or working is None or not working())):
                raise RenderError(
                    "Unreal sent no picture for {0:.0f} seconds: it may be out of graphics "
                    "memory, or the graphics card busy with something else".format(
                        RENDER_STALL_SECONDS))
            if reason:
                _render_wait(engine, reason, 0.0)
            elif frame is None:
                _render_wait(engine, "rendering", 0.0)
            elif averaged > 1 and settled > needed - averaged:
                count = (_render_average or {}).get("count", 0)
                _render_wait(engine, "anti-aliasing, sample {0} of {1}".format(
                    count, averaged), min(0.99, settled / float(needed)))
            else:
                _render_wait(engine, "settling, picture {0} of {1}".format(
                    min(settled, needed), needed), min(0.99, settled / float(needed)))
            time.sleep(0.01 if on_main else 0.02)
    finally:
        _end_render()

    done = time.perf_counter()
    last_still = dict(still_timing(started, phases, done - idle_since, settled, done, what),
                      size=(int(view.get("width", 0)), int(view.get("height", 0))),
                      done=done, started=started)
    return frame


def camera_warnings(data):
    """What a still (F12) of this camera (its data, or None) leaves out, to tell the user. Pure.

    Nothing now: a panoramic camera (Cycles' fisheyes, equirectangular...) is rendered as Cycles
    renders it (`pano_lens`). Before, it was a perspective one at its focal length, as EEVEE
    renders it.
    """
    return []


# Blender's panorama types, as `bu_link_pano` numbers them.
PANO_TYPES = ("EQUIRECTANGULAR", "EQUIANGULAR_CUBEMAP_FACE", "MIRRORBALL", "FISHEYE_EQUIDISTANT",
              "FISHEYE_EQUISOLID", "FISHEYE_LENS_POLYNOMIAL", "CENTRAL_CYLINDRICAL")


def pano_sensor(data, render_size, pixel_aspect=(1.0, 1.0)):
    """(width, height) in mm of a fisheye's sensor, as Cycles fits it to the render's shape
    (`blender_camera_sync`: Equisolid and Lens Polynomial read it). Pure."""
    x = float(render_size[0]) * float(pixel_aspect[0])
    y = float(render_size[1]) * float(pixel_aspect[1])
    fit = getattr(data, "sensor_fit", "AUTO")
    if fit == "VERTICAL":
        horizontal, size = False, float(data.sensor_height)
    else:
        horizontal, size = (x > y) if fit == "AUTO" else True, float(data.sensor_width)
    if x <= 0.0 or y <= 0.0:
        return size, size
    return (size, size * y / x) if horizontal else (size * x / y, size)


def pano_raster(window_matrix, camera_projection, shift=(0.0, 0.0)):
    """(sx, ox, sy, oy): where a picture's point (s, t), 0-1 from its left and its bottom, falls
    in Cycles' panorama coordinates, u = sx s + ox and v = sy t + oy. Pure.

    Cycles maps the camera's frame to 0-1, moved by the lens shift (`blender_camera_viewplane`).
    A still is the frame itself (`window_matrix` is the camera's own projection); the viewport
    through the camera shows the frame where Blender draws its border, panned and zoomed: both
    are perspective projections of the camera's view, so the one maps to the other by a scale
    and an offset.
    """
    view = np.array(window_matrix, dtype=np.float64).reshape(4, 4)
    camera = np.array(camera_projection, dtype=np.float64).reshape(4, 4)
    found = []
    for axis in (0, 1):
        def frame(s):
            # The view's point at s, as a ray x/-z; then where the camera's frame has it, 0-1.
            ray = ((2.0 * s - 1.0) + view[axis, 2]) / (view[axis, axis] or 1.0)
            return (camera[axis, axis] * ray - camera[axis, 2] + 1.0) / 2.0 + float(shift[axis])
        low, high = frame(0.0), frame(1.0)
        found += [high - low, low]
    return tuple(round(v, 7) for v in found)


def pano_lens(data, render_size, pixel_aspect=(1.0, 1.0), window_matrix=None,
              camera_projection=None):
    """A view's `pano` field: a panoramic camera's lens as Cycles renders it
    (`kernel/camera/projection.h`), for Unreal to warp a cube of pictures into
    (`bu_link_pano`). None for any other camera. Pure (`data` is a camera's data).

    {"type": one of PANO_TYPES, and what that type reads: "fov" (radians), "lens" (mm),
    "sensor" [w, h] mm, "k" [k0..k4], "range" (Cycles' own four numbers), and "raster"
    (`pano_raster`)}.
    """
    if data is None or getattr(data, "type", "") != "PANO":
        return None
    kind = getattr(data, "panorama_type", "FISHEYE_EQUISOLID")
    if kind not in PANO_TYPES:
        kind = "FISHEYE_EQUISOLID"
    lens = {"type": kind}
    if kind == "EQUIRECTANGULAR":
        lon = float(data.longitude_min), float(data.longitude_max)
        lat = float(data.latitude_min), float(data.latitude_max)
        lens["range"] = [lon[0] - lon[1], -lon[0], lat[0] - lat[1], -lat[0] + math.pi / 2.0]
    elif kind == "CENTRAL_CYLINDRICAL":
        radius = float(data.central_cylindrical_radius) or 1.0
        lens["range"] = [-float(data.central_cylindrical_range_u_min),
                         -float(data.central_cylindrical_range_u_max),
                         float(data.central_cylindrical_range_v_min) / radius,
                         float(data.central_cylindrical_range_v_max) / radius]
    elif kind.startswith("FISHEYE"):
        lens["fov"] = float(data.fisheye_fov)
        if kind != "FISHEYE_EQUIDISTANT":
            lens["sensor"] = list(pano_sensor(data, render_size, pixel_aspect))
        if kind == "FISHEYE_EQUISOLID":
            lens["lens"] = float(data.fisheye_lens)
        if kind == "FISHEYE_LENS_POLYNOMIAL":
            lens["k"] = [float(getattr(data, "fisheye_polynomial_k{0}".format(i)))
                         for i in range(5)]
    shift = (float(getattr(data, "shift_x", 0.0)), float(getattr(data, "shift_y", 0.0)))
    if window_matrix is None or camera_projection is None:
        lens["raster"] = [1.0, shift[0], 1.0, shift[1]]
    else:
        lens["raster"] = list(pano_raster(window_matrix, camera_projection, shift))
    for key in ("fov", "lens"):
        if key in lens:
            lens[key] = round(lens[key], 7)
    for key in ("sensor", "k", "range"):
        if key in lens:
            lens[key] = [round(v, 7) for v in lens[key]]
    return lens


# The node that is the compositor's result: a Group Output from Blender 5.0, Composite before.
COMPOSITE_OUTPUTS = ("NodeGroupOutput", "CompositorNodeComposite")
# What F12 gives the compositor: the picture (Combined) and its alpha.
STILL_PASSES = ("Image", "Alpha")


def compositor_tree(scene):
    """The compositor node tree that runs on F12's result, or None (Compositing off, or none)."""
    render = getattr(scene, "render", None)
    if render is None or not getattr(render, "use_compositing", False):
        return None
    if hasattr(scene, "compositing_node_group"):
        return scene.compositing_node_group
    return scene.node_tree if getattr(scene, "use_nodes", False) else None


def compositor_reads(scene):
    """Which of the render's passes the compositor builds F12's result from: (the picture itself
    or not, [the other passes, by name]), or None when no compositor runs on it.

    Traced back from the compositor's output through node groups. A link from a pass the engine
    does not make stays in the tree, unavailable, and the node reads its input's default
    instead: the tester's Sister Location map denoised Cycles' light passes one by one into a
    group whose inputs default to white, and summed them, never reading the picture, so every
    F12 came out white while the viewport was right.
    """
    tree = compositor_tree(scene)
    if tree is None:
        return None
    found = set()
    links = {}
    seen = set()

    def into(group, socket):
        index = links.get(group.as_pointer())
        if index is None:
            index = {}
            for link in group.links:
                if not getattr(link, "is_muted", False):
                    index.setdefault(link.to_socket.as_pointer(), []).append(link)
            links[group.as_pointer()] = index
        return index.get(socket.as_pointer(), ())

    def trace(group, socket, stack):
        key = (socket.as_pointer(), tuple(node.as_pointer() for _tree, node in stack))
        if key in seen or len(seen) > 100000:
            return
        seen.add(key)
        for link in into(group, socket):
            node, source = link.from_node, link.from_socket
            if node.bl_idname == "CompositorNodeRLayers":
                found.add(source.name)
            elif node.bl_idname == "NodeGroupInput":
                if stack:  # back out to the group node's matching input
                    outer, group_node = stack[-1]
                    for outer_socket in group_node.inputs:
                        if outer_socket.identifier == source.identifier:
                            trace(outer, outer_socket, stack[:-1])
            elif getattr(node, "node_tree", None) is not None:  # into the group's output
                inner = node.node_tree
                for output in inner.nodes:
                    if (output.bl_idname == "NodeGroupOutput"
                            and getattr(output, "is_active_output", True)):
                        for inner_socket in output.inputs:
                            if inner_socket.identifier == source.identifier:
                                trace(inner, inner_socket, stack + ((group, node),))
            else:
                for upstream in node.inputs:
                    trace(group, upstream, stack)

    for node in tree.nodes:
        if (node.bl_idname in COMPOSITE_OUTPUTS and not getattr(node, "mute", False)
                and getattr(node, "is_active_output", True)):
            for socket in node.inputs:
                trace(tree, socket, ())
    return "Image" in found, sorted(found - set(STILL_PASSES))


def pass_names(passes, shown=3):
    """'Diffuse Direct, Emission and 9 more'. Pure."""
    passes = list(passes)
    if len(passes) <= 1:
        return "".join(passes)
    if len(passes) <= shown + 1:
        return ", ".join(passes[:-1]) + " and " + passes[-1]
    return "{0} and {1} more".format(", ".join(passes[:shown]), len(passes) - shown)


def compositor_problem(reads):
    """(error, warning) for F12 from `compositor_reads`: an error when the compositor builds the
    result from passes Unreal does not make and not from its picture (it could only come out
    wrong, white on the tester's map), a warning when it reads such passes besides. Pure."""
    if not reads or not reads[1]:
        return None, None
    combined, passes = reads
    names = pass_names(passes)
    if not combined:
        return ("The compositor builds this scene's picture from Cycles passes Unreal does not "
                "make ({0}), not from the render: turn off Compositing (Output Properties > "
                "Post Processing) to see Unreal's".format(names)), None
    return None, ("The compositor also reads passes Unreal does not make ({0}): they read as "
                  "the nodes' own values".format(names))


def render_still(engine, depsgraph):
    """Unreal's picture of the scene camera, for the render engine's `render`: (pixels, width,
    height), or RenderError / RenderStopped.

    F12 runs this on a render thread while Blender's main thread keeps the link going (its
    timers take the pictures); a script's render runs it on the main thread, which then does
    the link's work itself between looks (`pump`).
    """
    import threading

    import bpy

    scene = depsgraph.scene
    if bpy.app.background:
        raise RenderError("Rendering through Unreal needs Blender's window: its live link "
                          "runs there")
    camera = scene.camera
    if camera is None:
        raise RenderError("The scene has no camera")
    data = camera.data if camera.type == "CAMERA" else None
    width, height = render_size(scene.render)
    from . import link_shm

    if not render_fits(width, height, link_shm.MAX_FRAME_SLOT_BYTES):
        raise RenderError(
            "{0} x {1} is more than Unreal can send back (up to {2:.0f} megapixels): lower the "
            "resolution or its %".format(width, height, link_shm.MAX_FRAME_SLOT_BYTES / 16e6))
    error, warning = compositor_problem(compositor_reads(scene))
    if error:
        raise RenderError(error)
    for warning in camera_warnings(data) + ([warning] if warning else []):
        engine.report({"WARNING"}, warning)
    projection = camera.calc_matrix_camera(
        depsgraph, x=width, y=height,
        scale_x=scene.render.pixel_aspect_x, scale_y=scene.render.pixel_aspect_y)
    managers = bpy.data.window_managers
    colour = getattr(managers[0], "bu_link_colour", COLOUR_BLENDER) if managers else COLOUR_BLENDER
    settings = getattr(scene, "bu_render", None)
    samples = (int(settings.pt_samples)
               if settings is not None and getattr(settings, "renderer", "") == "PATH_TRACER"
               else None)
    view = render_view_message(camera.matrix_world.inverted(), projection, width, height,
                               data is None or data.type != "ORTHO", colour, upscaling(scene),
                               getattr(settings, "still_cinematic", True),
                               1 if samples else getattr(settings, "still_aa_samples", 1),
                               filter_size(scene),
                               (getattr(settings, "still_volume_steps", 128),
                                getattr(settings, "still_volume_resolution", "4")))
    dof = camera_dof(camera, view.get("fov"))
    if dof is not None:
        view["dof"] = dof
    pano = pano_lens(data, (width, height),
                     (scene.render.pixel_aspect_x, scene.render.pixel_aspect_y))
    if pano is not None:
        view["pano"] = pano
    averaged = int(view.get("aa_samples") or 0)
    needed = render_needs(samples, getattr(settings, "still_warmup", RENDER_SETTLE)) + averaged
    on_main = threading.current_thread() is threading.main_thread()
    if engine.is_animation:
        if on_main:
            raise RenderError("Render the animation from Blender's window (Ctrl+F12): a "
                              "script's animation render holds the thread the link runs on")
        # Blender has worked out this frame for the render; the live scene Unreal shows is
        # moved to it too, and each frame is then a still.
        show_frame(engine, scene)

    global start_wanted, start_refused
    started = time.perf_counter()
    if _send is None:
        if on_main:
            raise RenderError("Start Unreal first (a Rendered viewport, or Render > Unreal > "
                              "Start): a script's render cannot wait for it to start")
        start_refused = ""
        start_wanted = True
    while _send is None:
        if start_refused:
            raise RenderError(start_refused)
        if time.perf_counter() - started > RENDER_START_SECONDS:
            raise RenderError("Unreal did not start: " + (status() if status else ""))
        _render_wait(engine, status() if status is not None else "starting")
        time.sleep(0.1)

    if getattr(settings, "still_as_rendered", True):
        _want_final(engine, on_main)
    if frame_room is not None:
        # Bigger picture slots than the viewport's, for a still that needs them (4K and up).
        refused = frame_room(width, height)
        if refused:
            raise RenderError(refused)
    frame = wait_for_still(engine, view, needed, started, on_main,
                           "Path tracing" if samples else "Warm-up", averaged)
    _serial, frame_width, frame_height, rgba, linear, crop, _report = frame
    x, y = crop_of(crop, frame_width, frame_height)
    if (frame_width - 2 * x, frame_height - 2 * y) != (width, height):
        raise RenderError("Unreal sent a {0} x {1} picture for a {2} x {3} render".format(
            frame_width - 2 * x, frame_height - 2 * y, width, height))
    table = None
    if not linear:
        table, _exact = link_color.build_lut(*link_color.settings_key(scene))
    pixels = render_pixels(rgba, frame_width, frame_height, crop, linear,
                           exposure_scale(scene), table)
    return pixels, width, height


def _register_engine():
    import bpy
    import gpu
    from gpu_extras.batch import batch_for_shader

    class BU_UnrealViewEngine(bpy.types.RenderEngine):
        bl_idname = ENGINE_ID
        bl_label = "Unreal"
        bl_use_preview = False
        # Blender's own shader nodes, so the Shader Editor and the material panels work as
        # they do for EEVEE; BU translates them for Unreal.
        bl_use_shading_nodes_custom = False
        # Material Preview stays EEVEE's quick look; Rendered is Unreal.
        bl_use_eevee_viewport = True

        _texture = None
        _depth = None     # the newest frame's 1/depth, rows x columns
        _depth_texture = None   # and as a texture, made once per frame
        _strip = None           # one row of Follow Depth's mesh (`_follow_depth`)
        _strip_width = 0        # and how many depth texels it spans
        _mesh_target = None     # the mesh pass's offscreen, the viewport's size
        _fill_targets = None    # and the fill pyramid's (`fill_levels`)
        _push_targets = None    # and its way back down (`fill_push`)
        _mesh_params = None     # the mesh pass's uniform buffer, reused
        _params = None    # the plain draw's uniform buffer, reused
        _texture_serial = -1
        _signature = None
        _lut = None
        _lut_key = None
        _announced = False

        def render(self, depsgraph):
            # F12: Unreal renders the scene camera (`render_still`), and its picture is this
            # render's result, which Blender's colour management and compositor then finish.
            global redraw_wanted
            try:
                pixels, width, height = render_still(self, depsgraph)
            except RenderStopped:
                return
            except RenderError as error:
                self.report({"ERROR"}, str(error))
                return
            result = self.begin_result(0, 0, width, height)
            write_pass(result.layers[0].passes["Combined"], pixels)
            self.end_result(result)
            finish_timing(last_still, time.perf_counter())
            redraw_wanted = True  # the F12 Render panel shows where the time went

        def view_update(self, context, depsgraph):
            # Called first when a viewport switches to Rendered: the moment to start Unreal.
            if not self._announced:
                self._announced = True
                if on_rendered is not None:
                    on_rendered()

        def _follow_depth(self, gpu, batch_for_shader, width, height, values):
            """Follow Depth's passes, into offscreens the viewport's size: the depth picture
            drawn as a mesh from the current view (`mesh_point`), then the fill pyramid of what
            that left open, up (`fill_levels`) and back down (`fill_push`). Returns the mesh
            pass's texture and the fill's."""
            depth_height, depth_width = self._depth.shape
            if self._strip is None or self._strip_width != depth_width:
                # One row of the mesh as a strip, a vertex above and below each depth texel;
                # drawn once per row of the depth picture, the row from the instance.
                corners = np.stack((np.repeat(np.arange(depth_width, dtype=np.float32), 2),
                                    np.tile(np.array((0.0, 1.0), dtype=np.float32), depth_width)),
                                   axis=1)
                layout = gpu.types.GPUVertFormat()
                layout.attr_add(id="corner", comp_type="F32", len=2, fetch_mode="FLOAT")
                strip = gpu.types.GPUVertBuf(layout, len(corners))
                strip.attr_fill("corner", corners)
                self._strip = gpu.types.GPUBatch(type="TRI_STRIP", buf=strip)
                self._strip_width = depth_width
            target = self._mesh_target
            if target is None or (target.width, target.height) != (width, height):
                self._mesh_target = gpu.types.GPUOffScreen(width, height, format="RGBA32F")
                sizes = []
                w, h = width, height
                for _ in range(FILL_LEVELS):
                    w, h = (w + 1) // 2, (h + 1) // 2
                    sizes.append((w, h))
                self._fill_targets = [gpu.types.GPUOffScreen(w, h, format="RGBA32F")
                                      for w, h in sizes]
                self._push_targets = [gpu.types.GPUOffScreen(w, h, format="RGBA32F")
                                      for w, h in sizes[:-1]]
            if self._mesh_params is None:
                self._mesh_params = gpu.types.GPUUniformBuf(values)
            else:
                self._mesh_params.update(values)
            viewport = gpu.state.viewport_get()
            depth_test = gpu.state.depth_test_get()
            depth_mask = gpu.state.depth_mask_get() if hasattr(gpu.state, "depth_mask_get") else False
            gpu.state.blend_set("NONE")
            shader = _mesh_shader(gpu)
            with self._mesh_target.bind():
                gpu.state.depth_mask_set(True)
                gpu.state.active_framebuffer_get().clear(color=(0.0, 0.0, 0.0, -1.0), depth=1.0)
                gpu.state.depth_test_set("LESS_EQUAL")
                shader.bind()
                shader.uniform_block("params", self._mesh_params)
                shader.uniform_sampler("image", self._texture)
                shader.uniform_sampler("depth", self._depth_texture)
                self._strip.draw_instanced(shader, instance_start=0,
                                           instance_count=max(depth_height - 1, 0))
                gpu.state.depth_test_set("NONE")
                gpu.state.depth_mask_set(depth_mask)
            fill = _fill_shader(gpu)
            quad = batch_for_shader(fill, "TRI_FAN", {
                "pos": ((-1.0, -1.0), (1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))})
            source = self._mesh_target.texture_color
            for level in self._fill_targets:
                with level.bind():
                    fill.bind()
                    fill.uniform_sampler("source", source)
                    quad.draw(fill)
                source = level.texture_color
            push = _push_shader(gpu)
            for index in range(len(self._push_targets) - 1, -1, -1):
                with self._push_targets[index].bind():
                    push.bind()
                    push.uniform_sampler("level", self._fill_targets[index].texture_color)
                    push.uniform_sampler("above", source)
                    quad.draw(push)
                source = self._push_targets[index].texture_color
            gpu.state.depth_test_set(depth_test)
            gpu.state.viewport_set(*viewport)
            return self._mesh_target.texture_color, source

        def view_draw(self, context, depsgraph):
            global _view_serial, _last_view, upload_ms
            region = context.region
            rv3d = context.region_data
            if region is None or rv3d is None:
                return

            if _render_view is not None or holding_viewports:
                # Unreal is rendering the camera for F12; the viewport's own view waits. In an
                # animation render, between frames too: the live view sent there would take
                # Unreal out of the still's settings and back, and its history with them.
                _draw_status(context, "", ["Unreal is rendering the camera (F12)…"])
                return
            bend, by_depth = bend_plan(
                getattr(context.window_manager, "bu_link_view_bend", BEND_OFF))
            if _send is not None:
                quality = getattr(context.window_manager, "bu_link_view_quality", "FULL")
                width, height = fit_size(
                    region.width, region.height, MAX_EDGE.get(quality, MAX_EDGE["FULL"]))
                params = view_params(
                    rv3d.view_matrix, rv3d.window_matrix, width, height, rv3d.is_perspective)
                if getattr(context.window_manager, "bu_link_colour",
                           COLOUR_BLENDER) == COLOUR_BLENDER:
                    params["colour"] = "linear"
                params["overscan"] = overscan(depsgraph.scene)
                # Unreal renders its depth picture only for Follow Depth.
                params["depth"] = by_depth
                scaled = upscaling(depsgraph.scene)
                params.update(scaled)
                # Through the camera, its depth of field, as EEVEE's and Cycles' viewports show.
                if rv3d.view_perspective == "CAMERA" and "fov" in params:
                    dof = camera_dof(getattr(context.space_data, "camera", None)
                                     or depsgraph.scene.camera, params["fov"])
                    if dof is not None:
                        params["dof"] = dof
                pano = viewport_pano(context, depsgraph) if rv3d.view_perspective == "CAMERA" \
                    else None
                if pano is not None:
                    # Through a panoramic camera, as Cycles' viewport shows it: the camera's
                    # fisheye (or other panorama) where its border is. No overscan, no depth and
                    # no bending: the picture is not a perspective one.
                    params["pano"] = pano
                    params["overscan"] = 0.0
                    params["depth"] = by_depth = False
                    bend = False
                current = signature(params) + (
                    params.get("colour"), params["overscan"], params["depth"],
                    tuple(sorted(scaled.items())), _render_epoch,
                    tuple(sorted(params["dof"].items())) if "dof" in params else None,
                    repr(pano))
                if current != self._signature:
                    self._signature = current
                    _view_serial += 1
                    params["type"] = "view"
                    params["seq"] = _view_serial
                    params["drive_editor"] = bool(
                        getattr(context.window_manager, "bu_link_drive_editor", True))
                    _last_view = params
                    remember_view(_view_serial, rv3d.view_matrix, rv3d.window_matrix)
                    _send(params)

            frame = _frame
            if frame is None or _send is None:
                _draw_status(context, status() if status is not None else "")
                return
            serial, width, height, rgba, linear, crop, depth = frame
            if serial != self._texture_serial or self._texture is None:
                started = time.perf_counter()
                buffer = gpu.types.Buffer("FLOAT", len(rgba), rgba)
                # 32F, not 16F: the data is float32 and uploads as it is. A half-float
                # texture makes the driver convert every pixel first, several times the cost.
                self._texture = gpu.types.GPUTexture((width, height), format="RGBA32F", data=buffer)
                self._depth = self._depth_texture = None
                if depth is not None:
                    self._depth = np.asarray(depth[2], dtype=np.float32).reshape(depth[1], depth[0])
                self._texture_serial = serial
                upload_ms = (time.perf_counter() - started) * 1000.0

            if not linear:
                # Unreal's finished display colour; Blender is about to view-transform whatever
                # is drawn here. The lookup table holds the inverse, so the two cancel. (A linear
                # frame is already scene-linear: Blender's view transform finishes it, as it
                # would a Cycles or EEVEE render.)
                key = link_color.settings_key(depsgraph.scene)
                if key != self._lut_key or self._lut is None:
                    table, _exact = link_color.build_lut(*key)
                    size = link_color.LUT_SIZE
                    self._lut = gpu.types.GPUTexture(
                        (size, size, size), format="RGBA16F",
                        data=gpu.types.Buffer("FLOAT", table.size, table.reshape(-1)))
                    self._lut_key = key
            extra = exposure_scale(depsgraph.scene) if linear else float(link_color.LUT_SIZE)
            quad = {"pos": ((-1.0, -1.0), (1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))}
            # The overscan Unreal rendered round the view is left off here; a picture the view
            # has moved on from is drawn where this view would see it.
            (u0, v0), _b, (u1, v1), _d = crop_coords(width, height, crop)
            new = (np.array(rv3d.window_matrix, dtype=np.float64)
                   @ np.array(rv3d.view_matrix, dtype=np.float64))
            old = _sent_views.get(_frame_seq) if _frame_seq is not None else None
            lens_now = depth_lens(rv3d.window_matrix)
            if (by_depth and old is not None and self._depth is not None
                    and min(self._depth.shape) > 1 and _frame_seq in _sent_lenses
                    and _sent_lenses[_frame_seq][2] != 0.0 and lens_now[2] != 0.0
                    and not np.allclose(old, new, rtol=0.0, atol=1e-9)):
                # Each pixel moved by its own distance: the depth picture drawn as a mesh from
                # this view, and what that leaves open filled. Perspective only, both views: an
                # orthographic view's pans and zooms are exact by the plane already. A view that
                # has not moved draws its picture as it is, below.
                if self._depth_texture is None:
                    found = self._depth
                    self._depth_texture = gpu.types.GPUTexture(
                        (found.shape[1], found.shape[0]), format="R32F",
                        data=gpu.types.Buffer("FLOAT", found.size, found.reshape(-1)))
                depth_height, depth_width = self._depth.shape
                rest = min(depth_width * (u1 - u0) / max(region.width, 1),
                           depth_height * (v1 - v0) / max(region.height, 1))
                values = mesh_params(old, new, (u0, v0, u1, v1), _sent_lenses[_frame_seq],
                                     clip_start(lens_now), rest)
                picture, filled = self._follow_depth(
                    gpu, batch_for_shader, region.width, region.height, values)
                shader = _composite_shader(gpu, linear)
                gpu.state.blend_set("NONE")
                shader.bind()
                shader.uniform_float("extra", extra)
                shader.uniform_sampler("picture", picture)
                shader.uniform_sampler("fill", filled)
            else:
                forward = -np.array(rv3d.view_matrix.inverted().col[2][:3], dtype=np.float64)
                h = frame_warp(_frame_seq, new, tuple(rv3d.view_location), forward) if bend else None
                values = draw_params(np.eye(3) if h is None else h, (u0, v0, u1, v1), extra)
                if self._params is None:
                    self._params = gpu.types.GPUUniformBuf(values)
                else:
                    self._params.update(values)
                shader = _shader(gpu, linear)
                gpu.state.blend_set("NONE")
                shader.bind()
                shader.uniform_block("params", self._params)
                shader.uniform_sampler("image", self._texture)
            if not linear:
                shader.uniform_sampler("lut", self._lut)
            batch_for_shader(shader, "TRI_FAN", quad).draw(shader)
            lines = loading() if loading is not None else []
            if lines:
                _draw_loading(context, lines)

    return BU_UnrealViewEngine


def viewport_pano(context, depsgraph):
    """The `pano` field for a viewport looking through a panoramic camera (`pano_lens`), or
    None."""
    camera = getattr(context.space_data, "camera", None) or depsgraph.scene.camera
    data = camera.data if camera is not None and camera.type == "CAMERA" else None
    if data is None or data.type != "PANO":
        return None
    render = depsgraph.scene.render
    size = render_size(render)
    aspect = (render.pixel_aspect_x, render.pixel_aspect_y)
    projection = camera.calc_matrix_camera(depsgraph, x=size[0], y=size[1],
                                           scale_x=aspect[0], scale_y=aspect[1])
    return pano_lens(data, size, aspect, context.region_data.window_matrix, projection)


def _draw_status(context, text, lines=None):
    """While there is no picture: a dark viewport that says why (starting, stopped, failed), or
    `lines` given."""
    import blf
    import gpu

    region = context.region
    gpu.state.active_framebuffer_get().clear(color=(0.02, 0.02, 0.02, 1.0))
    lines = lines or status_lines(text)
    size = 14.0 * context.preferences.system.ui_scale
    font = 0
    blf.size(font, size)
    blf.color(font, 0.8, 0.8, 0.8, 1.0)
    top = region.height / 2.0 + len(lines) * size * 0.75
    for index, line in enumerate(lines):
        width = blf.dimensions(font, line)[0]
        blf.position(font, (region.width - width) / 2.0, top - index * size * 1.5, 0.0)
        blf.draw(font, line)


def loading_lines(stats):
    """The viewport's small "still loading" note from Unreal's stats, or []. Pure.

    What is still on its way to the picture: textures not imported yet (materials show their
    plain colour), node materials not built yet, shaders compiling (grey until done); and
    texture streaming short of memory, which holds textures at blurrier levels to fit.
    """
    if not stats:
        return []
    lines = []
    for key, text in (("textures_waiting", "Loading textures: {0} left"),
                      ("graphs_waiting", "Building materials: {0} left"),
                      ("shaders_left", "Compiling shaders: {0} left"),
                      ("streaming_short_mb",
                       "Textures blurred to fit memory: {0} MB short")):
        try:
            count = int(stats.get(key) or 0)
        except (TypeError, ValueError):
            count = 0
        if count > 0:
            line = text.format(count)
            names = stats.get("textures_names") if key == "textures_waiting" else None
            if names:
                line += ": " + str(names[0])  # the one loading now
            lines.append(line)
    try:
        failed = int(stats.get("textures_failed_count") or 0)
    except (TypeError, ValueError):
        failed = 0
    if failed:
        lines.append("Textures not shown: {0} (names in Render > Unreal > Statistics)".format(
            failed))
    return lines


def _draw_loading(context, lines):
    """The loading note, small, in the viewport's bottom-left corner, over the picture."""
    import blf
    import gpu

    scale = context.preferences.system.ui_scale
    size = 11.0 * scale
    font = 0
    gpu.state.blend_set("ALPHA")
    blf.size(font, size)
    blf.color(font, 1.0, 1.0, 1.0, 0.9)
    blf.enable(font, blf.SHADOW)
    blf.shadow(font, 3, 0.0, 0.0, 0.0, 0.8)
    blf.shadow_offset(font, 1, -1)
    for index, line in enumerate(reversed(lines)):
        blf.position(font, 12.0 * scale, 12.0 * scale + index * size * 1.4, 0.0)
        blf.draw(font, line)
    blf.disable(font, blf.SHADOW)
    gpu.state.blend_set("NONE")


def status_lines(text):
    """What the viewport says while Unreal has sent no picture. Pure."""
    text = str(text or "").strip()
    if not text or text.lower().startswith("connected"):
        return ["Waiting for Unreal's first picture\u2026"]
    return [text, "Render properties \u25b8 Unreal"]


_shader_cache = {}


def _finish(linear):
    """GLSL `main` for a draw whose `picture_colour()` is the frame's colour here: as it is
    (linear; `extra` the exposure scale), or through the inverse-view-transform table (`extra`
    the table's size)."""
    if linear:
        # Not clamped: a lamp or the sun's disc is far above 1, and the view transform is what
        # rolls it off.
        return ("void main() {"
                "  fragColor = vec4(max(picture_colour(), vec3(0.0)) * EXTRA, 1.0);"
                "}")
    # Sample at texel centres: the table's first and last entries are colours 0 and 1.
    return ("void main() {"
            "  vec3 display = clamp(picture_colour(), 0.0, 1.0);"
            "  float size = EXTRA;"
            "  vec3 at = (display * (size - 1.0) + 0.5) / size;"
            "  fragColor = vec4(texture(lut, at).rgb, 1.0);"
            "}")


def _quad_info(gpu, name):
    """A full-viewport quad's shader info, with `ndc` handed to the fragment shader."""
    info = gpu.types.GPUShaderCreateInfo()
    info.vertex_in(0, "VEC2", "pos")
    interface = gpu.types.GPUStageInterfaceInfo(name)
    interface.smooth("VEC2", "ndc")
    info.vertex_out(interface)
    info.fragment_out(0, "VEC4", "fragColor")
    info.vertex_source("void main() { ndc = pos; gl_Position = vec4(pos, 0.0, 1.0); }")
    return info


def _shader(gpu, linear=False):
    """The plain draw: the frame as it is, or moved as one plane (`warp_matrix`).

    The quad covers the viewport in device coordinates; `warp` takes each point to where the
    picture's own view saw it if the scene were one plane, and `crop` is the picture inside the
    overscan. Clamped: a view moved past the picture's edge repeats that edge until the next
    one. misc.x is the exposure scale or the lookup table's size. Built once per session.
    """
    key = ("plain", linear)
    if key in _shader_cache:
        return _shader_cache[key]
    info = _quad_info(gpu, "bu_link_view_interface")
    # In a uniform buffer (`draw_params`), not push constants: Vulkan guarantees 128 bytes.
    info.typedef_source("struct BUDrawParams { mat4 warp; vec4 crop; vec4 misc; };")
    info.uniform_buf(0, "BUDrawParams", "params")
    info.sampler(0, "FLOAT_2D", "image")
    if not linear:
        info.sampler(1, "FLOAT_3D", "lut")
    # Per pixel, not per corner: the map is projective, and interpolating it would bend lines.
    info.fragment_source(
        "vec3 picture_colour() {"
        "  vec4 seen = params.warp * vec4(ndc, 0.0, 1.0);"
        "  vec2 at = seen.xy / seen.w;"
        "  return texture(image, clamp(mix(params.crop.xy, params.crop.zw, at * 0.5 + 0.5),"
        "                              0.0, 1.0)).rgb;"
        "}" + _finish(linear).replace("EXTRA", "params.misc.x"))
    _shader_cache[key] = gpu.shader.create_from_info(info)
    return _shader_cache[key]


def _mesh_shader(gpu):
    """Follow Depth's mesh pass (`mesh_point` is its numpy twin): one row of the depth picture
    per instance, each vertex moved from the picture's view to this one by its own depth, each
    fragment the picture's colour and this view's 1/depth (alpha). A 2x2 across an outline
    (`mesh_outline`) stretched past OPEN_STRETCH times its size at rest (`mesh_stretched`) is
    left open: alpha stays the -1 it was cleared to."""
    if "mesh" in _shader_cache:
        return _shader_cache["mesh"]
    info = gpu.types.GPUShaderCreateInfo()
    # `move`: new @ inv(old); `crop`: the view inside the overscan; `lens`: the old view's
    # `depth_lens`; misc: this view's clip start, EDGE_RATIO, depth texels per pixel at rest.
    info.typedef_source("struct BUMeshParams { mat4 move; vec4 crop; vec4 lens; vec4 misc; };")
    info.uniform_buf(0, "BUMeshParams", "params")
    info.sampler(0, "FLOAT_2D", "image")
    info.sampler(1, "FLOAT_2D", "depth")
    info.vertex_in(0, "VEC2", "corner")
    interface = gpu.types.GPUStageInterfaceInfo("bu_link_mesh_interface")
    interface.smooth("VEC2", "uv")
    interface.smooth("FLOAT", "inverse_z")
    info.vertex_out(interface)
    info.fragment_out(0, "VEC4", "fragColor")
    info.vertex_source(
        "void main() {"
        "  ivec2 size = textureSize(depth, 0);"
        "  vec2 texel = vec2(corner.x, corner.y + float(gl_InstanceID));"
        "  float s = texelFetch(depth, ivec2(texel), 0).r;"
        "  uv = (texel + 0.5) / vec2(size);"
        "  vec2 ndc = (uv - params.crop.xy) / (params.crop.zw - params.crop.xy) * 2.0 - 1.0;"
        "  float w = params.lens.z + params.lens.w * s;"
        "  vec4 h = params.move * vec4(ndc * w, params.lens.x + params.lens.y * s, w);"
        "  inverse_z = s / max(h.w, 1e-12);"
        "  gl_Position = vec4(h.xy, h.w * " + repr(MESH_FAR) + " - params.misc.x * s, h.w);"
        "}")
    info.fragment_source(
        "void main() {"
        "  ivec2 size = textureSize(depth, 0);"
        "  vec2 t = uv * vec2(size);"
        # The fewest depth texels one pixel crosses in any direction: the 2x2's stretch.
        "  vec2 across = dFdx(t);"
        "  vec2 down = dFdy(t);"
        "  float square = dot(across, across) + dot(down, down);"
        "  float det = abs(across.x * down.y - across.y * down.x);"
        "  float largest = sqrt(max(0.5 * (square + sqrt(max(square * square - 4.0 * det * det,"
        "                                                    0.0))), 1e-30));"
        "  ivec2 i0 = clamp(ivec2(floor(t - 0.5)), ivec2(0), size - ivec2(2));"
        "  float a = texelFetch(depth, i0, 0).r;"
        "  float b = texelFetch(depth, i0 + ivec2(1, 0), 0).r;"
        "  float c = texelFetch(depth, i0 + ivec2(0, 1), 0).r;"
        "  float d = texelFetch(depth, i0 + ivec2(1, 1), 0).r;"
        "  if (max(max(a, b), max(c, d)) > min(min(a, b), min(c, d)) * params.misc.y + 1e-5"
        "      && det / largest * " + repr(OPEN_STRETCH) + " < params.misc.z) {"
        "    discard;"
        "  }"
        "  fragColor = vec4(texture(image, uv).rgb, inverse_z);"
        "}")
    _shader_cache["mesh"] = gpu.shader.create_from_info(info)
    return _shader_cache["mesh"]


def _fill_shader(gpu):
    """One level of the fill pyramid (`fill_levels`) from the level below, or from the mesh
    pass: each texel the average colour of the drawn among the four under it that are no nearer
    than the farthest of them by EDGE_RATIO, and that 1/depth; alpha -1 where none is drawn."""
    if "fill" in _shader_cache:
        return _shader_cache["fill"]
    info = gpu.types.GPUShaderCreateInfo()
    info.sampler(0, "FLOAT_2D", "source")
    info.vertex_in(0, "VEC2", "pos")
    info.fragment_out(0, "VEC4", "fragColor")
    info.vertex_source("void main() { gl_Position = vec4(pos, 0.0, 1.0); }")
    info.fragment_source(
        "void main() {"
        "  ivec2 here = ivec2(gl_FragCoord.xy);"
        "  ivec2 size = textureSize(source, 0);"
        "  vec4 t0 = texelFetch(source, min(here * 2, size - ivec2(1)), 0);"
        "  vec4 t1 = texelFetch(source, min(here * 2 + ivec2(1, 0), size - ivec2(1)), 0);"
        "  vec4 t2 = texelFetch(source, min(here * 2 + ivec2(0, 1), size - ivec2(1)), 0);"
        "  vec4 t3 = texelFetch(source, min(here * 2 + ivec2(1, 1), size - ivec2(1)), 0);"
        "  float far = 3.0e38;"
        "  if (t0.a >= 0.0) { far = min(far, t0.a); }"
        "  if (t1.a >= 0.0) { far = min(far, t1.a); }"
        "  if (t2.a >= 0.0) { far = min(far, t2.a); }"
        "  if (t3.a >= 0.0) { far = min(far, t3.a); }"
        "  float limit = far * " + repr(EDGE_RATIO) + " + 1e-6;"
        "  vec4 sum = vec4(0.0);"
        "  if (t0.a >= 0.0 && t0.a <= limit) { sum += vec4(t0.rgb, 1.0); }"
        "  if (t1.a >= 0.0 && t1.a <= limit) { sum += vec4(t1.rgb, 1.0); }"
        "  if (t2.a >= 0.0 && t2.a <= limit) { sum += vec4(t2.rgb, 1.0); }"
        "  if (t3.a >= 0.0 && t3.a <= limit) { sum += vec4(t3.rgb, 1.0); }"
        "  fragColor = sum.a > 0.0 ? vec4(sum.rgb / sum.a, far) : vec4(0.0, 0.0, 0.0, -1.0);"
        "}")
    _shader_cache["fill"] = gpu.shader.create_from_info(info)
    return _shader_cache["fill"]


# GLSL: `drawn_bilinear(source, uv, far)`, `_drawn_bilinear` for one place: `source` read
# bilinear over its drawn texels (alpha >= 0) no nearer than the farthest of the four by
# EDGE_RATIO, as (colour sum, weight), and that farthest 1/depth in `far`.
_DRAWN_BILINEAR = (
    "vec4 drawn_bilinear(sampler2D source, vec2 uv, out float far) {"
    "  ivec2 size = textureSize(source, 0);"
    "  vec2 p = uv * vec2(size) - 0.5;"
    "  ivec2 i0 = ivec2(floor(p));"
    "  vec2 f = p - vec2(i0);"
    "  vec4 t[4];"
    "  far = 3.0e38;"
    "  for (int i = 0; i < 4; i++) {"
    "    t[i] = texelFetch(source, clamp(i0 + ivec2(i % 2, i / 2), ivec2(0), size - ivec2(1)), 0);"
    "    if (t[i].a >= 0.0) { far = min(far, t[i].a); }"
    "  }"
    "  vec4 sum = vec4(0.0);"
    "  for (int i = 0; i < 4; i++) {"
    "    float w = (i % 2 == 1 ? f.x : 1.0 - f.x) * (i / 2 == 1 ? f.y : 1.0 - f.y)"
    "              * (t[i].a >= 0.0 && t[i].a <= far * " + repr(EDGE_RATIO) + " + 1e-6 ? 1.0 : 0.0);"
    "    sum += vec4(t[i].rgb * w, w);"
    "  }"
    "  return sum;"
    "}")


def _push_shader(gpu):
    """One level of the fill pyramid's way back down (`fill_push`): a texel drawn keeps its
    colour, an undrawn one takes the level above read bilinear over the farthest of what that
    has drawn, and that 1/depth."""
    if "push" in _shader_cache:
        return _shader_cache["push"]
    info = gpu.types.GPUShaderCreateInfo()
    info.sampler(0, "FLOAT_2D", "level")
    info.sampler(1, "FLOAT_2D", "above")
    info.vertex_in(0, "VEC2", "pos")
    info.fragment_out(0, "VEC4", "fragColor")
    info.vertex_source("void main() { gl_Position = vec4(pos, 0.0, 1.0); }")
    info.fragment_source(
        _DRAWN_BILINEAR +
        "void main() {"
        "  ivec2 here = ivec2(gl_FragCoord.xy);"
        "  vec4 own = texelFetch(level, here, 0);"
        "  if (own.a >= 0.0) { fragColor = own; return; }"
        "  float far;"
        "  vec4 sum = drawn_bilinear(above, (vec2(here) + 0.5) / vec2(textureSize(level, 0)),"
        "                            far);"
        "  fragColor = sum.a > 1e-4 ? vec4(sum.rgb / sum.a, far) : vec4(0.0, 0.0, 0.0, -1.0);"
        "}")
    _shader_cache["push"] = gpu.shader.create_from_info(info)
    return _shader_cache["push"]


def _composite_shader(gpu, linear=False):
    """Follow Depth's last pass, into the viewport: the mesh pass's picture where it drew, and
    the fill (`fill_colour`) where it left an opening; then as `_shader` finishes it."""
    key = ("composite", linear)
    if key in _shader_cache:
        return _shader_cache[key]
    info = _quad_info(gpu, "bu_link_composite_interface")
    info.push_constant("FLOAT", "extra")
    info.sampler(0, "FLOAT_2D", "picture")
    info.sampler(1, "FLOAT_2D", "fill")
    if not linear:
        info.sampler(2, "FLOAT_3D", "lut")
    info.fragment_source(
        _DRAWN_BILINEAR +
        "vec3 picture_colour() {"
        "  vec2 uv = ndc * 0.5 + 0.5;"
        "  ivec2 size = textureSize(picture, 0);"
        "  vec4 t = texelFetch(picture, clamp(ivec2(uv * vec2(size)), ivec2(0),"
        "                                     size - ivec2(1)), 0);"
        "  if (t.a >= 0.0) { return t.rgb; }"
        "  float far;"
        "  vec4 sum = drawn_bilinear(fill, uv, far);"
        "  return sum.a > 1e-4 ? sum.rgb / sum.a : vec3(0.0);"
        "}" + _finish(linear).replace("EXTRA", "extra"))
    _shader_cache[key] = gpu.shader.create_from_info(info)
    return _shader_cache[key]


# From the Render properties, only these come from Blender: everything else there is EEVEE's
# renderer, which does nothing for Unreal. BU's own panels take their place.
RENDER_KEPT = ("RENDER_PT_simplify", "RENDER_PT_color_management")
# Elsewhere, EEVEE settings that only EEVEE reads.
EEVEE_ONLY = ("VIEWLAYER_PT_filter", "VIEWLAYER_PT_layer_passes", "DATA_PT_lightprobe",
              "DATA_PT_EEVEE_light_shadow", "DATA_PT_EEVEE_light_influence",
              "EEVEE_WORLD_PT_settings", "EEVEE_WORLD_PT_lightprobe", "EEVEE_WORLD_PT_sun",
              "EEVEE_WORLD_PT_mist", "EEVEE_MATERIAL_PT_thickness")


def borrowed(name, context, parent=""):
    """Whether Blender's panel `name` (an EEVEE one) also shows for the Unreal engine. Pure.

    Kept: what describes the scene (materials and their nodes, the World's surface and volume,
    lights, cameras, meshes), which BU translates, plus Simplify and Color Management. Left
    out: EEVEE's own renderer settings.
    """
    parent = parent or ""
    if context == "render":
        return any(name.startswith(kept) or parent.startswith(kept) for kept in RENDER_KEPT)
    return not any(name.startswith(prefix) or parent.startswith(prefix)
                   for prefix in EEVEE_ONLY)


def _compatible_panels():
    """Blender's own panels that should stay visible while this engine is selected.

    Panels list the engines they support, so an unknown engine hides the material, light and
    world settings. This is the recipe from Blender's RenderEngine documentation.
    """
    import bpy

    panels = []
    for panel in bpy.types.Panel.__subclasses__():
        engines = getattr(panel, "COMPAT_ENGINES", None)
        if (engines is not None and "BLENDER_EEVEE" in engines
                and borrowed(panel.__name__, getattr(panel, "bl_context", ""),
                             getattr(panel, "bl_parent_id", ""))):
            panels.append(panel)
    return panels


_add_menu = {}


def _patch_add_menu():
    """Offer the Shader Editor's Add menu as for EEVEE.

    Blender hides a few nodes per engine by name (`context.engine == 'BLENDER_EEVEE'`), so for
    an engine it does not know it would offer Cycles-only nodes and hide EEVEE's. Unreal gets
    what EEVEE gets: those are the nodes BU translates.
    """
    try:
        from bl_ui import node_add_menu_shader as menu
    except ImportError:
        return
    original = getattr(menu, "eevee_shader_nodes_poll", None)
    if original is None or _add_menu:
        return
    _add_menu["original"] = original
    menu.eevee_shader_nodes_poll = lambda context: (
        context.engine == ENGINE_ID or original(context))


def _unpatch_add_menu():
    original = _add_menu.pop("original", None)
    if original is None:
        return
    try:
        from bl_ui import node_add_menu_shader as menu
    except ImportError:
        return
    menu.eevee_shader_nodes_poll = original


def active_viewports(window_manager):
    """Every 3D viewport currently showing this engine."""
    found = []
    for window in window_manager.windows:
        scene = window.scene
        if scene is None or scene.render.engine != ENGINE_ID:
            continue
        for area in window.screen.areas:
            if area.type != "VIEW_3D":
                continue
            space = area.spaces.active
            if space is not None and space.shading.type == "RENDERED":
                found.append(area)
    return found


_engine_class = None


def register():
    global _engine_class
    import bpy

    _engine_class = _register_engine()
    bpy.utils.register_class(_engine_class)
    for panel in _compatible_panels():
        panel.COMPAT_ENGINES.add(ENGINE_ID)
    _patch_add_menu()


def unregister():
    global _engine_class
    import bpy

    _shader_cache.clear()
    _unpatch_add_menu()

    for panel in _compatible_panels():
        panel.COMPAT_ENGINES.discard(ENGINE_ID)
    if _engine_class is not None:
        bpy.utils.unregister_class(_engine_class)
        _engine_class = None
