# SPDX-License-Identifier: GPL-3.0-or-later
"""Named shared memory for the real-time link's bulk data.

The link's socket is for small messages. Meshes and pictures are megabytes that both programs
want as flat arrays, and pushing them through a socket means building a bytes object here and
unpicking it element by element in Unreal's Python — which is where nearly all the time went.
So when Unreal has BU's native module, Blender creates two mappings, writes into them with bulk
array calls, and sends only a name and an offset:

* a **mesh arena**, written by Blender and read by Unreal;
* a **frame ring**, written by Unreal and read by Blender.

The approach — a control channel plus shared memory, and no per-element Python on either side —
is AnimVoxel Render's (`AVR_IPC_Protocol_v1.md` §1), cut down to what a link between two
programs on one machine needs. No bpy here, so it is testable outside Blender.

Windows only: named mappings are how the two processes find the same memory, and the native
module that opens them is Win64. Elsewhere the link keeps to its socket.
"""

import collections
import mmap
import secrets
import sys

import numpy as np

# Must match `BULink::Version` in BULinkLibrary.cpp. A different number means a different
# layout, and the link falls back to the socket rather than guess.
NATIVE_VERSION = 3

ALIGN = 64
MESH_ARENA_BYTES = 256 * 1024 * 1024
# Float RGBA at the largest picture the viewport asks for (`link_view.MAX_EDGE`): a 2560 x 1440
# viewport with its 10% overscan on every side is 3072 x 1728. A bigger one gets less overscan.
FRAME_SLOT_BYTES = 2560 * 2560 * 16
FRAME_SLOTS = 2


def available():
    return sys.platform == "win32"


def new_token():
    return secrets.token_hex(8)


class Arena(object):
    """One named mapping, written as a ring.

    Blender writes meshes one after another. After a batch it sends a marker and calls `fence`
    with the marker's id; Unreal echoes the marker once it has read everything before it, and
    `consumed` then frees what lay before that fence. A region is never rewritten while the other
    side may still be reading it.

    A ring, not a bump allocator reset when everything is read: while an animation plays there
    is always one batch Unreal has not read yet, so the arena filled up every few frames and the
    link stood still until Unreal caught up completely.
    """

    def __init__(self, name, size):
        self.name = name
        self.size = int(size)
        self._map = mmap.mmap(-1, self.size, tagname=name)
        self.view = np.frombuffer(self._map, dtype=np.uint8)
        self.used = 0          # where the next write goes
        self.tail = 0          # the oldest byte Unreal may still read
        self._fences = collections.deque()  # (marker id, write position when it was sent)
        self._unfenced = False  # written since the last fence

    @property
    def busy(self):
        """True while Unreal may still read something in the arena."""
        return bool(self._fences) or self._unfenced

    def alloc(self, count):
        """Reserve `count` bytes. Returns the offset, or None when there is no room yet."""
        count = (int(count) + ALIGN - 1) & ~(ALIGN - 1)
        if not self.busy:
            self.used = self.tail = 0  # nothing outstanding: start again from the top
        if self.used >= self.tail:
            # Free: from here to the end, and before the tail.
            if self.used + count <= self.size:
                offset = self.used
            elif self.busy and count < self.tail:
                offset = 0  # wrap round
            else:
                return None
        elif self.used + count < self.tail:
            offset = self.used  # wrapped: free up to the tail
        else:
            return None
        self.used = offset + count
        self._unfenced = True
        return offset

    def fence(self, marker):
        """A marker with this id has been sent after everything written so far."""
        if self._unfenced:
            self._fences.append((int(marker), self.used))
            self._unfenced = False

    def consumed(self, marker):
        """Unreal has read everything written before the marker with this id."""
        while self._fences and self._fences[0][0] <= int(marker):
            self.tail = self._fences.popleft()[1]

    def reset(self):
        self.used = self.tail = 0
        self._fences.clear()
        self._unfenced = False

    def floats(self, offset, count):
        return self.view[offset:offset + count * 4].view(np.float32)

    def ints(self, offset, count):
        # intc, not int32: on Windows NumPy exports int32 as 'l', and Blender's foreach_get only
        # takes its memcpy path for 'i'. Same bytes, a couple of hundred times faster to fill.
        return self.view[offset:offset + count * 4].view(np.intc)

    def close(self):
        # Views export the mapping's buffer; it cannot close while one is alive.
        self.view = None
        try:
            self._map.close()
        except BufferError:
            pass  # released when the last view dies

