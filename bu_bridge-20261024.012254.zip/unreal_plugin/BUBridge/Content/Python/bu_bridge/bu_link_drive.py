# SPDX-License-Identifier: GPL-3.0-or-later
"""Objects imported from Unreal, moving the actors they came from.

An object brought into Blender with *Import from Unreal* stands for the actor it was exported
from. Moving it in Blender moves that actor, which keeps its own mesh (Nanite and all) and its
own materials. Blender sends `{"type": "drive", "path": <actor path>, "matrix": [...]}` as the
object moves.

A drag arrives as a stream of transforms. Each one is applied with no undo step. Once the
stream stops for `SETTLE_SECONDS`, the whole move is recorded as **one** undo step: the actor
is put back where the drag started, untracked, and then moved to where it ended inside a real
transaction. Ctrl+Z in Unreal then undoes the whole drag, and the level is marked as changed,
as it would be after a move made in Unreal.

Blender also says which actors its imports stand for (`watch`). Any that are deleted in Unreal
are reported back (`gone`), and Blender starts sending its copy over the link instead, so the
object does not disappear from the picture.
"""

from . import bu_link_editor

SETTLE_SECONDS = 0.4
WATCH_SECONDS = 1.0
DESCRIPTION = "Move from Blender"

try:
    _DRIVE  # noqa: B018 - survives importlib.reload on purpose
except NameError:
    _DRIVE = {}
for _key, _default in (("actors", {}), ("moving", {}), ("watched", set()), ("last_watch", 0.0)):
    _DRIVE.setdefault(_key, _default)


def _valid(actor):
    """Alive and not deleted. A deleted actor stays findable, and readable, until garbage
    collection (and for as long as an undo step holds it): only `is_valid` tells."""
    import unreal

    if not bu_link_editor.alive(actor):
        return False
    try:
        return bool(unreal.SystemLibrary.is_valid(actor))
    except Exception:  # noqa: BLE001
        return True


def find(path):
    """The level actor at this path, or None if it is gone."""
    import unreal

    actor = _DRIVE["actors"].get(path)
    if actor is not None and _valid(actor):
        return actor
    _DRIVE["actors"].pop(path, None)
    try:
        actor = unreal.find_object(None, path)
    except Exception:  # noqa: BLE001 - a malformed path
        actor = None
    if not isinstance(actor, unreal.Actor) or not _valid(actor):
        return None
    _DRIVE["actors"][path] = actor
    return actor


def drive(path, transform, now):
    """Move an actor to where Blender has its copy. False if the actor is gone."""
    actor = find(path)
    if actor is None:
        _DRIVE["moving"].pop(path, None)
        return False
    entry = _DRIVE["moving"].get(path)
    if entry is None:
        entry = _DRIVE["moving"][path] = {"original": actor.get_actor_transform()}
    entry["final"] = transform
    entry["at"] = now
    bu_link_editor.untracked(lambda: actor.set_actor_transform(transform, False, True))
    return True


def settle(now):
    """Record each finished drag as one undo step. Returns how many were recorded."""
    import unreal

    done = 0
    for path, entry in list(_DRIVE["moving"].items()):
        if now - entry["at"] < SETTLE_SECONDS:
            continue
        del _DRIVE["moving"][path]
        actor = find(path)
        if actor is None:
            continue
        original, final = entry["original"], entry["final"]
        bu_link_editor.untracked(lambda: actor.set_actor_transform(original, False, True))
        try:
            index = unreal.SystemLibrary.begin_transaction("BU", unreal.Text(DESCRIPTION), None)
        except Exception:  # noqa: BLE001 - no transaction system
            index = -1
        try:
            if index >= 0:
                unreal.SystemLibrary.transact_object(actor)
            actor.set_actor_transform(final, False, True)
        finally:
            if index >= 0:
                unreal.SystemLibrary.end_transaction()
        done += 1
    return done


def moving():
    return bool(_DRIVE["moving"])


def watch(paths):
    """The actors Blender's imports stand for, replacing the last list."""
    _DRIVE["watched"] = set(str(path) for path in paths or () if path)
    _DRIVE["last_watch"] = 0.0


def gone(now):
    """Watched actors deleted since the last look, at most once every WATCH_SECONDS."""
    if not _DRIVE["watched"] or now - _DRIVE["last_watch"] < WATCH_SECONDS:
        return []
    _DRIVE["last_watch"] = now
    missing = sorted(path for path in _DRIVE["watched"] if find(path) is None)
    _DRIVE["watched"].difference_update(missing)
    return missing


def reset():
    _DRIVE["moving"].clear()
    _DRIVE["watched"] = set()
    _DRIVE["actors"].clear()
