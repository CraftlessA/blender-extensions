# SPDX-License-Identifier: GPL-3.0-or-later
"""Keeps geometry-less meshes out of the export.

A real scene had **70 mesh objects with zero vertices** — leftovers from a Minecraft importer.
Blender still writes a prim for each one, so Unreal creates a component with no geometry and no
material. In one import that produced **384 components stacked at the origin**, which is pure
noise in the outliner and actively misleading when diagnosing (a "close-up" of a named object
can end up photographing that pile instead).

Blender's USD exporter has no "skip empty objects" switch, but `hide_render` does exclude an
object under `RENDER` evaluation — verified in tests/test_camera_visibility.py. So we set it for
the duration of the export and restore it afterwards, leaving the scene exactly as found.
"""

import contextlib

_MESH_LIKE = ("MESH", "CURVE", "SURFACE", "META", "FONT")


def find_empty_meshes(scene):
    """Mesh objects that would export as an empty prim."""
    empties = []
    for obj in scene.objects:
        if obj.type != "MESH":
            continue
        data = obj.data
        if data is None:
            continue
        if len(data.vertices) == 0:
            empties.append(obj)
    return empties


@contextlib.contextmanager
def excluded(scene, enabled=True):
    """Hide zero-vertex meshes from the export, then put them back.

    Yields the list of objects that were excluded. Restores `hide_render` on every object it
    touched even if the export raises, so an interrupted export cannot leave the scene altered.
    """
    if not enabled:
        yield []
        return

    from . import visibility

    empties = find_empty_meshes(scene)
    previous = [(obj, obj.hide_render) for obj in empties]
    # A rig can *drive* `hide_render`, which silently reverts the writes below before the
    # exporter reads them. Mute those channels for the duration. See visibility.py.
    with visibility.frozen(empties):
        try:
            for obj in empties:
                obj.hide_render = True
            yield empties
        finally:
            for obj, was_hidden in previous:
                obj.hide_render = was_hidden
