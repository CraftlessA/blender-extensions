# SPDX-License-Identifier: GPL-3.0-or-later
"""The BU export operator: USD + sidecar manifest, in one step."""

import contextlib
import json
import os

import bpy
from bpy.props import BoolProperty, EnumProperty, IntProperty, StringProperty
from bpy_extras.io_utils import ExportHelper

from . import (
    audit, bake, capture, curves, cut_cameras, empties, filter_ui, filters, live, material_slots,
    prefs, shots, subdivision, texture_files,
    transforms, usd_hook, usd_index, visibility,
)

MANIFEST_SUFFIX = ".bu.json"


def manifest_path_for(usd_path):
    """Sidecar sits next to the USD, sharing its stem: Shot_01.usda -> Shot_01.bu.json."""
    stem = os.path.splitext(usd_path)[0]
    return stem + MANIFEST_SUFFIX


class ExportFailed(Exception):
    """Raised when the export cannot complete; message is user-facing."""


def run_export(
    context,
    usd_path,
    selected_only=False,
    export_animation=True,
    export_cameras=True,
    export_materials=True,
    export_textures_mode="PRESERVE",
    evaluation_mode="RENDER",
    root_prim_path="/root",
    export_subdivision="TESSELLATE",
    skip_empty_meshes=True,
    export_skeletal=False,
    include=None,
    exclude=None,
    convert_curves=True,
    unblock_cut_cameras=True,
    subdivision_cap=None,
    shot=None,
    animated_only=False,
    geometry=None,
    export_normals=True,
):
    """Export USD + sidecar manifest. Shared by the file-browser and live operators.

    `shot` narrows the frame range to one camera cut; `animated_only` drops static geometry. Both
    exist because the expensive half of this pipeline is the import, not the export — see
    `shots.py` for the measured numbers.

    Returns (manifest, manifest_path, materialized_textures).
    """
    directory = os.path.dirname(usd_path)
    if directory:
        os.makedirs(directory, exist_ok=True)

    # The hook is global; only let it fire for the duration of our own export. Zero-vertex
    # meshes are hidden for the same window, so they do not become materialless components in
    # Unreal -- empties.excluded() restores hide_render even if the export raises.
    # Include/exclude default to whatever the scene has configured, so the file-browser export,
    # the live export and a headless call all honour the same saved intent.
    scene = context.scene
    if include is None and exclude is None and getattr(scene, "bu_use_filters", False):
        include = filter_ui.entry_names(scene.bu_include)
        exclude = filter_ui.entry_names(scene.bu_exclude)
    include = list(include or [])
    exclude = list(exclude or [])
    # One source of truth: the cap lives on the scene, is edited in BU's sidebar and is saved with
    # the .blend. A second copy on the export operator would let the dialog silently contradict
    # the panel the artist just set.
    if subdivision_cap is None:
        subdivision_cap = int(getattr(scene, "bu_subdivision_cap", -1))
    # Same rule as the cap: the shot selection lives on the scene, so the sidebar and any export
    # path agree by construction. An explicit argument still wins, for headless callers.
    if shot is None:
        selected = getattr(scene, "bu_shot", "ALL")
        if selected and selected != "ALL":
            shot = shots.find(scene, selected)
    elif not isinstance(shot, dict):
        # A caller naturally passes the marker or camera name; the internals want the dict that
        # `shots.find` returns. Passing the name used to fail deep inside with "string indices must
        # be integers", which says nothing about what was wrong.
        resolved = shots.find(scene, shot)
        if resolved is None:
            raise ValueError(
                "No shot matches {0!r}. Available: {1}".format(
                    shot, ", ".join(s["marker"] for s in shots.shots(scene)) or "none")
            )
        shot = resolved
    # Explicit argument wins, then the legacy boolean, then the scene property the sidebar edits.
    if geometry is None:
        geometry = shots.ANIMATED if animated_only else getattr(scene, "bu_geometry", shots.ALL)
    if geometry == shots.STATIC:
        # Static geometry has nothing to say per frame, and a shot's frame range is meaningless
        # for it. Writing timeSamples for 508 unmoving meshes is the waste this mode exists to
        # avoid, so both are forced off rather than left to the caller to remember.
        export_animation = False
        shot = None

    usd_hook.set_active(True)
    excluded_empties = []
    excluded_by_filter = []
    revealed_by_filter = []
    converted_curve_info = []
    freed_camera_info = []
    try:
        # Five scene mutations have to be in force at once, each of which must be undone even if
        # the export raises. ExitStack keeps them in one flat, ordered list rather than five
        # levels of indentation -- and the order below is the precedence order:
        #
        #   1. a camera bound to a marker is a shot, so make it exportable first
        #   2. curves with bevel are solid geometry; Blender would write BasisCurves and drop
        #      the thickness, so convert before anything else looks at the scene
        #   3. include/exclude hides everything the lists filter out, object by object
        #   4. ...which is what makes it safe for `revealed` to un-hide whole collections
        #   5. zero-vertex meshes would arrive in Unreal as components with no geometry
        with contextlib.ExitStack() as stack:
            freed_camera_info = list(stack.enter_context(cut_cameras.unblocked(
                context, unblock_cut_cameras, evaluation_mode, selected_only)))
            converted_curve_info = list(stack.enter_context(
                curves.converted(context, convert_curves)))
            # Fixed before the visibility filters run, so it applies to whatever ends up exported
            # regardless of include/exclude — a mesh either exports correctly or it doesn't, that
            # isn't something the artist's filter choices should change.
            corrected_slots = list(stack.enter_context(
                material_slots.corrected(context.scene)))
            # Has to happen before the actual export call: the illegal filename is baked into the
            # stage from whatever the image's datablock name is at export time, so fixing it only
            # afterwards (in texture_files.materialize) is too late. Same material set materialize
            # itself falls back to, so the two stay in step.
            renamed_images = list(stack.enter_context(texture_files.sanitized_image_names(
                [m for m in bpy.data.materials if m.users > 0])))
            # A Geometry Cache is a raw per-frame point stream with no concept of "absent this
            # frame." A driven hide_render on an animated mesh (mouth-shape rig hiding teeth,
            # say) leaves the cache with nowhere good to put the hidden frames, and the observed
            # result is the mesh freezing in its last-baked position while its rig keeps moving --
            # "the teeth don't stay in the head," not "the teeth disappear." Forced visible for
            # continuity; entered before the include/exclude filters below so a deliberate,
            # explicit exclude can still override it (later writes win in an ExitStack).
            forced_visible_names = []
            never_visible_names = []
            shrunk_when_hidden_names = []
            shrink_skipped_names = []
            if export_animation:
                classified = capture.classify_animation(context.scene, export_skeletal)
                cache_names = {
                    e["object"] for e in classified["geometry_cache"] + classified["skeletal"]
                }
                cache_objects = [o for o in context.scene.objects if o.name in cache_names]

                # An object the rig hides on *every* frame is not a continuity problem to solve,
                # it is geometry that should not be in the export at all. Holding it visible put
                # two invisible 224-poly body skins per character into Unreal, permanently
                # rendering on top of the real body — read as broken normals, and unfindable in
                # Blender because it is invisible there. Left hidden, so Blender's exporter drops
                # it the same way it drops any hidden object.
                never = visibility.never_visible(cache_objects, context.scene)
                never_visible_names = [o.name for o in never]
                skip = set(never_visible_names)
                partly_hidden = [o for o in cache_objects if o.name not in skip]

                # shrunk_when_hidden must run its own scan BEFORE forced_visible, not after: its
                # scan reads each object's actual driven hide_render/hide_viewport per frame, and
                # forced_visible's whole job is to mute those drivers and force the flags off for
                # the rest of the export. Entered in the other order, shrunk_when_hidden would see
                # every object reading "visible" on every frame — the mute already applied — and
                # find nothing to shrink. (Caught by comparing this call against a standalone
                # call on the same scene: same objects, same range, empty result only when nested
                # inside an already-active forced_visible.)
                shrink_result = stack.enter_context(
                    visibility.shrunk_when_hidden(partly_hidden, context.scene))
                shrunk_when_hidden_names = shrink_result["shrunk"]
                shrink_skipped_names = shrink_result["skipped"]

                # Layered on top, not instead of: the render/viewport flags still have to stay off
                # for the whole export so the cache's point stream is continuous. shrunk_when_hidden
                # is what keeps the mesh from actually *rendering* through the frames the rig means
                # to hide it, by shrinking it to near-zero instead of leaving it at full size. See
                # visibility.shrunk_when_hidden for the measured cost this replaces: two full-size
                # body skins per character sitting on top of the real body throughout the shot.
                forced_visible_names = list(stack.enter_context(
                    visibility.forced_visible(partly_hidden)))
            excluded_by_filter = list(stack.enter_context(
                filters.applied(context.scene, include, exclude)))
            revealed_by_filter = list(stack.enter_context(filters.revealed(
                context.scene, include, exclude, evaluation_mode,
                view_layer=context.view_layer)))
            excluded_empties = list(stack.enter_context(
                empties.excluded(context.scene, skip_empty_meshes)))
            # 6. subdivision last: it changes how much geometry the exporter has to write, not
            #    which objects it writes, so it is independent of every filter above.
            capped_subdivision = list(stack.enter_context(
                subdivision.capped(context.scene, subdivision_cap)))
            # 7. shot scoping last of all. Narrowing the frame range and dropping static geometry
            #    changes how much of the scene gets written, not which filters apply to it, so it
            #    composes with everything above rather than interacting with it.
            shot_range = stack.enter_context(shots.framed(
                context.scene,
                shot["frame_start"] if shot else None,
                shot["frame_end"] if shot else None))
            hidden_static = list(stack.enter_context(
                shots.only_geometry(context.scene, geometry)))

            result = bpy.ops.wm.usd_export(
                filepath=usd_path,
                selected_objects_only=selected_only,
                export_animation=export_animation,
                export_materials=export_materials,
                export_cameras=export_cameras,
                export_textures_mode=export_textures_mode,
                export_subdivision=export_subdivision,
                evaluation_mode=evaluation_mode,
                root_prim_path=root_prim_path,
                generate_preview_surface=True,
                # Off by default. These two are what make Blender write UsdSkel, which Unreal
                # turns into SkeletalMesh + Skeleton + PhysicsAsset + AnimSequence. With them
                # off the exporter writes the *evaluated* geometry instead, so a rigged
                # character arrives as plain meshes (animated ones as a Geometry Cache) —
                # which is what a scene handoff usually wants.
                export_armatures=export_skeletal,
                export_shapekeys=export_skeletal,
                # Measured on a 346-frame scene: normals are 2.18 GB of a 2.69 GB export, four
                # times the point payload, because they are faceVarying (one per face-corner) and
                # rewritten every frame for every deforming mesh. Turning them off is by far the
                # largest single lever on both file size and import time -- at the cost of the
                # authored normals on static geometry, which is where hard edges live.
                export_normals=export_normals,
                export_uvmaps=True,
                relative_paths=True,
                convert_orientation=False,
                # Lighting is authored in Unreal, never exported. Both of these default to
                # True in Blender 5.2, and convert_world_material would otherwise arrive as
                # a dome light.
                export_lights=False,
                convert_world_material=False,
            )
    except (RuntimeError, TypeError) as exc:
        raise ExportFailed("USD export failed: {0}".format(exc))
    finally:
        usd_hook.set_active(False)

    if "FINISHED" not in result:
        raise ExportFailed("USD export did not complete")

    # Blender authors transforms as time samples with no default value. Unreal's prim
    # collapsing reads defaults, so an ancestor Xform's placement can be read as identity and
    # everything under it lands at the world origin. Author defaults before anything else
    # touches the stage.
    prims_fixed, ops_fixed = transforms.flatten(usd_path, context.scene.frame_start)

    # Packed and generated images are referenced by the stage but never written by the
    # exporter; write them now so the references resolve.
    written, texture_failures = texture_files.materialize(usd_path)

    manifest = capture.build_manifest(
        context,
        os.path.basename(usd_path),
        evaluation_mode=evaluation_mode,
        selected_only=selected_only,
        subdivision_mode=export_subdivision,
        export_skeletal=export_skeletal,
        freed={name for name, _ in freed_camera_info},
        # The survey runs after the scene is restored, so it would otherwise report the very
        # collections BU un-hid to satisfy the include list as having blocked the export.
        revealed={name for name, _ in revealed_by_filter},
        # Topology stability only matters for geometry caches, which only exist when animation
        # is exported. Skipping the scan for a static export also saves evaluating every animated
        # mesh five times over.
        export_animation=export_animation,
    )
    manifest["materialized_textures"] = [os.path.basename(p) for p in written]
    if renamed_images:
        manifest["warnings"].append(
            "{0} image(s) had a name Windows cannot use in a filename (|, :, \", <, >, ?, *) — "
            "renamed for export only, restored in Blender afterwards: {1}. The exported texture "
            "file uses the new name; rename the image datablock permanently to make it stick "
            "next time too.".format(
                len(renamed_images),
                ", ".join("'{0}' -> '{1}'".format(o, n) for o, n in renamed_images[:6]),
            )
        )
    if corrected_slots:
        manifest["warnings"].append(
            "{0} mesh object(s) have material slots that use only one material, but not slot 0 — "
            "Blender's USD exporter binds slot 0's material regardless, which would arrive wrong "
            "in Unreal. Corrected for export: {1}.".format(
                len(corrected_slots),
                ", ".join("{0} -> {1}".format(name, mat) for name, mat in corrected_slots[:6]),
            )
        )
    if never_visible_names:
        manifest["never_visible"] = list(never_visible_names)
        manifest["warnings"].append(
            "{0} animated mesh object(s) are hidden by the rig on every frame of the range and "
            "were NOT exported: {1}. They can never be seen in Blender, so holding them visible "
            "for the export — which is what BU does for meshes the rig hides only part of the "
            "time — would put them in Unreal permanently, rendering on top of whatever they sit "
            "on. If you expected one of these in Unreal, its visibility driver is hiding it for "
            "the whole shot.".format(
                len(never_visible_names), ", ".join(never_visible_names[:8])
            )
        )
    if shrunk_when_hidden_names:
        manifest["shrunk_when_hidden"] = list(shrunk_when_hidden_names)
        manifest["warnings"].append(
            "{0} animated mesh object(s) have visibility driven by the rig, which a Geometry "
            "Cache cannot represent as an absent frame — the hidden frames would otherwise "
            "freeze the mesh in its last position while the rig kept moving. Kept visible for "
            "cache continuity, but scaled to near-zero on the frames the rig means to hide them, "
            "so they stay correctly attached to their rig throughout without rendering: {1}.".format(
                len(shrunk_when_hidden_names), ", ".join(shrunk_when_hidden_names[:6])
            )
        )
    if shrink_skipped_names:
        manifest["warnings"].append(
            "{0} animated mesh object(s) have visibility driven by the rig AND an existing "
            "delta_scale animation of their own, so BU could not layer a hidden-frame shrink on "
            "top without risking that animation: {1}. Held fully visible for the whole export "
            "instead — it will render in Unreal even on frames where the rig means to hide it.".format(
                len(shrink_skipped_names), ", ".join(shrink_skipped_names[:6])
            )
        )

    # `build_manifest` runs *after* the ExitStack has restored the scene, so it sees the full frame
    # range even when only one shot was exported — and shipped all 13 cuts for a 41-frame export,
    # twelve of them pointing past the end of the imported data. Narrow the manifest to what the
    # USD actually contains.
    if shot:
        first, last = shot["frame_start"], shot["frame_end"]
        manifest["scene"]["frame_start"] = first
        manifest["scene"]["frame_end"] = last
        kept = []
        for cut in manifest.get("camera_cuts", []):
            # `frame_end` is exclusive, so the shot's own window is [first, last + 1).
            start = max(cut["frame_start"], first)
            end = min(cut["frame_end"], last + 1)
            if end > start:
                kept.append(dict(cut, frame_start=start, frame_end=end))
        dropped = len(manifest.get("camera_cuts", [])) - len(kept)
        manifest["camera_cuts"] = kept
        if dropped:
            manifest["warnings"].append(
                "{0} camera cut(s) fall outside this shot and were left out; {1} remain.".format(
                    dropped, len(kept)))
    # A scoped export looks like a broken one from Unreal: a third of the frames and none of the
    # set. Record what was deliberately left out so the import reports a choice, not a loss.
    if shot or geometry != shots.ALL:
        manifest["shot"] = {
            "marker": shot["marker"] if shot else "",
            "camera": shot["camera"] if shot else "",
            "frame_start": shot["frame_start"] if shot else context.scene.frame_start,
            "frame_end": shot["frame_end"] if shot else context.scene.frame_end,
            "geometry": geometry,
            "meshes_omitted": len(hidden_static),
        }
        if shot:
            manifest["warnings"].append(
                "This export covers one shot only — '{0}' on camera '{1}', frames {2}-{3} of "
                "{4}-{5}. The rest of the sequence is not in this file.".format(
                    shot["marker"], shot["camera"], shot["frame_start"], shot["frame_end"],
                    manifest["scene"]["frame_start"], manifest["scene"]["frame_end"]))
        if geometry == shots.ANIMATED:
            manifest["warnings"].append(
                "Animated geometry only: {0} static mesh object(s) left out, so the set will be "
                "missing in Unreal. Import the set once from a Static-only export, then keep "
                "re-importing this file while you iterate.".format(len(hidden_static)))
        elif geometry == shots.STATIC:
            manifest["warnings"].append(
                "Static geometry only: {0} animated mesh object(s) left out, and animation was "
                "disabled for this export. This is the set — import it once, then iterate with "
                "Animated-only exports.".format(len(hidden_static)))
    manifest["subdivision_cap"] = {
        "cap": subdivision_cap,
        "lowered": [
            {"object": o, "modifier": m, "from": was, "to": now}
            for o, m, was, now in capped_subdivision
        ],
    }
    if subdivision_cap >= 0:
        survey = subdivision.survey(context.scene, subdivision_cap)
        manifest["subdivision_cap"]["survey"] = survey
        if capped_subdivision:
            manifest["warnings"].append(
                "Subdivision capped at {0} for this export: {1} modifier(s) lowered, {2} of them "
                "on animated meshes. Animated geometry pays subdivision once per frame, so this "
                "is roughly {3}x the per-frame geometry it would otherwise write. Your scene is "
                "unchanged.".format(
                    subdivision_cap, len(capped_subdivision), survey["affected_animated"],
                    survey["ratio"],
                )
            )
        else:
            # A cap that changes nothing is worth saying out loud: it looks like a safeguard and
            # is not one. Measured on the real scene, where every modifier was already at 3.
            manifest["warnings"].append(
                "Subdivision cap of {0} changed nothing — every subdivision modifier in this "
                "scene is already at or below it. The export is the same size as with no cap. "
                "Lower the cap if you need the export smaller.".format(subdivision_cap)
            )
    manifest["transform_defaults_authored"] = ops_fixed
    manifest["skipped_empty_meshes"] = [o.name for o in excluded_empties]
    manifest["freed_cut_cameras"] = [
        {"camera": name, "was_blocked_by": reason} for name, reason in freed_camera_info
    ]
    if freed_camera_info:
        manifest["warnings"].append(
            "{0} camera(s) bound to timeline markers were excluded from the export by "
            "visibility settings; BU exported them anyway because a marker binding means the "
            "camera is a shot: {1}".format(
                len(freed_camera_info), ", ".join(n for n, _ in freed_camera_info)
            )
        )

    manifest["converted_curves"] = [
        {"object": name, "vertices": count} for name, count in converted_curve_info
    ]
    if converted_curve_info:
        manifest["warnings"].append(
            "Converted {0} curve-like object(s) to meshes so their thickness survives; Blender "
            "would otherwise export them as BasisCurves with the bevel discarded: {1}".format(
                len(converted_curve_info),
                ", ".join(n for n, _ in converted_curve_info[:8]),
            )
        )

    # Record the filter, so a shot that is missing something can be traced to a deliberate
    # decision rather than looking like the exporter dropped it.
    manifest["filters"] = {
        "include": list(include),
        "exclude": list(exclude),
        "excluded_objects": list(excluded_by_filter),
        "revealed": [{"name": n, "cleared": what} for n, what in revealed_by_filter],
    }
    if revealed_by_filter:
        manifest["warnings"].append(
            "Include list overrode visibility on {0}: {1}. Naming something in the Include list "
            "means BU exports it, so the camera icon above it does not apply. Your scene is "
            "unchanged.".format(
                len(revealed_by_filter),
                ", ".join(n for n, _ in revealed_by_filter[:8]),
            )
        )
    if excluded_by_filter:
        manifest["warnings"].append(
            "Include/exclude lists kept {0} object(s) out of this export: {1}{2}".format(
                len(excluded_by_filter),
                ", ".join(excluded_by_filter[:12]),
                " (+{0} more)".format(len(excluded_by_filter) - 12)
                if len(excluded_by_filter) > 12 else "",
            )
        )
    unknown = filters.unknown_entries(context.scene, include + exclude)
    if unknown:
        manifest["warnings"].append(
            "Include/exclude names nothing in this scene: {0}. Check for a typo or a renamed "
            "collection.".format(", ".join(unknown))
        )
    manifest["warnings"].extend(texture_failures)
    if excluded_empties:
        manifest["warnings"].append(
            "Skipped {0} mesh object(s) with zero vertices; they would arrive in Unreal as "
            "components with no geometry or material.".format(len(excluded_empties))
        )

    # Blender's exporter drops objects silently. Compare the scene against the file it wrote
    # and name anything that did not make it, with a reason.
    completeness = audit.audit(context, usd_path, evaluation_mode, selected_only)
    manifest["export_audit"] = completeness
    manifest["warnings"].extend(audit.summarise(completeness, context=context))
    manifest["errors"].extend(audit.escalate(completeness, context))

    # Recover the Blender-name -> USD-prim-name mapping from the file we just wrote.
    # Blender sanitises "Camera.001" to "Camera_001", and Unreal names actors after
    # prims, so without this the Unreal side cannot find the cameras.
    usd_index.annotate(manifest, usd_path)

    manifest_path = manifest_path_for(usd_path)
    try:
        with open(manifest_path, "w", encoding="utf-8") as handle:
            json.dump(manifest, handle, indent=2)
    except OSError as exc:
        raise ExportFailed("Wrote USD but could not write manifest: {0}".format(exc))

    return manifest, manifest_path, written


def summarise(manifest, written, manifest_path):
    nearest = sum(1 for t in manifest["textures"] if t["unreal"]["filter"] == "Nearest")
    return (
        "{0} textures ({1} nearest, {2} written from .blend), {3} cameras, {4} cuts -> {5}".format(
            len(manifest["textures"]),
            nearest,
            len(written),
            len(manifest["cameras"]),
            len(manifest["camera_cuts"]),
            os.path.basename(manifest_path),
        )
    )


class BU_OT_export(bpy.types.Operator, ExportHelper):
    bl_idname = "bu.export_scene"
    bl_label = "Export to Unreal (USD + BU manifest)"
    bl_description = (
        "Export the scene as USD together with a BU manifest carrying texture filtering, "
        "camera intrinsics and marker-driven camera cuts"
    )
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".usdc"
    filter_glob: StringProperty(default="*.usd;*.usda;*.usdc", options={"HIDDEN"})

    usd_format: EnumProperty(
        name="Format",
        items=(
            ("USDC", "Binary (.usdc)", "Compact binary crate file — best for large scenes"),
            ("USDA", "Text (.usda)", "Human-readable ASCII — easier to inspect and diff"),
        ),
        default="USDC",
    )
    selected_only: BoolProperty(
        name="Selected Objects Only",
        description="Export only selected objects",
        default=False,
    )
    export_animation: BoolProperty(
        name="Animation",
        description="Bake the scene frame range into USD time samples",
        default=True,
    )
    export_cameras: BoolProperty(
        name="Cameras",
        description="Export cameras and build a camera-cut list from timeline markers",
        default=True,
    )
    export_materials: BoolProperty(
        name="Materials & Textures",
        default=True,
    )
    export_textures_mode: EnumProperty(
        name="Textures",
        items=(
            ("PRESERVE", "Preserve", "Copy textures next to the USD, keeping their names"),
            ("NEW", "New", "Write newly exported texture files"),
            ("KEEP", "Keep", "Reference textures where they already live"),
        ),
        default="PRESERVE",
    )
    export_skeletal: BoolProperty(
        name="Skeletal Meshes (rigs)",
        description=(
            "Export armatures and shape keys as USD skeletal data. Off by default: Unreal turns "
            "that into SkeletalMesh, Skeleton, PhysicsAsset and AnimSequence assets. With it off "
            "you get the deformed geometry instead, and animated meshes arrive as a Geometry Cache"
        ),
        default=False,
    )
    export_subdivision: EnumProperty(
        name="Subdivision",
        description=(
            "How Subdivision Surface modifiers are exported. Unreal's importer only reads USD's "
            "catmullClark scheme when its own Subdivision Level option is above zero, and that "
            "defaults to zero -- so Preserve alone gives you the blocky base cage"
        ),
        items=(
            ("TESSELLATE", "Apply (recommended)",
             "Blender bakes the subdivision, so Unreal receives the final geometry"),
            ("BEST_MATCH", "Preserve as USD subdiv",
             "Write the base cage plus catmullClark; BU tells Unreal what level to use"),
            ("IGNORE", "Ignore", "Export the unsubdivided base mesh"),
        ),
        default="TESSELLATE",
    )
    evaluation_mode: EnumProperty(
        name="Evaluate As",
        items=(
            ("RENDER", "Render", "Use render-resolution modifier settings"),
            ("VIEWPORT", "Viewport", "Use viewport modifier settings"),
        ),
        default="RENDER",
    )
    root_prim_path: StringProperty(
        name="Root Prim",
        default="/root",
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True

        col = layout.column(heading="Include")
        col.prop(self, "selected_only")
        col.prop(self, "export_animation")
        col.prop(self, "export_cameras")
        col.prop(self, "export_materials")
        col.prop(self, "export_skeletal")

        col = layout.column()
        col.prop(self, "usd_format")
        col.prop(self, "export_textures_mode")
        col.prop(self, "export_subdivision")
        col.prop(self, "evaluation_mode")
        col.prop(self, "root_prim_path")

    def execute(self, context):
        usd_path = bpy.path.ensure_ext(
            self.filepath, ".usda" if self.usd_format == "USDA" else ".usdc"
        )

        try:
            manifest, manifest_path, written = run_export(
                context,
                usd_path,
                selected_only=self.selected_only,
                export_animation=self.export_animation,
                export_cameras=self.export_cameras,
                export_materials=self.export_materials,
                export_textures_mode=self.export_textures_mode,
                export_subdivision=self.export_subdivision,
                export_skeletal=self.export_skeletal,
                evaluation_mode=self.evaluation_mode,
                root_prim_path=self.root_prim_path,
            )
        except ExportFailed as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        for warning in manifest["warnings"]:
            self.report({"WARNING"}, warning)
        # Errors are things the export produced that cannot work in Unreal. Reported as ERROR so
        # they surface in red and stay in the Info log, rather than scrolling past with the
        # dozens of routine warnings a large scene generates.
        for problem in manifest.get("errors", []):
            self.report({"ERROR"}, problem)

        self.report({"INFO"}, "BU export: " + summarise(manifest, written, manifest_path))
        return {"FINISHED"}


# Said whenever no open editor answers: these buttons are for an Unreal the user opened, and
# a tester clicked one expecting BU's own hidden Unreal, which never answers them.
HIDDEN_UNREAL_HINT = (
    " To see this scene through Unreal instead, you need no editor open: set Render Properties > "
    "Render Engine to Unreal and a viewport to Rendered, and BU starts its own.")


class BU_OT_scan_unreal(bpy.types.Operator):
    bl_idname = "bu.scan_unreal"
    bl_label = "Scan for Unreal Editors"
    bl_description = (
        "Find every running Unreal Editor and list them, so an export can be aimed at a chosen "
        "project instead of whichever one answers first"
    )

    def execute(self, context):
        preferences = prefs.get(context)
        nodes, error = live.scan(
            preferences.unreal_dir if preferences else "",
            preferences.multicast_group if preferences else "",
            preferences.bind_address if preferences else "",
            timeout=(preferences.discovery_timeout if preferences else 4.0),
        )
        if error:
            self.report({"ERROR"}, error)
            return {"CANCELLED"}
        if not nodes:
            self.report(
                {"WARNING"},
                "No Unreal Editor answered. Check the project is open and Project Settings > "
                "Plugins > Python > 'Enable Remote Execution?' is ticked — it is off by default "
                "and needs an editor restart." + HIDDEN_UNREAL_HINT,
            )
            return {"CANCELLED"}

        names = [n["project_name"] for n in nodes]
        # Keep a valid selection if it survived the rescan; otherwise take the only sensible
        # default, which exists precisely when there is no ambiguity to resolve.
        current = live.chosen_target(context.scene)
        if current not in names:
            context.scene.bu_unreal_target = names[0] if len(names) == 1 else live.UNSET

        self.report({"INFO"}, "Found {0} editor(s): {1}".format(len(nodes), ", ".join(names)))
        return {"FINISHED"}


class BU_OT_live_export(bpy.types.Operator):
    bl_idname = "bu.live_export"
    bl_label = "Live Export to Unreal"
    bl_description = (
        "Export the scene and import it straight into the running Unreal Editor, without "
        "touching a file browser"
    )
    bl_options = {"REGISTER"}

    selected_only: BoolProperty(name="Selected Objects Only", default=False)
    export_animation: BoolProperty(name="Animation", default=True)

    def execute(self, context):
        preferences = prefs.get(context)
        if preferences is None:
            self.report({"ERROR"}, "Could not read BU preferences")
            return {"CANCELLED"}

        directory = preferences.resolved_live_dir()
        stem = os.path.splitext(os.path.basename(bpy.data.filepath))[0] or context.scene.name
        extension = ".usda" if preferences.live_format == "USDA" else ".usdc"
        usd_path = os.path.join(directory, stem + extension)

        try:
            manifest, manifest_path, written = run_export(
                context,
                usd_path,
                selected_only=self.selected_only,
                export_animation=self.export_animation,
            )
        except ExportFailed as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        for warning in manifest["warnings"]:
            self.report({"WARNING"}, warning)
        # Errors are things the export produced that cannot work in Unreal. Reported as ERROR so
        # they surface in red and stay in the Info log, rather than scrolling past with the
        # dozens of routine warnings a large scene generates.
        for problem in manifest.get("errors", []):
            self.report({"ERROR"}, problem)
        self.report({"INFO"}, "BU export: " + summarise(manifest, written, manifest_path))

        script = live.build_import_script(
            usd_path,
            preferences.content_path,
            pixel_art_preset=preferences.pixel_art_preset,
            reload_first=preferences.reload_first,
        )

        with live.Session(
            preferences.unreal_dir, preferences.multicast_group, preferences.bind_address
        ) as session:
            ok, lines, message = session.run(
                script,
                # The chosen project, not whichever editor answers first. Empty means "no choice
                # made", which `run` turns into a refusal when more than one editor is up.
                node_id=live.chosen_target(context.scene),
                timeout=preferences.discovery_timeout,
            )

        # Surface the editor's own log back into Blender, so failures are visible here
        # rather than only in Unreal's Output Log.
        failed = [line for line in lines if "BU_LIVE_FAIL" in line or "Error:" in line]
        for line in lines:
            if line.startswith("BU:") or "BU_LIVE" in line:
                warn = "FAIL" in line or "UNSAVED" in line
                self.report({"WARNING"} if warn else {"INFO"},
                            line.replace("BU_LIVE_UNSAVED ", "") if "UNSAVED" in line else line)

        if not ok or failed or not any("BU_LIVE_OK" in line for line in lines):
            # Prefer a real explanation over a generic pointer, in this order: an explicit message
            # from the session (a refusal, a dead connection), then the first line Unreal itself
            # flagged, then whatever it said last. "See the Output Log" is the answer of last
            # resort — it is what the artist is already looking at when they read this.
            detail = message or (failed[0] if failed else "")
            if not detail and lines:
                detail = lines[-1]
            if not detail:
                detail = (
                    "the editor ran the script but reported nothing. Check Unreal's Output Log, "
                    "and that the BU plugin is enabled in that project."
                )
            self.report({"ERROR"}, "Unreal import failed: {0}".format(detail))
            return {"CANCELLED"}

        self.report({"INFO"}, "Live export complete -> " + preferences.content_path)
        return {"FINISHED"}


class BU_OT_find_unreal(bpy.types.Operator):
    bl_idname = "bu.find_unreal"
    bl_label = "Find Running Unreal"
    bl_description = (
        "Check which Unreal Editors you opened BU can reach, for Live Export. BU's own hidden "
        "Unreal starts by itself when a viewport is Rendered with the Unreal render engine")
    bl_options = {"REGISTER"}

    def execute(self, context):
        preferences = prefs.get(context)
        engine_dir = preferences.unreal_dir if preferences else ""
        timeout = preferences.discovery_timeout if preferences else 3.0

        module, info = live.load_client(engine_dir)
        if module is None:
            self.report({"ERROR"}, info)
            return {"CANCELLED"}
        self.report({"INFO"}, "Using client: " + str(info))

        with live.Session(
            engine_dir,
            preferences.multicast_group if preferences else "",
            preferences.bind_address if preferences else "",
        ) as session:
            if session.error:
                self.report({"ERROR"}, session.error)
                return {"CANCELLED"}
            nodes = session.nodes(timeout)

        if not nodes:
            self.report(
                {"ERROR"},
                "No Unreal Editor you opened answered. For Live Export, tick its Project "
                "Settings > Plugins > Python > 'Enable Remote Execution?' (off by default) and "
                "restart it." + HIDDEN_UNREAL_HINT,
            )
            return {"CANCELLED"}

        for node in nodes:
            self.report({"INFO"}, "Found: " + live.describe_node(node))
        return {"FINISHED"}


class BU_PT_sidebar(bpy.types.Panel):
    bl_label = "BU — Unreal Bridge"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "BU"

    def draw(self, context):
        layout = self.layout
        preferences = prefs.get(context)

        column = layout.column()
        column.scale_y = 1.5
        column.operator(BU_OT_live_export.bl_idname, icon="EXPORT")

        row = layout.row()
        row.operator(BU_OT_find_unreal.bl_idname, icon="VIEWZOOM")

        if preferences is not None:
            box = layout.box()
            box.label(text="Destination", icon="FILE_FOLDER")
            box.label(text=preferences.content_path)
            box.prop(preferences, "live_format", text="Format")
            box.prop(preferences, "reload_first")
            box.prop(preferences, "pixel_art_preset")

        # Only shown when there is something to fix. A texture trapped in a node group is
        # invisible in Blender — the material looks perfect — so the panel is the only place the
        # artist can find out before the import looks flat.
        try:
            trapped = bake.targets(context)
        except Exception:  # noqa: BLE001 - a panel must never break the UI
            trapped = []
        if trapped:
            box = layout.box()
            box.alert = True
            box.label(text="Textures trapped in node groups", icon="ERROR")
            for material, entry in trapped[:3]:
                box.label(text="{0}: {1}".format(
                    material.name, ", ".join(entry["buried"][:2])), icon="TEXTURE")
            box.label(text="These cannot travel through USD and will arrive flat.")
            box.operator(bake.BU_OT_bake_buried.bl_idname, icon="RENDER_STILL")

        layout.separator()
        filter_ui.draw_unreal_target(layout, context)
        filter_ui.draw_shot(layout, context)
        filter_ui.draw_subdivision(layout, context)

        layout.separator()
        filter_ui.draw_filters(layout, context)

        layout.separator()
        layout.operator(BU_OT_export.bl_idname, text="Export to File…", icon="FILE_TICK")

        scene = context.scene
        bound = [m for m in scene.timeline_markers if m.camera is not None]
        info = layout.box()
        info.label(text="{0} camera cut marker(s)".format(len(bound)), icon="MARKER_HLT")
        if not bound:
            info.label(text="Ctrl+Shift+C binds a camera", icon="INFO")


def menu_func_export(self, context):
    self.layout.operator(BU_OT_export.bl_idname, text="Unreal Bridge (.usd + .bu.json)")


_classes = (BU_OT_export, BU_OT_live_export, BU_OT_scan_unreal, BU_OT_find_unreal, BU_PT_sidebar)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
