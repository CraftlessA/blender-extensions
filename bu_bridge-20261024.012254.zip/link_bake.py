# SPDX-License-Identifier: GPL-3.0-or-later
"""Bake to Match: a material's node chains baked to textures, so Unreal shows exactly Blender's.

For a material set to *Bake to Match* (BU's material panel), every Principled input fed by
nodes that are more than a plain image — a Noise into a Color Ramp, a Mix of two textures — is
baked with Cycles into an image, and the image is sent as an ordinary map. Unreal then shows
Blender's own result, pixel for pixel, at the cost of a bake: about a second after the edits
stop (`QUIET_SECONDS`), and only for materials that asked for it.

The bake borrows the material for a moment: a temporary Emission shader takes the input's source
and an Image Texture node receives the result (Cycles' EMIT bake, one sample — emission needs
no more). The output link, the active node, the render engine and the bake settings are all put
back, whatever happens. The image is baked on one object's UVs (the first visible one using the
material), so objects sharing the material but not its UV layout would see that layout.

Until a material's first bake lands, its inputs are translated (`link_nodes`) instead.
"""

import hashlib
import os
import re
import time

import bpy

try:
    from . import link_material, link_nodes
except ImportError:  # loaded by path in the tests
    import link_material
    import link_nodes

QUIET_SECONDS = 1.0
# Pixels a side of each baked image.
SIZE = 1024
# Principled input -> (channel name, colour?)
INPUTS = (("Base Color", "BaseColor", True), ("Metallic", "Metallic", False),
          ("Roughness", "Roughness", False), ("Alpha", "Opacity", False),
          ("Emission Color", "EmissiveColor", True))
# A failed bake (Edit Mode, no UVs yet) is tried again this much later.
RETRY_SECONDS = 3.0
# material name -> {"inputs": {channel: texture field}, "size": int, "signature": str}
_BAKED = {}
# material name -> what the panel says about its last bake
_STATUS = {}


def wanted(material):
    settings = getattr(material, "bu_link", None)
    return str(getattr(settings, "nodes", "TRANSLATE")) == "BAKE"


def baked(material):
    """{channel: texture field} last baked for this material."""
    return dict((_BAKED.get(material.name) or {}).get("inputs") or {})


def forget(name=None):
    if name is None:
        _BAKED.clear()
        _STATUS.clear()
    else:
        _BAKED.pop(name, None)
        _STATUS.pop(name, None)


def status(material):
    return _STATUS.get(material.name, "")


def due(material, size=None):
    """Whether this material wants a bake and its nodes changed since the last one."""
    if not wanted(material) or material.node_tree is None:
        return False
    return (_BAKED.get(material.name) or {}).get("signature") != signature(material, size)


def invalidate(name):
    """Bake this material again next time, whatever its signature (its images were painted)."""
    entry = _BAKED.get(name)
    if entry is not None:
        entry["signature"] = None


def uses_dirty_image(material):
    """Whether an image the material reads has unsaved changes — painting, usually."""
    def walk(tree, seen):
        if tree is None or tree.name in seen:
            return False
        seen.add(tree.name)
        for node in tree.nodes:
            image = getattr(node, "image", None)
            if image is not None and image.is_dirty:
                return True
            if walk(getattr(node, "node_tree", None), seen):
                return True
        return False
    return walk(material.node_tree, set())


def _tree_signature(tree, seen=None):
    """Everything about a node tree that can change what it shows, as plain values."""
    seen = set() if seen is None else seen
    if tree is None or tree.name in seen:
        return ()
    seen.add(tree.name)
    nodes = []
    for node in sorted(tree.nodes, key=lambda n: n.name):
        props = []
        for prop in node.bl_rna.properties:
            if (prop.type in ("ENUM", "FLOAT", "INT", "BOOLEAN") and not prop.is_readonly
                    and getattr(prop, "array_length", 0) == 0 and prop.identifier not in (
                        "select", "show_options", "show_preview", "hide", "show_texture",
                        "width", "height", "location")):
                props.append((prop.identifier, repr(getattr(node, prop.identifier, None))))
        inputs = [(socket.identifier, repr(tuple(socket.default_value))
                   if hasattr(socket.default_value, "__len__") else repr(socket.default_value))
                  for socket in node.inputs if hasattr(socket, "default_value")]
        extra = ()
        ramp = getattr(node, "color_ramp", None)
        if ramp is not None:
            extra = tuple((round(e.position, 5), tuple(round(c, 5) for c in e.color))
                          for e in ramp.elements)
        image = getattr(node, "image", None)
        if image is not None:
            extra += (image.name, image.filepath, image.source)
        group = _tree_signature(getattr(node, "node_tree", None), seen)
        nodes.append((node.name, node.bl_idname, tuple(props), tuple(inputs), extra, group))
    links = sorted((link.from_node.name, link.from_socket.identifier, link.to_node.name,
                    link.to_socket.identifier, bool(getattr(link, "is_muted", False)))
                   for link in tree.links)
    return (tuple(nodes), tuple(links))


def signature(material, size=None):
    """A hash of everything a bake of this material depends on."""
    size = size or SIZE
    # Not the image epoch: the bake's own images bump it, which would bake forever. Painting is
    # caught by `uses_dirty_image` instead.
    text = repr((_tree_signature(material.node_tree), size))
    return hashlib.sha1(text.encode("utf-8")).hexdigest()


def _shader(material):
    tree = material.node_tree
    output = None
    for target in ("CYCLES", "ALL", "EEVEE"):
        try:
            output = tree.get_output_node(target)
        except (AttributeError, TypeError):
            output = None
        if output is not None:
            break
    surface = output.inputs.get("Surface") if output is not None else None
    if surface is None or not surface.is_linked:
        return None, None
    node = surface.links[0].from_node
    return (node if node.type == "BSDF_PRINCIPLED" else None), output


def _bake_object(material, view_layer):
    for obj in view_layer.objects:
        if (obj.type == "MESH" and obj.visible_get(view_layer=view_layer) and obj.data.uv_layers
                and any(slot.material == material for slot in obj.material_slots)):
            return obj
    return None


def _path(material, channel):
    stem = re.sub(r"[^A-Za-z0-9_]", "_", material.name)[:40]
    digest = hashlib.sha1(material.name.encode("utf-8")).hexdigest()[:8]
    return os.path.join(link_material.packed_folder(),
                        "baked_{0}_{1}_{2}.png".format(stem, digest, channel))


def bake(material, view_layer, size=None):
    """Bake the material's node-driven inputs. Returns (baked channels, why not, or "")."""
    size = size or SIZE
    done, why = _bake(material, view_layer, size)
    if why:
        _STATUS[material.name] = "Not baked: " + why
        return [], why
    _BAKED[material.name] = {"inputs": done, "size": size, "at": time.time(),
                             "signature": signature(material, size)}
    _STATUS[material.name] = ("Baked " + ", ".join(sorted(done)) if done
                              else "Nothing to bake: every input is a value or a plain image")
    return sorted(done), ""


def _bake(material, view_layer, size):
    shader, output = _shader(material)
    if shader is None:
        # Mixed Principled BSDFs are translated through their mixes instead (`link_nodes`).
        return {}, "its surface is not a single Principled BSDF"
    jobs = [(socket_name, channel, colour) for socket_name, channel, colour in INPUTS
            if shader.inputs.get(socket_name) is not None
            and not link_nodes._simple(shader.inputs[socket_name], colour, socket_name)]
    if not jobs:
        return {}, ""
    obj = _bake_object(material, view_layer)
    if obj is None:
        return {}, "no visible mesh with UVs uses it"
    if bpy.context.mode != "OBJECT":
        return {}, "Blender is not in Object Mode"

    scene = bpy.context.scene
    tree = material.node_tree
    surface = output.inputs["Surface"]
    previous = surface.links[0].from_socket
    saved_active = tree.nodes.active
    saved = (scene.render.engine, scene.cycles.samples, scene.render.bake.margin,
             scene.render.bake.use_clear, scene.render.bake.target,
             scene.render.bake.use_selected_to_active)
    emission = tree.nodes.new("ShaderNodeEmission")
    target = tree.nodes.new("ShaderNodeTexImage")
    done = {}
    try:
        scene.render.engine = "CYCLES"
        scene.cycles.samples = 1
        scene.render.bake.margin = 4
        scene.render.bake.use_clear = True
        scene.render.bake.target = "IMAGE_TEXTURES"
        scene.render.bake.use_selected_to_active = False
        tree.links.new(emission.outputs["Emission"], surface)
        for socket_name, channel, colour in jobs:
            source = shader.inputs[socket_name].links[0].from_socket
            for link in list(emission.inputs["Color"].links):
                tree.links.remove(link)
            tree.links.new(source, emission.inputs["Color"])
            emission.inputs["Strength"].default_value = 1.0
            image = bpy.data.images.new("BU_bake_" + channel, size, size, alpha=False)
            image.colorspace_settings.name = "sRGB" if colour else "Non-Color"
            target.image = image
            tree.nodes.active = target
            try:
                override = {"object": obj, "active_object": obj, "selected_objects": [obj],
                            "selected_editable_objects": [obj]}
                windows = bpy.context.window_manager.windows
                if windows:
                    override["window"] = windows[0]  # a timer has none of its own
                with bpy.context.temp_override(**override):
                    bpy.ops.object.bake(type="EMIT")
                path = _path(material, channel)
                image.filepath_raw = path
                image.file_format = "PNG"
                image.save()
                with open(path, "rb") as handle:
                    stamp = hashlib.sha1(handle.read()).hexdigest()[:16]
                found = {"path": path, "stamp": stamp, "nearest": False}
                if not colour:
                    found["linear"] = True
                done[channel] = found
            finally:
                target.image = None
                bpy.data.images.remove(image)
    finally:
        tree.nodes.remove(emission)
        tree.nodes.remove(target)
        tree.links.new(previous, surface)
        if saved_active is not None and saved_active.name in tree.nodes:
            tree.nodes.active = saved_active
        (scene.render.engine, scene.cycles.samples, scene.render.bake.margin,
         scene.render.bake.use_clear, scene.render.bake.target,
         scene.render.bake.use_selected_to_active) = saved
    return done, ""


def apply(spec, material):
    """Put the material's baked images into its description, as ordinary maps.

    Returns the channels it covered, which translation then leaves alone.
    """
    found = baked(material)
    maps = spec.setdefault("maps", {})
    for channel, field in found.items():
        field = dict(field)
        if channel == "BaseColor":
            spec["texture"] = field
            spec["textured"] = True
        elif channel in ("Metallic", "Roughness"):
            maps[channel.lower()] = dict(field, channel="color")
        elif channel == "Opacity":
            spec["mask"] = dict(field, channel="color")
            spec["cutout"] = True
        elif channel == "EmissiveColor":
            maps["emission"] = field
    if not maps:
        spec.pop("maps", None)
    return set(found)
