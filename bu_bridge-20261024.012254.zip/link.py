# SPDX-License-Identifier: GPL-3.0-or-later
"""The real-time link: Blender's scene, live in Unreal, with no file and no sequence.

Live Export writes a USD and has Unreal import it — the right tool for a finished shot, and
fifty seconds to several minutes a time. This is the other thing: a socket that stays open and
carries each object's evaluated mesh as it changes. Because what is sent is the *evaluated*
mesh, everything that changes it comes for free — edits, modifiers, armatures, shape keys, and
therefore the timeline: scrub or play and the frames arrive as Blender evaluates them.

How a change travels:

1. Blender's depsgraph handlers say *which* objects changed and whether it was their geometry or
   only their transform. Nothing is read here; the handler runs inside evaluation.
2. A timer picks the changes up and, within a time budget, extracts and queues them. A moved
   object costs sixteen floats; only a reshaped one costs a mesh.
3. `link_net.Client` sends from its own thread, replacing any older queued version of the same
   object, so a slow link shows fewer frames rather than older ones.

By default Unreal is BU's own: `link_host` starts a hidden editor on a project BU keeps for the
purpose, and closes it when the link stops. The other choice connects to an editor someone has
open, starting the link there over the remote-execution channel Live Export already uses.
"""

import atexit
import time

import bpy
import numpy as np
from bpy.app.handlers import persistent

from . import (link_bake, link_host, link_import, link_instances, link_light, link_lighting, link_material, link_mesh, link_net, link_nodes,
               link_shm, link_surface, link_view, live, prefs)

SYNC_TYPES = {"MESH", "CURVE", "SURFACE", "FONT", "META"}
# Sent as Unreal lights rather than meshes (`link_light`).
LIGHT_TYPES = {"LIGHT"}
IDENTITY = (1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0)


def drawn(obj, view_layer):
    """True for an object the link sends: one Blender's viewport shows.

    Hidden ones are not, nor a mesh shown as Wire or Bounds (no surface drawn, in Rendered
    shading too) unless it is a fog box, nor a particle emitter set not to show itself.
    """
    if not obj.visible_get(view_layer=view_layer):
        return False
    if obj.type not in SYNC_TYPES:
        return True
    if getattr(obj, "is_instancer", False) and not getattr(obj, "show_instancer_for_viewport", True):
        return False
    return not link_lighting.outline_only(obj) or link_lighting.is_volume(obj)


def visibility(obj):
    """What of a drawn object the camera does not see, for Unreal: {} for an ordinary one.

    `camera` False: Ray Visibility's Camera box off (a glowing card lighting a set from out of
    shot), or a holdout. Unreal hides it but keeps its light and its shadow. `shadow` False:
    the Shadow box off.
    """
    found = {}
    if not getattr(obj, "visible_camera", True) or getattr(obj, "is_holdout", False):
        found["camera"] = False
    if not getattr(obj, "visible_shadow", True):
        found["shadow"] = False
    return found

# The tick is also what notices a finished frame, so its period is added to every frame's
# latency. Unreal turns a frame round in about 9 ms; at 30 Hz this was the slowest link in the
# chain by a wide margin.
TICK_SECONDS = 1.0 / 60.0
# How often the newest picture is looked for. 0 is every pass of Blender's event loop, 5.5 ms
# apart when idle (it sleeps 5 ms when there is nothing to do): a 1/60 s timer fires only every
# 21 ms, and a picture waited half that on average. Measured at 3% of one core at most.
FRAME_TICK_SECONDS = 0.0
# A picture announced as it began that has not arrived after this long is given up.
FRAME_WAIT_SECONDS = 1.0
# Pictures whose delay is kept, broken down (link_view.delay_parts): about two seconds' worth.
DELAYS_KEPT = 120
# How long one tick may spend extracting meshes Unreal does not have yet (a scene opening,
# objects added). Blender's UI shares this thread.
EXTRACT_BUDGET = 0.012
# How long one tick may spend on a frame: meshes Unreal already has, changed (an animation, a
# drag). A frame goes whole, or parts of a character arrive frames apart: with the 12 ms budget a
# heavy body used it up and its clothes followed up to eight frames later. Over this, the rest
# goes next tick and Unreal waits for it before rendering.
FRAME_BUDGET = 0.25
# How many frames may be on their way to Unreal, not yet applied there. Unreal says when it has
# applied one ("frame_done"); until then a newer frame waits in Blender, where it is taken in its
# newest state, instead of queueing up behind the others. Blender ran up to nine frames ahead of
# a heavy character, which was all latency, and filled the shared memory part way through a
# frame. Past HOLD_LIMIT without an answer the frame goes anyway.
FRAMES_AHEAD = 1
HOLD_LIMIT = 1.0
# Stop queueing new meshes once this much is waiting to go out; they stay dirty and are picked
# up, in their newest state, when the link has drained.
BACKLOG_LIMIT = 48 * 1024 * 1024
RESCAN_SECONDS = 0.25
KEEPALIVE_SECONDS = 1.0
# How long to hold the first meshes back for Unreal's hello, which says whether it has the
# native module. Sending before knowing would put the whole first sync through the slow path.
HANDSHAKE_SECONDS = 2.0
IMAGE_QUIET_SECONDS = 1.0
# How often BU's own editor is looked at while it starts, and once it runs.
HOST_TICK_SECONDS = 0.5
HOST_IDLE_SECONDS = 1.0


class Sync(object):
    """Tracks what Unreal has and what has changed since."""

    def __init__(self, client, max_triangles=0):
        self.client = client
        self.max_triangles = max_triangles
        self.known = {}        # object name -> tuple of material names last sent
        self.materials = {}    # material name -> the description Unreal has
        self.lights = {}       # light object name -> the description Unreal has
        self.lights_sent = 0
        # How many UV maps Unreal takes per mesh: it says so in its hello. One until then, which
        # is what an older Unreal side reads.
        self.uv_channels = 1
        # Whether Unreal subdivides cages (its hello says): an object ending in Subdivision
        # Surface then goes as the mesh before it, and Blender never subdivides it on the CPU.
        self.subdiv = False
        self.cages_sent = 0
        # Positions-only cages (Unreal's hello says `subdiv_positions`): a mesh whose modifiers
        # before its Subdivision only deform keeps its layout while its data is not edited, so
        # only its points go. The layout each cage was last sent whole with (`cage_layout`), and
        # that message's fields, reused for the positions.
        self.subdiv_positions = False
        self.cage_layouts = {}
        self.cage_fields = {}
        self.cages_moved = 0
        # Cages whose layout no rule vouches for (a curve's, say): how many went as positions
        # since one was read whole (`CAGE_RECHECK`).
        self.cage_unchecked = {}
        # Each object's world matrix as Blender had it when last converted, with what it became:
        # an object that did not move is not converted again every frame.
        self.matrix_sources = {}
        # Imported objects standing for Unreal actors (`link_import`): the converted matrix each
        # was last at, and the actor paths Unreal was last asked to watch.
        self.driven = {}
        self.watched = frozenset()
        self.drives_sent = 0
        # Sky, fog and camera (`link_lighting`): the description Unreal last had, and whether
        # the world or scene changed since. Fog volumes, like lights, by object name.
        self.environment = None
        self.environment_dirty = True
        self.volumes = {}
        self.visible = {}      # mesh name -> its `visibility` as last sent
        # Shared memory for meshes, set once Unreal says it has the native module. None means
        # every mesh goes through the socket as a blob.
        self.arena = None
        # Markers bracket what has been written to the arena: Unreal echoes each one once it
        # has consumed everything sent before it, and only then is the arena reused.
        self.marker_sent = 0
        self.marker_seen = 0
        # Frames: after a tick's changes have all been queued, a "frame_end" message says so, and
        # Unreal renders only between them, never with half a frame applied.
        self.scene_sends = 0
        self.frames_marked = 0
        self.frames_done = 0        # the newest frame Unreal says it has applied
        self.frames_answered = False  # an older Unreal never answers, and is never waited for
        self.held_since = None
        self.arena_meshes = 0
        self.meshes_shared = 0
        self.rescan_materials = False
        # Materials whose own settings changed, when it is known which: an animated value in
        # one material re-describes that one each frame, not all of them.
        self.materials_touched = set()
        # Materials a frame change tagged (drivers, keys), and the driven values each was last
        # described with: unchanged, the description is skipped (`animated_values`).
        self.frame_materials = set()
        self.animated_keys = {}
        # Values-only updates (Unreal's hello says `material_values`): a material whose drivers
        # move only typed-in values of its translated graph sends just those (`matv`), not its
        # description again. Where each graph value is read from (`link_nodes.socket_source`),
        # how many full descriptions agreed with the patched one (-1: one did not, so this
        # material always goes whole), and how many went since the last such check.
        self.material_values = False
        self.value_sources = {}
        self.value_trust = {}
        self.value_unchecked = {}
        self.values_sent = 0
        self.images_changed_at = None
        # When to look for Bake to Match materials whose nodes changed (`link_bake`): edits
        # push it back, so a bake waits until they stop.
        self.bake_due = None
        self.bake_retry_at = None  # bake_due when it is a retry (Edit Mode, no UVs): not waited on
        self.bakes = 0
        self.materials_sent = 0
        # Dicts used as ordered sets: first-dirtied is first-sent, and an object that is dirtied
        # again while waiting keeps its place instead of going to the back.
        self.dirty_geometry = {}
        self.dirty_transform = {}
        self.lights_touched = set()   # lights whose object changed other than by moving
        self.rescan = True
        self.last_scan = 0.0
        self.skipped = {}      # object name -> why it is not being sent
        self.meshes_sent = 0
        self.transforms_sent = 0
        # Unreal adopts what an earlier connection left; the first scan says which of it stays.
        # (Whether a mesh it already has is unchanged, Unreal works out for itself: see
        # `BULinkLibrary.MeshDigest`. Nothing here is hashed.)
        self.keep_pending = True
        # What each mesh last went as: its counts, its data's edit count and its vertex
        # positions. While an animation plays the depsgraph flags every object with a modifier
        # as changed, moved or not; one that has not is not sent again (a 224-piece character
        # had 30 pieces that deformed and 174 that were the same every frame). Positions alone
        # do not show an edit to normals, UVs or face materials, so an edit to an object's own
        # data (Shade Smooth, a UV unwrap) is counted in `data_edits` and always sends it.
        self.shapes = {}
        self.data_edits = {}
        self.matrices = {}     # object name -> the matrix Unreal was last sent for it
        self.topologies = {}   # object name -> its triangles, kept by `link_mesh.extract_native`
        self.meshes_unchanged = 0
        # Instances (`link_instances`): the prototype meshes Unreal has, by content digest, and
        # each instancer's copies as last sent: (prototype digest, matrices digest, visibility).
        self.protos = {}
        self.groups = {}
        self.instances_due = True
        self.scanned = frozenset()  # the objects the last scan found
        self.instancers = frozenset()  # objects whose copies were sent at the last collection
        self.instances_sent = 0
        self.instances_skipped = {}

    # -- called from depsgraph handlers ---------------------------------------------------------

    def note(self, depsgraph, frame=False):
        if depsgraph is not None and getattr(depsgraph, "mode", "VIEWPORT") == "RENDER":
            # A render's own copy of the scene (F12 sends one through the frame handlers, with
            # every object and material in it new): nothing the user changed. Taken as edits,
            # each F12 began by reading the whole scene again and waiting while it was compared.
            return
        self.rescan = True
        if depsgraph is None:
            return
        if depsgraph.id_type_updated("WORLD") or depsgraph.id_type_updated("SCENE"):
            self.environment_dirty = True
        if depsgraph.id_type_updated("LIGHT"):
            # A light's own settings (power, colour, size) tag its data, not its object. Each
            # light is described again and sent only if that changed.
            for name in self.lights:
                self.dirty_geometry[name] = True
        if depsgraph.id_type_updated("IMAGE"):
            # Painting, or a generated image changed. Picked up once the edits stop for
            # IMAGE_QUIET_SECONDS: each refresh writes a PNG here and re-imports it in Unreal,
            # which a brush stroke per tick would turn into a stall per tick.
            self.images_changed_at = time.perf_counter()
        # One pass over what changed: a frame change lists every object that moved, and walking
        # the list again for the materials among it cost a millisecond a frame.
        material_updates = []
        for update in depsgraph.updates:
            target = update.id
            if not isinstance(target, bpy.types.Object):
                if isinstance(target, (bpy.types.Material, bpy.types.ShaderNodeTree)):
                    material_updates.append(update)
                if update.is_updated_geometry and isinstance(target, bpy.types.ID):
                    key = target.name_full
                    self.data_edits[key] = self.data_edits.get(key, 0) + 1
                    if isinstance(target, INSTANCING_DATA):
                        self.instances_due = True
                continue
            name = target.name
            if not self.instances_due and instancing_update(target, update, self.known,
                                                             self.instancers):
                self.instances_due = True
            if update.is_updated_geometry:
                self.dirty_geometry[name] = True
            elif name in self.lights and update.is_updated_shading:
                # A light's Ray Visibility boxes tag its object for shading only. Described
                # again, and sent only if that changed; not as geometry, which would hold back
                # the transform a move sends.
                self.lights_touched.add(name)
            if update.is_updated_transform:
                self.dirty_transform[name] = True
        # Editing a node value tags the material, its node tree, or both depending on the edit;
        # either names the material. Only those are described again: a file with one animated
        # material re-described all 61 every frame, 12 ms of each. A shared shader node group
        # changing could be in any of them, so that describes them all.
        if material_updates:
            touched = touched_materials(material_updates, self.materials)
            if frame:
                # A frame change re-evaluates every driver on a material, changed or not: a
                # character with drivers into 14 materials had all 14 described every frame
                # (3.7 ms each). These are compared first (`_step`).
                self.frame_materials.update(self.materials if touched is None else touched)
            elif touched is None:
                self.rescan_materials = True
                self.value_trust.clear()  # an edit can change what the values decide
            else:
                self.materials_touched.update(touched)
                for name in touched:
                    self.value_trust.pop(name, None)
            # Also what a bake's own borrowing of the material tags; the check after it finds
            # the signature unchanged and does nothing. Only for a material that bakes (Bake
            # to Match): a still (F12) waits for a bake that is due, and every edit to any
            # material made each F12 after it wait a second for none.
            names = self.materials if touched is None else touched
            if any(link_bake.wanted(bpy.data.materials.get(name)) for name in names):
                self.bake_due = time.perf_counter() + link_bake.QUIET_SECONDS

    def resend_everything(self):
        self.protos.clear()
        self.groups.clear()
        self.instances_due = True
        self.scanned = frozenset()
        link_material.images_changed()
        self.known.clear()
        self.materials.clear()
        self.lights.clear()
        self.dirty_geometry.clear()
        self.dirty_transform.clear()
        self.skipped.clear()
        self.driven.clear()
        self.watched = frozenset()
        self.environment = None
        self.environment_dirty = True
        self.volumes.clear()
        self.keep_pending = True
        self.shapes.clear()
        self.cage_layouts.clear()
        self.cage_fields.clear()
        self.cage_unchecked.clear()
        self.matrix_sources.clear()
        self.value_trust.clear()
        self.visible.clear()
        self.matrices.clear()
        self.topologies.clear()
        self.materials_touched.clear()
        self.frame_materials.clear()
        self.animated_keys.clear()
        self.rescan = True
        self.last_scan = 0.0

    # -- called from the timer ------------------------------------------------------------------

    def _scan(self, view_layer):
        current = {}
        for obj in view_layer.objects:
            if ((obj.type in SYNC_TYPES or obj.type in LIGHT_TYPES)
                    and drawn(obj, view_layer)
                    # Imported from Unreal: it is already there, and sent back would sit on top.
                    and not link_import.is_imported(obj)):
                current[obj.name] = obj

        if self.keep_pending:
            self.keep_pending = False
            self.client.send("keep", {"type": "keep", "names": sorted(current)})

        # Hidden in Blender is not deleted in Unreal, so every imported object counts here.
        drivers = {obj.name: obj for obj in view_layer.objects if link_import.is_driver(obj)}
        watched = frozenset(link_import.actor_of(obj) for obj in drivers.values())
        if watched != self.watched:
            self.watched = watched
            self.client.send("watch", {"type": "watch", "paths": sorted(watched)})
        for name in [n for n in self.driven if n not in drivers]:
            del self.driven[name]
        for name, obj in drivers.items():
            if name not in self.driven:
                self.driven[name] = link_mesh.matrix_to_unreal(obj.matrix_world)

        for name in [n for n in self.known if n not in current]:
            del self.known[name]
            self.shapes.pop(name, None)
            self._forget_cage(name)
            self.matrix_sources.pop(name, None)
            self.matrices.pop(name, None)
            self.topologies.pop(name, None)
            self.lights.pop(name, None)
            self.volumes.pop(name, None)
            self.visible.pop(name, None)
            self.skipped.pop(name, None)
            self.dirty_geometry.pop(name, None)
            self.dirty_transform.pop(name, None)
            self.client.drop("xf:" + name)
            # Same key as the mesh, so a mesh still waiting to be sent is replaced by its removal.
            self._send("mesh:" + name, {"type": "delete", "name": name})

        for name, obj in current.items():
            materials = tuple(
                slot.material.name if slot.material else "" for slot in obj.material_slots)
            if name not in self.known:
                self.dirty_geometry[name] = True
            elif self.known[name] != materials:
                self.dirty_geometry[name] = True
            elif (name in self.volumes) != link_lighting.is_volume(obj):
                self.dirty_geometry[name] = True  # its material became, or stopped being, a volume
            elif name in self.visible and self.visible[name] != visibility(obj):
                self.dirty_geometry[name] = True  # a Ray Visibility box changed
        return current

    def unsent(self, since=None):
        """What Blender has noted that is not on its way to Unreal yet, or "": a still (F12)
        must show the scene as it is. `since`: when the still began; a look for objects that
        came or went, due then, is waited for (one follows every edit, RESCAN_SECONDS apart).
        A bake being retried (Edit Mode, no UVs) is not: it may never succeed."""
        if (self.dirty_geometry or self.dirty_transform or self.materials_touched
                or self.rescan_materials or self.frame_materials or self.environment_dirty
                or self.lights_touched or self.keep_pending or self.instances_due
                or (self.rescan and since is not None and self.last_scan < since)):
            return "Sending the scene"
        if self.images_changed_at is not None:
            return "Sending painted images"
        if self.bake_due is not None and self.bake_due != self.bake_retry_at:
            return "Baking textures"
        return ""

    def _send(self, key, header, blob=b""):
        """Queue a message that changes what Unreal shows: part of the frame being sent."""
        self.scene_sends += 1
        self.client.send(key, header, blob)

    def holding(self, now):
        """True while Unreal is FRAMES_AHEAD frames behind: this tick's changes wait."""
        if not self.frames_answered or self.frames_marked - self.frames_done < FRAMES_AHEAD:
            self.held_since = None
            return False
        if self.held_since is None:
            self.held_since = now
        if now - self.held_since < HOLD_LIMIT:
            return True
        # Past the limit one frame goes, and the wait starts again. Left unset, every tick after
        # the first slow answer went: Blender stopped waiting for good, flooded Unreal while it
        # played, and neither side caught up (5.5 frames a second, pictures seconds apart).
        self.held_since = now
        return False

    def step(self, view_layer, depsgraph):
        if self.holding(time.perf_counter()):
            return  # nothing is lost: what changed stays dirty, and goes in its newest state
        sends_before = self.scene_sends
        self._step(view_layer, depsgraph)
        if self.scene_sends != sends_before:
            # The frame Unreal was last told is complete is not any more. Dropped and sent again,
            # the marker goes behind everything of this frame; while some of it is still to come,
            # there is none, and Unreal waits rather than render the half it has.
            if self.client.drop("frame_end"):
                self.frames_marked -= 1  # never sent, so not on its way: its id is used again
            if not self.dirty_geometry:
                self.frames_marked += 1
                self.client.send("frame_end", {"type": "frame_end", "id": self.frames_marked})

    def _step(self, view_layer, depsgraph):
        now = time.perf_counter()
        if self.rescan and now - self.last_scan >= RESCAN_SECONDS:
            self.rescan = False
            self.last_scan = now
            scanned = frozenset(self._scan(view_layer))
            if scanned != self.scanned:
                # Objects came or went: an instancer among them, or one an instancer uses.
                # Not after every scan: a scan follows every frame change, and collecting the
                # instances again each time cost half a second a quarter-second on Ennard.
                self.scanned = scanned
                self.instances_due = True

        objects = view_layer.objects

        if (self.images_changed_at is not None
                and now - self.images_changed_at >= IMAGE_QUIET_SECONDS):
            self.images_changed_at = None
            link_material.images_changed()
            self.rescan_materials = True
            for name in self.materials:
                material = bpy.data.materials.get(name)
                if (material is not None and link_bake.wanted(material)
                        and link_bake.uses_dirty_image(material)):
                    link_bake.invalidate(name)  # painted into: what was baked from it is stale
                    self.bake_due = now

        if self.bake_due is not None and now >= self.bake_due:
            self.bake_due = None
            self._bake(view_layer)

        if self.rescan_materials or self.materials_touched:
            names = list(self.materials) if self.rescan_materials else [
                name for name in self.materials_touched if name in self.materials]
            self.rescan_materials = False
            self.materials_touched.clear()
            for name in names:
                try:
                    self._send_material(name)
                except Exception as exc:  # noqa: BLE001 - one material must not stop the rest
                    _failed_once("material " + name, exc)
            for name in list(self.volumes):
                self.dirty_geometry[name] = True  # a fog volume's settings are its material's

        if self.frame_materials:
            names = [name for name in self.frame_materials if name in self.materials]
            self.frame_materials.clear()
            for name in names:
                key = animated_values(bpy.data.materials.get(name))
                if key is not None and self.animated_keys.get(name) == key:
                    continue  # the frame changed nothing it shows
                try:
                    if key is None or not self._send_values(name):
                        self._send_material(name)
                except Exception as exc:  # noqa: BLE001
                    _failed_once("material " + name, exc)
                if key is not None:
                    self.animated_keys[name] = key

        if self.environment_dirty:
            self.environment_dirty = False
            self._send_environment(view_layer)

        for name in sorted(self.lights_touched):
            obj = objects.get(name)
            if obj is not None and name in self.known and name not in self.dirty_geometry:
                self._send_light(obj, depsgraph)
        self.lights_touched.clear()

        for name in list(self.dirty_transform):
            del self.dirty_transform[name]
            obj = objects.get(name)
            if obj is not None and link_import.is_driver(obj):
                self._drive(obj)
                continue
            if name in self.dirty_geometry or name not in self.known:
                continue  # the mesh message carries the transform too
            if obj is None:
                continue
            matrix = obj.evaluated_get(depsgraph).matrix_world
            if name in self.volumes:
                self._send_volume(obj, depsgraph)  # its size is in its transform
                continue
            if obj.type in LIGHT_TYPES:
                # Scaling an area light resizes it, which is a setting, not a transform. The
                # move itself goes as the transform below, so it is recorded first.
                matrix = link_light.light_matrix(matrix)
                self.matrices[name] = matrix
                self._send_light(obj, depsgraph)
            else:
                matrix = link_mesh.matrix_to_unreal(matrix)
                if self.matrices.get(name) == matrix:
                    continue  # flagged, as everything an armature touches is, but not moved
                self.matrices[name] = matrix
            self._send("xf:" + name, {"type": "xf", "name": name, "matrix": matrix})
            self.transforms_sent += 1

        # Flagged but never sent: armatures, lattices, hidden objects, imports from Unreal
        # (already there: sent, each would be removed again by the next scan). Dropped first, or
        # a rig's armature, never `known`, would make every frame look like a new object
        # arriving, cut to EXTRACT_BUDGET, and no frame would ever be marked whole.
        for name in list(self.dirty_geometry):
            obj = objects.get(name)
            if (obj is None or obj.type not in SYNC_TYPES | LIGHT_TYPES
                    or link_import.is_imported(obj)
                    or not drawn(obj, view_layer)):
                del self.dirty_geometry[name]

        shared_before = self.meshes_shared
        first_sending = any(name not in self.known for name in self.dirty_geometry)
        deadline = now + (EXTRACT_BUDGET if first_sending else FRAME_BUDGET)
        for name in list(self.dirty_geometry):
            if self.client.pending_bytes() > BACKLOG_LIMIT:
                break
            obj = objects[name]
            try:
                if obj.type in LIGHT_TYPES:
                    self._send_light(obj, depsgraph)
                    del self.dirty_geometry[name]
                    continue
                if link_lighting.is_volume(obj):
                    self._send_volume(obj, depsgraph)
                    del self.dirty_geometry[name]
                    continue
                if self.volumes.pop(name, None) is not None:
                    self.known.pop(name, None)  # a fog volume again a mesh: a new actor
                if not self._send_mesh(obj, depsgraph):
                    break  # the arena is full; this object stays dirty until Unreal catches up
            except Exception as exc:  # noqa: BLE001
                # Dropped, not retried every tick: first in line, one object that cannot be
                # read blocked every object behind it and the frame was never marked whole.
                _failed_once("object " + name, exc)
                self.skipped[name] = "could not be sent: {0}".format(exc)
            self.dirty_geometry.pop(name, None)
            if time.perf_counter() >= deadline:
                break

        # After the scene's own objects have arrived: an instancer's copies are extra.
        if self.instances_due and not any(n not in self.known for n in self.dirty_geometry):
            self._sync_instances(view_layer, depsgraph)

        if self.meshes_shared != shared_before:
            # Dropped first so the marker goes to the back of the queue, behind these meshes.
            self.marker_sent += 1
            self.client.drop("sync")
            self.client.send("sync", {"type": "sync", "id": self.marker_sent})
            if self.arena is not None:
                self.arena.fence(self.marker_sent)  # freed when Unreal echoes it

    def _sync_instances(self, view_layer, depsgraph):
        """Send what changed of the scene's instances (`link_instances`): new prototype meshes,
        each instancer's copies as a list of matrices, and removals."""
        self.instances_due = False

        def shows(parent):
            return (parent.visible_get(view_layer=view_layer)
                    and not link_import.is_imported(parent))

        def read(mesh):
            return link_mesh.extract(mesh, self.max_triangles, self.uv_channels)

        found = link_instances.collect(depsgraph, shows, self.protos, read, self.max_triangles)
        for key, (fields, blob, materials) in found.protos.items():
            for material in materials:
                if material and material not in self.materials:
                    self._send_material(material)
            name = link_instances.proto_name(key)
            header = {"type": "mesh", "name": name, "matrix": list(IDENTITY), "proto": True,
                      "materials": list(materials)}
            header.update(fields)
            self._send("mesh:" + name, header, blob)
            self.protos[key] = name
        objects = view_layer.objects
        for name, group in found.groups.items():
            parent = objects.get(group["parent"])
            seen = visibility(parent) if parent is not None else {}
            blob, digest = link_instances.matrices_blob(group["matrices"])
            wanted = (group["key"], digest, tuple(sorted(seen.items())))
            if self.groups.get(name) == wanted:
                continue
            self.groups[name] = wanted
            header = {"type": "instances", "name": name, "count": len(group["matrices"]),
                      "proto": link_instances.proto_name(group["key"])}
            header.update(seen)
            # The mesh key, so a removal queued after it replaces it rather than following it.
            self._send("mesh:" + name, header, blob)
            self.instances_sent += 1
        for name in [n for n in self.groups if n not in found.groups]:
            del self.groups[name]
            self._send("mesh:" + name, {"type": "delete", "name": name})
        for key in [k for k in self.protos if k not in found.keys]:
            name = self.protos.pop(key)
            self._send("mesh:" + name, {"type": "delete", "name": name})
        self.instances_skipped = found.skipped
        self.instancers = frozenset(group["parent"] for group in found.groups.values())

    def _send_volume(self, obj, depsgraph):
        """Queue a fog volume (a mesh with a volume-only material) as a Local Fog Volume."""
        name = obj.name
        matrix, spec = link_lighting.describe_volume(obj.evaluated_get(depsgraph))
        header = dict(spec, matrix=matrix)
        if name in self.known and self.volumes.get(name) == header:
            return
        self._send("mesh:" + name, dict(header, type="volume", name=name))
        self.volumes[name] = header
        self.known[name] = ()

    def _send_environment(self, view_layer):
        """Sky, fog and camera, if they differ from what Unreal has."""
        scene = getattr(view_layer, "id_data", None) or bpy.context.scene
        try:
            spec = link_lighting.describe_environment(scene, level_sky=not _STATE.host_wanted)
        except Exception as exc:  # noqa: BLE001 - an unreadable HDRI must not stop the link
            self.environment_dirty = False
            _STATE.unreal_message = "Sky not sent: {0}".format(exc)
            return
        if spec == self.environment:
            return
        if self.environment is None and not link_lighting.environment_active(spec):
            self.environment = spec  # nothing asked for: leave the level's own lighting alone
            return
        self.environment = spec
        self._send("environment", dict(spec, type="environment"))

    def _drive(self, obj):
        """Move the Unreal actor an imported object stands for, if the object moved."""
        name = obj.name
        matrix = link_mesh.matrix_to_unreal(obj.matrix_world)
        last = self.driven.get(name)
        self.driven[name] = matrix
        if last is None or all(abs(a - b) < 1e-4 for a, b in zip(last, matrix)):
            return  # first seen (just imported), or not really moved
        self._send("drive:" + name, {"type": "drive", "path": link_import.actor_of(obj),
                                           "matrix": matrix})
        self.drives_sent += 1

    def _bake(self, view_layer):
        """Bake every Bake to Match material in use whose nodes changed since its last bake."""
        for name in list(self.materials):
            material = bpy.data.materials.get(name)
            if material is None or not link_bake.due(material):
                continue
            _baked, why = link_bake.bake(material, view_layer)
            if why:
                # Edit Mode, or no UVs yet: try again shortly rather than wait for an edit.
                self.bake_due = time.perf_counter() + link_bake.RETRY_SECONDS
                self.bake_retry_at = self.bake_due
            else:
                self.bakes += 1
            self.rescan_materials = True

    def _send_light(self, obj, depsgraph):
        """Queue a light's description, with its matrix, if it differs from what Unreal has."""
        name = obj.name
        evaluated = obj.evaluated_get(depsgraph)
        spec = link_light.describe(evaluated)
        matrix = link_light.light_matrix(evaluated.matrix_world)
        # The matrix counts too: one light's settings changing marks every light, and the
        # transform pass then leaves them to this; a light moving at the same time froze.
        if name in self.known and self.lights.get(name) == spec                 and self.matrices.get(name) == matrix:
            return
        header = {"type": "light", "name": name, "matrix": matrix}
        header.update(spec)
        # The mesh key, so a removal queued after it replaces it rather than following it.
        self._send("mesh:" + name, header)
        self.lights[name] = spec
        self.matrices[name] = matrix
        self.known[name] = ()
        self.lights_sent += 1

    def _send_mesh(self, obj, depsgraph):
        """Queue one object's mesh. False means it could not go yet and must stay dirty."""
        name = obj.name
        evaluated = obj.evaluated_get(depsgraph)
        materials = tuple(
            slot.material.name if slot.material else "" for slot in obj.material_slots)
        if (self.subdiv and self.arena is not None and obj.type in link_mesh.CAGE_TYPES
                and obj.mode != "EDIT"):
            sent = self._send_cage(obj, evaluated, depsgraph, materials)
            if sent is not None:
                return sent
        # A mesh object's evaluated mesh is read as it is, without the copy `to_mesh` makes,
        # to tell whether it changed: most of a character's pieces have not, each frame.
        shape = None
        if (obj.type == "MESH" and evaluated.data is not None
                and (not len(evaluated.data.vertices) or link_mesh.has_positions(evaluated.data))):
            shape = self._shape(obj, evaluated.data)
            if self._unchanged(name, materials, shape, obj):
                return self._unchanged_sent(name, evaluated)

        try:
            mesh = evaluated.to_mesh()
        except RuntimeError:
            mesh = None
        if mesh is None:
            # A metaball that is not its family's base, or a curve with no geometry: legitimately
            # nothing to draw. Recorded as known so it is not retried every scan.
            self.known[name] = ()
            return True

        if shape is None:
            shape = self._shape(obj, mesh)
            if self._unchanged(name, materials, shape, obj):
                evaluated.to_mesh_clear()
                return self._unchanged_sent(name, evaluated)

        blob = b""
        try:
            fields = None
            if self.arena is not None:
                fields = link_mesh.extract_native(mesh, self.arena, self.max_triangles,
                                                  self.uv_channels,
                                                  self.topologies.setdefault(name, {}))
                # Triangles never outnumber corners, so this bounds the mesh without asking
                # Blender to tessellate it.
                if fields is None and link_mesh.native_bytes(
                        len(mesh.loops), len(mesh.loops), True) <= self.arena.size:
                    return False  # it fits an empty arena; wait for Unreal to catch up
            if fields is None:
                # No shared memory, or a mesh bigger than all of it: the socket still works.
                fields, blob = link_mesh.extract(mesh, self.max_triangles, self.uv_channels)
            elif fields["offset"] is None:
                fields.pop("offset")
                fields["groups"] = []  # empty or over the limit: nothing to read
            else:
                fields["shm"] = {"name": self.arena.name, "offset": fields.pop("offset")}
                self.meshes_shared += 1
        finally:
            evaluated.to_mesh_clear()
        return self._queue_mesh(obj, evaluated, materials, shape, fields, blob)

    def _send_cage(self, obj, evaluated, depsgraph, materials):
        """Queue an object ending in Subdivision Surface as its cage, for Unreal to subdivide.

        The cage is the evaluated geometry's `mesh_base`: Blender leaves its last Subdivision to
        whoever draws, and reading the subdivided mesh instead (`evaluated.data`, `to_mesh`) is
        what made it subdivide on the CPU, every frame, for every such object. Returns what
        `_send_mesh` does, or None when the object is not sent this way after all (no trailing
        Subdivision, or normals Unreal would not match: see `link_mesh.cage_refusal`).
        """
        name = obj.name
        render = depsgraph.scene.render
        modifier = link_mesh.trailing_subsurf(evaluated, render)
        if modifier is None:
            return None
        if self._rigid_unchanged(name, obj, evaluated, render, modifier, materials):
            return self._unchanged_sent(name, evaluated)
        try:
            geometry = evaluated.evaluated_geometry()  # holds the cage: kept until it is read
            cage = geometry.mesh_base
        except (AttributeError, RuntimeError, TypeError, ReferenceError):
            return None
        if cage is None:
            return None
        levels = link_mesh.subdiv_levels(modifier, render)
        packed, settings = link_mesh.subdiv_settings(modifier, levels)
        counts, edits, positions = self._shape(obj, cage)
        shape = ((counts, packed, settings["creases"], "cage"), edits, positions)
        layout = cage_layout(obj, evaluated, render, shape, self.uv_channels)
        learned = layout is None
        if learned:
            # No rule says the layout holds (a curve's comes from its settings, and its filled
            # caps are cut afresh as it bends): read whole every CAGE_RECHECK frames, positions
            # between. Unreal refines a new layout at most once a second, showing the tables it
            # has on the newest positions meanwhile, so reading it every frame showed nothing
            # sooner.
            layout = (shape[0], shape[1], self.uv_channels, obj.type, "learned")
        # What refuses a cage is in its data (sharp edges, custom normals): a layout that went
        # whole before, its data not edited since, was not refused then.
        known = self.cage_layouts.get(name) == layout and (
            not learned or self.cage_unchecked.get(name, 0) < CAGE_RECHECK)
        if not known and link_mesh.cage_refusal(cage, modifier):
            return None
        if self._unchanged(name, materials, shape, obj):
            return self._unchanged_sent(name, evaluated)
        if (known and self.subdiv_positions and self.known.get(name) == materials
                and self.visible.get(name) == visibility(obj)):
            # Only deformed since it went whole: its points alone, nothing else read.
            offset = link_mesh.write_cage_positions(self.arena, shape[2])
            if offset is None:
                return False  # no room until Unreal catches up
            fields = dict(self.cage_fields[name])
            fields["subd"] = dict(fields["subd"], positions_only=1)
            fields["shm"] = {"name": self.arena.name, "offset": offset}
            self.meshes_shared += 1
            self.cages_moved += 1
            if learned:
                self.cage_unchecked[name] = self.cage_unchecked.get(name, 0) + 1
            return self._queue_mesh(obj, evaluated, materials, shape, fields, b"")
        # A curve's filled caps are triangulated afresh as it bends, so its cage can change
        # layout every frame. It still goes as a cage: Blender would rebuild its subdivision
        # from nothing each frame (100 ms for a hand), where Unreal keeps showing it with the
        # tables it has and refines the new layout on a background thread.
        fields = link_mesh.extract_cage(cage, self.arena, modifier, levels, self.max_triangles,
                                        self.uv_channels)
        if fields is None:
            if link_mesh.cage_bytes(len(cage.vertices), len(cage.polygons), len(cage.loops),
                                    self.uv_channels, True, 0, 0) <= self.arena.size:
                return False  # it fits an empty arena; wait for Unreal to catch up
            return None  # bigger than all of it: the subdivided mesh, through the socket
        del geometry, cage
        if fields["offset"] is None:
            fields.pop("offset")
            fields["groups"] = []  # over the limit: nothing to read
        else:
            fields["shm"] = {"name": self.arena.name, "offset": fields.pop("offset")}
            self.meshes_shared += 1
            self.cages_sent += 1
        queued = self._queue_mesh(obj, evaluated, materials, shape, fields, b"")
        if "shm" in fields:
            self.cage_unchecked[name] = 0
            self.cage_layouts[name] = layout
            self.cage_fields[name] = {k: v for k, v in fields.items() if k != "shm"}
        return queued

    def _queue_mesh(self, obj, evaluated, materials, shape, fields, blob):
        """Queue a mesh message (and the materials it wears, first). True."""
        name = obj.name
        self.known[name] = materials
        self.shapes[name] = shape
        if "subd" not in fields:
            # A plain mesh now: Unreal forgets the cage, so positions alone would find none.
            self._forget_cage(name)
        if fields["skipped"]:
            self.skipped[name] = fields["skipped"]
        else:
            self.skipped.pop(name, None)

        # Queued ahead of the mesh that wears them, so Unreal never has to guess.
        for material in materials:
            if material and material not in self.materials:
                self._send_material(material)

        header = {
            "type": "mesh",
            "name": name,
            "matrix": link_mesh.matrix_to_unreal(evaluated.matrix_world),
            "materials": list(materials),
        }
        self.matrices[name] = header["matrix"]
        seen = visibility(obj)
        self.visible[name] = seen
        header.update(seen)
        header.update(fields)
        self.client.drop("xf:" + name)
        self._send("mesh:" + name, header, blob)
        self.meshes_sent += 1
        return True

    def _unchanged_sent(self, name, evaluated):
        """A mesh Unreal already has as it is: only its transform goes, if that moved."""
        raw = evaluated.matrix_world
        source = self.matrix_sources.get(name)
        if source is not None and source[0] == raw and self.matrices.get(name) == source[1]:
            self.meshes_unchanged += 1
            return True
        matrix = link_mesh.matrix_to_unreal(raw)
        self.matrix_sources[name] = (raw.copy(), matrix)
        if self.matrices.get(name) != matrix:
            self.matrices[name] = matrix
            self._send("xf:" + name, {"type": "xf", "name": name, "matrix": matrix})
            self.transforms_sent += 1
        self.meshes_unchanged += 1
        return True

    def _shape(self, obj, mesh):
        """What says whether a mesh changed: (counts, edits to its data, positions)."""
        data = obj.data
        edits = self.data_edits.get(data.name_full, 0) if data is not None else 0
        counts = (len(mesh.vertices), len(mesh.loops), len(mesh.polygons))
        return counts, edits, link_mesh.vertex_positions(mesh)

    def _rigid_unchanged(self, name, obj, evaluated, render, modifier, materials):
        """True for a cage that cannot have changed since it went: a mesh or curve with nothing
        before its Subdivision and no shape keys is its own data, which changes only by an edit
        (counted in `data_edits`); a curve also needs no other object shaping it (a bevel or
        taper object). Blender flags such curves as changed every frame they move: a character's
        tubes, moved by their parent bones, were read and compared every frame (28 of Ennard's
        a frame), only to be found the same."""
        last = self.shapes.get(name)
        data = obj.data
        if (last is None or last[0][3] != "cage" or obj.type not in ("MESH", "CURVE")
                or getattr(data, "shape_keys", None) is not None):
            return False
        if obj.type == "CURVE" and (
                getattr(data, "bevel_object", None) is not None
                or getattr(data, "taper_object", None) is not None):
            return False
        for found in evaluated.modifiers:
            if found.type == "SUBSURF":
                break
            if link_mesh.modifier_active(found, render):
                return False
        edits = self.data_edits.get(data.name_full, 0)
        packed, settings = link_mesh.subdiv_settings(
            modifier, link_mesh.subdiv_levels(modifier, render))
        return (last[1] == edits and last[0][1] == packed and last[0][2] == settings["creases"]
                and self.known.get(name) == materials and self.visible.get(name) == visibility(obj))

    def _forget_cage(self, name):
        for kept in (self.cage_layouts, self.cage_fields, self.cage_unchecked):
            kept.pop(name, None)

    def resend(self, name):
        """Unreal asked for a whole cage: it had none to move (`ApplySubdivPositions` -7)."""
        self.shapes.pop(name, None)
        self._forget_cage(name)
        if name in self.known:
            self.dirty_geometry[name] = True
        self.rescan = True

    def _unchanged(self, name, materials, shape, obj=None):
        """True if Unreal already has this mesh exactly as it would be sent now."""
        last = self.shapes.get(name)
        if obj is not None and self.visible.get(name) != visibility(obj):
            return False
        return (last is not None and self.known.get(name) == materials
                and last[0] == shape[0] and last[1] == shape[1]
                and np.array_equal(last[2], shape[2]))

    def _send_material(self, name):
        """Describe one material to Unreal, if what it has is out of date."""
        material = bpy.data.materials.get(name)
        if material is None:
            self.materials.pop(name, None)
            return
        sources = {}
        spec = link_material.describe(material, sources)
        if name not in self.materials and self.bake_due is None and link_bake.due(material):
            # Sent for the first time: translated now, baked once the link settles.
            self.bake_due = time.perf_counter() + link_bake.QUIET_SECONDS
        self._commit_material(name, spec, sources)

    def _commit_material(self, name, spec, sources):
        if sources != self.value_sources.get(name):
            self.value_sources[name] = sources
            self.value_trust.pop(name, None)
        if self.materials.get(name) == spec:
            return
        self.materials[name] = spec
        header = {"type": "mat", "name": name}
        header.update(spec)
        # A values-only message still waiting would land after this and put older values back.
        self.client.drop("matv:" + name)
        self._send("mat:" + name, header)
        self.materials_sent += 1

    def _send_values(self, name):
        """Send only a driven material's changed graph values, if that is all that changed.

        True when handled. False when the material has to be described whole: Unreal has not
        said it takes values, a driver moves something that is not a graph value (a Principled
        input sent as a plain number, a ramp's colour), or a full description once disagreed
        with the patched one. The first VALUES_VERIFY times, and every VALUES_RECHECK after,
        the material is described anyway and the two compared: a description can also decide
        things from a value (a cutout from its alpha), which a patch would miss.
        """
        material = bpy.data.materials.get(name)
        previous = self.materials.get(name)
        if not self.material_values or material is None or previous is None:
            return False
        trust = self.value_trust.get(name, 0)
        if trust < 0:
            return False
        values = driven_values(material, self.value_sources.get(name), previous)
        if values is None:
            return False
        patched = patched_spec(previous, values)
        if trust < VALUES_VERIFY or self.value_unchecked.get(name, 0) >= VALUES_RECHECK:
            sources = {}
            spec = link_material.describe(material, sources)
            self.value_unchecked[name] = 0
            if spec != patched or sources != self.value_sources.get(name):
                self._commit_material(name, spec, sources)
                self.value_trust[name] = -1
                return True
            self.value_trust[name] = trust + 1
        else:
            self.value_unchecked[name] = self.value_unchecked.get(name, 0) + 1
        if patched == previous:
            return True
        self.materials[name] = patched
        self._send("matv:" + name, {"type": "matv", "name": name, "values": values})
        self.values_sent += 1
        return True


def touched_materials(updates, known):
    """Names of the materials a depsgraph update changed, or None if that cannot be told.

    A material's settings live on the material and on its own (embedded) node tree, and an edit
    tags either or both. A shared shader node group could be in any material, so one of those
    changing is None: describe them all. Other node trees (geometry nodes) do not describe a
    material.
    """
    touched = set()
    trees = set()
    for update in updates:
        found = update.id
        # The type first: a frame change lists every moved object, and asking each for its
        # original was most of this.
        if not isinstance(found, (bpy.types.Material, bpy.types.ShaderNodeTree)):
            continue
        target = getattr(found, "original", None) or found
        if isinstance(target, bpy.types.Material):
            touched.add(target.name)
        elif not target.is_embedded_data:
            return None
        else:
            trees.add(target.as_pointer())
    for pointer in trees:
        name = _tree_owner(pointer, known)
        if name is not None:
            touched.add(name)
    return touched


# Embedded node tree (pointer) -> the material it belongs to, rebuilt when one is not found.
_TREE_OWNERS = {}


def _tree_owner(pointer, known):
    """The known material whose own node tree this is, or None."""
    for attempt in range(2):
        name = _TREE_OWNERS.get(pointer)
        if name is not None and name in known:
            material = bpy.data.materials.get(name)
            tree = material.node_tree if material is not None else None
            if tree is not None and tree.as_pointer() == pointer:
                return name
        if attempt == 0:
            _TREE_OWNERS.clear()
            for known_name in known:
                material = bpy.data.materials.get(known_name)
                tree = material.node_tree if material is not None else None
                if tree is not None:
                    _TREE_OWNERS[tree.as_pointer()] = known_name
    return None


class _State(object):
    client = None
    sync = None
    status = "Not connected"
    project = ""
    unreal_message = ""
    frames = 0
    frame_times = []
    frame_delays = []      # link_view.delay_parts of the last DELAYS_KEPT pictures
    last_keepalive = 0.0
    unreal_stats = None
    frame_ms = 0.0         # Blender's own cost to read the newest frame
    pending_frames = []    # frame files announced but not yet readable
    shared_frames = []     # frames announced in shared memory, not yet copied out
    started = 0.0
    handshaken = False     # Unreal has answered the hello
    upscalers = None       # the upscaler plugins Unreal said it has (None: not heard yet)
    arena = None           # link_shm.Arena for meshes, when Unreal has the native module
    frame_ring = None      # link_shm.Arena Unreal writes pictures into
    unreal_materials = []  # the project's materials, for "Use an Unreal Material"
    unreal_assets = {}     # kind -> asset paths, for the Unreal Light panel's pickers
    assets_asked = {}      # kind -> when they were last asked for
    import_status = ""     # the last "Import from Unreal", for the panel
    materials_asked = 0.0  # when they were last asked for
    host_wanted = False    # BU's own editor should be running and connected


_STATE = _State()


def is_running():
    return _STATE.client is not None and _STATE.client.alive


def lighting_changed():
    """An Unreal Light, Sky & Fog or Camera setting changed: describe them again."""
    if _STATE.sync is not None:
        _STATE.sync.environment_dirty = True
        for name in _STATE.sync.lights:
            _STATE.sync.dirty_geometry[name] = True


def unreal_assets(kind):
    """Asset paths of one kind ("ies", "light_function", "texture"), asking Unreal if unknown."""
    found = _STATE.unreal_assets.get(kind)
    if found is None:
        request_unreal_assets(kind)
    return found or []


def request_unreal_assets(kind, force=False):
    now = time.perf_counter()
    if is_running() and (force or now - _STATE.assets_asked.get(kind, -10.0) > 5.0):
        _STATE.assets_asked[kind] = now
        _STATE.client.send("list_assets:" + kind, {"type": "list_assets", "kind": kind})


def material_settings_changed():
    """BU's material panel changed a setting: describe the materials in use again."""
    if _STATE.sync is not None:
        _STATE.sync.rescan_materials = True
        _STATE.sync.bake_due = time.perf_counter()  # a material may now want a bake


def bake_now(name):
    """Bake one material at the next tick (the panel's button), whatever its signature."""
    link_bake.invalidate(name)
    if _STATE.sync is not None:
        _STATE.sync.bake_due = time.perf_counter()


def rescan_scene():
    """Look at which objects to send again (after objects stop being imports)."""
    if _STATE.sync is not None:
        _STATE.sync.rescan = True


def request_export(scope, source_model=False, texture_size=1024):
    """Ask Unreal to export actors for `link_import` to bring in."""
    if is_running():
        link_import.request(_STATE.client, scope, source_model, texture_size)
        _STATE.import_status = "Waiting for Unreal to export…"


def _finish_import(path, actors=None):
    try:
        created = link_import.import_file(path, actors=actors)
    except Exception as exc:  # noqa: BLE001 - shown in the panel rather than lost in a timer
        _STATE.import_status = "Import failed: {0}".format(exc)
    else:
        _STATE.import_status = "Imported {0} object(s) from Unreal".format(len(created))
    _redraw_viewports()
    return None  # a one-shot timer


def released_imports(paths):
    """Imported objects whose Unreal actors were deleted: send them instead. Returns how many."""
    paths = set(str(path) for path in paths or ())
    count = 0
    for obj in bpy.data.objects:
        if link_import.actor_of(obj) in paths:
            link_import.release(obj)
            count += 1
    if count:
        rescan_scene()
    return count


def sent_material(name):
    """What Unreal was last told about this material, or None."""
    return _STATE.sync.materials.get(name) if _STATE.sync is not None else None


def unreal_materials():
    return _STATE.unreal_materials


def request_unreal_materials():
    """Ask Unreal for its project's materials; the answer arrives as a "materials" message."""
    now = time.perf_counter()
    if is_running() and now - _STATE.materials_asked > 1.0:
        _STATE.materials_asked = now
        _STATE.client.send("list_materials", {"type": "list_materials"})


def _context_bits():
    """A view layer and its depsgraph, from a timer — where `bpy.context` has no window."""
    window_manager = bpy.context.window_manager
    window = window_manager.windows[0] if window_manager and window_manager.windows else None
    if window is not None:
        view_layer = window.view_layer
    else:
        view_layer = bpy.context.view_layer
    return view_layer, view_layer.depsgraph


def _redraw_viewports(kinds=("VIEW_3D",)):
    window_manager = bpy.context.window_manager
    if window_manager is None:
        return
    for window in window_manager.windows:
        for area in window.screen.areas:
            if area.type in kinds:
                area.tag_redraw()


_FAILURES = set()


def _node_trees(tree, seen=None):
    """A node tree and every group tree it uses, each once."""
    seen = set() if seen is None else seen
    if tree is None or tree.as_pointer() in seen:
        return seen
    seen.add(tree.as_pointer())
    yield tree
    for node in tree.nodes:
        if node.type == "GROUP" and node.node_tree is not None:
            for inner in _node_trees(node.node_tree, seen):
                yield inner


# Full descriptions that must agree with the patched one before a material's driven values go
# alone, and how many values-only updates go between two more such checks.
VALUES_VERIFY = 2
VALUES_RECHECK = 30
DEFAULT_VALUE = ".default_value"


# Positions-only frames between two whole reads of a cage no rule vouches for.
CAGE_RECHECK = 20

# Modifiers that only move vertices: before a Subdivision, the cage keeps the mesh's own layout
# (faces, corners, UVs, colours, creases) whatever they do.
DEFORM_ONLY = frozenset((
    "ARMATURE", "CAST", "CURVE", "DISPLACE", "HOOK", "LAPLACIANDEFORM", "LAPLACIANSMOOTH",
    "LATTICE", "MESH_CACHE", "MESH_DEFORM", "SHRINKWRAP", "SIMPLE_DEFORM", "SMOOTH",
    "CORRECTIVE_SMOOTH", "SURFACE_DEFORM", "WARP", "WAVE"))


def cage_layout(obj, evaluated, render, shape, uv_channels):
    """What a cage's layout depends on, when only that can change it; None when something else
    can (a curve's caps, a generating modifier, Geometry Nodes): then it is read every time.

    A mesh whose modifiers before its last Subdivision all only deform has its own data's
    layout: the same while the data is not edited (`shape`'s counts, settings and edit count).
    """
    if obj.type != "MESH":
        return None
    stack = []
    for modifier in evaluated.modifiers:
        if not link_mesh.modifier_active(modifier, render):
            continue
        if modifier.type == "SUBSURF":
            break
        if modifier.type not in DEFORM_ONLY:
            return None
        stack.append(modifier.type)
    return (shape[0], shape[1], uv_channels, tuple(stack),
            getattr(obj.data, "name_full", ""))


def driven_values(material, sources, spec):
    """{parameter: value} for every graph value a driver on this material moves, read now; None
    if any driver moves something else (then the material is described whole).

    `sources` is `link_material.describe`'s (parameter -> (tree, socket path)); a driver names
    the same socket as `<path>.default_value` on the node tree it lives in.
    """
    if material is None or not sources or not isinstance((spec or {}).get("graph_values"), dict):
        return None
    data = getattr(material, "animation_data", None)
    if data is not None and len(data.drivers):
        return None  # on the material itself (its viewport colour, say): not a socket
    by_socket = {}
    for param, source in sources.items():
        by_socket.setdefault(tuple(source), []).append(param)
    values = {}
    for tree in _node_trees(material.node_tree):
        data = getattr(tree, "animation_data", None)
        if data is None:
            continue
        owner = "" if tree.is_embedded_data else tree.name
        for curve in data.drivers:
            path = curve.data_path
            if not path.endswith(DEFAULT_VALUE):
                return None
            path = path[:-len(DEFAULT_VALUE)]
            params = by_socket.get((owner, path))
            if not params:
                return None
            try:
                value = tree.path_resolve(path).default_value
            except (ValueError, TypeError, AttributeError):
                return None
            for param in params:
                kind = "c" if isinstance(spec["graph_values"].get(param), list) else "f"
                try:
                    values[param] = link_nodes.param_value(
                        value if kind == "f" else tuple(value), kind)
                except (TypeError, ValueError):
                    return None
    return values or None


def patched_spec(spec, values):
    """`spec` with some graph values replaced. Pure."""
    patched = dict(spec)
    patched["graph_values"] = dict(spec.get("graph_values") or {})
    patched["graph_values"].update(values)
    return patched


def animated_values(material):
    """The current values of every driver on a material and the node trees it uses, as a
    tuple; None when they cannot be compared (a keyed action, a path that does not resolve):
    then the material is always described again."""
    if material is None:
        return None
    values = []
    owners = [material] + list(_node_trees(material.node_tree))
    for owner in owners:
        data = getattr(owner, "animation_data", None)
        if data is None:
            continue
        if data.action is not None:
            return None
        for curve in data.drivers:
            try:
                value = owner.path_resolve(curve.data_path)
                if hasattr(value, "__len__"):
                    value = value[curve.array_index]
                values.append((curve.data_path, curve.array_index, round(float(value), 6)))
            except (ValueError, TypeError, IndexError, AttributeError):
                return None
    return tuple(values)
# Data whose change can change what instancers produce.
INSTANCING_DATA = (bpy.types.ParticleSettings, bpy.types.GeometryNodeTree)
INSTANCED_TYPES = frozenset(("MESH", "CURVE", "SURFACE", "FONT", "META"))


def instancing_update(obj, update, known, instancers):
    """Whether this object's update can change the scene's instances, so that they are collected
    again: an instancer (an instance type, particles, Geometry Nodes, or one with copies sent),
    or a geometry change on an object not sent itself, which an instancer may be copying (a
    collection instance's contents). An armature posing a character, or the character's own
    meshes deforming, does not."""
    original = getattr(obj, "original", None) or obj
    if (getattr(original, "instance_type", "NONE") != "NONE"
            or len(getattr(original, "particle_systems", ()))
            or any(m.type == "NODES" for m in getattr(original, "modifiers", ()))):
        return True
    if update.is_updated_geometry and original.name not in known             and original.type in INSTANCED_TYPES:
        return True
    return original.name in instancers


def _failed_once(what, exc):
    """Print a failure's traceback the first time it happens, not every tick."""
    key = (what, type(exc).__name__, str(exc))
    if key in _FAILURES:
        return
    _FAILURES.add(key)
    import traceback

    print("BU link: {0} failed: {1}".format(what, exc))
    traceback.print_exc()


@persistent
def _on_depsgraph(scene, depsgraph=None):
    if _STATE.sync is not None:
        _STATE.sync.note(depsgraph)


@persistent
def _on_frame_change(scene, depsgraph=None):
    if _STATE.sync is not None:
        _STATE.sync.note(depsgraph, frame=True)


@persistent
def _on_load(*_args):
    # A different file is a different scene: nothing Unreal holds can be assumed to match.
    if _STATE.sync is not None:
        _STATE.sync.resend_everything()
        if _STATE.client is not None:
            # Not a clear: the first scan's "keep" removes what this file does not have, and
            # what it does have, unchanged, stays as Unreal built it.
            _STATE.client.send("hello", {"type": "hello"})


def _handle_message(header):
    kind = header.get("type")
    if kind == "hello":
        _STATE.project = str(header.get("project") or "")
        if _STATE.host_wanted:
            _STATE.status = "Connected to BU's Unreal {0}".format(link_host.HOST.version).strip()
        else:
            _STATE.status = "Connected to " + (_STATE.project or "Unreal")
        _STATE.handshaken = True
        if _STATE.sync is not None:
            try:
                _STATE.sync.uv_channels = max(1, min(8, int(header.get("uv_channels") or 1)))
            except (TypeError, ValueError):
                _STATE.sync.uv_channels = 1
            _STATE.sync.material_values = bool(header.get("material_values"))
            _STATE.sync.subdiv_positions = bool(header.get("subdiv_positions"))
            subdiv = bool(header.get("subdiv"))
            if subdiv != _STATE.sync.subdiv:
                _STATE.sync.subdiv = subdiv
                if _STATE.sync.known:
                    # Sent the other way already (subdivided, or as cages): again, this way.
                    _STATE.sync.resend_everything()
        _open_shared(header.get("native"))
        found = header.get("upscalers")
        _STATE.upscalers = [str(name) for name in found] if isinstance(found, list) else []
    elif kind == "resend":
        if _STATE.sync is not None:
            _STATE.sync.resend(str(header.get("name") or ""))
    elif kind == "synced":
        if _STATE.sync is not None:
            _STATE.sync.marker_seen = max(_STATE.sync.marker_seen, int(header.get("id") or 0))
            if _STATE.sync.arena is not None:
                _STATE.sync.arena.consumed(_STATE.sync.marker_seen)
    elif kind == "frame_done":
        if _STATE.sync is not None:
            _STATE.sync.frames_answered = True
            _STATE.sync.frames_done = max(_STATE.sync.frames_done, int(header.get("id") or 0))
    elif kind == "frame" and "slot" in header:
        _STATE.shared_frames.append(header)
    elif kind == "frame":
        path = header.get("path") or ""
        if path:
            # Only the newest matters; an older one still queued is already out of date.
            _STATE.pending_frames = [(
                path, time.perf_counter(), header.get("width", 0), header.get("height", 0),
                header.get("crop"), header.get("seq"), link_view.still_report(header))]
    elif kind == "log":
        _STATE.unreal_message = str(header.get("text") or "")
    elif kind == "stats":
        _STATE.unreal_stats = header
    elif kind == "materials":
        _STATE.unreal_materials = [str(path) for path in header.get("paths") or ()]
    elif kind == "assets":
        _STATE.unreal_assets[str(header.get("kind") or "")] = [
            str(path) for path in header.get("paths") or ()]
    elif kind == "gone":
        released = released_imports(header.get("paths"))
        if released:
            _STATE.import_status = ("{0} object(s) deleted in Unreal are now sent from "
                                    "Blender".format(released))
    elif kind == "export_done":
        if header.get("error"):
            _STATE.import_status = "Unreal: " + str(header["error"])
        else:
            # Not from inside the link's tick: an import adds objects, and runs operators.
            path = str(header.get("path") or "")
            actors = list(header.get("actors") or ())
            bpy.app.timers.register(lambda: _finish_import(path, actors), first_interval=0.01)
            _STATE.import_status = "Importing {0} actor(s)…".format(header.get("count", 0))


def _open_shared(native):
    """Create the shared memory, once Unreal has said its native module can read it."""
    try:
        native = int(native or 0)
    except (TypeError, ValueError):
        native = 0
    if (_STATE.arena is not None or _STATE.client is None
            or native != link_shm.NATIVE_VERSION or not link_shm.available()):
        return
    token = link_shm.new_token()
    arena = ring = None
    try:
        arena = link_shm.Arena("Local\\bu-{0}-mesh".format(token), link_shm.MESH_ARENA_BYTES)
        ring = link_shm.Arena("Local\\bu-{0}-frames".format(token),
                              link_shm.FRAME_SLOTS * link_shm.FRAME_SLOT_BYTES)
    except (OSError, ValueError, MemoryError) as exc:
        if arena is not None:
            arena.close()
        _STATE.unreal_message = "No shared memory ({0}); using the socket".format(exc)
        return

    _STATE.arena, _STATE.frame_ring = arena, ring
    if _STATE.sync is not None:
        _STATE.sync.arena = arena
    client = _STATE.client
    frames = {"name": ring.name, "slots": link_shm.FRAME_SLOTS,
              "slot_bytes": link_shm.FRAME_SLOT_BYTES}
    link_view.set_sender(lambda header: client.send("view", dict(header, frames=frames)))
    link_view.resend_view()


def _close_shared():
    for arena in (_STATE.arena, _STATE.frame_ring):
        if arena is not None:
            arena.close()
    _STATE.arena = None
    _STATE.frame_ring = None
    _STATE.shared_frames = []


def _service_shared_frames():
    frames, _STATE.shared_frames = _STATE.shared_frames, []
    ring, client = _STATE.frame_ring, _STATE.client
    if not frames or ring is None or client is None:
        return

    def release(header):
        slot = int(header.get("slot") or 0)
        client.send("frame_ack:{0}".format(slot), {"type": "frame_ack", "slot": slot})

    def offset(header):
        return int(header.get("slot") or 0) * link_shm.FRAME_SLOT_BYTES

    # Announced as Unreal began them: each is taken once its ready word says it is copied.
    now = time.perf_counter()
    ready = []
    for header in frames:
        state = link_view.frame_state(ring.view, offset(header), header)
        if state == link_view.FRAME_READY:
            ready.append(header)
        elif state == link_view.FRAME_FAILED:
            release(header)
        elif now - header.setdefault("_heard", now) > FRAME_WAIT_SECONDS:
            release(header)  # never came; Unreal takes the slot back by itself as well
        else:
            _STATE.shared_frames.append(header)
    if not ready:
        return
    # Several can be ready at once. Only the newest is worth copying; the rest go straight
    # back so Unreal has somewhere to put the next one.
    for header in ready[:-1]:
        release(header)
    newest = ready[-1]
    if newest.get("ready") and newest.get("times"):
        newest["times"]["ready"] = now
    started = time.perf_counter()
    slot = int(newest.get("slot") or 0)
    accepted = 0 <= slot < link_shm.FRAME_SLOTS and link_view.accept_shared(
        ring.view, offset(newest),
        newest.get("width", 0), newest.get("height", 0), bool(newest.get("linear")),
        newest.get("crop"), newest.get("seq"), link_view.frame_depth(ring.view, offset(newest), newest),
        link_view.still_report(newest))
    # Only now: the sender is another thread, and Unreal may reuse the slot the moment it hears.
    release(newest)
    if accepted:
        now = time.perf_counter()
        _STATE.frame_ms = (now - started) * 1000.0
        parts = link_view.delay_parts(link_view._sent_times.get(newest.get("seq")),
                                      newest.get("times"), now)
        if parts is not None:
            _STATE.frame_delays = _STATE.frame_delays[-(DELAYS_KEPT - 1):] + [parts]
        _STATE.frames += 1
        _STATE.frame_times = [t for t in _STATE.frame_times if now - t < 2.0] + [now]
        for area in link_view.active_viewports(bpy.context.window_manager):
            area.tag_redraw()


def _service_frames():
    _service_shared_frames()
    if not _STATE.pending_frames:
        return
    path, announced, width, height, crop, seq, report = _STATE.pending_frames[0]
    started = time.perf_counter()
    if link_view.accept_frame(path, width, height, crop, seq, report):
        _STATE.pending_frames = []
        now = time.perf_counter()
        _STATE.frame_ms = (now - started) * 1000.0
        _STATE.frames += 1
        _STATE.frame_times = [t for t in _STATE.frame_times if now - t < 2.0] + [now]
        for area in link_view.active_viewports(bpy.context.window_manager):
            area.tag_redraw()
    elif time.perf_counter() - announced > 1.0:
        _STATE.pending_frames = []  # never became readable; wait for the next one


def _frame_tick():
    """What Unreal sent, pictures above all, as soon as Blender's event loop comes round."""
    client = _STATE.client
    if client is None:
        return None
    if not client.alive:
        return FRAME_TICK_SECONDS  # `_tick` says why and stops the link
    try:
        for header, _blob in client.poll():
            _handle_message(header)
        _service_frames()
    except Exception as exc:  # noqa: BLE001 - a timer that raises is silently unregistered
        _STATE.status = "Link error: {0}".format(exc)
        import traceback

        traceback.print_exc()
    return FRAME_TICK_SECONDS


def _tick():
    client = _STATE.client
    if client is None:
        return None
    if not client.alive:
        reason = client.error or "The link closed."
        stop()
        _STATE.status = reason
        _redraw_viewports()
        return None

    try:
        for header, _blob in client.poll():
            _handle_message(header)
        _service_frames()

        now = time.perf_counter()
        view_layer, depsgraph = _context_bits()
        if (_STATE.sync is not None and depsgraph is not None
                and (_STATE.handshaken or now - _STATE.started > HANDSHAKE_SECONDS)):
            try:
                _STATE.sync.step(view_layer, depsgraph)
            except Exception as exc:  # noqa: BLE001
                # Reported, and the keep-alive below still goes: behind a failing step it did
                # not, and after VIEW_TIMEOUT Unreal stopped drawing a viewport left still.
                _STATE.status = "Link error: {0}".format(exc)
                _failed_once("sync", exc)

        if now - _STATE.last_keepalive >= KEEPALIVE_SECONDS:
            _STATE.last_keepalive = now
            window_manager = bpy.context.window_manager
            sync_view_overrides({w.scene for w in window_manager.windows if w.scene},
                                colour_mode(window_manager))
            if (link_view.active_viewports(bpy.context.window_manager)
                    or link_view._render_view is not None):
                link_view.resend_view()
    except Exception as exc:  # noqa: BLE001 - a timer that raises is silently unregistered
        _STATE.status = "Link error: {0}".format(exc)
        import traceback

        traceback.print_exc()
    return TICK_SECONDS


def start(port, max_triangles=0, material_root="/Game", clear=False):
    """Connect to a listening Unreal and begin streaming. Returns (ok, message)."""
    stop()
    client = link_net.Client(port=port)
    if not client.connect(timeout=1.0):
        return False, client.error

    _STATE.client = client
    _STATE.sync = Sync(client, max_triangles=max_triangles)
    _STATE.status = "Connected"
    _STATE.project = ""
    _STATE.unreal_message = ""
    _STATE.unreal_stats = None
    _STATE.frames = 0
    _STATE.frame_times = []
    _STATE.frame_delays = []
    _STATE.pending_frames = []
    _STATE.shared_frames = []
    _STATE.started = time.perf_counter()
    _STATE.handshaken = False

    client.send("hello", {
        "type": "hello",
        "clear": bool(clear),
        "material_root": material_root,
        "blender": bpy.app.version_string,
    })
    link_view.set_sender(lambda header: client.send("view", header))

    for handlers, handler in ((bpy.app.handlers.depsgraph_update_post, _on_depsgraph),
                              (bpy.app.handlers.frame_change_post, _on_frame_change)):
        if handler not in handlers:
            handlers.append(handler)
    if _on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load)
    if not bpy.app.timers.is_registered(_tick):
        bpy.app.timers.register(_tick, first_interval=0.0, persistent=True)
    if not bpy.app.timers.is_registered(_frame_tick):
        bpy.app.timers.register(_frame_tick, first_interval=0.0, persistent=True)
    return True, "Connected"


def stop():
    link_view.set_sender(None)
    for handlers in (bpy.app.handlers.depsgraph_update_post, bpy.app.handlers.frame_change_post):
        for handler in (_on_depsgraph, _on_frame_change):
            if handler in handlers:
                handlers.remove(handler)
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    for timer in (_tick, _frame_tick):
        if bpy.app.timers.is_registered(timer):
            bpy.app.timers.unregister(timer)
    client, _STATE.client = _STATE.client, None
    _STATE.sync = None
    if client is not None:
        client.close()
    _close_shared()
    _STATE.handshaken = False
    _STATE.status = "Not connected"


def _link_arguments(preferences):
    if preferences is None:  # not installed as an extension: a test, or a script
        return dict(max_triangles=0, material_root="/Game/BU")
    return dict(
        max_triangles=preferences.link_max_triangles,
        material_root=material_root(preferences.content_path),
    )


def managed(preferences):
    return getattr(preferences, "link_unreal", "OPEN") == "MANAGED"


def hosting():
    """BU's own editor is running, or starting, for the link."""
    return _STATE.host_wanted and link_host.HOST.alive()


def start_hosted(preferences):
    """Start BU's own editor (or reconnect to it). Returns (ok, message)."""
    host = link_host.HOST
    if host.alive() and host.quit_asked:
        # Still closing: one with its window may be waiting on its save question.
        message = ("Unreal is still closing. Answer its save question in its window, then "
                   "start again" if host.answering() else "Unreal is still closing; start again "
                   "in a moment")
        _STATE.status = message
        return False, message
    if not host.alive():
        try:
            message = host.launch(
                unreal_dir=bpy.path.abspath(preferences.unreal_dir) if preferences.unreal_dir else "",
                project_root=(bpy.path.abspath(preferences.render_project_dir)
                              if preferences.render_project_dir else ""),
                show_window=preferences.show_unreal_window,
                dlss_dir=(bpy.path.abspath(preferences.dlss_dir)
                          if getattr(preferences, "dlss_dir", "") else ""),
                start_level=getattr(preferences, "unreal_start_level", "LAST"),
                cache_gb=getattr(preferences, "cache_limit_gb", None),
            )
        except link_host.HostError as exc:
            _STATE.status = str(exc)
            return False, str(exc)
        _STATE.status = message
    _STATE.host_wanted = True
    if not bpy.app.timers.is_registered(_host_tick):
        bpy.app.timers.register(_host_tick, first_interval=HOST_TICK_SECONDS, persistent=True)
    return True, _STATE.status


def stop_hosted():
    """Stop the link and close BU's own editor."""
    _STATE.host_wanted = False
    stop()
    host = link_host.HOST
    if host.alive():
        host.quit()
        _STATE.status = host.closing_line()
        if not bpy.app.timers.is_registered(_host_tick):
            bpy.app.timers.register(_host_tick, first_interval=HOST_TICK_SECONDS, persistent=True)


def _host_tick():
    host = link_host.HOST
    state, detail = host.poll()
    if state != "running":
        _STATE.host_wanted = False
        if _STATE.client is not None:
            stop()
        if state == "exited":
            _STATE.status = detail or "Unreal closed"
            _redraw_viewports()
        return None
    if not _STATE.host_wanted:
        # Asked to close; watched until it has.
        line = host.closing_line() if host.quit_asked else _STATE.status
        if line != _STATE.status:
            _STATE.status = line
            _redraw_viewports(("VIEW_3D", "PROPERTIES"))
        return HOST_TICK_SECONDS
    if is_running():
        return HOST_IDLE_SECONDS
    try:
        status = host.status()
        if status.get("state") == "ready":
            preferences = prefs.get()
            ok, _message = start(host.port, **_link_arguments(preferences))
            if ok:
                _STATE.status = "Connected to BU's Unreal {0}".format(host.version)
                _redraw_viewports()
                return HOST_IDLE_SECONDS
        _STATE.status = link_host.describe(status, host.elapsed())
        if status.get("error"):
            _STATE.unreal_message = status["error"]
    except Exception as exc:  # noqa: BLE001 - a timer that raises is silently unregistered
        _STATE.status = "BU's Unreal: {0}".format(exc)
    _redraw_viewports()
    return HOST_TICK_SECONDS


def _on_exit():
    link_host.shutdown()


def material_root(content_path):
    """`/Game/BU/Live` -> `/Game/BU`: where earlier BU imports put their materials."""
    parts = [p for p in (content_path or "").split("/") if p]
    return "/" + "/".join(parts[:2]) if parts else "/Game"


class BU_OT_link_start(bpy.types.Operator):
    bl_idname = "bu.link_start"
    bl_label = "Start Real-Time Link"
    bl_description = (
        "Stream this scene's meshes to the running Unreal Editor as they change — edits, "
        "modifiers and animation — without exporting a file"
    )

    def execute(self, context):
        preferences = prefs.get(context)
        if preferences is None:
            self.report({"ERROR"}, "Could not read BU preferences")
            return {"CANCELLED"}
        if managed(preferences):
            ok, message = start_hosted(preferences)
            if not ok:
                self.report({"ERROR"}, message)
                return {"CANCELLED"}
            self.report({"INFO"}, message)
            return {"FINISHED"}

        port = preferences.link_port
        arguments = _link_arguments(preferences)

        # A listener may already be up — started from Unreal's Tools menu, or left from the last
        # session — in which case there is nothing to ask the editor for.
        ok, message = start(port, **arguments)
        if not ok:
            with live.Session(
                preferences.unreal_dir, preferences.multicast_group, preferences.bind_address
            ) as session:
                ran, lines, detail = session.run(
                    live.build_link_script(port, reload_first=preferences.reload_first),
                    node_id=live.chosen_target(context.scene),
                    timeout=preferences.discovery_timeout,
                )
            failed = [line for line in lines if "BU_LINK_FAIL" in line]
            if not ran or failed or not any("BU_LINK_OK" in line for line in lines):
                reason = detail or (failed[0] if failed else "") or (lines[-1] if lines else "")
                if "bu_link" in reason and "import" in reason.lower():
                    reason += (" — the BU plugin in that project predates the real-time link. "
                               "Run: python build.py --deploy")
                self.report({"ERROR"}, "Could not start the link in Unreal: {0}".format(
                    reason or "the editor reported nothing; check its Output Log"))
                return {"CANCELLED"}

            deadline = time.time() + 3.0
            while True:
                ok, message = start(port, **arguments)
                if ok or time.time() >= deadline:
                    break
                time.sleep(0.1)
            if not ok:
                self.report({"ERROR"}, message)
                return {"CANCELLED"}

        self.report({"INFO"}, "Real-time link up on port {0}".format(port))
        return {"FINISHED"}


class BU_OT_link_stop(bpy.types.Operator):
    bl_idname = "bu.link_stop"
    bl_label = "Stop Real-Time Link"
    bl_description = (
        "Close the link. BU's own Unreal closes with it; an editor you opened keeps what was "
        "sent until it closes"
    )

    def execute(self, context):
        if _STATE.host_wanted or link_host.HOST.alive():
            stop_hosted()
        else:
            stop()
        return {"FINISHED"}


class BU_OT_link_resend(bpy.types.Operator):
    bl_idname = "bu.link_resend"
    bl_label = "Resend Everything"
    bl_description = "Send every visible object again, for when Unreal and Blender disagree"

    @classmethod
    def poll(cls, context):
        return is_running()

    def execute(self, context):
        _STATE.sync.resend_everything()
        return {"FINISHED"}


def texture_report(stats):
    """What the textures line says on hover and click: the textures still loading, the next
    one first, and those that will not show and why. [] when there is nothing to say. Pure."""
    stats = stats or {}
    lines = []
    names = [str(name) for name in stats.get("textures_names") or ()]
    waiting = int(stats.get("textures_waiting") or 0)
    if names:
        lines.append("Loading now: {0}".format(names[0]))
        if len(names) > 1:
            lines.append("Waiting:")
            lines += ["  " + name for name in names[1:]]
        if waiting > len(names):
            lines.append("  and {0} more".format(waiting - len(names)))
    failed = [(str(entry[0]), str(entry[1])) for entry in stats.get("textures_failed") or ()
              if isinstance(entry, (list, tuple)) and len(entry) == 2]
    if failed:
        lines.append("Not shown:")
        lines += ["  {0} ({1})".format(name, why) for name, why in failed]
        total = int(stats.get("textures_failed_count") or len(failed))
        if total > len(failed):
            lines.append("  and {0} more".format(total - len(failed)))
    return lines


class BU_OT_link_textures(bpy.types.Operator):
    bl_idname = "bu.link_textures"
    bl_label = "Textures"
    bl_description = "Which textures Unreal is still loading, and which will not show"

    @classmethod
    def description(cls, context, properties):
        lines = texture_report(_STATE.unreal_stats)
        return "\n".join(lines) if lines else cls.bl_description

    def execute(self, context):
        lines = texture_report(_STATE.unreal_stats)
        if not lines:
            return {"CANCELLED"}

        def draw(menu, _context):
            for line in lines:
                menu.layout.label(text=line)

        context.window_manager.popup_menu(draw, title="Textures", icon="TEXTURE")
        return {"FINISHED"}


# Applied in this order: which looks exist depends on the view transform.
VIEW_OVERRIDES = (("view_transform", "Standard"), ("look", "None"), ("exposure", 0.0),
                  ("gamma", 1.0))


def override_view(scene):
    """Put the scene's view on Standard while the picture is Unreal's, remembering what it was.

    Unreal's frame is finished colour and Blender is going to view-transform it. `link_color`
    undoes that, but no tone mapper can be undone for saturated colour — AgX is out by up to
    38/255 on a pure primary, which is most of a voxel palette. Standard is the one view whose
    inverse is exact, so the picture is shown under it. The previous settings are stored on the
    scene, so they survive a save and reload in between.
    """
    view = scene.view_settings
    for name, value in VIEW_OVERRIDES:
        # Only remember the first time: called again while already overridden, "previous" would
        # be overwritten with Standard and the artist's own setting lost.
        if scene.get("bu_link_previous_" + name) is None:
            scene["bu_link_previous_" + name] = getattr(view, name)
        try:
            setattr(view, name, value)
        except TypeError:
            pass


def restore_view(scene):
    view = scene.view_settings
    for name, _value in VIEW_OVERRIDES:
        saved = scene.get("bu_link_previous_" + name)
        if saved is None:
            continue
        try:
            setattr(view, name, saved)
        except TypeError:
            pass  # a look that does not exist under the restored view transform
        del scene["bu_link_previous_" + name]


def colour_mode(window_manager=None):
    """Who colour-manages Unreal's picture: `link_view.COLOUR_BLENDER` or `COLOUR_UNREAL`."""
    if window_manager is None:
        window_manager = bpy.context.window_manager
    return getattr(window_manager, "bu_link_colour", link_view.COLOUR_BLENDER)


def sync_view_overrides(scenes, mode=link_view.COLOUR_UNREAL):
    """Keep each scene's view in step with whether it is showing Unreal's picture.

    The viewport button does this too, but it is not the only way in or out: the render engine
    can be changed from the Render properties, and a file can be opened already on this engine.
    On the first live session the picture was reached by a path that skipped the override, and
    the result was washed-out colour with nothing but a hint to explain it. So the link checks,
    rather than trusting how the engine came to be selected.

    An artist who deliberately moves the view off Standard while the picture is showing is left
    alone: the override is applied once per visit, marked by the saved "previous" value.

    With Blender doing the colour management (`COLOUR_BLENDER`) nothing is overridden, and an
    override left from before is undone.
    """
    for scene in scenes:
        overridden = scene.get("bu_link_previous_view_transform") is not None
        if mode == link_view.COLOUR_BLENDER:
            if overridden:
                restore_view(scene)
        elif scene.render.engine == link_view.ENGINE_ID:
            if not overridden and scene.view_settings.view_transform != "Standard":
                override_view(scene)
        elif overridden:
            restore_view(scene)


class BU_OT_link_exact_colour(bpy.types.Operator):
    bl_idname = "bu.link_exact_colour"
    bl_label = "Show Exact Colours"
    bl_description = (
        "Switch this scene's View Transform to Standard while Unreal's picture is showing, so "
        "its colours are exact. Your own setting is restored when you switch back"
    )

    def execute(self, context):
        scene = context.scene
        override_view(scene)
        # Pressed after deliberately leaving Standard, the saved value already exists and
        # override_view keeps it; the view itself still has to be put back on Standard.
        for name, value in VIEW_OVERRIDES:
            try:
                setattr(scene.view_settings, name, value)
            except TypeError:
                pass
        return {"FINISHED"}


def auto_start():
    """Start BU's own Unreal for a viewport that has just switched to Rendered.

    Run once per switch (a timer, from `link_view`), never from inside a draw. Only BU's own
    hidden editor starts by itself; an editor the user opens is theirs to link. After a failure
    it waits for Restart, rather than starting again on every redraw.
    """
    preferences = prefs.get(bpy.context)
    if (preferences is None or not managed(preferences) or is_running() or hosting()
            or link_host.HOST.failure):
        return None
    start_hosted(preferences)
    return None


def _rendered_viewport_opened():
    if not bpy.app.timers.is_registered(auto_start):
        bpy.app.timers.register(auto_start, first_interval=0.0)


# How often the main thread looks in on a still (F12) rendering on its own thread.
RENDER_WATCH_SECONDS = 0.25
# Messages a still does not wait for: the view and its keep-alive, picture acknowledgements.
QUIET_KEYS = ("view", "frame_ack")


def _render_watch():
    """The main thread's part in a still (F12), whose render runs on a thread of its own: start
    BU's Unreal for one that found no link (only the main thread may), and redraw the viewports
    once one has ended (they wait while Unreal renders the camera)."""
    if link_view.start_wanted:
        link_view.start_wanted = False
        preferences = prefs.get(bpy.context)
        if preferences is not None and not managed(preferences):
            link_view.start_refused = (
                "Start the Real-Time Link first (Render > Unreal): BU is set to link to an "
                "Unreal you open yourself")
        elif link_host.HOST.failure:
            link_view.start_refused = "Unreal did not start: {0}. Restart the link".format(
                _STATE.status)
        elif not is_running() and not hosting():
            ok, message = start_hosted(preferences) if preferences is not None else (
                False, "BU's preferences are missing")
            if not ok:
                link_view.start_refused = message
    if link_view.redraw_wanted:
        link_view.redraw_wanted = False
        _redraw_viewports(("VIEW_3D", "PROPERTIES"))  # and the F12 Render panel's timing
    return RENDER_WATCH_SECONDS


def render_busy(report=None, since=None):
    """What is still on its way to Unreal's picture, or "" once it is the scene as it is: a
    still (F12) is taken only once this is "" (`link_view.busy`).

    `report`: what the newest picture says about itself (`link_view.still_report`). From a
    current Unreal side it says which of Blender's frames it holds and how much was still
    loading as it was rendered: exact for that picture, where the stats are once a second.
    `since`: when the still began (`LiveSync.unsent`).
    """
    client = _STATE.client
    if client is None or not client.alive:
        return _STATE.status or "Not connected"
    if not _STATE.handshaken:
        return "Waiting for Unreal"
    sync = _STATE.sync
    unsent = sync.unsent(since) if sync is not None else ""
    if unsent:
        return unsent
    if any(not key.startswith(QUIET_KEYS) for key in client.pending_keys()):
        return "Sending the scene"
    if link_view.reports_itself(report):
        if sync is not None and report["applied"] < sync.frames_marked:
            return "Taking in the scene"
        if report["loading"]:
            waiting = link_view.still_loading(_STATE.unreal_stats)
            return waiting[0] if waiting else "Loading: {0} left".format(report["loading"])
        return ""
    if (sync is not None and sync.frames_answered
            and sync.frames_done < sync.frames_marked):
        return "Taking in the scene"
    waiting = link_view.still_loading(_STATE.unreal_stats)
    return waiting[0] if waiting else ""


def _render_pump():
    """The link's timer, once: for a still rendered on the main thread, where timers wait."""
    if _STATE.client is not None:
        _tick()


def _colour_changed(window_manager, context):
    sync_view_overrides({w.scene for w in window_manager.windows if w.scene},
                        colour_mode(window_manager))
    # The view message carries the choice, so the next draw asks Unreal for the other kind.
    for area in link_view.active_viewports(window_manager):
        area.tag_redraw()


# A picture taking longer than this from render to delivery, with Unreal ticking freely, means
# the graphics card is what holds the viewport back (under 25 pictures a second).
GPU_BOUND_MS = 40.0


def gpu_bound(stats):
    """True when Unreal is awake and its pictures are slow: the graphics card is the limit, not
    BU or a throttled editor. Pure."""
    if not stats or stats.get("tick_hz", 0.0) < 10.0 or not stats.get("frame_hz"):
        return False
    return stats.get("write_ms", 0.0) >= GPU_BOUND_MS


TEXTURE_LINES = ("Loading textures", "Textures not shown")
# Milliseconds of a tick's own work over which a slow Unreal is busy, not idling.
BUSY_TICK_MS = 50.0


def slow_tick_reason(stats):
    """Why Unreal ticks under 10 times a second, as a panel line, or "". Pure.

    Slow ticks used to mean only one thing, an editor idling in the background, and the panel
    said "click its window". A scene's first load slows them too, by its own work: importing a
    texture (100-200 ms on Unreal's main thread for a big one) or building a node material.
    Said as such, since clicking would change nothing, and BU's own editor has no window to
    click.
    """
    tick = stats.get("tick_hz", 0.0)
    if not tick or tick >= 10.0:
        return ""
    textures = stats.get("bg_textures_ms") or 0.0
    graphs = stats.get("bg_graphs_ms") or 0.0
    standins = stats.get("bg_standins_ms") or 0.0
    own = ((stats.get("scene_ms") or 0.0) + (stats.get("capture_ms") or 0.0)
           + (stats.get("background_ms") or 0.0))
    if own < BUSY_TICK_MS:
        return "Unreal is throttled - click its window"
    work = max((textures, "importing textures"), (graphs, "building materials"),
               (standins, "building stand-ins"), ((stats.get("scene_ms") or 0.0), "applying changes"))
    return "Unreal is busy {0} ({1:.0f} ms a tick)".format(work[1], own)


def stats_lines(stats, frame_ms=0.0):
    """Unreal's timings as panel text, so a slow link says *where* it is slow."""
    if not stats:
        return []
    lines = ["Unreal: {0:.0f} ticks/s".format(stats.get("tick_hz", 0.0))]
    busy = slow_tick_reason(stats)
    if busy:
        lines.append(busy)
    if stats.get("frame_hz"):
        lines.append("Frame: render {0:.0f} + read {1:.0f} + write {2:.0f} ms".format(
            stats.get("render_ms", 0.0), stats.get("readback_ms", 0.0),
            stats.get("write_ms", 0.0)))
        lines.append("Blender: read {0:.0f} + upload {1:.0f} ms".format(
            frame_ms, link_view.upload_ms))
        if stats.get("gpu_wait_ms") is not None:
            lines.append("GPU: waited {0:.0f} ms, render thread {1:.0f} ms".format(
                stats.get("gpu_wait_ms", 0.0), stats.get("render_thread_ms", 0.0)))
    if stats.get("applies"):
        lines.append("Mesh apply: {0:.0f} ms avg, {1:.0f} ms worst".format(
            stats.get("apply_ms", 0.0), stats.get("apply_worst_ms", 0.0)))
    if stats.get("standins") or stats.get("kept"):
        lines.append("Static: {0} shown, {1} from cache, {2} built".format(
            stats.get("standins", 0), stats.get("cached", 0), stats.get("built", 0)))
    if stats.get("kept"):
        lines.append("Unchanged meshes not rebuilt: {0}".format(stats["kept"]))
    if stats.get("textures_waiting"):
        # Unreal imports them one at a time (bu_link_pace); materials show plain colour meanwhile.
        lines.append("Loading textures: {0} left{1}".format(
            stats["textures_waiting"],
            " - waiting for free memory" if stats.get("textures_held") == "memory" else ""))
    if stats.get("textures_failed_count"):
        # A file Unreal cannot find (moved, or on another computer) or cannot import.
        lines.append("Textures not shown: {0}".format(stats["textures_failed_count"]))
    if stats.get("graphs_waiting"):
        # Node materials, one at a time; each shows Blender's plain values until it is built.
        lines.append("Building node materials: {0} left{1}".format(
            stats["graphs_waiting"],
            " - waiting for free memory" if stats.get("graphs_held") == "memory" else ""))
    if stats.get("shaders_left"):
        lines.append("Compiling shaders: {0} left".format(stats["shaders_left"]))
    if stats.get("streaming_pool_mb"):
        # Over the pool, the streamer keeps textures at blurrier mips so they fit.
        lines.append("Texture memory: {0} of {1} MB wanted{2}".format(
            stats.get("streaming_pool_mb"), stats.get("streaming_wanted_mb", 0),
            " - textures blurred" if stats.get("streaming_short_mb") else ""))
    return lines


class BU_PT_render_unreal(link_lighting._RenderPanel, bpy.types.Panel):
    bl_label = "Unreal"

    def draw(self, context):
        layout = self.layout
        running = is_running()
        starting = hosting() and not running
        preferences = prefs.get(context)

        own = preferences is not None and managed(preferences)
        column = layout.column()
        column.scale_y = 1.4
        if starting or running:
            column.operator(BU_OT_link_stop.bl_idname, icon="CANCEL",
                            text="Stop Unreal" if own else "Disconnect")
        elif link_host.HOST.failure and own:
            column.operator(BU_OT_link_start.bl_idname, icon="FILE_REFRESH", text="Restart Unreal")
        else:
            column.operator(BU_OT_link_start.bl_idname, icon="PLAY",
                            text="Start Unreal" if own else "Connect to Unreal")
        status = layout.column(align=True)
        for index, line in enumerate(wrap(_STATE.status, 48)):
            icon = "NONE"
            if index == 0:
                icon = "LINKED" if running else ("TIME" if starting else "UNLINKED")
            status.label(text=line, icon=icon)
        if not link_view.active_viewports(context.window_manager):
            layout.label(text="Set a 3D viewport to Rendered to see Unreal", icon="SHADING_RENDERED")

        layout.use_property_split = True
        layout.use_property_decorate = False
        window_manager = context.window_manager
        layout.prop(window_manager, "bu_link_view_quality", text="Viewport Resolution")
        layout.prop(window_manager, "bu_link_view_bend", text="Camera Moves")
        layout.prop(window_manager, "bu_link_colour", text="Colour Managed By")
        if preferences is None or not managed(preferences):
            layout.prop(window_manager, "bu_link_drive_editor")
        unreal_colour = colour_mode(window_manager) == link_view.COLOUR_UNREAL
        if unreal_colour and context.scene.view_settings.view_transform != "Standard":
            hint = layout.box()
            hint.label(text="Colours are approximate: View Transform is not Standard", icon="INFO")
            hint.operator(BU_OT_link_exact_colour.bl_idname, icon="COLOR")
        elif not unreal_colour and link_view.linear_frames is False:
            hint = layout.box()
            hint.label(text="Unreal sent finished colour, not linear", icon="INFO")
            hint.label(text="Update BU's Unreal plugin for Blender's colour")

        if not running:
            return
        sync = _STATE.sync
        skipped = dict(sync.instances_skipped)
        skipped.update(sync.skipped)
        if skipped:
            warning = layout.box()
            warning.alert = True
            warning.label(text="{0} object(s) not sent".format(len(skipped)), icon="ERROR")
            for name, reason in list(skipped.items())[:3]:
                warning.label(text="{0}: {1}".format(name, reason))
        if _STATE.unreal_message:
            layout.label(text="Unreal: " + _STATE.unreal_message[:80], icon="INFO")
        render = getattr(context.scene, "bu_render", None)
        if (gpu_bound(_STATE.unreal_stats) and render is not None
                and render.renderer != "PATH_TRACER"):
            # Seen by testers as "every scene is laggy": say where the time goes and what helps.
            hint = layout.box()
            hint.label(text="The graphics card is the limit: {0:.0f} ms a picture".format(
                _STATE.unreal_stats.get("write_ms", 0.0)), icon="INFO")
            if render.upscaler == "NONE":
                hint.label(text="Upscaling renders fewer pixels and is much faster")
                hint.prop(render, "upscaler")
            else:
                hint.label(text="A lower Viewport Resolution or Resolution % is faster")


class BU_PT_render_unreal_stats(link_lighting._RenderPanel, bpy.types.Panel):
    bl_label = "Statistics"
    bl_parent_id = "BU_PT_render_unreal"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        if not is_running():
            layout.label(text="Unreal is not connected")
            return
        sync = _STATE.sync
        column = layout.column(align=True)
        column.label(text="{0} object(s) live, {1} waiting".format(
            len(sync.known), len(sync.dirty_geometry)))
        column.label(text="{0} mesh / {1} transform updates sent".format(
            sync.meshes_sent, sync.transforms_sent))
        column.label(text="Bulk data: shared memory" if sync.arena is not None
                     else "Bulk data: socket (no native module)")
        if _STATE.frame_times:
            column.label(text="Unreal picture: {0:.0f} fps".format(len(_STATE.frame_times) / 2.0))
        for line in stats_lines(_STATE.unreal_stats, _STATE.frame_ms):
            if line.startswith(TEXTURE_LINES):
                # Hover for the names, click for a list that stays open.
                column.operator(BU_OT_link_textures.bl_idname, text=line, emboss=False,
                                icon="TEXTURE")
            else:
                column.label(text=line)
        layout.operator(BU_OT_link_resend.bl_idname, icon="FILE_REFRESH")


def still_lines(timing):
    """The F12 Render panel's account of the last still (`link_view.last_still`): a heading,
    then (what, "seconds") rows, and Unreal's frame rate while it warmed up. Pure."""
    if not timing or "rows" not in timing:
        return None, [], ""
    width, height = timing.get("size", (0, 0))
    heading = "Last F12: {0:.2f} s at {1} x {2}".format(timing["total"], width, height)
    rows = [(what, "{0:.2f} s".format(seconds)) for what, seconds in timing["rows"]]
    rate = ("Unreal ran at {0:.0f} frames a second".format(timing["fps"])
            if timing.get("fps") else "")
    return heading, rows, rate


class BU_PT_render_still(link_lighting._RenderPanel, bpy.types.Panel):
    bl_label = "F12 Render"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        settings = context.scene.bu_render
        if settings.renderer == "PATH_TRACER":
            layout.label(text="F12 waits for the path tracer's {0} samples".format(
                settings.pt_samples), icon="INFO")
        else:
            layout.prop(settings, "still_warmup")
        reads = link_view.compositor_reads(context.scene)
        if reads is not None and reads[1]:
            # A Cycles compositor rebuilding the picture from its light passes: F12 through
            # Unreal cannot feed it (`link_view.compositor_problem`).
            box = layout.box()
            box.alert = not reads[0]
            column = box.column(align=True)
            column.label(text="The compositor reads passes Unreal does not make:", icon="ERROR")
            column.label(text=link_view.pass_names(reads[1]))
            column.label(text="F12 needs Compositing off for this scene" if not reads[0]
                         else "They read as the nodes' own values")
            box.prop(context.scene.render, "use_compositing", text="Compositing")
        heading, rows, rate = still_lines(link_view.last_still)
        if heading is None:
            return
        column = layout.box().column(align=True)
        column.label(text=heading, icon="TIME")
        for what, seconds in rows:
            split = column.split(factor=0.7)
            split.label(text=what)
            split.label(text=seconds)
        if rate:
            column.label(text=rate)


class BU_PT_render_import(link_lighting._RenderPanel, bpy.types.Panel):
    bl_label = "Import from Unreal"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        if not is_running():
            layout.label(text="Start Unreal to bring its actors in")
            return
        row = layout.row(align=True)
        row.operator(link_import.BU_OT_link_import.bl_idname, text="Selected").scope = "selected"
        row.operator(link_import.BU_OT_link_import.bl_idname, text="Whole Level").scope = "level"
        if _STATE.import_status:
            layout.label(text=_STATE.import_status[:80])
        if any(link_import.is_imported(obj) for obj in context.selected_objects):
            if any(link_import.is_driver(obj) for obj in context.selected_objects):
                layout.label(text="Moving these moves their actors in Unreal", icon="INFO")
            layout.operator(link_import.BU_OT_link_send_imported.bl_idname, icon="LINKED")


_classes = (BU_OT_link_start, BU_OT_link_stop, BU_OT_link_resend, BU_OT_link_textures, BU_OT_link_exact_colour,
            BU_PT_render_unreal, BU_PT_render_unreal_stats, BU_PT_render_still,
            BU_PT_render_import)


def wrap(text, width):
    """Words in lines of at most `width` characters, for a panel's labels. Pure."""
    lines, line = [], ""
    for word in str(text or "").split():
        if line and len(line) + 1 + len(word) > width:
            lines.append(line)
            line = word
        else:
            line = word if not line else line + " " + word
    if line:
        lines.append(line)
    return lines or [""]


def register():
    atexit.register(_on_exit)
    link_view.on_rendered = _rendered_viewport_opened
    link_view.status = lambda: _STATE.status
    link_view.loading = lambda: link_view.loading_lines(_STATE.unreal_stats)
    link_view.busy = render_busy
    link_view.pump = _render_pump
    if not bpy.app.timers.is_registered(_render_watch):
        bpy.app.timers.register(_render_watch, first_interval=RENDER_WATCH_SECONDS,
                                persistent=True)
    link_view.register()
    link_surface.register()
    link_import.register()
    link_lighting.register()
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.bu_link_view_quality = bpy.props.EnumProperty(
        name="Picture Quality",
        description="Size of the image Unreal sends back. Smaller is faster",
        items=(
            ("LOW", "Fast", "Up to 640 pixels on the long edge"),
            ("MEDIUM", "Balanced", "Up to 960 pixels on the long edge"),
            ("HIGH", "Sharp", "Up to 1600 pixels on the long edge"),
            ("FULL", "Full", "The viewport's own size, up to 2560 pixels on the long edge: as "
             "sharp as Blender's own view"),
        ),
        default="FULL",
    )
    bpy.types.WindowManager.bu_link_colour = bpy.props.EnumProperty(
        name="Colour Management",
        description="Which program turns Unreal's light into the colours you see here",
        items=(
            (link_view.COLOUR_BLENDER, "Blender",
             "Unreal sends its picture before its own tone mapping, and this scene's View "
             "Transform, Look, Exposure, Curves and White Balance finish it, as for Cycles"),
            (link_view.COLOUR_UNREAL, "Unreal",
             "Unreal's own finished picture, as its editor shows it. The View Transform is set "
             "to Standard while it is showing"),
        ),
        default=link_view.COLOUR_BLENDER,
        update=_colour_changed,
    )
    bpy.types.WindowManager.bu_link_view_bend = bpy.props.EnumProperty(
        name="Camera Moves",
        description="How the last picture is moved to follow the view until Unreal's next "
                    "one arrives",
        items=(
            (link_view.BEND_DEPTH, "Follow Depth",
             "Each pixel moves by its own distance, so things stay on their outlines; what the "
             "move uncovers is stretched until the next picture"),
            (link_view.BEND_FLAT, "Flat",
             "The picture moves as one sheet: nothing stretches, but near things sit slightly "
             "off their outlines and the next picture lands with a bigger jump. Unreal also "
             "skips its depth picture"),
            (link_view.BEND_OFF, "Off",
             "The picture stays where Unreal drew it until the next one arrives: no stretching "
             "or jitter, but it trails the overlays a little while the view moves"),
        ),
        default=link_view.BEND_OFF,
    )
    bpy.types.WindowManager.bu_link_drive_editor = bpy.props.BoolProperty(
        name="Move Unreal's Viewport Too",
        description="Keep Unreal's own editor viewport on the same camera as this one",
        default=True,
    )


def unregister():
    stop_hosted()
    if bpy.app.timers.is_registered(_host_tick):
        bpy.app.timers.unregister(_host_tick)
    atexit.unregister(_on_exit)
    del bpy.types.WindowManager.bu_link_drive_editor
    del bpy.types.WindowManager.bu_link_view_bend
    del bpy.types.WindowManager.bu_link_colour
    del bpy.types.WindowManager.bu_link_view_quality
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    link_lighting.unregister()
    link_import.unregister()
    link_surface.unregister()
    link_view.unregister()
    link_view.on_rendered = None
    link_view.status = None
    link_view.loading = None
    link_view.busy = None
    link_view.pump = None
    if bpy.app.timers.is_registered(_render_watch):
        bpy.app.timers.unregister(_render_watch)
    if bpy.app.timers.is_registered(auto_start):
        bpy.app.timers.unregister(auto_start)

