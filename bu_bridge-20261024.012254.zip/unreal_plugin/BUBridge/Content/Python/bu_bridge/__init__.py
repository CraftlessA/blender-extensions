# SPDX-License-Identifier: GPL-3.0-or-later
"""BU — Blender to Unreal Bridge, Unreal side.

Typical use from the Unreal Python console:

    import bu_bridge
    bu_bridge.import_scene(r"D:/Exports/Shot_01.usdc", "/Game/BU/Shot_01")

Or, if the assets are already imported and only the texture settings and camera cuts need
re-asserting:

    bu_bridge.reapply_settings(r"D:/Exports/Shot_01.bu.json", "/Game/BU/Shot_01")

Material presets are normally applied by right-clicking material instances in the Content
Browser, but the same thing works on a selection from here:

    bu_bridge.apply_material_preset("cutout")      # leaves, grass, glass panes
    bu_bridge.apply_material_preset("character")   # skins and their overlay layers

The real-time link is normally started from Blender, but can be left listening from here:

    bu_bridge.start_link()

**After updating these files on disk, run `bu_bridge.reload()`.** Unreal caches Python
modules in `sys.modules` for the life of the editor process, so edits to this package have no
effect on a running editor until the modules are reloaded (or the editor restarts).
"""

import importlib
import sys

from .bu_import import import_scene, reapply_settings
from .bu_link import clear_cache as clear_link_cache, start as start_link, stop as stop_link
from .bu_manifest import Manifest
from .bu_materials import prune_material_variants, wire_materials
from .bu_names import sanitize_asset_name, sanitize_package_path
from .bu_presets import PRESETS as MATERIAL_PRESETS, apply_preset as apply_material_preset
from .bu_surface import ensure as ensure_bu_surface
from .bu_sequence import (
    build_sequence,
    find_imported_sequence,
    verify_geometry_caches,
)
from .bu_textures import apply_to_path, apply_to_texture

__all__ = [
    "import_scene",
    "reapply_settings",
    "Manifest",
    "build_sequence",
    "find_imported_sequence",
    "wire_materials",
    "prune_material_variants",
    "apply_material_preset",
    "MATERIAL_PRESETS",
    "ensure_bu_surface",
    "verify_geometry_caches",
    "apply_to_path",
    "apply_to_texture",
    "sanitize_asset_name",
    "sanitize_package_path",
    "start_link",
    "clear_link_cache",
    "stop_link",
    "reload",
]

# Leaf-first, so each module picks up the already-reloaded ones it imports.
_RELOAD_ORDER = (
    "bu_names",
    "bu_manifest",
    "bu_textures",
    "bu_surface",
    "bu_materials",
    "bu_presets",
    "bu_sequence",
    "bu_import",
    "bu_link_wire",
    "bu_link_pace",
    "bu_link_material",
    "bu_link_graph",
    "bu_link_light",
    "bu_link_editor",
    "bu_link_drive",
    "bu_link_environment",
    "bu_link_export",
    "bu_link_static",
    "bu_link_instances",
    "bu_link",
    "bu_host",
)


def reload():
    """Reload every BU module in place so on-disk changes take effect immediately.

    Unreal imports this package once at editor startup via init_unreal.py and then caches it,
    which means replacing the files does nothing until the editor restarts. This is the
    faster alternative while iterating.
    """
    done = set()
    for name in _RELOAD_ORDER:
        module = sys.modules.get("{0}.{1}".format(__name__, name))
        if module is not None:
            importlib.reload(module)
        done.add(name)

    # Re-running our own __init__ rebinds the names above to the reloaded functions.
    package = importlib.reload(sys.modules[__name__])

    # The loop above ran with the module list this function was *compiled* with. An update that
    # adds a module to `_RELOAD_ORDER` is therefore invisible to the first reload after it, and
    # a copy of that module already in memory stays stale — which is how the real-time link's
    # first fix appeared not to deploy. Catch up on anything the new list names.
    for name in getattr(package, "_RELOAD_ORDER", ()):
        if name in done:
            continue
        module = sys.modules.get("{0}.{1}".format(__name__, name))
        if module is not None:
            importlib.reload(module)
    try:
        import unreal

        unreal.log("BU: reloaded {0} modules from disk".format(len(_RELOAD_ORDER)))
    except Exception:  # noqa: BLE001 - reload is useful outside the editor too
        pass
    return package
