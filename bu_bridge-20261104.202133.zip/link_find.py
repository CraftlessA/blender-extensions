# SPDX-License-Identifier: GPL-3.0-or-later
"""The Unreal Editors open on this machine with BU in their project, and putting BU into one.

An editor whose project has BU's plugin listens for Blender by itself, and keeps a small file
in the user's %LOCALAPPDATA%/BU/editors while it does (`bu_link_setup.py`, Unreal's side;
BU_EDITORS_DIR overrides the folder for both): its project and .uproject, the port, its process
ID, its engine version, when it started and when its window last had the focus. Blender reads
them here, so connecting needs no port, no remote execution and no picking, most of the time.

Which one, when several are open: the project chosen in Blender before (`remembered`, from the
Unreal panel's buttons), when it is open; otherwise the one most recently used (its window had
the focus last, or it started last). The panel offers the others as one click each.

Standard library only, and nothing here imports `bpy`, so the tests run without Blender.
"""

import json
import os
import shutil
import sys

try:
    from . import link_host
except ImportError:  # loaded by path in the plain-CPython tests
    import link_host

ENV_DIR = "BU_EDITORS_DIR"
RECORD_KIND = "bu-editor"


def editors_dir(environ=None):
    """The folder the editors' files are in. Unreal's `bu_link_setup.editors_dir` agrees."""
    environ = os.environ if environ is None else environ
    if environ.get(ENV_DIR):
        return environ[ENV_DIR]
    base = environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local")
    return os.path.join(base, "BU", "editors")


def pid_alive(pid):
    """Whether process `pid` is running. On Windows by asking for its exit code; never
    `os.kill(pid, 0)`, which there *ends* the process."""
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    if sys.platform == "win32":
        import ctypes

        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
        kernel32.GetExitCodeProcess.argtypes = (wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD))
        kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
        query = 0x1000  # PROCESS_QUERY_LIMITED_INFORMATION
        handle = kernel32.OpenProcess(query, False, pid)
        if not handle:
            # Gone; or there but not this user's to look at (ERROR_ACCESS_DENIED), which still
            # means a process has that ID.
            return ctypes.get_last_error() == 5
        try:
            code = wintypes.DWORD(0)
            if not kernel32.GetExitCodeProcess(handle, ctypes.byref(code)):
                return False
            return code.value == 259  # STILL_ACTIVE
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _record(path):
    try:
        with open(path, encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or data.get("kind") != RECORD_KIND:
        return None
    try:
        data["port"] = int(data.get("port") or 0)
        data["pid"] = int(data.get("pid") or 0)
        data["started"] = float(data.get("started") or 0.0)
        data["focused"] = float(data.get("focused") or 0.0)
    except (TypeError, ValueError):
        return None
    if not data["port"] or not data["pid"]:
        return None
    data["project"] = str(data.get("project") or "") or "Unreal"
    data["uproject"] = str(data.get("uproject") or "")
    data["path"] = path
    return data


def recency(record):
    """When the editor was last used: its window had the focus, or it started."""
    return max(record.get("focused") or 0.0, record.get("started") or 0.0)


def read_editors(folder=None, alive=pid_alive, tidy=True):
    """The open editors listening for Blender, most recently used first. A file whose editor
    has gone (a crash leaves one behind) is skipped, and removed when `tidy`."""
    folder = editors_dir() if folder is None else folder
    try:
        names = sorted(os.listdir(folder))
    except OSError:
        return []
    found = []
    for name in names:
        if not name.endswith(".json"):
            continue
        path = os.path.join(folder, name)
        record = _record(path)
        if record is None:
            continue
        if not alive(record["pid"]):
            if tidy:
                try:
                    os.remove(path)
                except OSError:
                    pass
            continue
        found.append(record)
    found.sort(key=recency, reverse=True)
    return found


def same_project(first, second):
    """Whether two .uproject paths are the same file. Pure."""
    if not first or not second:
        return False
    return (os.path.normcase(os.path.normpath(str(first)))
            == os.path.normcase(os.path.normpath(str(second))))


def choose(editors, remembered=""):
    """The editor to connect to, or None when there is none. Pure.

    The project chosen before, when it is open; otherwise the most recently used."""
    if not editors:
        return None
    for record in editors:
        if same_project(record.get("uproject"), remembered):
            return record
    return max(editors, key=recency)


def label(record):
    """The panel's name for an editor: its project, and the engine when it says. Pure."""
    engine = str(record.get("engine") or "")
    version = ".".join(engine.split("-")[0].split(".")[:2]) if engine else ""
    return "{0} ({1})".format(record.get("project") or "Unreal", version) if version else (
        record.get("project") or "Unreal")


# -- putting BU into a project -------------------------------------------------------------------

class InstallError(Exception):
    pass


def project_engine(uproject, engines=None, registered=None):
    """(version, engine folder) a .uproject is for, or ("", "") when it cannot be told.

    Its EngineAssociation is a version ("5.8") for a launcher engine, or an ID for one
    registered by "Switch Unreal Engine version" (looked up as build.py does)."""
    try:
        with open(uproject, encoding="utf-8-sig") as handle:
            association = str(json.load(handle).get("EngineAssociation") or "")
    except (OSError, ValueError, AttributeError):
        return "", ""
    engines = link_host.find_engines() if engines is None else engines
    if association in engines:
        return association, engines[association]
    registered = registered_engines() if registered is None else registered
    folder = registered.get(association.upper()) if association else ""
    if folder and os.path.isfile(link_host.editor_exe(folder)):
        return link_host.engine_version(folder) or association, os.path.normpath(folder)
    return association, ""


def registered_engines():
    """Engines registered by ID ({ID: folder})."""
    try:
        import winreg
    except ImportError:
        return {}
    found = {}
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Epic Games\Unreal Engine\Builds") as key:
            index = 0
            while True:
                try:
                    name, value, _kind = winreg.EnumValue(key, index)
                except OSError:
                    break
                found[name.upper()] = str(value)
                index += 1
    except OSError:
        pass
    return found


def old_python_copy(project_folder):
    """BU's Python copied by hand into the project's Content/Python, from before BU was a
    plugin: with the plugin as well, every menu would register twice. The paths found."""
    python = os.path.join(project_folder, "Content", "Python")
    return [os.path.join(python, name) for name in ("bu_bridge", "init_unreal.py")
            if os.path.exists(os.path.join(python, name))
            and (name != "init_unreal.py" or _mentions_bu(os.path.join(python, name)))]


def _mentions_bu(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as handle:
            return "bu_bridge" in handle.read()
    except OSError:
        return False


def install_into_project(uproject, editors=(), bundle=None, engines=None, registered=None):
    """Copy BU's Unreal plugin, bundled in this extension, into `<project>/Plugins/BUBridge`.
    Its compiled module goes with it only when built for that project's engine. Returns a line
    to report; raises InstallError when it cannot (not a project, its editor open, no bundle)."""
    uproject = os.path.normpath(str(uproject or ""))
    if not uproject.lower().endswith(".uproject") or not os.path.isfile(uproject):
        raise InstallError("Choose an Unreal project's .uproject file")
    project_name = os.path.splitext(os.path.basename(uproject))[0]
    for record in editors:
        if same_project(record.get("uproject"), uproject):
            raise InstallError("{0} is open in Unreal with BU already in it. Close it first, "
                               "then install again to update BU there".format(project_name))
    bundle = bundle or link_host.BUNDLE
    if not os.path.isfile(os.path.join(bundle, link_host.PLUGIN_NAME + ".uplugin")):
        raise InstallError("BU's Unreal plugin is missing from this Blender extension ({0}). "
                           "Reinstall BU".format(bundle))
    folder = os.path.dirname(uproject)
    destination = os.path.join(folder, "Plugins", link_host.PLUGIN_NAME)
    version, root = project_engine(uproject, engines, registered)
    wanted = link_host.bundle_build_id(bundle)
    native = bool(wanted and root) and wanted == link_host.engine_build_id(root)
    try:
        os.makedirs(os.path.dirname(destination), exist_ok=True)
        copied = link_host.install_plugin(bundle, destination, native)
    except (OSError, shutil.Error, link_host.HostError) as exc:
        raise InstallError("Could not copy BU into {0} ({1}). If Unreal has that project open, "
                           "close it and try again".format(destination, exc))
    line = "BU is in {0}".format(project_name) if copied else (
        "{0} already has this BU".format(project_name))
    if not native:
        line += (": without its compiled module, which is built for another Unreal than "
                 "{0}, so the link is slower there".format(version or "this project's"))
    old = old_python_copy(folder)
    if old:
        line += (". Delete the old copy in Content/Python ({0}), or every BU menu appears "
                 "twice".format(", ".join(os.path.basename(path) for path in old)))
    return line + ". Open the project in Unreal: Blender connects to it by itself"
