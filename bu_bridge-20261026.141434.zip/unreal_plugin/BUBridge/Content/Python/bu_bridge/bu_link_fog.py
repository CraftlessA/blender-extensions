# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender's fog volumes as boxes of Unreal's volumetric fog.

A mesh whose material is only a volume (Blender's `link_lighting.describe_volume`) arrives as a
box: the object's own, rotated and scaled as it is. Unreal shows it as a cube (the engine's,
100 cm) with a **Volume** material: Unreal voxelizes a mesh with a volume material into its
volumetric fog, clipped to the mesh's own box ("object box" voxelization), and evaluates the
material at every cell. So the box keeps its shape (a Local Fog Volume is always a sphere, as
wide as the box's longest side: a 102 x 83 x 11 m layer of ground fog filled a ball 102 m high),
and its density can follow Blender's nodes (`link_nodes.translate_volume`): a height gradient,
a noise. It is lit as volumetric fog is, by every light with a volumetric scattering intensity.

Cycles' Principled Volume, as the material works it out per cell (`extinction`):
scattering = Color x Density, absorption = max(1 - Color, 0) x max(1 - sqrt(Absorption Color),
0) x Density, emission = Emission Color x Strength. Unreal's volumetric fog takes one extinction
(per metre, as Blender's Density) and an albedo, so the extinction is the average of the three
channels and the albedo what scatters of it. Emission is radiance per metre, x 683 to nits as
every light is.

The graph's Object and Generated coordinates are the Blender object's (`FogEmitter`): the cube's
own position, scaled and moved by `BoxScale` and `BoxOffset`, set per box.
"""

import math

from . import bu_link_graph, bu_link_material

SURFACE = "fog"
VERSION = 1
CUBE = "/Engine/BasicShapes/Cube.Cube"
CUBE_CM = 100.0
NITS_PER_UNIT = bu_link_material.NITS_PER_UNIT
# Parameters of the master (and of a graph material, for what the graph does not drive).
COLOR, DENSITY, ABSORPTION, EMISSION = "Color", "Density", "AbsorptionColor", "Emission"
EMISSION_SCALE, BOX_SCALE, BOX_OFFSET = "EmissionScale", "BoxScale", "BoxOffset"


def master_name():
    return "M_BU_Live_Fog_v{0}{1}".format(VERSION, "_S" if bu_link_material.substrate() else "")


def master_path():
    return "{0}/{1}.{1}".format(bu_link_material.PACKAGE, master_name())


def _number(value, fallback=0.0):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return fallback
    return value if value == value else fallback


def _triple(value, fallback):
    try:
        values = [float(v) for v in value][:3]
    except (TypeError, ValueError):
        return tuple(fallback)
    return tuple(values) if len(values) == 3 else tuple(fallback)


def extinction(color, density, absorption):
    """(extinction per metre, albedo) Unreal's volumetric fog takes for Cycles' Principled Volume
    inputs, as the master works them out. Pure."""
    color = [max(0.0, c) for c in _triple(color, (1.0, 1.0, 1.0))]
    absorption = _triple(absorption, (1.0, 1.0, 1.0))
    total = [c + min(1.0, max(0.0, 1.0 - c)) * min(1.0, max(0.0, 1.0 - math.sqrt(max(0.0, a))))
             for c, a in zip(color, absorption)]
    average = sum(total) / 3.0
    albedo = tuple(min(1.0, c / max(average, 1e-6)) for c in color)
    return max(0.0, _number(density)) * average, albedo


def parameters(spec):
    """({scalar: value}, {vector: (r, g, b)}) for a fog box's material instance. Pure.

    `BoxScale` and `BoxOffset` turn the cube's own position (cm, Unreal's axes) into the Blender
    object's coordinates (m): its box's size over 100 with Y the other way, and its centre."""
    spec = spec or {}
    size = _triple(spec.get("box_size"), (1.0, 1.0, 1.0))
    centre = _triple(spec.get("box_centre"), (0.0, 0.0, 0.0))
    scalars = {DENSITY: max(0.0, _number(spec.get("density"), 1.0)),
               EMISSION_SCALE: NITS_PER_UNIT}
    vectors = {COLOR: _triple(spec.get("color"), (1.0, 1.0, 1.0)),
               ABSORPTION: _triple(spec.get("absorption"), (1.0, 1.0, 1.0)),
               EMISSION: tuple(max(0.0, c) for c in _triple(spec.get("emission"), (0, 0, 0))),
               BOX_SCALE: (size[0] / CUBE_CM, -size[1] / CUBE_CM, size[2] / CUBE_CM),
               BOX_OFFSET: centre}
    return scalars, vectors


def reach(scale):
    """The radius (cm) a fog box of this actor scale reaches from its centre. Pure."""
    return 0.5 * CUBE_CM * math.sqrt(sum(float(s) ** 2 for s in scale))


class FogEmitter(bu_link_graph.Emitter):
    """The graph emitter, with Blender's Object and Generated coordinates of the fog box's own
    object rather than the cube's (`parameters`)."""

    def _vector_param(self, name, value):
        found = self._new("MaterialExpressionVectorParameter", parameter_name=name,
                          default_value=self.unreal.LinearColor(*value, 1.0))
        return (found, "RGB")

    def _cube(self):
        return (self.expr("MaterialExpressionLocalPosition")[0], "XYZ")

    def _object(self):
        return self.add(self.mul(self._cube(), self._vector_param(BOX_SCALE, (0.01, -0.01, 0.01))),
                        self._vector_param(BOX_OFFSET, (0.0, 0.0, 0.0)))

    def _op_generated(self, i, opt):
        return self.add(self.mul(self._cube(), self.const(0.01, -0.01, 0.01)),
                        self.const(0.5, 0.5, 0.5))


def build(unreal, material, emitter):
    """Wire a fog material: Volume domain, additive, the channels the graph drives (`emitter`'s)
    or parameters. Returns the connections that failed."""
    library = unreal.MaterialEditingLibrary
    quiet = bu_link_material._quiet
    quiet(material, "material_domain", unreal.MaterialDomain.MD_VOLUME, unreal)
    quiet(material, "blend_mode", unreal.BlendMode.BLEND_ADDITIVE, unreal)
    quiet(material, "use_material_attributes", False, unreal)
    e = emitter

    def scalar(name, value):
        return (e._new("MaterialExpressionScalarParameter", parameter_name=name,
                       default_value=float(value)), "")

    def channel(name, fallback):
        found = e.channel(name)
        return found if found is not None else fallback()

    color = channel(COLOR, lambda: e._vector_param(COLOR, (1.0, 1.0, 1.0)))
    density = channel(DENSITY, lambda: scalar(DENSITY, 1.0))
    absorb = channel(ABSORPTION, lambda: e._vector_param(ABSORPTION, (1.0, 1.0, 1.0)))
    glow = channel(EMISSION, lambda: e._vector_param(EMISSION, (0.0, 0.0, 0.0)))
    root = e.expr("MaterialExpressionSquareRoot",
                  [e.expr("MaterialExpressionMax", [absorb, e.const(0.0)])])
    absorbed = e.mul(e.saturate(e.one_minus(color)), e.saturate(e.one_minus(root)))
    total = e.add(color, absorbed)
    average = e.expr("MaterialExpressionDotProduct", [total, e.const(1 / 3.0, 1 / 3.0, 1 / 3.0)])
    thick = e.mul(e.expr("MaterialExpressionMax", [density, e.const(0.0)]), average)
    albedo = e.saturate(e.div(color, e.expr("MaterialExpressionMax", [average, e.const(1e-6)])))
    emissive = e.mul(glow, scalar(EMISSION_SCALE, NITS_PER_UNIT))
    failed = []
    if bu_link_material.substrate():
        cloud = e._new("MaterialExpressionSubstrateVolumetricFogCloudBSDF")
        names = list(library.get_material_expression_input_names(cloud) or [])
        for source, wanted in ((albedo, "Albedo"), (thick, "Extinction"),
                               (emissive, "Emissive Color")):
            name = next((n for n in names if n.replace(" ", "") == wanted.replace(" ", "")), None)
            if name is None:
                failed.append("FogCloud." + wanted)
                continue
            e._connect(source, cloud, name)
        if not library.connect_material_property(cloud, "",
                                                 unreal.MaterialProperty.MP_FRONT_MATERIAL):
            failed.append("FrontMaterial")
    else:
        # Classic materials: Base Color is the albedo, Subsurface Color's red the extinction.
        for (expression, output), pin in ((albedo, unreal.MaterialProperty.MP_BASE_COLOR),
                                          (thick, unreal.MaterialProperty.MP_SUBSURFACE_COLOR),
                                          (emissive, unreal.MaterialProperty.MP_EMISSIVE_COLOR)):
            if not library.connect_material_property(expression, output, pin):
                failed.append(str(pin))
    return failed + list(e.failed)


def ensure_master():
    """The fog master (no graph), created on first use, or None."""
    import unreal

    path = master_path()
    if unreal.EditorAssetLibrary.does_asset_exist(path.split(".")[0]):
        found = unreal.EditorAssetLibrary.load_asset(path)
        if found is not None:
            return found
    material = unreal.AssetToolsHelpers.get_asset_tools().create_asset(
        master_name(), bu_link_material.PACKAGE, unreal.Material, unreal.MaterialFactoryNew())
    if material is None:
        unreal.log_error("BU: could not create " + path)
        return None
    failed = build(unreal, material, FogEmitter(unreal, material, {"nodes": [], "out": {}}))
    if failed:
        unreal.log_warning("BU: {0}: could not connect {1}".format(master_name(),
                                                                   ", ".join(failed)))
    bu_link_material.compile_material(unreal, material)
    unreal.EditorAssetLibrary.save_loaded_asset(material, only_if_is_dirty=False)
    unreal.log("BU: created {0} for Blender's fog volumes".format(master_name()))
    return material


def parent_for(spec):
    """The material a fog box wears: its graph's, once compiled (`bu_link_graph.ensure`), else
    the master."""
    graph = None
    if (spec or {}).get("graph_key"):
        graph = bu_link_graph.ensure(SURFACE, spec)
    return graph if graph is not None else ensure_master()


def apply(actor, spec, instances):
    """Give a fog box's actor (a StaticMeshActor) the cube and its material. `instances`: the
    link's {actor name: (parent path, dynamic instance)}, reused while the parent stays."""
    import unreal

    name = str(spec.get("name") or "")
    component = actor.get_component_by_class(unreal.StaticMeshComponent)
    cube = unreal.load_asset(CUBE)
    if component.get_editor_property("static_mesh") != cube:
        component.set_static_mesh(cube)
        for prop, value in (("cast_shadow", False), ("affect_distance_field_lighting", False),
                            ("affect_dynamic_indirect_lighting", False),
                            ("visible_in_ray_tracing", False),
                            ("visible_in_reflection_captures", False)):
            try:
                component.set_editor_property(prop, value)
            except Exception:  # noqa: BLE001 - a build without one
                pass
        try:
            component.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION)
        except Exception:  # noqa: BLE001
            pass
    parent = parent_for(spec)
    if parent is None:
        return None
    path = parent.get_path_name()
    held = instances.get(name)
    if held is None or held[0] != path or held[1] is None:
        instance = component.create_dynamic_material_instance(0, parent)
        instances[name] = (path, instance)
    instance = instances[name][1]
    scalars, vectors = parameters(spec)
    for key, value in scalars.items():
        instance.set_scalar_parameter_value(key, value)
    for key, value in vectors.items():
        instance.set_vector_parameter_value(key, unreal.LinearColor(*value, 1.0))
    if spec.get("graph_key"):
        graph_scalars, graph_vectors, textures = bu_link_material.graph_parameters(spec)
        for key, value in graph_scalars.items():
            instance.set_scalar_parameter_value(key, value)
        for key, value in graph_vectors.items():
            instance.set_vector_parameter_value(key, unreal.LinearColor(*value, 1.0))
        for key, (field, role) in textures.items():
            # Imported at once: a texture queued for later reaches only the surface materials
            # waiting for it, never this box, and a Color Ramp's lookup left as the placeholder
            # made Sister Location's fog several times too thick. Ramps are 256 x 1.
            texture = bu_link_material.load_texture(field, role=role, wait=True)
            if texture is not None:
                instance.set_texture_parameter_value(key, texture)
    return instance
