# SPDX-License-Identifier: GPL-3.0-or-later
"""Scene-level UI for the include / exclude lists.

Stored on the scene rather than in add-on preferences, because "which collections make up this
shot" is a property of the .blend, not of the machine it is opened on -- and it needs to travel
with the file and survive a reinstall.

Entries are picked from a dropdown of real collections and objects rather than typed, so a name
cannot be misspelled. They are still *stored* as plain strings: a `PointerProperty` would go stale
if the collection were renamed or deleted, and a dangling pointer is harder to notice and repair
than a name BU can simply report as unknown.
"""

import bpy

from . import filters


class BU_FilterEntry(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(
        name="Collection or Object",
        description="Name of a collection (resolved recursively) or a single object",
        default="",
    )


def _search_items(self, context, edit_text):
    """Collections first, then objects — collections are the common case for a shot."""
    scene = context.scene
    names = [c.name for c in bpy.data.collections]
    names += [o.name for o in scene.objects]
    lowered = (edit_text or "").lower()
    return [n for n in names if lowered in n.lower()][:64]


class BU_UL_filter(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_prop, index):
        scene = context.scene
        known = (
            bpy.data.collections.get(item.name) is not None
            or item.name in scene.objects
        )
        row = layout.row(align=True)
        row.prop_search(
            item, "name", bpy.data, "collections", text="", icon="OUTLINER_COLLECTION"
        )
        if item.name and not known:
            row.label(text="", icon="ERROR")


class BU_OT_filter_add(bpy.types.Operator):
    bl_idname = "bu.filter_add"
    bl_label = "Add Entry"
    bl_description = "Add a collection or object to this list"
    bl_options = {"REGISTER", "UNDO"}

    which: bpy.props.EnumProperty(
        items=(("INCLUDE", "Include", ""), ("EXCLUDE", "Exclude", "")),
        default="INCLUDE",
        options={"HIDDEN"},
    )

    def execute(self, context):
        scene = context.scene
        collection = scene.bu_include if self.which == "INCLUDE" else scene.bu_exclude
        entry = collection.add()
        # Seed with the active collection: usually exactly what the artist meant to add.
        active = context.view_layer.active_layer_collection
        if active is not None and active.collection is not None:
            entry.name = active.collection.name
        if self.which == "INCLUDE":
            scene.bu_include_index = len(collection) - 1
        else:
            scene.bu_exclude_index = len(collection) - 1
        return {"FINISHED"}


class BU_OT_filter_remove(bpy.types.Operator):
    bl_idname = "bu.filter_remove"
    bl_label = "Remove Entry"
    bl_description = "Remove the selected entry from this list"
    bl_options = {"REGISTER", "UNDO"}

    which: bpy.props.EnumProperty(
        items=(("INCLUDE", "Include", ""), ("EXCLUDE", "Exclude", "")),
        default="INCLUDE",
        options={"HIDDEN"},
    )

    def execute(self, context):
        scene = context.scene
        if self.which == "INCLUDE":
            collection, index = scene.bu_include, scene.bu_include_index
        else:
            collection, index = scene.bu_exclude, scene.bu_exclude_index
        if not collection:
            return {"CANCELLED"}
        index = max(0, min(index, len(collection) - 1))
        collection.remove(index)
        # Clamp at zero: removing the last entry would otherwise leave the index at -1, which is
        # not a valid selection for a UIList.
        new_index = max(0, min(index, len(collection) - 1))
        if self.which == "INCLUDE":
            scene.bu_include_index = new_index
        else:
            scene.bu_exclude_index = new_index
        return {"FINISHED"}


def entry_names(collection):
    return [e.name for e in collection if (e.name or "").strip()]


def live_module():
    from . import live
    return live


def shots_module():
    """Imported lazily: filter_ui registers before shots is needed, and a top-level import here
    would make the two modules' import order load-bearing."""
    from . import shots
    return shots


def draw_unreal_target(layout, context):
    """Which Unreal editor an export goes to, when more than one is running.

    Exists because picking the first editor that answers is not a neutral default: with a test
    project and a production project both open, the target is decided by whichever multicast
    heartbeat lands first. That is a coin toss over someone's real work, and it has already sent
    one command to the wrong project during development.
    """
    from . import live

    box = layout.box()
    row = box.row(align=True)
    row.label(text="Unreal Project", icon="LINKED")
    row.operator("bu.scan_unreal", text="", icon="FILE_REFRESH")

    nodes = live.found()
    if not nodes:
        box.label(text="Press refresh to find running editors", icon="INFO")
        return

    box.prop(context.scene, "bu_unreal_target", text="")
    chosen = live.chosen_target(context.scene)
    if len(nodes) > 1 and not chosen:
        warning = box.column()
        warning.alert = True
        warning.label(text="{0} editors running — pick one".format(len(nodes)), icon="ERROR")
        warning.label(text="BU will not guess between projects.")
    elif chosen and chosen not in [n["project_name"] for n in nodes]:
        # A stale selection is worse than none: it looks chosen but no longer matches anything.
        warning = box.column()
        warning.alert = True
        warning.label(text="'{0}' is not running".format(chosen), icon="ERROR")


def draw_shot(layout, context):
    """The shot picker, with a live estimate of what the scoping actually buys.

    The point of scoping is that the *import* is what hurts, not the export, so the estimate is
    shown as a fraction of a full export rather than as a time. It is deliberately labelled as an
    estimate: the same caveat as the subdivision survey applies, and a measured 0.63 face ratio
    came out as a 0.80 file ratio on the reference scene.
    """
    from . import shots

    scene = context.scene
    box = layout.box()
    box.label(text="Shot", icon="SEQUENCE")

    mode = scene.bu_geometry
    box.prop(scene, "bu_geometry", text="")

    available = shots.shots(scene)
    if mode == shots.STATIC:
        # A shot is a frame range, and a static export has no frames to range over.
        box.label(text="One frame, no animation — import once", icon="INFO")
    elif not available:
        box.label(text="No camera-bound markers; whole sequence exports", icon="INFO")
    else:
        box.prop(scene, "bu_shot", text="")

    shot = None
    if available and mode != shots.STATIC and scene.bu_shot != "ALL":
        shot = shots.find(scene, scene.bu_shot)
    if shot is None and mode == shots.ALL:
        return

    try:
        plan = shots.plan(scene, shot, int(scene.bu_subdivision_cap), mode=mode)
    except Exception:  # noqa: BLE001 - a panel must never break the UI
        return

    column = box.column(align=True)
    if mode == shots.STATIC:
        column.label(text="1 of {0} frames".format(plan["total_frames"]))
    elif shot:
        column.label(text="{0} of {1} frames".format(plan["frames"], plan["total_frames"]))
    if mode != shots.ALL:
        column.label(text="{0} of {1} meshes".format(
            plan["meshes_kept"], plan["meshes_total"]))
    # Lead with the counts, which are exact. The multiplied ratio is optimistic by about an order
    # of magnitude (measured), so it is phrased as a floor rather than a number to plan around.
    column.label(text="At best {0:.0%} of a full export; expect several times more".format(
        plan["relative"]), icon="SORTTIME")


def draw_subdivision(layout, context):
    """The subdivision cap, with a live reading of what it would actually do.

    A cap is easy to set and easy to misjudge: on the scene this was written against, every
    modifier was already at level 3, so a cap of 3 looked like a safeguard and saved nothing.
    Showing the affected count and the resulting ratio makes a no-op obvious before the export.
    """
    from . import subdivision

    scene = context.scene
    box = layout.box()
    box.prop(scene, "bu_subdivision_cap")

    cap = scene.bu_subdivision_cap
    if cap < 0:
        box.label(text="Modifiers exported as authored", icon="INFO")
        return

    try:
        survey = subdivision.survey(scene, cap)
    except Exception:  # noqa: BLE001 - a panel must never break the UI
        return

    if not survey["modifiers"]:
        box.label(text="No subdivision modifiers in this scene", icon="INFO")
        return

    if not survey["affected"]:
        warn = box.box()
        warn.alert = True
        warn.label(text="Cap changes nothing — all levels already <= {0}".format(cap),
                   icon="ERROR")
        return

    box.label(
        text="{0} of {1} lowered, {2} on animated meshes".format(
            survey["affected"], survey["modifiers"], survey["affected_animated"]),
        icon="MOD_SUBSURF",
    )
    box.label(text="~{0:.0%} of the per-frame geometry".format(survey["ratio"]), icon="FILE_TICK")


def draw_filters(layout, context):
    """The include/exclude UI, shared by the sidebar and the export operator."""
    scene = context.scene
    include = entry_names(scene.bu_include)
    exclude = entry_names(scene.bu_exclude)

    box = layout.box()
    box.prop(scene, "bu_use_filters")
    if not scene.bu_use_filters:
        return

    for label, which, prop, index_prop, hint in (
        ("Include", "INCLUDE", "bu_include", "bu_include_index",
         "empty = everything; overrides the camera icon"),
        ("Exclude", "EXCLUDE", "bu_exclude", "bu_exclude_index",
         "always wins"),
    ):
        column = box.column(align=True)
        header = column.row()
        header.label(text="{0}  ({1})".format(label, hint))
        row = column.row()
        row.template_list("BU_UL_filter", label, scene, prop, scene, index_prop, rows=2)
        side = row.column(align=True)
        side.operator(BU_OT_filter_add.bl_idname, text="", icon="ADD").which = which
        side.operator(BU_OT_filter_remove.bl_idname, text="", icon="REMOVE").which = which

    unknown = filters.unknown_entries(scene, include + exclude)
    if unknown:
        warn = box.box()
        warn.alert = True
        warn.label(text="Not found: " + ", ".join(unknown[:3]), icon="ERROR")

    if include or exclude:
        dropped = filters.filtered_out(scene, include, exclude)
        box.label(
            text="{0} object(s) will be left out".format(len(dropped)),
            icon="FILTER",
        )

    # Say up front that the include list beats the camera icon. Without this the behaviour looks
    # like BU ignoring the artist's visibility settings, rather than obeying the more specific
    # instruction they just gave it.
    if include:
        blockers, blocked_objects = filters.visibility_blockers(scene, include)
        overridden = [c.name for c in blockers] + [o.name for o in blocked_objects]
        if overridden:
            note = box.box()
            note.label(
                text="Render-disabled, exported anyway: " + ", ".join(overridden[:3]),
                icon="RESTRICT_RENDER_OFF",
            )


_classes = (
    BU_FilterEntry,
    BU_UL_filter,
    BU_OT_filter_add,
    BU_OT_filter_remove,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.bu_use_filters = bpy.props.BoolProperty(
        name="Limit What Exports",
        description=(
            "Export only the collections and objects named below. Saved with the .blend, so one "
            "scene can feed several shots"
        ),
        default=False,
    )
    bpy.types.Scene.bu_shot = bpy.props.EnumProperty(
        name="Shot",
        description=(
            "Export only this camera cut's frame range. The expensive half of this pipeline is "
            "the import, and its cost is linear in frames"
        ),
        items=lambda self, context: shots_module().menu_items(self),
    )
    bpy.types.Scene.bu_unreal_target = bpy.props.EnumProperty(
        name="Unreal Project",
        description=(
            "Which running Unreal Editor a live export goes to. With more than one open, BU "
            "refuses to guess rather than risk importing into the wrong project"
        ),
        items=lambda self, context: live_module().target_items(self, context),
    )
    bpy.types.Scene.bu_geometry = bpy.props.EnumProperty(
        name="Geometry",
        description=(
            "Which half of the scene to export. The set and the characters change on completely "
            "different schedules, so exporting them separately means only the small half gets "
            "re-imported while you work"
        ),
        items=lambda self, context: shots_module().geometry_items(self, context),
    )
    bpy.types.Scene.bu_subdivision_cap = bpy.props.IntProperty(
        name="Cap Subdivision At",
        description=(
            "Temporarily lower every Subdivision Surface modifier to at most this level while "
            "exporting. -1 leaves them alone. Static geometry pays subdivision once and it is "
            "nearly free; animated geometry pays it again on every frame, which is what makes a "
            "character-heavy shot enormous. Your scene is restored exactly afterwards"
        ),
        default=-1,
        min=-1,
        max=6,
    )
    bpy.types.Scene.bu_include = bpy.props.CollectionProperty(type=BU_FilterEntry)
    bpy.types.Scene.bu_include_index = bpy.props.IntProperty(default=0)
    bpy.types.Scene.bu_exclude = bpy.props.CollectionProperty(type=BU_FilterEntry)
    bpy.types.Scene.bu_exclude_index = bpy.props.IntProperty(default=0)


def unregister():
    for attr in ("bu_use_filters", "bu_subdivision_cap", "bu_include", "bu_include_index",
                 "bu_exclude", "bu_exclude_index"):
        if hasattr(bpy.types.Scene, attr):
            delattr(bpy.types.Scene, attr)
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
