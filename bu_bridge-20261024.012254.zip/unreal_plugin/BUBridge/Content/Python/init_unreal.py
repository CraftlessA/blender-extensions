# SPDX-License-Identifier: GPL-3.0-or-later
"""Unreal auto-startup for BU. Copy this file and the bu_bridge/ folder into your
project's Content/Python/ directory; Unreal runs init_unreal.py on editor startup.

Adds a "BU" section to the main Tools menu, and material presets to the Content Browser's
right-click menu for material instances.
"""

import os

import unreal

import bu_bridge
from bu_bridge import bu_presets

_MENU_OWNER = "bu_bridge"
_DEFAULT_DESTINATION = "/Game/BU"

# Right-clicking a material instance is where a per-material fix belongs: the correct render
# state differs between two materials in the same import, so this cannot be a project setting.
_ASSET_CONTEXT_MENU = "ContentBrowser.AssetContextMenu.MaterialInstanceConstant"


def _pick_file(title, patterns):
    """Best-effort native file picker.

    Unreal exposes no file-open dialog to Python, so use tkinter when it is available and
    fall back to telling the user the console call rather than failing silently.
    """
    try:
        import tkinter
        from tkinter import filedialog

        root = tkinter.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        path = filedialog.askopenfilename(title=title, filetypes=patterns)
        root.destroy()
        return path or None
    except Exception:  # noqa: BLE001 - tkinter is not guaranteed in every UE build
        unreal.log_warning(
            "BU: no file dialog available here. Run it from the Python console instead:\n"
            '    import bu_bridge; bu_bridge.import_scene(r"D:/path/Shot.usdc", "/Game/BU")'
        )
        return None


@unreal.uclass()
class BUImportSceneEntry(unreal.ToolMenuEntryScript):
    @unreal.ufunction(override=True)
    def execute(self, context):
        path = _pick_file(
            "Select a BU-exported USD",
            [("USD", "*.usd *.usda *.usdc"), ("All files", "*.*")],
        )
        if path:
            bu_bridge.import_scene(path, _DEFAULT_DESTINATION)


@unreal.uclass()
class BUReapplyEntry(unreal.ToolMenuEntryScript):
    @unreal.ufunction(override=True)
    def execute(self, context):
        path = _pick_file("Select a BU manifest", [("BU manifest", "*.bu.json"), ("All files", "*.*")])
        if path:
            bu_bridge.reapply_settings(path, _DEFAULT_DESTINATION)


def _preset_entry_class(preset_name):
    """Build a menu-entry class bound to one preset.

    A class per preset, because `ToolMenuEntryScript.execute` takes no arguments -- the preset it
    applies has to be baked in. Closing over the loop variable directly would give every entry the
    last preset, so the name is captured as a class attribute.
    """

    @unreal.uclass()
    class _Entry(unreal.ToolMenuEntryScript):
        @unreal.ufunction(override=True)
        def execute(self, context):
            bu_presets.apply_preset(preset_name)

    return _Entry


@unreal.uclass()
class BUPruneVariantsEntry(unreal.ToolMenuEntryScript):
    @unreal.ufunction(override=True)
    def execute(self, context):
        bu_bridge.prune_material_variants(_DEFAULT_DESTINATION)


@unreal.uclass()
class BUVerifyCachesEntry(unreal.ToolMenuEntryScript):
    @unreal.ufunction(override=True)
    def execute(self, context):
        bu_bridge.verify_geometry_caches()


@unreal.uclass()
class BUStartLinkEntry(unreal.ToolMenuEntryScript):
    @unreal.ufunction(override=True)
    def execute(self, context):
        bu_bridge.start_link()


@unreal.uclass()
class BUStopLinkEntry(unreal.ToolMenuEntryScript):
    @unreal.ufunction(override=True)
    def execute(self, context):
        bu_bridge.stop_link()


def _add_entry(menu, script_class, name, label, tooltip, menu_name=None, section="BU"):
    entry = script_class()
    entry.init_entry(
        owner_name=_MENU_OWNER,
        menu=menu_name or menu.menu_name,
        section=section,
        name=name,
        label=label,
        tool_tip=tooltip,
    )
    entry.register_menu_entry()


def register_material_presets():
    """Add BU's material presets to the material-instance right-click menu."""
    menus = unreal.ToolMenus.get()
    menu = menus.extend_menu(_ASSET_CONTEXT_MENU)
    if menu is None:
        unreal.log_warning(
            "BU: could not extend '{0}'; material presets will still work from the Python "
            "console via bu_bridge.apply_material_preset('cutout')".format(_ASSET_CONTEXT_MENU)
        )
        return 0

    menu.add_section(section_name="BUPresets", label="BU — Material Presets")

    added = 0
    for preset_name in bu_presets.PRESET_ORDER:
        preset = bu_presets.PRESETS[preset_name]
        _add_entry(
            menu,
            _preset_entry_class(preset_name),
            "BUPreset_" + preset_name,
            preset["label"],
            preset["tooltip"],
            menu_name=_ASSET_CONTEXT_MENU,
            section="BUPresets",
        )
        added += 1
    return added


def register_menus():
    menus = unreal.ToolMenus.get()
    tools_menu = menus.find_menu("LevelEditor.MainMenu.Tools")
    if tools_menu is None:
        unreal.log_warning("BU: could not find the Tools menu; skipping menu registration")
        return

    tools_menu.add_section(section_name="BU", label="BU — Blender Bridge")

    _add_entry(
        tools_menu,
        BUImportSceneEntry,
        "BUImportScene",
        "Import Blender Scene (BU)",
        "Import a BU-exported USD, apply texture filtering and build the camera-cut sequence",
    )
    _add_entry(
        tools_menu,
        BUReapplyEntry,
        "BUReapply",
        "Re-apply BU Texture Settings",
        "Re-assert texture filtering from a BU manifest without re-importing",
    )

    _add_entry(
        tools_menu,
        BUVerifyCachesEntry,
        "BUVerifyCaches",
        "Check Baked Geometry Is Animating",
        "Report any GeometryCache with no sequence track — the usual reason a rigged character "
        "does not appear",
    )

    _add_entry(
        tools_menu,
        BUPruneVariantsEntry,
        "BUPruneVariants",
        "Remove Duplicate One-Sided Materials",
        "Unreal makes a plain and a TwoSided instance per material but only uses the TwoSided "
        "one; this deletes the unused plain copies",
    )

    _add_entry(
        tools_menu,
        BUStartLinkEntry,
        "BUStartLink",
        "Start Real-Time Link (listen for Blender)",
        "Listen on this machine for BU's real-time link, so Blender can stream meshes into the "
        "level as they change. Blender normally starts this itself",
    )
    _add_entry(
        tools_menu,
        BUStopLinkEntry,
        "BUStopLink",
        "Stop Real-Time Link",
        "Close the real-time link. Actors it created stay until the editor closes",
    )

    presets = register_material_presets()

    menus.refresh_all_widgets()
    unreal.log(
        "BU: menu registered under Tools; {0} material preset(s) on the material-instance "
        "right-click menu.".format(presets)
    )


def prune_link_cache():
    """Delete real-time-link cache files nothing refers to, before anything can load them."""
    try:
        from bu_bridge import bu_link_static

        removed = bu_link_static.prune_files()
        if removed:
            unreal.log("BU: removed {0} unused real-time link mesh(es) from the cache".format(removed))
        from bu_bridge import bu_link_cache

        removed, freed = bu_link_cache.prune_files()
        if removed:
            unreal.log("BU: removed {0} old texture(s) and node material(s) from the cache "
                       "({1:.0f} MB)".format(removed, freed / 2.0 ** 20))
    except Exception as exc:  # noqa: BLE001 - never stop the editor starting over a cache
        unreal.log_warning("BU: could not tidy the real-time link cache: {0}".format(exc))


def host_for_blender():
    """When Blender started this editor as its renderer (`bu_host`), open BU's level and listen."""
    if not os.environ.get("BU_HOST_PORT"):
        return
    try:
        from bu_bridge import bu_host

        bu_host.begin()
    except Exception as exc:  # noqa: BLE001
        unreal.log_error("BU: could not start as Blender's renderer: {0}".format(exc))


prune_link_cache()

if os.environ.get("BU_DISABLE_MENU") != "1":
    register_menus()

host_for_blender()
