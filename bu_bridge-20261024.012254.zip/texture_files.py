# SPDX-License-Identifier: GPL-3.0-or-later
"""Writes out textures that only exist inside the .blend file.

Blender's USD exporter references packed and generated images -- it writes
`@./textures/Foo.png@` into the stage -- but never writes the file, so the texture arrives
in Unreal as a dangling reference. Rather than mutating the user's image datablocks before
export (unpacking, repointing paths) we let the exporter decide the paths it wants, then
materialise whatever is missing afterwards.

`Image.save(filepath=..., save_copy=True)` is what makes this safe: without `save_copy` the
datablock mutates (a GENERATED image flips to FILE), which would quietly alter the artist's
scene.
"""

import contextlib
import os
import re

import bpy

from . import capture

# Characters Windows will not accept in a filename. Blender happily names an image datablock
# "Props | 1" -- pipes, colons and the rest are all legal there -- and its own USD exporter bakes
# that name straight into the stage as the texture's authored filename with no sanitising at all.
# Measured: `materialize()` then fails to write "Props | 1.png" with an OpenImageIO/Windows error,
# and because that happens inside the live-export path it surfaces as a hard failure, not a
# per-texture warning -- one bad image name stops the whole export from reaching Unreal.
_WINDOWS_ILLEGAL = re.compile(r'[<>:"|?*\x00-\x1f]')


@contextlib.contextmanager
def sanitized_image_names(materials):
    """Rename images with a Windows-illegal name for the duration of the export.

    Has to run *before* `bpy.ops.wm.usd_export`, not after: the illegal filename is baked into
    the stage at export time from whatever `image.name` is at that moment, so fixing it only in
    `materialize()` (which runs on the already-written stage) is too late -- the stage would
    still reference the illegal name even if a clean file existed on disk beside it.

    Yields the renames made, as (original, sanitized) pairs, and restores every name exactly
    afterwards, however the export goes.
    """
    seen = set()
    renamed = []
    try:
        for material in materials:
            for node in capture._iter_image_nodes(getattr(material, "node_tree", None)):
                image = node.image
                if image is None or image.name in seen:
                    continue
                seen.add(image.name)
                if not _WINDOWS_ILLEGAL.search(image.name):
                    continue
                original = image.name
                cleaned = _WINDOWS_ILLEGAL.sub("_", original).strip(" .") or "image"
                # bpy.data collections de-duplicate names automatically (Foo, Foo.001, ...), so
                # this can never collide with an existing datablock.
                image.name = cleaned
                renamed.append((original, image.name))
        yield renamed
    finally:
        for original, current in renamed:
            image = bpy.data.images.get(current)
            if image is not None:
                try:
                    image.name = original
                except Exception:  # noqa: BLE001 - restore must never mask the export result
                    pass


def _index_images(materials):
    """Map every candidate export filename to the image that should provide it."""
    index = {}
    for material in materials:
        for node in capture._iter_image_nodes(getattr(material, "node_tree", None)):
            for key in capture.texture_match_keys(node.image):
                index.setdefault(key, node.image)
    return index


def _iter_texture_refs(usd_path):
    """Yield (prim_path, authored_asset_path) for every UsdUVTexture in the stage."""
    try:
        from pxr import Usd, UsdShade
    except ImportError:
        return

    stage = Usd.Stage.Open(usd_path)
    if stage is None:
        return

    for prim in stage.Traverse():
        if not prim.IsA(UsdShade.Shader):
            continue
        shader = UsdShade.Shader(prim)
        shader_id = shader.GetShaderId()
        if shader_id != "UsdUVTexture":
            continue
        file_input = shader.GetInput("file")
        if not file_input:
            continue
        value = file_input.Get()
        if value is None:
            continue
        authored = getattr(value, "path", None) or str(value)
        if authored:
            yield prim.GetPath().pathString, authored


def materialize(usd_path, materials=None):
    """Write any texture the stage references but that does not exist on disk.

    Returns (written, failures) where written is a list of paths and failures is a list of
    human-readable strings.
    """
    if materials is None:
        materials = [m for m in bpy.data.materials if m.users > 0]

    usd_dir = os.path.dirname(os.path.abspath(usd_path))
    index = _index_images(materials)

    written = []
    failures = []
    seen = set()

    for prim_path, authored in _iter_texture_refs(usd_path):
        # Authored paths are relative to the stage; normalise the ".\textures\x.png" form.
        candidate = authored.replace("\\", "/")
        target = candidate if os.path.isabs(candidate) else os.path.join(usd_dir, candidate)
        target = os.path.normpath(target)

        if target in seen:
            continue
        seen.add(target)

        if os.path.isfile(target):
            continue

        image = index.get(os.path.basename(target).lower())
        if image is None:
            failures.append(
                "{0} references '{1}', which is missing and could not be matched to an "
                "image in the scene.".format(prim_path, authored)
            )
            continue

        # An image whose file is gone and whose pixels are not held anywhere cannot be written,
        # and trying produces "does not have any image data" once per candidate path — twice for
        # a single broken link on Ennard.blend, naming neither the path nor the materials.
        # `capture.unresolvable_images` reports that case properly, so stay quiet here.
        if not image.packed_file and image.source != "GENERATED" and not image.has_data:
            continue

        try:
            os.makedirs(os.path.dirname(target), exist_ok=True)
            # save_copy keeps the datablock untouched -- see module docstring.
            image.save(filepath=target, save_copy=True)
        except (RuntimeError, OSError) as exc:
            failures.append("Could not write '{0}' for image '{1}': {2}".format(target, image.name, exc))
            continue

        if os.path.isfile(target):
            written.append(target)
        else:
            failures.append(
                "Blender reported no error but '{0}' was not written (image '{1}').".format(
                    target, image.name
                )
            )

    return written, failures
