# SPDX-License-Identifier: GPL-3.0-or-later
"""BU's own surface material: eight parameters where UsdPreviewSurface has thirty-nine.

Unreal's `UsdPreviewSurface` carries **8 texture parameters and 31 scalars**. In a voxel scene
almost none are used -- metallic, roughness, normal, refraction and ambient occlusion all sit bound
to shared `127grey` / `BaseFlattenNormalMap` placeholders, and every channel drags along its own
UV-index and rotation scalars. They are parameters that exist to be ignored.

The same surface, expressed for Minecraft-style content:

    BaseColorTexture / BaseColor, switched by UseBaseColorTexture -> BaseColor
    OpacityTexture (alpha) -> OpacityMask *and* Opacity
    EmissiveColorTexture   -> x UseEmissiveColorTexture -> EmissiveColor
    NormalTexture          -> Normal        flat by default, so unbound behaves as no map
    Roughness  (float)     -> Roughness      one value per material, never a map
    Specular   (float)     -> Specular
    Metallic   (float)     -> Metallic

Four deliberate decisions:

* **Alpha drives both opacity pins.** `Opacity` and `OpacityMask` are separate material inputs and
  the blend mode decides which is read -- OpacityMask when masked, Opacity when translucent.
  Wiring only one is precisely how a material ends up silently opaque in the other mode, which is
  the bug that made masked alpha do nothing at all until BU authored its own material.
* **Roughness and specular are floats, not textures.** Voxel textures never map them per-pixel, so
  a sampler plus its UV-index and rotation scalars would buy nothing. Roughness defaults to 1.0
  rather than Unreal's 0.5, because flat pixel art under a 0.5 default reads as wet plastic.
* **Metallic is a float too.** It was originally left unconnected on the reasoning that voxel art
  is never metallic -- which was wrong: a real Blender material in this project exported
  `Metallic = 0.2`, and it was being silently dropped.
* **Base colour is a *switch*, not a blend.** A material has either a texture or a constant, and
  `UseBaseColorTexture` says which -- so the unused half is left at whatever value it happens to
  hold. Multiplying the two seemed elegant and was wrong: a real clothing material carried
  `T_Charlotte_Clothing1` **and** `BaseColor = (0,0,0)`, because with the switch on the constant is
  meant to be ignored. Multiplying gave `texture x black` and the body turned solid black. Lerping
  on the switch matches Unreal and handles both halves. (The constant-only case is not
  hypothetical either: a skin material with no image at all first imported pure white, because
  BU's material had no vector parameter for the colour to land in.)
* **The normal map needs no on/off switch.** Its default is a flat tangent-space normal, so an
  unbound slot shades identically to having no map. A switch would only be a second way to say
  the same thing.

Blend mode lives on instances rather than in per-material overrides -- the same shape Epic uses
for `UsdPreviewSurfaceTranslucent`, and it means one compiled master serves every surface type.
"""

import unreal

PACKAGE = "/Game/BU/Materials"
MATERIAL = "M_BU_Surface"

BASE_COLOR_PARAM = "BaseColorTexture"
OPACITY_PARAM = "OpacityTexture"
EMISSIVE_PARAM = "EmissiveColorTexture"
# Named for Unreal's convention, not ours: `wire_materials` sets `Use<Channel>Texture` to 1.0
# whenever it binds a channel, so matching that name means emissive lights up with no special
# casing. It is a multiplier, so a value above 1 also serves as a glow boost.
EMISSIVE_STRENGTH_PARAM = "UseEmissiveColorTexture"
ROUGHNESS_PARAM = "Roughness"
SPECULAR_PARAM = "Specular"
METALLIC_PARAM = "Metallic"
NORMAL_PARAM = "NormalTexture"
BASE_COLOR_TINT_PARAM = "BaseColor"
USE_BASE_COLOR_PARAM = "UseBaseColorTexture"

# (suffix, blend mode, two-sided)
VARIANTS = (
    ("Opaque", "BLEND_OPAQUE", False),
    ("OpaqueTwoSided", "BLEND_OPAQUE", True),
    ("Masked", "BLEND_MASKED", False),
    ("MaskedTwoSided", "BLEND_MASKED", True),
    ("Translucent", "BLEND_TRANSLUCENT", False),
    ("TranslucentTwoSided", "BLEND_TRANSLUCENT", True),
)

WHITE_TEXTURE = "/Engine/EngineResources/WhiteSquareTexture"
BLACK_TEXTURE = "/Engine/EngineResources/Black"
# Flat tangent-space normal, so an unbound normal map shades exactly as if there
# were none at all. Not `DefaultNormal`, which is the tiled, bumpy normal map of Unreal's
# grey default material; earlier builds used it, and `ensure` swaps it out.
FLAT_NORMAL_TEXTURE = "/Engine/EngineMaterials/FlatNormal"
OLD_NORMAL_TEXTURE = "DefaultNormal"


def material_path():
    return "{0}/{1}.{1}".format(PACKAGE, MATERIAL)


def variant_name(suffix):
    return "MI_BU_Surface_" + suffix


def variant_path(suffix):
    name = variant_name(suffix)
    return "{0}/{1}.{1}".format(PACKAGE, name)


def _texture_param(material, library, name, y, default):
    node = library.create_material_expression(
        material, unreal.MaterialExpressionTextureSampleParameter2D, -520, y
    )
    node.set_editor_property("parameter_name", name)
    # A texture parameter with no default compiles against Unreal's checkerboard placeholder and
    # then masks against that placeholder's opaque alpha, clipping nothing.
    if default is not None:
        node.set_editor_property("texture", default)
    return node


def _scalar_param(material, library, name, y, value):
    node = library.create_material_expression(
        material, unreal.MaterialExpressionScalarParameter, -520, y
    )
    node.set_editor_property("parameter_name", name)
    node.set_editor_property("default_value", value)
    return node


def _vector_param(material, library, name, y, value):
    node = library.create_material_expression(
        material, unreal.MaterialExpressionVectorParameter, -520, y
    )
    node.set_editor_property("parameter_name", name)
    node.set_editor_property("default_value", value)
    return node


def _tint_base_colour(material, library, base):
    """Lerp(BaseColor constant, base colour texture, UseBaseColorTexture) -> BaseColor.

    A switch rather than a blend, because that is what the importer means by these values: with
    `UseBaseColorTexture = 1` the constant is dead weight and frequently (0,0,0).
    """
    tint = _vector_param(
        material, library, BASE_COLOR_TINT_PARAM, -420,
        unreal.LinearColor(1.0, 1.0, 1.0, 1.0),
    )
    switch = _scalar_param(material, library, USE_BASE_COLOR_PARAM, -420, 0.0)
    blend = library.create_material_expression(
        material, unreal.MaterialExpressionLinearInterpolate, -240, -300
    )
    library.connect_material_expressions(tint, "", blend, "A")
    library.connect_material_expressions(base, "RGB", blend, "B")
    library.connect_material_expressions(switch, "", blend, "Alpha")
    library.connect_material_property(blend, "", unreal.MaterialProperty.MP_BASE_COLOR)
    return blend


def _add_normal(material, library):
    """Wire a normal map, defaulting to flat.

    The sampler type is the part that matters: a normal map sampled as SAMPLERTYPE_COLOR is
    interpreted as sRGB colour rather than a tangent-space vector, which does not merely look
    wrong -- it fails material compilation, and a material that fails to compile renders as
    Unreal's default grey. Setting it explicitly avoids diagnosing that as a missing texture.
    """
    flat = unreal.EditorAssetLibrary.load_asset(FLAT_NORMAL_TEXTURE)
    node = library.create_material_expression(
        material, unreal.MaterialExpressionTextureSampleParameter2D, -520, 760
    )
    node.set_editor_property("parameter_name", NORMAL_PARAM)
    if flat is not None:
        node.set_editor_property("texture", flat)
    try:
        node.set_editor_property("sampler_type", unreal.MaterialSamplerType.SAMPLERTYPE_NORMAL)
    except Exception as exc:  # noqa: BLE001
        unreal.log_warning("BU: could not set the normal sampler type ({0})".format(exc))
    library.connect_material_property(node, "RGB", unreal.MaterialProperty.MP_NORMAL)


def _flatten_normal(material, library):
    """Swap an earlier build's `DefaultNormal` default for the flat one. True if it changed."""
    flat = unreal.EditorAssetLibrary.load_asset(FLAT_NORMAL_TEXTURE)
    if flat is None:
        return False
    for expression in library.get_material_expressions(material):
        try:
            if str(expression.get_editor_property("parameter_name")) != NORMAL_PARAM:
                continue
            texture = expression.get_editor_property("texture")
        except Exception:  # noqa: BLE001
            continue
        if texture is not None and texture.get_name() == OLD_NORMAL_TEXTURE:
            expression.set_editor_property("texture", flat)
            return True
    return False


def build_graph(material):
    """Wire the eight parameters onto the pins that matter."""
    library = unreal.MaterialEditingLibrary
    white = unreal.EditorAssetLibrary.load_asset(WHITE_TEXTURE)
    black = unreal.EditorAssetLibrary.load_asset(BLACK_TEXTURE)

    base = _texture_param(material, library, BASE_COLOR_PARAM, -300, white)
    _tint_base_colour(material, library, base)

    opacity = _texture_param(material, library, OPACITY_PARAM, -60, white)
    library.connect_material_property(opacity, "A", unreal.MaterialProperty.MP_OPACITY_MASK)
    library.connect_material_property(opacity, "A", unreal.MaterialProperty.MP_OPACITY)

    emissive = _texture_param(material, library, EMISSIVE_PARAM, 180, black)
    strength = _scalar_param(material, library, EMISSIVE_STRENGTH_PARAM, 400, 0.0)
    multiply = library.create_material_expression(
        material, unreal.MaterialExpressionMultiply, -240, 240
    )
    library.connect_material_expressions(emissive, "RGB", multiply, "A")
    library.connect_material_expressions(strength, "", multiply, "B")
    library.connect_material_property(multiply, "", unreal.MaterialProperty.MP_EMISSIVE_COLOR)

    roughness = _scalar_param(material, library, ROUGHNESS_PARAM, 500, 1.0)
    library.connect_material_property(roughness, "", unreal.MaterialProperty.MP_ROUGHNESS)

    specular = _scalar_param(material, library, SPECULAR_PARAM, 580, 0.5)
    library.connect_material_property(specular, "", unreal.MaterialProperty.MP_SPECULAR)

    metallic = _scalar_param(material, library, METALLIC_PARAM, 660, 0.0)
    library.connect_material_property(metallic, "", unreal.MaterialProperty.MP_METALLIC)

    _add_normal(material, library)


def ensure():
    """Create the material and its blend-mode instances once. Returns (material, {suffix: mi})."""
    material = unreal.EditorAssetLibrary.load_asset(material_path())
    tools = unreal.AssetToolsHelpers.get_asset_tools()
    library = unreal.MaterialEditingLibrary

    if material is not None:
        # Upgrade an earlier build in place. Recreating would orphan every instance already
        # parented to it, so add only what is missing and recompile.
        try:
            textures = {str(x) for x in library.get_texture_parameter_names(material)}
            scalars = {str(x) for x in library.get_scalar_parameter_names(material)}
        except Exception:  # noqa: BLE001
            textures, scalars = {NORMAL_PARAM}, {METALLIC_PARAM}
        added = []
        if METALLIC_PARAM not in scalars:
            metallic = _scalar_param(material, library, METALLIC_PARAM, 660, 0.0)
            library.connect_material_property(metallic, "", unreal.MaterialProperty.MP_METALLIC)
            added.append(METALLIC_PARAM)
        if NORMAL_PARAM not in textures:
            _add_normal(material, library)
            added.append(NORMAL_PARAM)
        elif _flatten_normal(material, library):
            added.append("a flat default normal")
        try:
            vectors = {str(x) for x in library.get_vector_parameter_names(material)}
        except Exception:  # noqa: BLE001
            vectors = {BASE_COLOR_TINT_PARAM}
        if BASE_COLOR_TINT_PARAM not in vectors or USE_BASE_COLOR_PARAM not in scalars:
            # Rewire the existing base-colour sampler through a multiply rather than rebuilding
            # the material, which would orphan every instance already parented to it.
            found = {}
            for expression in library.get_material_expressions(material):
                try:
                    name = str(expression.get_editor_property("parameter_name"))
                except Exception:  # noqa: BLE001
                    continue
                if name in (BASE_COLOR_PARAM, BASE_COLOR_TINT_PARAM, USE_BASE_COLOR_PARAM):
                    found[name] = expression
            existing_base = found.get(BASE_COLOR_PARAM)
            if existing_base is not None:
                # Rewiring MP_BASE_COLOR replaces the old connection; whatever fed it before is
                # left dangling, so sweep it up rather than leaving a stale multiply behind.
                # Reuse whatever already exists -- creating a second node with the same
                # parameter name would give the material two BaseColor parameters.
                tint = found.get(BASE_COLOR_TINT_PARAM) or _vector_param(
                    material, library, BASE_COLOR_TINT_PARAM, -420,
                    unreal.LinearColor(1.0, 1.0, 1.0, 1.0),
                )
                switch = found.get(USE_BASE_COLOR_PARAM) or _scalar_param(
                    material, library, USE_BASE_COLOR_PARAM, -420, 0.0
                )
                blend = library.create_material_expression(
                    material, unreal.MaterialExpressionLinearInterpolate, -240, -300
                )
                library.connect_material_expressions(tint, "", blend, "A")
                library.connect_material_expressions(existing_base, "RGB", blend, "B")
                library.connect_material_expressions(switch, "", blend, "Alpha")
                library.connect_material_property(
                    blend, "", unreal.MaterialProperty.MP_BASE_COLOR
                )
                # Rewiring MP_BASE_COLOR leaves the previous multiply dangling; sweep it up.
                try:
                    library.delete_unused_expressions(material)
                except Exception:  # noqa: BLE001
                    pass
                added.append(USE_BASE_COLOR_PARAM)
            else:
                unreal.log_warning(
                    "BU: could not find the BaseColorTexture node to add the colour tint to"
                )
        if added:
            library.recompile_material(material)
            unreal.EditorAssetLibrary.save_loaded_asset(material, only_if_is_dirty=False)
            unreal.log("BU: added {0} to {1} in place".format(", ".join(added), MATERIAL))

    if material is None:
        material = tools.create_asset(
            MATERIAL, PACKAGE, unreal.Material, unreal.MaterialFactoryNew()
        )
        if material is None:
            unreal.log_error("BU: could not create " + material_path())
            return None, {}
        build_graph(material)
        # Masked on the master, so the default compile carries the mask path; instances override.
        material.set_editor_property("blend_mode", unreal.BlendMode.BLEND_MASKED)
        # Two-sided by default, because Blender's default is backface culling *off* -- so a
        # material that says nothing about sidedness is double-sided, and single-sided is the
        # deliberate choice. Getting this backwards makes thin geometry (panes, leaves, layered
        # clothing) vanish from one side with no obvious cause.
        material.set_editor_property("two_sided", True)
        library.recompile_material(material)
        unreal.EditorAssetLibrary.save_loaded_asset(material, only_if_is_dirty=False)
        unreal.log(
            "BU: created {0} — 4 textures and 4 floats, where UsdPreviewSurface has 8 textures "
            "and 31 scalars".format(MATERIAL)
        )

    # An earlier build of this material was single-sided. Fix it in place rather than leaving
    # thin geometry invisible from behind.
    try:
        if not material.get_editor_property("two_sided"):
            material.set_editor_property("two_sided", True)
            library.recompile_material(material)
            unreal.EditorAssetLibrary.save_loaded_asset(material, only_if_is_dirty=False)
            unreal.log("BU: {0} switched to two-sided".format(MATERIAL))
    except Exception:  # noqa: BLE001
        pass

    variants = {}
    for suffix, blend, two_sided in VARIANTS:
        instance = unreal.EditorAssetLibrary.load_asset(variant_path(suffix))
        if instance is None:
            instance = tools.create_asset(
                variant_name(suffix), PACKAGE, unreal.MaterialInstanceConstant,
                unreal.MaterialInstanceConstantFactoryNew(),
            )
            if instance is None:
                continue
            instance.set_editor_property("parent", material)
            overrides = instance.get_editor_property("base_property_overrides")
            overrides.set_editor_property("override_blend_mode", True)
            overrides.set_editor_property("blend_mode", getattr(unreal.BlendMode, blend))
            try:
                overrides.set_editor_property("override_two_sided", True)
                overrides.set_editor_property("two_sided", two_sided)
            except Exception:  # noqa: BLE001
                unreal.log_warning(
                    "BU: this engine build exposes no two-sided override; "
                    "{0} will follow the master".format(variant_name(suffix))
                )
            instance.set_editor_property("base_property_overrides", overrides)
            library.update_material_instance(instance)
            unreal.EditorAssetLibrary.save_loaded_asset(instance, only_if_is_dirty=False)
        variants[suffix] = instance

    return material, variants


# Channels BU's surface does not carry. A material genuinely using one is named in a warning
# rather than silently losing it. Emissive is absent from this list because BU *does* carry it.
CHANNELS_NOT_CARRIED = (
    "NormalTexture", "RoughnessTexture", "MetallicTexture", "AmbientOcclusionTexture",
)

# Never adopt BU's own assets -- reparenting a variant onto itself would form a cycle.
_OWN_PREFIX = "MI_BU_Surface"


def blend_for_entry(entry):
    """Which blend mode a manifest material wants.

    Blender's `surface_render_method` is the signal: `BLENDED` means the artist wanted real
    transparency (glass, water) and `DITHERED`/`CLIP` means a cutout. Anything with no alpha at all
    is opaque, which is the majority of a voxel scene and the case Unreal gets wrong -- it hands a
    translucent parent to anything whose texture merely *has* an alpha channel.
    """
    alpha = entry.get("alpha") or {}
    if not alpha.get("uses_alpha"):
        return "Opaque"
    return "Masked" if alpha.get("unreal_blend") == "Masked" else "Translucent"


def adopt_all(content_path, manifest):
    """Reparent every imported material onto BU's surface. Returns (adopted, skipped, failed).

    Runs after `wire_materials`, so the texture bindings already exist. They survive the reparent
    untouched because material instance overrides are keyed by *name*, and BU deliberately uses
    Unreal's own parameter names.
    """
    from . import bu_names

    material, variants = ensure()
    if material is None:
        return 0, 0, 0

    wanted = {}
    thresholds = {}
    sidedness = {}
    for entry in manifest.data.get("materials", []):
        blend = blend_for_entry(entry)
        alpha = entry.get("alpha") or {}
        # Blender's `use_backface_culling` is the artist's actual statement about sidedness, and
        # it defaults to False -- so absent any flag, two-sided is correct.
        two_sided = not bool(entry.get("backface_culling", False))
        sanitized = bu_names._BLENDER_PRIM_UNSAFE.sub("_", entry.get("name", ""))
        for prefix in ("MI_" + sanitized, "M_" + sanitized, sanitized):
            wanted[prefix.lower()] = blend
            thresholds[prefix.lower()] = float(alpha.get("alpha_threshold", 0.5) or 0.5)
            sidedness[prefix.lower()] = two_sided

    library = unreal.MaterialEditingLibrary
    adopted = skipped = failed = 0
    counts = {}
    dropped_channels = {}

    for path in unreal.EditorAssetLibrary.list_assets(content_path, recursive=True):
        asset = unreal.EditorAssetLibrary.load_asset(path)
        if not isinstance(asset, unreal.MaterialInstanceConstant):
            continue
        name = asset.get_name()
        if name.startswith(_OWN_PREFIX):
            continue

        lowered = name.lower()
        blend = None
        threshold = 0.5
        two_sided = True
        for prefix, value in wanted.items():
            if lowered == prefix or lowered.startswith(prefix + "_"):
                blend = value
                threshold = thresholds.get(prefix, 0.5)
                two_sided = sidedness.get(prefix, True)
                break
        if blend is None:
            # Not in the manifest -- opaque is the safe default: it sorts correctly and costs
            # least, and a wrongly-opaque surface is far easier to spot than a wrongly-translucent
            # one, which just looks subtly dark.
            blend = "Opaque"

        parent = parent_for(asset, blend, two_sided)
        if parent is None:
            failed += 1
            continue
        if asset.parent is not None and asset.parent.get_path_name() == parent.get_path_name():
            skipped += 1
            continue

        for channel in CHANNELS_NOT_CARRIED:
            try:
                texture = library.get_material_instance_texture_parameter_value(asset, channel)
            except Exception:  # noqa: BLE001
                continue
            if texture is not None and content_path in texture.get_path_name():
                dropped_channels.setdefault(channel, []).append(name)

        try:
            asset.set_editor_property("parent", parent)
            if blend == "Masked":
                overrides = asset.get_editor_property("base_property_overrides")
                overrides.set_editor_property("override_opacity_mask_clip_value", True)
                overrides.set_editor_property("opacity_mask_clip_value", threshold)
                asset.set_editor_property("base_property_overrides", overrides)
            library.update_material_instance(asset)
            unreal.EditorAssetLibrary.save_loaded_asset(asset, only_if_is_dirty=False)
            adopted += 1
            counts[blend] = counts.get(blend, 0) + 1
        except Exception as exc:  # noqa: BLE001
            failed += 1
            unreal.log_warning("BU: could not adopt '{0}' ({1})".format(name, exc))

    for channel, names in dropped_channels.items():
        unreal.log_warning(
            "BU: {0} material(s) bind {1}, which BU's surface does not carry, so that channel "
            "stops contributing: {2}".format(len(names), channel, ", ".join(names[:6]))
        )

    unreal.log(
        "BU: adopted {0} material(s) onto {1} ({2}), {3} already correct, {4} failed".format(
            adopted, MATERIAL,
            ", ".join("{0} {1}".format(v, k.lower()) for k, v in sorted(counts.items())) or "none",
            skipped, failed,
        )
    )
    return adopted, skipped, failed


def parent_for(instance, blend="Masked", two_sided=None):
    """The BU surface variant for a blend mode and sidedness.

    `two_sided` defaults to True: Blender's default is backface culling *off*, so double-sided is
    what a material means when it says nothing, and single-sided is the deliberate choice. Pass
    False only when the Blender material actually enabled backface culling.
    """
    material, variants = ensure()
    if material is None:
        return None

    if two_sided is None:
        two_sided = True

    if two_sided:
        return variants.get(blend + "TwoSided") or variants.get(blend)
    return variants.get(blend)
