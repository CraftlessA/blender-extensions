# SPDX-License-Identifier: GPL-3.0-or-later
"""How a material looks in Unreal: BU's panel in Material Properties.

Unreal needs to know things Blender's node tree only implies — whether a surface is glass, skin,
foliage or car paint is a *render state* there (blend mode, shading model), not a value. Left on
Auto, the link works it out (`link_material.auto_surface`): Transmission means glass, a typed-in
Alpha means translucent, an image behind Alpha a cutout (or translucent when the material's
Render Method is Blended), Subsurface means skin, Coat means clear coat. Any of those can be
chosen outright instead, or the material can be replaced by one already in the Unreal project —
for a hero material built there by hand.

The Nodes setting says what happens to node chains behind the shader's inputs: translated into
an Unreal material graph (`link_nodes`), baked to textures with Cycles so Unreal shows exactly
Blender's result (`link_bake`), or left out.
"""

import bpy

from . import link_material

SURFACE_ITEMS = (
    ("AUTO", "Auto", "Work it out from the material's settings"),
    ("OPAQUE", "Opaque", "A solid surface"),
    ("MASKED", "Cutout", "Fully visible or fully cut away, from the alpha (leaves, fences, hair cards)"),
    ("TRANSLUCENT", "Translucent", "See-through by the alpha, lit like a surface"),
    ("GLASS", "Glass", "Refracting glass, tinted by the base colour"),
    ("SUBSURFACE", "Skin / Subsurface", "Light scatters under the surface"),
    ("FOLIAGE", "Foliage", "Thin leaves that let light through, with a cutout"),
    ("CLEARCOAT", "Clear Coat", "A glossy layer over the surface (car paint, lacquer)"),
    ("UNLIT", "Unlit / Emissive", "Shows its colour with no lighting"),
    ("UNREAL", "Use an Unreal Material", "Use a material from the Unreal project as it is"),
)
LABELS = {item[0].lower(): item[1] for item in SURFACE_ITEMS}
SEARCH_LIMIT = 500


def _changed(_self, context):
    from . import link

    link.material_settings_changed()
    settings = getattr(getattr(context, "material", None), "bu_link", None)
    if settings is not None and settings.surface == "UNREAL" and not link.unreal_materials():
        link.request_unreal_materials()


def _search(_self, _context, edit_text):
    from . import link

    words = (edit_text or "").lower().split()
    found = [path for path in link.unreal_materials()
             if all(word in path.lower() for word in words)]
    return found[:SEARCH_LIMIT]


class BU_LinkMaterialSettings(bpy.types.PropertyGroup):
    surface: bpy.props.EnumProperty(
        name="Unreal Surface",
        description="How this material is shown in Unreal by BU's real-time link",
        items=SURFACE_ITEMS,
        default="AUTO",
        update=_changed,
    )
    nodes: bpy.props.EnumProperty(
        name="Nodes",
        description="How node chains behind the shader's inputs are shown in Unreal",
        items=(
            ("TRANSLATE", "Translate",
             "Rebuild them as an Unreal material graph: values stay instant, rewiring compiles "
             "a new material. Noise and Voronoi look alike rather than identical"),
            ("BAKE", "Bake to Match",
             "Bake them to textures with Cycles about a second after the edits stop, so Unreal "
             "shows exactly what Blender does. Needs UVs; translated until the first bake lands"),
            ("OFF", "Values Only", "Send typed-in values and plain image maps, as before"),
        ),
        default="TRANSLATE",
        update=_changed,
    )
    refraction: bpy.props.BoolProperty(
        name="Refraction in Unreal",
        description=(
            "Bend what is seen through this glass in Unreal. Unreal refracts at one surface, "
            "from the picture behind it, so a flat pane comes out crinkled where Blender's "
            "light bends in and back out and shows it clear. For solid glass (bottles, "
            "tumblers, lenses), not windows"),
        default=False,
        update=_changed,
    )
    unreal_material: bpy.props.StringProperty(
        name="Unreal Material",
        description="A material from the Unreal project to use instead of this one",
        search=_search,
        update=_changed,
    )


class BU_OT_link_list_materials(bpy.types.Operator):
    bl_idname = "bu.link_list_materials"
    bl_label = "Refresh Unreal Materials"
    bl_description = "Ask Unreal for the materials in its project"

    @classmethod
    def poll(cls, context):
        from . import link

        return link.is_running()

    def execute(self, context):
        from . import link

        link.request_unreal_materials()
        return {"FINISHED"}


class BU_OT_link_bake_material(bpy.types.Operator):
    bl_idname = "bu.link_bake_material"
    bl_label = "Bake Now"
    bl_description = "Bake this material's node chains for Unreal again, now"

    @classmethod
    def poll(cls, context):
        from . import link

        return link.is_running() and getattr(context, "material", None) is not None

    def execute(self, context):
        from . import link

        link.bake_now(context.material.name)
        return {"FINISHED"}


class BU_PT_link_material(bpy.types.Panel):
    bl_label = "BU — Unreal Surface"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "material"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return getattr(context, "material", None) is not None

    def draw(self, context):
        from . import link

        layout = self.layout
        material = context.material
        settings = material.bu_link
        layout.prop(settings, "surface", text="Surface")
        if settings.surface == "UNREAL":
            row = layout.row(align=True)
            row.prop(settings, "unreal_material", text="", icon="MATERIAL")
            row.operator(BU_OT_link_list_materials.bl_idname, text="", icon="FILE_REFRESH")
            if not link.is_running():
                layout.label(text="Start the link to list Unreal's materials", icon="INFO")
            elif not link.unreal_materials():
                layout.label(text="Asking Unreal for its materials…", icon="TIME")
        sent = link.sent_material(material.name)
        if sent is not None and settings.surface == "AUTO":
            layout.label(text="Auto picks: " + LABELS.get(link_material.auto_surface(sent), "Opaque"),
                         icon="INFO")
        picked = settings.surface.lower() if settings.surface != "AUTO" else (
            link_material.auto_surface(sent) if sent is not None else "")
        if picked == "glass":
            layout.prop(settings, "refraction")
        maps = sorted((sent or {}).get("maps") or ())
        if maps:
            layout.label(text="Maps sent: " + ", ".join(maps), icon="TEXTURE")
        if settings.surface != "UNREAL":
            layout.prop(settings, "nodes")
            if settings.nodes == "BAKE":
                from . import link_bake

                row = layout.row()
                row.label(text=link_bake.status(material) or "Not baked yet", icon="RENDER_STILL")
                row.operator(BU_OT_link_bake_material.bl_idname, text="", icon="FILE_REFRESH")
            graph = (sent or {}).get("graph") or {}
            if graph.get("out"):
                layout.label(text="Nodes translated: " + ", ".join(sorted(graph["out"])),
                             icon="NODETREE")
            for note in (sent or {}).get("graph_approximate") or ():
                layout.label(text="Approximate: " + note, icon="INFO")
            for socket, why in sorted(((sent or {}).get("graph_skipped") or {}).items()):
                row = layout.row()
                row.alert = True
                row.label(text="{0}: {1}".format(socket, why)[:90], icon="ERROR")


_classes = (BU_LinkMaterialSettings, BU_OT_link_list_materials, BU_OT_link_bake_material,
            BU_PT_link_material)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Material.bu_link = bpy.props.PointerProperty(type=BU_LinkMaterialSettings)


def unregister():
    del bpy.types.Material.bu_link
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
