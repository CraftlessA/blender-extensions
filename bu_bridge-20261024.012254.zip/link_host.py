# SPDX-License-Identifier: GPL-3.0-or-later
"""Unreal as Blender's renderer: BU starts its own hidden editor, and closes it again.

The real-time link began as "connect to the Unreal Editor you have open". This is the other way
round. Blender owns the editor: it keeps a small Unreal project of its own (BU's render
project), starts the editor on it with no window, and talks to it over the same link. The person
never opens Unreal; the editor's own viewports are switched off, so nothing renders the scene a
second time beside the picture Blender asked for.

What lives where:

* The render project, one per engine version, under `%LOCALAPPDATA%/BU/RenderProject` unless
  the preferences say otherwise. It is made the first time and refreshed when BU updates: a
  `.uproject`, renderer settings, and BU's Unreal plugin, copied from the copy bundled inside this
  extension (`unreal_plugin/BUBridge`). The compiled module goes with it only when it was built
  for exactly this engine build, which the two `UnrealEditor.modules` files say.
* The conversation with the editor goes through three files in the project's `Saved/BU` and the
  environment it is started with: `BU_HOST_PORT` (the link's port), `BU_HOST_PARENT` (this
  Blender, so the editor quits by itself if Blender dies), `BU_HOST_STATUS` (a JSON file the
  editor rewrites every second: starting, compiling shaders, ready) and `BU_HOST_QUIT` (a file
  whose appearance asks it to close). Files rather than the link, because the editor spends its
  first minutes compiling shaders long before any link exists.

Standard library only, and nothing here imports `bpy`, so the tests run without Blender.
"""

import hashlib
import json
import os
import re
import shutil
import socket
import stat
import subprocess
import sys
import time

PROJECT_NAME = "BURender"
PLUGIN_NAME = "BUBridge"
# The engine's own tiny empty map: startup loads nothing worth waiting for, and the editor then
# replaces it with a blank level that is never saved (`bu_host`).
STARTUP_MAP = "/Engine/Maps/Entry"
BUNDLE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "unreal_plugin", PLUGIN_NAME)
# The compute shaders' module first: Unreal takes shader types only from modules loaded before
# it compiles its global shaders. Declared only when its binary is in the bundle.
NATIVE_MODULES = (
    {"Name": "BULinkShaders", "Type": "Runtime", "LoadingPhase": "PostConfigInit",
     "PlatformAllowList": ["Win64"]},
    {"Name": "BULink", "Type": "Editor", "LoadingPhase": "Default",
     "PlatformAllowList": ["Win64"]},
)
STAMP_NAME = "bu_stamp.txt"

ENV_PORT = "BU_HOST_PORT"
ENV_PARENT = "BU_HOST_PARENT"
ENV_STATUS = "BU_HOST_STATUS"
ENV_QUIT = "BU_HOST_QUIT"
ENV_LEVEL = "BU_HOST_LEVEL"
ENV_WINDOW = "BU_HOST_WINDOW"
# The size the editor trims BU's saved textures and node materials to when it starts (GB):
# Unreal's `bu_link_cache.ENV_LIMIT`.
ENV_CACHE = "BU_CACHE_GB"
# What the real-time link saves in the render project to load faster next time: (folder under
# Content, file prefix) as Unreal's `bu_link_cache` and `bu_link_static` keep them, and the
# indexes under Saved that say what is in them.
CACHE_FOLDERS = ((("BU", "Live", "Textures"), "T_BU_"), (("BU", "Live", "Meshes"), "SM_BU_"),
                 (("BU", "Materials", "Graphs"), "M_BU_Graph_"))
CACHE_INDEXES = (("BU", "link_asset_use.json"), ("BU", "link_mesh_cache.json"))
# Where the editor notes the saved level it had open, to start in next time (`bu_host`).
LEVEL_FILE = os.path.join("Saved", "BU", "level.txt")
START_LEVELS = ("LAST", "BLANK")

# How long the editor gets to close by itself, after being asked, before it is ended. One with
# its window may be asking whether to save: that one is waited for while it still answers.
QUIT_SECONDS = 20.0
# The status file is rewritten every second; this much older and the editor is stuck.
STATUS_STALE = 15.0

# Written into the project once and left alone after that, so a setting changed by hand stays.
# The renderer section is the user's MetaHuman project's, which is where BU's materials were
# checked: Lumen, hardware ray tracing, Substrate, DX12 SM6.
ENGINE_INI = """; Written by BU for its render project. Edit freely; BU does not overwrite this file.
[/Script/EngineSettings.GameMapsSettings]
EditorStartupMap={startup}
GameDefaultMap={startup}

[/Script/Engine.RendererSettings]
r.AllowStaticLighting=False
r.Shadow.Virtual.Enable=1
r.GenerateMeshDistanceFields=True
r.DynamicGlobalIlluminationMethod=1
r.ReflectionMethod=1
r.SkinCache.CompileShaders=True
r.RayTracing=True
r.RayTracing.RayTracingProxies.ProjectEnabled=True
r.Substrate=True
r.Substrate.ProjectGBufferFormat=1
r.DefaultFeature.AutoExposure.ExtendDefaultLuminanceRange=True
r.DefaultFeature.LocalExposure.HighlightContrastScale=0.8
r.DefaultFeature.LocalExposure.ShadowContrastScale=0.8
r.GPUSkin.Support16BitBoneIndex=True
r.GPUSkin.UnlimitedBoneInfluences=True
r.Nanite.ProjectEnabled=False

[/Script/WindowsTargetPlatform.WindowsTargetSettings]
DefaultGraphicsRHI=DefaultGraphicsRHI_DX12
-D3D12TargetedShaderFormats=PCD3D_SM5
+D3D12TargetedShaderFormats=PCD3D_SM6

[/Script/HardwareTargeting.HardwareTargetingSettings]
TargetedHardwareClass=Desktop
AppliedTargetedHardwareClass=Desktop
DefaultGraphicsPerformance=Maximum
AppliedDefaultGraphicsPerformance=Maximum
"""

# Autosave would write the link's actors into BU's level; nobody needs the backup.
EDITOR_USER_INI = """; Written by BU for its render project.
[/Script/UnrealEd.EditorLoadingSavingSettings]
bAutoSaveEnable=False

[/Script/UnrealEd.EditorPerformanceSettings]
bThrottleCPUWhenNotForeground=False
"""

GAME_INI = """; Written by BU for its render project.
[/Script/EngineSettings.GeneralProjectSettings]
ProjectName=BU Render
Description=Blender's renderer. Made and started by BU; there is no need to open it.
"""

# Log lines that say why an editor stopped, most telling first. Matched case-insensitively.
FAILURE_PATTERNS = (
    # Before video memory: Windows' commit (RAM and page file) running out fails Unreal's
    # uploads to the card too, and those it reports as "out of video memory". Its memory line
    # at the crash says which: under 1000 MB of virtual memory free.
    (r"paging file is too small|LogMemory: Virtual Memory: [\d.]+ MB used,\s+\d{1,3}\.\d+ MB free",
     "the computer ran out of memory (RAM and page file). Close other programs, then restart "
     "Unreal"),
    (r"out of video memory|E_OUTOFMEMORY|ran out of (gpu )?memory",
     "Unreal ran out of video memory. Close other GPU-heavy programs, or lower the picture size"),
    (r"GPU crashed|DXGI_ERROR_DEVICE_REMOVED|DXGI_ERROR_DEVICE_HUNG|device removed",
     "the graphics driver stopped Unreal (GPU crash or driver reset)"),
    (r"does not support (DirectX 12|SM6|ray tracing)|requires a (DirectX 12|SM6)",
     "this graphics card cannot run BU's renderer settings (DirectX 12 SM6)"),
    (r"Plugin '([^']+)' failed to load|Unable to load plugin '([^']+)'",
     "a plugin failed to load"),
    (r"(Fatal error!?|LowLevelFatalError|Assertion failed:)\s*(.*)", None),
)


class HostError(Exception):
    pass


# -- engines ---------------------------------------------------------------------------------

def find_engines(environ=None):
    """Installed Unreal Engines as {"5.8": root}, as build.py finds them."""
    environ = os.environ if environ is None else environ
    engines = {}
    manifest = os.path.join(environ.get("PROGRAMDATA", "C:/ProgramData"), "Epic",
                            "UnrealEngineLauncher", "LauncherInstalled.dat")
    try:
        with open(manifest, encoding="utf-8") as handle:
            installed = json.load(handle).get("InstallationList", [])
    except (OSError, ValueError):
        installed = []
    for item in installed:
        name = str(item.get("AppName", ""))
        location = str(item.get("InstallLocation", ""))
        if name.startswith("UE_") and os.path.isfile(editor_exe(location)):
            engines[name[3:]] = location
    # The launcher's list is not always there (seen missing with 5.8 installed).
    default = os.path.join(environ.get("PROGRAMFILES", "C:/Program Files"), "Epic Games")
    try:
        folders = sorted(os.listdir(default))
    except OSError:
        folders = []
    for name in folders:
        location = os.path.join(default, name)
        if name.startswith("UE_") and name[3:] not in engines and os.path.isfile(editor_exe(location)):
            engines[name[3:]] = location
    return engines


def editor_exe(root):
    return os.path.join(root, "Engine", "Binaries", "Win64", "UnrealEditor.exe")


def engine_version(root):
    """"5.8" from an engine folder's Build.version, or ""."""
    try:
        with open(os.path.join(root, "Engine", "Build", "Build.version"), encoding="utf-8") as handle:
            data = json.load(handle)
        return "{0}.{1}".format(int(data["MajorVersion"]), int(data["MinorVersion"]))
    except (OSError, ValueError, KeyError, TypeError):
        return ""


def build_id(modules_file):
    """The BuildId an `UnrealEditor.modules` file names, or ""."""
    try:
        with open(modules_file, encoding="utf-8-sig") as handle:
            return str(json.load(handle).get("BuildId") or "")
    except (OSError, ValueError, AttributeError):
        return ""


def engine_build_id(root):
    return build_id(os.path.join(root, "Engine", "Binaries", "Win64", "UnrealEditor.modules"))


def bundle_build_id(bundle=None):
    return build_id(os.path.join(bundle or BUNDLE, "Binaries", "Win64", "UnrealEditor.modules"))


def choose_engine(unreal_dir="", engines=None, bundle=None):
    """(version, root) of the engine to start, or ("", "") when there is none.

    An engine the preferences name wins. Otherwise the one BU's compiled module was built for,
    since without the module the link falls back to its much slower pure-Python path; otherwise
    the newest.
    """
    if unreal_dir:
        root = os.path.normpath(unreal_dir)
        if os.path.isfile(editor_exe(root)):
            return engine_version(root) or os.path.basename(root), root
        return "", ""
    engines = find_engines() if engines is None else engines
    if not engines:
        return "", ""
    wanted = bundle_build_id(bundle)
    if wanted:
        for version in sorted(engines, key=_version_key, reverse=True):
            if engine_build_id(engines[version]) == wanted:
                return version, engines[version]
    version = sorted(engines, key=_version_key)[-1]
    return version, engines[version]


def _version_key(version):
    return tuple(int(part) if part.isdigit() else 0 for part in re.split(r"[.\-]", version))


# -- the render project ----------------------------------------------------------------------

def default_project_root(environ=None):
    environ = os.environ if environ is None else environ
    base = environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local")
    return os.path.join(base, "BU", "RenderProject")


def project_dir(root, version):
    """One project per engine version: a project opened once in 5.9 cannot go back to 5.8."""
    return os.path.join(root or default_project_root(), "UE_" + (version or "unknown"))


# The only engine plugins the render project loads (with whatever they need themselves). An
# editor normally mounts about 250 (phone platforms, source control, online services, media
# players, Niagara, MetaHuman...), and starting them is time the person spends waiting.
ENGINE_PLUGINS = (
    "PythonScriptPlugin",        # BU's Unreal side is Python
    "EditorScriptingUtilities",  # EditorAssetLibrary, the blank level
    "USDImporter",               # BUBridge's own dependencies
    "GeometryScripting",
    "Interchange",               # importing Blender's images
    "InterchangeEditor",
    "InterchangeAssets",
    "GeometryCache",             # BU's scene import, should someone open the window
    "SequencerScripting",
    "LevelSequenceEditor",
    "ContentBrowserAssetDataSource",
    "ContentBrowserClassDataSource",
    "EngineAssetDefinitions",
    "NNEDenoiser",               # the path tracer's denoiser (Unreal's default one)
    # For whoever opens the window: Edit > Plugins (to turn on anything else, which BU then
    # keeps) and Window > Fab. Engine plugins themselves, so off without these lines.
    "PluginBrowser",
    "Fab",
)


def uproject_text(version, extra=(), kept=()):
    """The render project's .uproject. `extra`: more plugins to turn on (DLSS when found);
    `kept`: plugin entries someone added in Unreal (Edit > Plugins), kept as they wrote them."""
    data = {
        "FileVersion": 3,
        "EngineAssociation": version,
        "Category": "",
        "Description": "Blender's renderer, made and started by BU.",
        "DisableEnginePluginsByDefault": True,
        "Plugins": [{"Name": name, "Enabled": True}
                    for name in (PLUGIN_NAME,) + ENGINE_PLUGINS + tuple(extra)] + list(kept),
    }
    return json.dumps(data, indent="\t") + "\n"


def managed_plugins():
    """The plugins BU itself turns on or off in the render project."""
    return {PLUGIN_NAME} | set(ENGINE_PLUGINS) | set(DLSS_PLUGINS)


def kept_plugins(uproject):
    """Plugin entries in an existing .uproject that BU did not put there: someone turned them
    on (or off) in Unreal's Edit > Plugins, which writes the .uproject. [] when there is none or
    it cannot be read."""
    try:
        with open(uproject, encoding="utf-8-sig") as handle:
            plugins = json.load(handle).get("Plugins") or []
    except (OSError, ValueError, AttributeError):
        return []
    managed = managed_plugins()
    kept, seen = [], set()
    for entry in plugins:
        name = entry.get("Name") if isinstance(entry, dict) else None
        if isinstance(name, str) and name and name not in managed and name not in seen:
            seen.add(name)
            kept.append(entry)
    return kept


_FOLDER_CACHE = {}


def render_project_folder(unreal_dir="", project_root="", now=None):
    """The render project the editor would be started on, or "" with no engine. Remembered for a
    few seconds: the preferences ask on every redraw, and finding engines reads the disk."""
    now = time.time() if now is None else now
    key = (unreal_dir or "", project_root or "")
    cached = _FOLDER_CACHE.get(key)
    if cached is not None and now - cached[0] < 5.0:
        return cached[1]
    version, root = choose_engine(unreal_dir)
    folder = project_dir(project_root, version) if root else ""
    _FOLDER_CACHE[key] = (now, folder)
    return folder


def start_level_line(folder, start_level="LAST"):
    """What the preferences say about the level BU's editor starts in."""
    if str(start_level).upper() == "BLANK":
        return "Starts in a new blank level"
    level = remembered_level(folder) if folder else ""
    if level:
        return "Starts in " + level
    return "Starts in a new blank level until you save one in Unreal's window"


def _cache_files(folder):
    """BU's own cache files in a render project: [(path, size)]."""
    found = []
    for parts, prefix in CACHE_FOLDERS:
        directory = os.path.join(folder, "Content", *parts)
        try:
            names = os.listdir(directory)
        except OSError:
            continue
        for name in names:
            if name.startswith(prefix):
                path = os.path.join(directory, name)
                try:
                    found.append((path, os.path.getsize(path)))
                except OSError:
                    pass
    return found


_CACHE_SIZE = {}


def cache_size(folder, now=None):
    """Bytes of textures, meshes and node materials the link has saved in the render project.
    Remembered for a few seconds: the preferences ask on every redraw."""
    now = time.time() if now is None else now
    cached = _CACHE_SIZE.get(folder)
    if cached is not None and now - cached[0] < 5.0:
        return cached[1]
    total = sum(size for _path, size in _cache_files(folder)) if folder else 0
    _CACHE_SIZE[folder] = (now, total)
    return total


def cache_line(folder, limit_gb):
    """What the preferences say about the cache."""
    size = cache_size(folder) / 2.0 ** 30
    return "Saved textures, meshes and materials: {0:.1f} GB (trimmed to {1:g} GB when Unreal " \
           "starts)".format(size, limit_gb)


def clear_cache(folder):
    """Delete everything the link saved to load faster next time. Only with BU's editor closed:
    it may have them loaded. Returns (files removed, bytes freed)."""
    removed = freed = 0
    for path, size in _cache_files(folder):
        try:
            os.remove(path)
        except OSError:
            continue
        removed += 1
        freed += size
    for parts in CACHE_INDEXES:
        try:
            os.remove(os.path.join(folder, "Saved", *parts))
        except OSError:
            pass
    _CACHE_SIZE.pop(folder, None)
    return removed, freed


def remembered_level(folder):
    """The saved level BU's editor will start in ("/Game/Maps/Sky"), or "" for a blank one.

    What the editor last noted in Saved/BU/level.txt; a /Game/ level whose file has gone since
    is not reported, as the editor would not open it either.
    """
    try:
        with open(os.path.join(folder, LEVEL_FILE), encoding="utf-8") as handle:
            level = handle.read().strip()
    except OSError:
        return ""
    if not level.startswith("/") or level.startswith(("/Temp/", "/Engine/")):
        return ""
    if level.startswith("/Game/"):
        umap = os.path.join(folder, "Content", *level[len("/Game/"):].split("/")) + ".umap"
        if not os.path.isfile(umap):
            return ""
    return level


# -- NVIDIA DLSS ---------------------------------------------------------------------------------
#
# NVIDIA's DLSS plugin comes from outside BU's own code: the engine's (installed from Fab into
# Engine/Plugins/Marketplace), a folder of NVIDIA's download named in the preferences, or
# `DLSS_FOLDER` beside BU's Unreal plugin, should a build of BU carry one. From a folder
# only what runs is copied into the render project: the Win64 modules, NVIDIA's two model DLLs,
# shaders and settings, about 105 MB (no sources, debug symbols, ARM or development builds).
DLSS_PLUGIN = "DLSS"
DLSS_PLUGINS = ("DLSS", "StreamlineNGXCommon")   # DLSS needs NVIDIA's common module
DLSS_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "unreal_plugin", "DLSS")
DLSS_SKIP = ("Source", "Intermediate", "WinArm64", "Development", "*.pdb")
DLSS_STAMP = "bu_dlss_stamp.txt"


def _plugin_engine_version(uplugin):
    try:
        with open(uplugin, encoding="utf-8-sig") as handle:
            return str(json.load(handle).get("EngineVersion") or "")
    except (OSError, ValueError):
        return ""


def _same_engine(plugin_version, version):
    """A plugin's EngineVersion ("5.8.0") against an engine version ("5.8"). Pure."""
    if not plugin_version or not version:
        return False
    return plugin_version.split(".")[:2] == str(version).split(".")[:2]


def dlss_source(folder, version):
    """The folder holding DLSS/ and StreamlineNGXCommon/ inside `folder` (NVIDIA's zip unpacked,
    its Plugins folder, or the two plugins themselves) when they are for this engine; else ""."""
    if not folder:
        return ""
    for base in (folder, os.path.join(folder, "Plugins")):
        if all(os.path.isfile(os.path.join(base, name, name + ".uplugin"))
               for name in DLSS_PLUGINS):
            found = _plugin_engine_version(os.path.join(base, DLSS_PLUGIN, DLSS_PLUGIN + ".uplugin"))
            if _same_engine(found, version):
                return base
    return ""


def engine_has_dlss(engine_root):
    """Whether the engine itself has the DLSS plugin (a Fab install puts it in Marketplace)."""
    market = os.path.join(engine_root or "", "Engine", "Plugins", "Marketplace")
    try:
        names = os.listdir(market)
    except OSError:
        return False
    for name in names:
        if os.path.isfile(os.path.join(market, name, DLSS_PLUGIN + ".uplugin")):
            return True
    return False


def install_dlss(source, plugins_dir):
    """Copy DLSS's runtime files from `source` into the project's Plugins unless the same ones
    are there. Returns True if copied."""
    stamp = []
    for name in DLSS_PLUGINS:
        uplugin = os.path.join(source, name, name + ".uplugin")
        stamp.append("{0} {1} {2}".format(name, os.path.getsize(uplugin), os.path.getmtime(uplugin)))
    stamp = "\n".join(stamp)
    marker = os.path.join(plugins_dir, DLSS_PLUGIN, DLSS_STAMP)
    try:
        with open(marker, encoding="utf-8") as handle:
            if handle.read().strip() == stamp:
                return False
    except OSError:
        pass
    for name in DLSS_PLUGINS:
        destination = os.path.join(plugins_dir, name)
        if os.path.isdir(destination):
            shutil.rmtree(destination)
        shutil.copytree(os.path.join(source, name), destination,
                        ignore=shutil.ignore_patterns(*DLSS_SKIP))
    with open(marker, "w", encoding="utf-8") as handle:
        handle.write(stamp + "\n")
    return True


def remove_dlss(plugins_dir):
    """Take a DLSS that BU copied in out again (it is no longer found where it came from)."""
    if not os.path.isfile(os.path.join(plugins_dir, DLSS_PLUGIN, DLSS_STAMP)):
        return
    for name in DLSS_PLUGINS:
        shutil.rmtree(os.path.join(plugins_dir, name), ignore_errors=True)


def ensure_dlss(folder, version, engine_root, dlss_dir=""):
    """Put DLSS where the render project loads it. Returns the plugins to turn on: ("DLSS",)
    or ()."""
    plugins_dir = os.path.join(folder, "Plugins")
    source = dlss_source(dlss_dir, version) or dlss_source(DLSS_FOLDER, version)
    if source:
        install_dlss(source, plugins_dir)
        return (DLSS_PLUGIN,)
    remove_dlss(plugins_dir)
    if engine_has_dlss(engine_root):
        return (DLSS_PLUGIN,)
    return ()


def _write_if_missing(path, text):
    if not os.path.isfile(path):
        with open(path, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)


def _write_if_changed(path, text):
    try:
        with open(path, encoding="utf-8") as handle:
            if handle.read() == text:
                return
    except OSError:
        pass
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def bundle_stamp(bundle, native):
    """A digest of the bundled plugin, so an unchanged one is not copied again."""
    digest = hashlib.sha256(b"native" if native else b"python")
    for dirpath, dirnames, filenames in os.walk(bundle):
        dirnames[:] = sorted(d for d in dirnames if d != "__pycache__")
        for name in sorted(filenames):
            if name.endswith(".pyc"):
                continue
            full = os.path.join(dirpath, name)
            digest.update(os.path.relpath(full, bundle).replace(os.sep, "/").encode("utf-8"))
            with open(full, "rb") as handle:
                digest.update(handle.read())
    return digest.hexdigest()


def plugin_descriptor(bundle, native):
    """The bundled .uplugin, declaring the C++ module only when it is installed beside it."""
    with open(os.path.join(bundle, PLUGIN_NAME + ".uplugin"), encoding="utf-8-sig") as handle:
        data = json.load(handle)
    data.pop("Modules", None)
    if native:
        binaries = os.path.join(bundle, "Binaries", "Win64")
        # The shaders' module only with its binary: a bundle built before it existed has none.
        data["Modules"] = [dict(module) for module in NATIVE_MODULES if module["Name"] == "BULink"
                           or os.path.isfile(os.path.join(binaries, "UnrealEditor-{0}.dll".format(module["Name"])))]
    return json.dumps(data, indent="\t") + "\n"


def _writable_again(function, path, _error):
    """For rmtree: a read-only file (a licence copied out of Program Files keeps its flag) is
    made writable and removed; anything else still fails."""
    os.chmod(path, stat.S_IWRITE)
    function(path)


def remove_tree(path):
    """shutil.rmtree, through read-only files too."""
    if sys.version_info >= (3, 12):
        shutil.rmtree(path, onexc=_writable_again)
    else:
        shutil.rmtree(path, onerror=_writable_again)


def install_plugin(bundle, destination, native):
    """Copy the bundled plugin into the project unless the same one is there. Returns True if copied."""
    if not os.path.isfile(os.path.join(bundle, PLUGIN_NAME + ".uplugin")):
        raise HostError("BU's Unreal plugin is missing from this Blender extension ({0}). "
                        "Reinstall BU.".format(bundle))
    stamp = bundle_stamp(bundle, native)
    try:
        with open(os.path.join(destination, STAMP_NAME), encoding="utf-8") as handle:
            if handle.read().strip() == stamp:
                return False
    except OSError:
        pass
    if os.path.isdir(destination):
        try:
            remove_tree(destination)
        except OSError as exc:
            raise HostError("Could not update BU's plugin in the render project ({0}). Is an "
                            "earlier BU Unreal still running? Close it, or end UnrealEditor.exe "
                            "in Task Manager".format(exc))
    ignore = ["__pycache__", "*.pyc", "Source", "Intermediate"]
    if not native:
        ignore.append("Binaries")
    shutil.copytree(bundle, destination, ignore=shutil.ignore_patterns(*ignore))
    with open(os.path.join(destination, PLUGIN_NAME + ".uplugin"), "w", encoding="utf-8",
              newline="\n") as handle:
        handle.write(plugin_descriptor(bundle, native))
    with open(os.path.join(destination, STAMP_NAME), "w", encoding="utf-8") as handle:
        handle.write(stamp + "\n")
    return True


# Settings BU itself once wrote differently, moved on in a project that still has BU's old line.
# Substrate's Blendable G-buffer (0, copied from a MetaHuman project) folds every Substrate
# material back into Unreal's old shading models and drops what they have no room for: Sheen
# (Substrate's Fuzz) barely showed. Adaptive (1) keeps it.
ENGINE_INI_UPGRADES = (("r.Substrate.ProjectGBufferFormat=0", "r.Substrate.ProjectGBufferFormat=1"),)


def upgrade_engine_ini(path):
    """Replace BU's own old lines in a render project's DefaultEngine.ini; a line changed by hand
    is something else and is left. True if the file changed."""
    try:
        with open(path, encoding="utf-8", newline="") as handle:
            text = handle.read()
    except OSError:
        return False
    if not text.startswith("; Written by BU"):
        return False
    lines = text.split("\n")
    changed = False
    for old, new in ENGINE_INI_UPGRADES:
        for index, line in enumerate(lines):
            if line.strip() == old:
                lines[index] = new + line[len(line.rstrip()):]  # keep its line ending
                changed = True
    if changed:
        with open(path, "w", encoding="utf-8", newline="") as handle:
            handle.write("\n".join(lines))
    return changed


def ensure_project(folder, version, engine_root, bundle=None, dlss_dir=""):
    """Make or refresh the render project. Returns (uproject path, native module installed)."""
    bundle = bundle or BUNDLE
    for sub in ("Config", "Content", "Plugins", os.path.join("Saved", "BU")):
        os.makedirs(os.path.join(folder, sub), exist_ok=True)
    uproject = os.path.join(folder, PROJECT_NAME + ".uproject")
    extra = ensure_dlss(folder, version, engine_root, dlss_dir)
    _write_if_changed(uproject, uproject_text(version, extra, kept_plugins(uproject)))
    config = os.path.join(folder, "Config")
    _write_if_missing(os.path.join(config, "DefaultEngine.ini"),
                      ENGINE_INI.format(startup=STARTUP_MAP))
    upgrade_engine_ini(os.path.join(config, "DefaultEngine.ini"))
    _write_if_missing(os.path.join(config, "DefaultEditorPerProjectUserSettings.ini"),
                      EDITOR_USER_INI)
    _write_if_missing(os.path.join(config, "DefaultGame.ini"), GAME_INI)
    wanted = bundle_build_id(bundle)
    native = bool(wanted) and wanted == engine_build_id(engine_root)
    install_plugin(bundle, os.path.join(folder, "Plugins", PLUGIN_NAME), native)
    return uproject, native


# -- starting and watching the editor ---------------------------------------------------------

def free_port():
    """A loopback port nothing is listening on right now."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        probe.bind(("127.0.0.1", 0))
        return probe.getsockname()[1]
    finally:
        probe.close()


def launch_command(engine_root, uproject, show_window=False):
    """The editor's command line.

    Hidden: `-RenderOffscreen`, and `-unattended` so that nothing waits for a click nobody can
    give. With its window, not unattended: Unreal cancels every Save and Save All in an
    unattended editor without a word, and closes it without asking, so what someone built in
    the window (a sky from Fab, say) would be thrown away.
    """
    command = [editor_exe(engine_root), uproject, "-nosplash", "-nosound", "-NoLiveCoding"]
    if not show_window:
        command[2:2] = ["-unattended"]
        command.append("-RenderOffscreen")
    return command


def launch_environment(base, port, parent, status, quit_file, start_level="LAST", window=False,
                       cache_gb=None):
    """The editor's environment: Blender's, without what would break Unreal's own Python."""
    environ = {k: v for k, v in base.items()
               if k.upper() not in ("PYTHONHOME", "PYTHONPATH", "PYTHONSTARTUP")}
    environ[ENV_PORT] = str(port)
    environ[ENV_PARENT] = str(parent)
    environ[ENV_STATUS] = status
    environ[ENV_QUIT] = quit_file
    environ[ENV_LEVEL] = "blank" if str(start_level).upper() == "BLANK" else "last"
    environ[ENV_WINDOW] = "1" if window else "0"
    if cache_gb is not None:
        environ[ENV_CACHE] = "{0:g}".format(max(0.0, float(cache_gb)))
    return environ


def read_status(path, now=None):
    """The editor's last status, or {} if it has not written one."""
    try:
        with open(path, encoding="utf-8") as handle:
            status = json.load(handle)
    except (OSError, ValueError):
        return {}
    if not isinstance(status, dict):
        return {}
    if now is not None:
        try:
            status["age"] = max(0.0, now - float(status.get("time", now)))
        except (TypeError, ValueError):
            status["age"] = 0.0
    return status


def failure_reason(log_text):
    """Why the editor stopped, from the end of its log, in words; "" if the log does not say."""
    lines = log_text.splitlines()[-600:]
    for pattern, reason in FAILURE_PATTERNS:
        regex = re.compile(pattern, re.IGNORECASE)
        for line in reversed(lines):
            match = regex.search(line)
            if not match:
                continue
            if reason is not None:
                return reason
            detail = (match.group(2) or line).strip()
            return "Unreal stopped: " + detail[:160]
    return ""


def describe(status, elapsed):
    """One line for Blender's panel about an editor that is still starting."""
    clock = "{0}:{1:02d}".format(int(elapsed) // 60, int(elapsed) % 60)
    state = status.get("state")
    shaders = int(status.get("shaders") or 0)
    if shaders > 0:
        return "Compiling shaders ({0:,} left) {1}".format(shaders, clock)
    if state == "loading":
        return "Preparing Unreal… " + clock
    if state == "ready":
        return "Connecting… " + clock
    if state == "exiting":
        return "Unreal is closing…"
    # Before Unreal's Python runs it writes nothing; the first start compiles shaders here.
    if elapsed > 90:
        return "Starting Unreal {0} (the first start compiles shaders: minutes)".format(clock)
    return "Starting Unreal… " + clock


def _tail(path, size=256 * 1024):
    try:
        with open(path, "rb") as handle:
            handle.seek(0, os.SEEK_END)
            end = handle.tell()
            handle.seek(max(0, end - size))
            return handle.read().decode("utf-8", "replace")
    except OSError:
        return ""


class Host(object):
    """One editor BU started. At most one exists at a time (`HOST`)."""

    def __init__(self):
        self.process = None
        self.folder = ""
        self.port = 0
        self.started = 0.0
        self.quit_asked = 0.0
        self.status_path = ""
        self.quit_path = ""
        self.log_path = ""
        self.native = False
        self.version = ""
        self.failure = ""
        self.window = False

    def alive(self):
        return self.process is not None and self.process.poll() is None

    def launch(self, unreal_dir="", project_root="", show_window=False, parent=None,
               dlss_dir="", start_level="LAST", cache_gb=None):
        """Start the editor. Returns a line for the panel; raises HostError when it cannot."""
        if self.alive():
            return "Unreal is already running"
        version, root = choose_engine(unreal_dir)
        if not root:
            raise HostError("No Unreal Engine found. Install one with the Epic Games Launcher, "
                            "or set Unreal Install in BU's preferences")
        folder = project_dir(project_root, version)
        try:
            uproject, native = ensure_project(folder, version, root, dlss_dir=dlss_dir)
        except OSError as exc:
            raise HostError("Could not make BU's render project in {0}: {1}".format(folder, exc))

        saved = os.path.join(folder, "Saved", "BU")
        status = os.path.join(saved, "host_status.json")
        quit_file = os.path.join(saved, "quit")
        for stale in (status, quit_file):
            try:
                os.remove(stale)
            except OSError:
                pass
        port = free_port()
        environ = launch_environment(os.environ, port, parent or os.getpid(), status, quit_file,
                                     start_level, show_window, cache_gb)
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            process = subprocess.Popen(
                launch_command(root, uproject, show_window), env=environ, cwd=folder,
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=flags)
        except OSError as exc:
            raise HostError("Could not start Unreal ({0}): {1}".format(editor_exe(root), exc))

        self.process = process
        self.folder = folder
        self.port = port
        self.started = time.time()
        self.quit_asked = 0.0
        self.status_path = status
        self.quit_path = quit_file
        self.log_path = os.path.join(folder, "Saved", "Logs", PROJECT_NAME + ".log")
        self.native = native
        self.version = version
        self.failure = ""
        self.window = bool(show_window)
        return "Starting Unreal {0}…".format(version)

    def status(self):
        return read_status(self.status_path, time.time()) if self.status_path else {}

    def elapsed(self):
        return time.time() - self.started if self.started else 0.0

    def answering(self):
        """True while an editor with its window, asked to close, still runs and still ticks:
        it is most likely asking whether to save (Unreal keeps ticking under that question)."""
        if not (self.window and self.quit_asked and self.alive()):
            return False
        status = self.status()
        return bool(status) and status.get("age", STATUS_STALE) < STATUS_STALE

    def closing_line(self):
        """The panel's line while the editor closes."""
        if self.answering() and time.time() - self.quit_asked > 3.0:
            return "Unreal is closing: answer its save question in its window"
        return "Unreal is closing…"

    def poll(self):
        """("running" | "exited" | "none", detail). Notes why an editor that died, died."""
        if self.process is None:
            return "none", self.failure
        code = self.process.poll()
        if code is None:
            if (self.quit_asked and time.time() - self.quit_asked > QUIT_SECONDS
                    and not self.answering()):
                self.terminate()
            return "running", ""
        if not self.failure and not self.quit_asked:
            reason = failure_reason(_tail(self.log_path))
            if reason:
                self.failure = reason
            elif code == 0 and self.window:
                self.failure = "Unreal was closed"  # its window's close button
            else:
                self.failure = "Unreal closed unexpectedly (exit code {0}). Its log: {1}".format(
                    code, self.log_path)
        self.process = None
        return "exited", self.failure

    def quit(self):
        """Ask the editor to close; it is ended after QUIT_SECONDS if it does not."""
        if not self.alive():
            self.process = None
            return
        self.quit_asked = self.quit_asked or time.time()
        if not self.status():
            # Unreal's Python is not up yet, so nothing would read the request.
            self.terminate()
            return
        try:
            with open(self.quit_path, "w", encoding="utf-8") as handle:
                handle.write("quit\n")
        except OSError:
            self.terminate()

    def terminate(self):
        process = self.process
        if process is None:
            return
        self.quit_asked = self.quit_asked or time.time()
        try:
            process.kill()
        except OSError:
            pass


HOST = Host()


def shutdown():
    """Blender is quitting: ask BU's editor to close (it also notices Blender is gone)."""
    if HOST.alive():
        HOST.quit()
