# SPDX-License-Identifier: GPL-3.0-or-later
"""Turns an evaluated Blender mesh into the bytes the real-time link sends. numpy, no `bpy`.

Everything is converted to Unreal's conventions *here*, so the Unreal side — which has no numpy
and pays per element for everything it touches — only has to copy:

* **Axes and units.** Blender is right-handed Z-up in metres, Unreal left-handed Z-up in
  centimetres. Negate Y, multiply by 100.
* **Winding is left alone.** Mirroring Y reverses a triangle's apparent winding, which looks
  like it needs the indices swapping. It does not: Unreal's geometry core computes a face normal
  as `edge2 x edge1` — the reverse of Blender's — precisely because it is left-handed
  (`VectorUtil.h`: "Unreal has Left-Hand Coordinate System so we need to reverse this
  cross-product"). The two reversals cancel, so the same index order is correct on both sides.
* **V is flipped.** Blender's UV origin is bottom-left, Unreal's top-left.

**One vertex per face corner, not per vertex.** `AppendBuffersToMesh` takes per-vertex normals
and UVs, so a vertex on a UV seam or a hard edge has to be several vertices. Corners are exactly
that split, and voxel models are almost all hard edges anyway.

**One group per material slot.** `AppendBuffersToMesh` assigns a single material ID per call, so
triangles are grouped by slot and each group carries its own vertices.
"""

import numpy as np

SCALE = 100.0

# The 4x4 that swaps handedness: conjugating by it converts a Blender transform.
_FLIP = np.diag([1.0, -1.0, 1.0, 1.0])


def points_to_unreal(points):
    """(n, 3) Blender positions in metres -> Unreal centimetres. Returns a new float32 array."""
    out = np.asarray(points, dtype=np.float32).reshape(-1, 3) * np.float32(SCALE)
    out[:, 1] *= -1.0
    return out


def directions_to_unreal(directions):
    """(n, 3) Blender directions -> Unreal. Mirrored, not scaled."""
    out = np.array(directions, dtype=np.float32).reshape(-1, 3)
    out[:, 1] *= -1.0
    return out


def uvs_to_unreal(uvs):
    out = np.array(uvs, dtype=np.float32).reshape(-1, 2)
    out[:, 1] = 1.0 - out[:, 1]
    return out


def matrix_to_unreal(matrix):
    """A Blender world matrix as 16 floats laid out the way `unreal.Matrix` wants them.

    Blender matrices act on column vectors; Unreal's act on row vectors, so its four "planes" are
    the three basis axes and then the translation — the transpose. Returned as X, Y, Z, W planes.
    """
    # _FLIP @ m @ _FLIP negates row 1 and column 1 (their shared element twice, so not at all);
    # written out, as it runs for every object that moves every frame.
    r0, r1, r2, r3 = (tuple(row) for row in matrix)
    return [float(r0[0]), -float(r1[0]), float(r2[0]), float(r3[0]),
            -float(r0[1]), float(r1[1]), -float(r2[1]), -float(r3[1]),
            float(r0[2]), -float(r1[2]), float(r2[2]), float(r3[2]),
            float(r0[3]) * SCALE, -float(r1[3]) * SCALE, float(r2[3]) * SCALE, float(r3[3])]


def build(positions, normals, uvs, triangles, material_indices, max_triangles=0):
    """Pack corner-indexed arrays into `(fields, blob)`.

    positions / normals: (corners, 3) Blender space. uvs: (corners, 2), a list of those (one per
    UV map, the render one first), or None.
    triangles: (n, 3) corner indices. material_indices: (n,) or None.

    `fields` holds a `groups` list — one `{"slot", "corners", "triangles"}` per material slot in
    use — and the blob is each group's positions, normals, UVs (`uv_channels` of them, one after
    another) and triangles in turn.
    """
    if uvs is not None and not isinstance(uvs, (list, tuple)):
        uvs = [uvs]
    if uvs is not None and not len(uvs):
        uvs = None
    triangles = np.asarray(triangles, dtype=np.int32).reshape(-1, 3)
    count = int(triangles.shape[0])
    fields = {"uv": uvs is not None, "groups": [], "triangles": count, "skipped": ""}
    if uvs is not None:
        fields["uv_channels"] = len(uvs)

    if count == 0:
        return fields, b""
    if max_triangles and count > max_triangles:
        fields["skipped"] = "{0:,} triangles is over the live-link limit of {1:,}".format(
            count, max_triangles)
        fields["triangles"] = 0
        return fields, b""

    positions = points_to_unreal(positions)
    normals = directions_to_unreal(normals)
    if uvs is not None:
        uvs = [uvs_to_unreal(channel) for channel in uvs]

    if material_indices is None:
        slots = np.zeros(count, dtype=np.int32)
    else:
        slots = np.asarray(material_indices, dtype=np.int32).reshape(-1)

    used = np.unique(slots)
    chunks = []
    for slot in used:
        if len(used) == 1:
            # The common case, and the fast one: nothing to split, nothing to renumber.
            group_triangles = triangles
            group_positions, group_normals, group_uvs = positions, normals, uvs
        else:
            group_triangles = triangles[slots == slot]
            corners, remapped = np.unique(group_triangles, return_inverse=True)
            group_triangles = remapped.reshape(-1, 3).astype(np.int32)
            group_positions = positions[corners]
            group_normals = normals[corners]
            group_uvs = [channel[corners] for channel in uvs] if uvs is not None else None

        fields["groups"].append({
            "slot": int(slot),
            "corners": int(group_positions.shape[0]),
            "triangles": int(group_triangles.shape[0]),
        })
        chunks.append(np.ascontiguousarray(group_positions, dtype="<f4").tobytes())
        chunks.append(np.ascontiguousarray(group_normals, dtype="<f4").tobytes())
        for channel in group_uvs or ():
            chunks.append(np.ascontiguousarray(channel, dtype="<f4").tobytes())
        chunks.append(np.ascontiguousarray(group_triangles, dtype="<i4").tobytes())

    return fields, b"".join(chunks)


def extract(mesh, max_triangles=0, uv_channels=1):
    """Read an evaluated `bpy.types.Mesh` into `(fields, blob)`. See `build`."""
    triangle_count = len(mesh.loop_triangles)
    corner_count = len(mesh.loops)
    if triangle_count == 0 or corner_count == 0:
        return build(np.zeros((0, 3)), np.zeros((0, 3)), None, np.zeros((0, 3)), None)
    if max_triangles and triangle_count > max_triangles:
        # Decided before reading anything: the point of the limit is not to pay for the read.
        fields, blob = build(np.zeros((0, 3)), np.zeros((0, 3)), None, np.zeros((0, 3)), None)
        fields["skipped"] = "{0:,} triangles is over the live-link limit of {1:,}".format(
            triangle_count, max_triangles)
        return fields, blob

    coords = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", coords)
    # intc, not int32: on Windows NumPy exports int32 as 'l' and Blender's foreach_get only takes
    # its memcpy path for 'i'. Same bytes; the slow path converts element by element.
    corner_vertices = np.empty(corner_count, dtype=np.intc)
    mesh.loops.foreach_get("vertex_index", corner_vertices)
    positions = coords.reshape(-1, 3)[corner_vertices]

    normals = np.empty(corner_count * 3, dtype=np.float32)
    mesh.corner_normals.foreach_get("vector", normals)

    uvs = None
    layers = uv_layers(mesh, corner_count, uv_channels)
    if layers:
        uvs = []
        for layer in layers:
            values = np.empty(corner_count * 2, dtype=np.float32)
            layer.uv.foreach_get("vector", values)
            uvs.append(values)

    triangles = np.empty(triangle_count * 3, dtype=np.intc)
    mesh.loop_triangles.foreach_get("loops", triangles)
    material_indices = np.empty(triangle_count, dtype=np.intc)
    mesh.loop_triangles.foreach_get("material_index", material_indices)

    return build(positions, normals.reshape(-1, 3), uvs, triangles, material_indices)


def render_uv_layer(mesh, corner_count):
    """The UV map Unreal should get: the one marked for render, else the active one."""
    layer = next((l for l in mesh.uv_layers if l.active_render), None) or mesh.uv_layers.active
    if layer is not None and len(layer.uv) == corner_count:
        return layer
    return None


def uv_order(names, render_name):
    """UV map names in the order Unreal gets them: the render one first, then the mesh's order.

    The same order `link_nodes` uses to turn a UV Map node's name into a texture coordinate
    index, so the two agree. Pure.
    """
    names = list(names)
    if render_name in names:
        names.remove(render_name)
        names.insert(0, render_name)
    return names


def uv_layers(mesh, corner_count, channels=1):
    """Up to `channels` UV maps for Unreal, the render one first (`uv_order`)."""
    first = render_uv_layer(mesh, corner_count)
    if first is None or channels < 1:
        return []
    by_name = {layer.name: layer for layer in mesh.uv_layers}
    found = []
    for name in uv_order(by_name, first.name):
        layer = by_name[name]
        if len(layer.uv) == corner_count:
            found.append(layer)
        if len(found) >= channels:
            break
    return found


def native_bytes(corners, triangles, uv, colors=False):
    """Size of one mesh in the layout `BULinkLibrary.ApplyMesh` reads (`uv`: UV map count;
    `colors`: whether vertex colours follow, four bytes a corner)."""
    return corners * 24 + corners * 8 * int(uv) + triangles * 16 + (corners * 4 if colors else 0)


def has_positions(mesh):
    """Whether a mesh carries its vertex positions as an attribute. An object in Edit Mode with
    modifiers evaluates to Blender's edit-mode wrapper, which has vertices but no "position"
    attribute (its geometry lives in the edit mesh); `to_mesh()` gives a complete copy."""
    return mesh.attributes.get("position") is not None


def vertex_positions(mesh):
    """Vertex positions, flat float32: from the attribute, or else from the vertices."""
    coords = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
    if not len(coords):
        return coords
    found = mesh.attributes.get("position")
    if found is not None:
        found.data.foreach_get("vector", coords)
    else:
        mesh.vertices.foreach_get("co", coords)
    return coords


def corner_vertex_indices(mesh, corner_count):
    """Each face corner's vertex, as an int array."""
    corner_vertices = np.empty(corner_count, dtype=np.intc)
    found = mesh.attributes.get(".corner_vert")
    if found is not None:
        found.data.foreach_get("value", corner_vertices)
    else:
        mesh.loops.foreach_get("vertex_index", corner_vertices)
    return corner_vertices


def render_colors(mesh, corner_count):
    """The Color Attribute a render reads (the camera icon in Blender's list), as an attribute
    on points or face corners, or None."""
    attributes = getattr(mesh, "color_attributes", None)
    if attributes is None or not len(attributes):
        return None
    index = getattr(attributes, "render_color_index", -1)
    if index is None or index < 0 or index >= len(attributes):
        return None
    found = attributes[index]
    if found.domain == "CORNER" and len(found.data) == corner_count:
        return found
    if found.domain == "POINT" and len(found.data) == len(mesh.vertices):
        return found
    return None


def srgb_bytes(values):
    """sRGB colours (n, 4) floats -> (n, 4) bytes, rounded. Pure."""
    scaled = np.clip(np.asarray(values, dtype=np.float32), 0.0, 1.0) * 255.0 + 0.5
    return scaled.astype(np.uint8)


_TO_UNREAL = np.array([SCALE, -SCALE, SCALE], dtype=np.float32)


def fan_triangles(starts, corner_count, corner_vertices=None, coords=None):
    """Cut faces of three and four corners into triangles, the way Blender does.

    starts: first corner of each face. Returns `(triangles, per_face)` — (n, 3) corner indices
    in face order and how many triangles each face produced — or None if any face has more than
    four corners, which needs Blender's real tessellator.

    This exists because `loop_triangles.foreach_get` is not a bulk read: it costs about 70 ns
    per value, 17 ms for a quarter of a million triangles, where this is a few numpy passes.
    The result is the same. A quad is cut along its first diagonal unless that diagonal lies
    outside the quad — `is_quad_flip_v3_first_third_fast` in Blender's tessellator — which
    needs `corner_vertices` and `coords` (flat xyz per vertex) to decide; without them every
    quad is cut the same way.
    """
    starts = np.asarray(starts, dtype=np.int64)
    sizes = np.diff(starts, append=corner_count)
    if sizes.size == 0:
        return np.zeros((0, 3), dtype=np.intc), np.zeros(0, dtype=np.int64)
    if sizes.max() > 4 or sizes.min() < 3:
        return None

    per_face = sizes - 2
    first = np.cumsum(per_face) - per_face
    triangles = np.empty((int(per_face.sum()), 3), dtype=np.intc)

    is_quad = sizes == 4
    corner = starts[~is_quad]
    row = first[~is_quad]
    triangles[row, 0] = corner
    triangles[row, 1] = corner + 1
    triangles[row, 2] = corner + 2

    corner = starts[is_quad]
    row = first[is_quad]
    flip = None
    if corner.size and corner_vertices is not None and coords is not None:
        points = np.asarray(coords, dtype=np.float32).reshape(-1, 3)
        origin = points[corner_vertices[corner]]
        d12 = points[corner_vertices[corner + 1]] - origin
        d13 = points[corner_vertices[corner + 2]] - origin
        d14 = points[corner_vertices[corner + 3]] - origin
        flip = np.einsum("ij,ij->i", np.cross(d12, d13), np.cross(d14, d13)) > 0.0
        if not flip.any():
            flip = None
    # (0, 1, 2) and (0, 2, 3); a flipped quad is (0, 1, 3) and (1, 2, 3).
    triangles[row, 0] = corner
    triangles[row, 1] = corner + 1
    triangles[row, 2] = corner + 2
    triangles[row + 1, 0] = corner
    triangles[row + 1, 1] = corner + 2
    triangles[row + 1, 2] = corner + 3
    if flip is not None:
        flipped = row[flip]
        triangles[flipped, 2] = corner[flip] + 3
        triangles[flipped + 1, 0] = corner[flip] + 1
    return triangles, per_face


def _face_materials(mesh, face_count):
    """Material slot per face, read as one attribute rather than face by face."""
    attribute = mesh.attributes.get("material_index")
    if attribute is None or attribute.domain != "FACE" or len(attribute.data) != face_count:
        return None
    values = np.empty(face_count, dtype=np.intc)
    attribute.data.foreach_get("value", values)
    return values


def _cut(mesh, face_count, corner_count, corner_vertices, coords, slots):
    """A mesh's triangles (flat corner indices) and their material slots, for `extract_native`."""
    starts = np.empty(face_count, dtype=np.intc)
    mesh.polygons.foreach_get("loop_start", starts)
    fanned = fan_triangles(starts, corner_count, corner_vertices, coords)
    if fanned is not None:
        triangles = np.ascontiguousarray(fanned[0], dtype=np.intc).reshape(-1)
        if slots is None:
            materials = np.zeros(len(triangles) // 3, dtype=np.intc)
        else:
            materials = np.repeat(slots, fanned[1]).astype(np.intc)
    else:
        count = len(mesh.loop_triangles)
        triangles = np.empty(count * 3, dtype=np.intc)
        materials = np.empty(count, dtype=np.intc)
        mesh.loop_triangles.foreach_get("loops", triangles)
        mesh.loop_triangles.foreach_get("material_index", materials)
    return {"faces": face_count, "corners": corner_vertices, "slots": slots,
            "triangles": triangles, "materials": materials}


def extract_native(mesh, arena, max_triangles=0, uv_channels=1, cache=None):
    """Write an evaluated mesh straight into shared memory, for Unreal's native module.

    Same conventions as `extract`, different shape: nothing is split by material and nothing
    becomes a bytes object. Every array is filled by one bulk call into a view of the arena —

        positions  f32 x 3 x corners      normals  f32 x 3 x corners
        uvs        f32 x 2 x corners      (once per UV map, the render one first)
        triangles  i32 x 3 x triangles    material slots  i32 x triangles

    — which is the layout `BULinkLibrary.ApplyMesh` reads without copying.

    Which bulk call matters as much as there being one. Attribute arrays (`.corner_vert`,
    `position`, `material_index`) copy at memory speed; `loops.vertex_index` and anything on
    `loop_triangles` go element by element and were 54 of the first version's 59 ms on a
    250,000-triangle mesh. So triangles come from `fan_triangles`, and Blender's own
    tessellation is only read for meshes with faces of five corners or more.

    `cache`, a dict kept per object, holds the triangles from last time. While the corners, face
    count and face materials are the same (an armature or shape keys deforming the mesh), they
    are copied from it rather than cut again, which was most of the time for a deforming mesh.
    A quad that bends past its diagonal keeps the cut it had, where a fresh cut would flip it:
    the same triangles keep Unreal updating the mesh in place rather than rebuilding it.

    Returns `fields` (`uv`, `triangles`, `vertices`, `skipped`, `offset`), or None when the
    arena has no room left. An empty or over-limit mesh takes no room and has `offset` None.
    """
    corner_count = len(mesh.loops)
    face_count = len(mesh.polygons)
    fields = {"uv": False, "triangles": 0, "vertices": 0, "skipped": "", "offset": None}
    if face_count == 0 or corner_count == 0:
        return fields

    coords = vertex_positions(mesh)
    corner_vertices = corner_vertex_indices(mesh, corner_count)
    slots = _face_materials(mesh, face_count)

    kept = cache.get("topology") if cache is not None else None
    if not (kept is not None and kept["faces"] == face_count
            and np.array_equal(kept["corners"], corner_vertices)
            and (np.array_equal(kept["slots"], slots) if slots is not None
                 else kept["slots"] is None)):
        kept = _cut(mesh, face_count, corner_count, corner_vertices, coords, slots)
        if cache is not None:
            cache["topology"] = kept
    triangle_count = len(kept["materials"])
    if triangle_count == 0:
        return fields
    if max_triangles and triangle_count > max_triangles:
        fields["skipped"] = "{0:,} triangles is over the live-link limit of {1:,}".format(
            triangle_count, max_triangles)
        return fields

    layers = uv_layers(mesh, corner_count, uv_channels)
    colors = render_colors(mesh, corner_count)
    offset = arena.alloc(native_bytes(corner_count, triangle_count, len(layers),
                                      colors is not None))
    if offset is None:
        return None

    cursor = offset
    positions = arena.floats(cursor, corner_count * 3)
    cursor += corner_count * 12
    normals = arena.floats(cursor, corner_count * 3)
    cursor += corner_count * 12
    channels = []
    for _layer in layers:
        channels.append(arena.floats(cursor, corner_count * 2))
        cursor += corner_count * 8
    triangles = arena.ints(cursor, triangle_count * 3)
    cursor += triangle_count * 12
    materials = arena.ints(cursor, triangle_count)

    by_corner = positions.reshape(-1, 3)
    # mode="clip" lets numpy write into `out` directly; the default buffers the whole result.
    np.take(coords.reshape(-1, 3), corner_vertices, axis=0, out=by_corner, mode="clip")
    by_corner *= _TO_UNREAL

    mesh.corner_normals.foreach_get("vector", normals)
    normals[1::3] *= -1.0

    for layer, uvs in zip(layers, channels):
        layer.uv.foreach_get("vector", uvs)
        flipped = uvs[1::2]
        np.subtract(1.0, flipped, out=flipped)

    triangles[:] = kept["triangles"]
    materials[:] = kept["materials"]

    if colors is not None:
        # sRGB bytes, as Unreal keeps a mesh's vertex colours; its material decodes them.
        cursor += triangle_count * 4
        values = np.empty(len(colors.data) * 4, dtype=np.float32)
        colors.data.foreach_get("color_srgb", values)
        values = values.reshape(-1, 4)
        if colors.domain == "POINT":
            values = values[corner_vertices]
        arena.view[cursor:cursor + corner_count * 4] = srgb_bytes(values).reshape(-1)

    fields.update(uv=bool(layers), triangles=triangle_count, vertices=corner_count,
                  offset=offset)
    if layers:
        fields["uv_channels"] = len(layers)
    if colors is not None:
        fields["colors"] = True
    return fields


# -- subdivision cages ---------------------------------------------------------------------------
#
# An object whose last modifier is Subdivision Surface goes to Unreal as its cage, the mesh before
# that modifier, with the modifier's settings; BU's native module subdivides it there
# (`BULinkSubdiv.cpp`, OpenSubdiv). Reading a subdivided mesh is what makes Blender subdivide on
# the CPU every frame — 230 of a heavy character's 290 ms a frame — where Blender otherwise
# leaves the last Subdivision to the GPU, and so to whoever draws. The cage is
# `evaluated_geometry().mesh_base`; the subdivided mesh (`evaluated.data`) is never touched.

# Blender's uv_smooth choices, in the order the native module numbers them.
SUBDIV_UV_SMOOTH = ("NONE", "PRESERVE_CORNERS", "PRESERVE_CORNERS_AND_JUNCTIONS",
                    "PRESERVE_CORNERS_JUNCTIONS_AND_CONCAVE", "PRESERVE_BOUNDARIES", "SMOOTH_ALL")

# Object types whose evaluated geometry can be a cage. Curves are most of a rigged character's
# subdivided pieces; their cage is the mesh the curve becomes.
CAGE_TYPES = frozenset(("MESH", "CURVE"))

# More levels than this go Blender's way: level 7 of one cube is 300,000 triangles.
MAX_SUBDIV_LEVELS = 6

# Modifiers that do nothing without their target; one left without it is not "last".
_NEEDS_OBJECT = frozenset(("ARMATURE", "HOOK", "LATTICE", "CURVE", "MESH_DEFORM"))

# A crease of 1 is infinitely sharp to OpenSubdiv.
SHARPNESS_INFINITE = 10.0


def subdiv_levels(modifier, render):
    """The viewport levels a Subdivision modifier subdivides by, after Simplify (`render`:
    the scene's RenderSettings). What Blender's own viewport shows."""
    levels = int(modifier.levels)
    if getattr(render, "use_simplify", False):
        levels = min(levels, int(render.simplify_subdivision))
    return max(0, levels)


def modifier_active(modifier, render):
    """Whether a modifier changes the viewport's mesh: shown in the viewport, has what it needs."""
    if not modifier.show_viewport:
        return False
    kind = modifier.type
    if kind == "SUBSURF":
        return subdiv_levels(modifier, render) > 0
    if kind in _NEEDS_OBJECT and getattr(modifier, "object", None) is None:
        return False
    if kind == "NODES" and modifier.node_group is None:
        return False
    if (kind == "BOOLEAN" and getattr(modifier, "operand_type", "") == "OBJECT"
            and modifier.object is None):
        return False
    return True


def trailing_subsurf(evaluated, render):
    """The Subdivision modifier an object's viewport mesh ends with, or None.

    Read from the evaluated object, so a driver on `show_viewport` or `levels` counts. A
    modifier after it that does nothing (hidden, or missing its target) does not count.
    """
    for modifier in reversed(evaluated.modifiers):
        if modifier_active(modifier, render):
            return modifier if modifier.type == "SUBSURF" else None
    return None


def _any_true(mesh, name, domain):
    attribute = mesh.attributes.get(name)
    if attribute is None or attribute.domain != domain or attribute.data_type != "BOOLEAN":
        return False
    values = np.empty(len(attribute.data), dtype=bool)
    attribute.data.foreach_get("value", values)
    return bool(values.any())


def cage_refusal(mesh, modifier):
    """Why a cage is not subdivided in Unreal, or "" if it can be.

    Sharp edges, flat faces and custom normals split a mesh's normals. Blender's GPU
    subdivision does not take those meshes either: it subdivides them on the CPU whatever is
    read, so sending their subdivided mesh costs nothing more, and Unreal need not match
    Blender's split normals.
    """
    if not has_positions(mesh):
        return "in Edit Mode"
    if not len(mesh.polygons):
        return "no faces"
    if modifier.use_custom_normals and mesh.attributes.get("custom_normal") is not None:
        return "custom normals"
    if _any_true(mesh, "sharp_face", "FACE"):
        return "flat faces"
    if _any_true(mesh, "sharp_edge", "EDGE"):
        return "sharp edges"
    return ""


def subdiv_settings(modifier, levels):
    """A Subdivision modifier's settings for the native module: `(packed, fields)`.

    Packed as `BUSubdiv::FSettings::Unpack` reads it: levels in bits 0-3, Simple 4, limit
    surface 5, boundary preserving corners 6, UV smoothing in bits 8-10, quality 11-14 (how
    exactly Blender places limit-surface points, which Unreal copies). Pure, given the
    modifier's values.
    """
    simple = modifier.subdivision_type == "SIMPLE"
    limit = bool(modifier.use_limit_surface)
    corners = modifier.boundary_smooth == "PRESERVE_CORNERS"
    try:
        uv_smooth = SUBDIV_UV_SMOOTH.index(modifier.uv_smooth)
    except ValueError:
        uv_smooth = 1
    levels = max(1, min(MAX_SUBDIV_LEVELS, int(levels)))
    quality = max(1, min(10, int(modifier.quality)))
    packed = (levels | (simple << 4) | (limit << 5) | (corners << 6) | (uv_smooth << 8)
              | (quality << 11))
    fields = {"levels": levels, "simple": simple, "limit": limit, "preserve_corners": corners,
              "uv_smooth": SUBDIV_UV_SMOOTH[uv_smooth], "quality": quality,
              "creases": bool(modifier.use_creases), "packed": packed}
    return packed, fields


def crease_sharpness(creases):
    """Blender's crease (0..1) as OpenSubdiv sharpness: 10 c², 1 being infinitely sharp. Pure.

    Measured, not assumed: creases 0.1, 0.2, 0.25 and 0.3 subdivide exactly as sharpness 0.1,
    0.4, 0.625 and 0.9 do.
    """
    values = np.clip(np.asarray(creases, dtype=np.float32), 0.0, 1.0)
    return SHARPNESS_INFINITE * values * values


def corner_sharpness(edge_vertices, edge_sharpness, vertex_sharpness, vertex_count):
    """Vertex sharpness with Blender's rule for a vertex on exactly two edges added: such a
    vertex is also as sharp as the softer of its two edges. A plane's corner with both its
    edges creased stays a corner. Pure; returns a new array."""
    edge_vertices = np.asarray(edge_vertices, dtype=np.int64).reshape(-1, 2)
    sharp = np.array(vertex_sharpness, dtype=np.float32, copy=True)
    if not len(edge_vertices):
        return sharp
    edge_count = np.bincount(edge_vertices.reshape(-1), minlength=vertex_count)
    softer = np.full(vertex_count, np.inf, dtype=np.float32)
    np.minimum.at(softer, edge_vertices[:, 0], edge_sharpness)
    np.minimum.at(softer, edge_vertices[:, 1], edge_sharpness)
    two = edge_count == 2
    sharp[two] += softer[two]
    return np.minimum(sharp, SHARPNESS_INFINITE)


def _float_attribute(mesh, name, domain, count):
    attribute = mesh.attributes.get(name)
    if attribute is None or attribute.domain != domain or len(attribute.data) != count:
        return None
    values = np.empty(count, dtype=np.float32)
    attribute.data.foreach_get("value", values)
    return values


def _no_creases():
    return (np.zeros((0, 2), dtype=np.intc), np.zeros(0, dtype=np.float32),
            np.zeros(0, dtype=np.intc), np.zeros(0, dtype=np.float32))


def cage_creases(mesh, vertex_count):
    """A cage's creases as OpenSubdiv takes them: `(edges (n, 2), edge sharpness, vertices,
    vertex sharpness)`, only the ones above 0."""
    edge_count = len(mesh.edges)
    edge_creases = _float_attribute(mesh, "crease_edge", "EDGE", edge_count)
    vertex_creases = _float_attribute(mesh, "crease_vert", "POINT", vertex_count)
    if edge_creases is None and vertex_creases is None:
        return _no_creases()
    edge_vertices = np.empty(edge_count * 2, dtype=np.intc)
    if edge_count:
        mesh.edges.foreach_get("vertices", edge_vertices)
    edge_vertices = edge_vertices.reshape(-1, 2)
    edge_sharp = (crease_sharpness(edge_creases) if edge_creases is not None
                  else np.zeros(edge_count, dtype=np.float32))
    vertex_sharp = (crease_sharpness(vertex_creases) if vertex_creases is not None
                    else np.zeros(vertex_count, dtype=np.float32))
    if edge_sharp.any():
        vertex_sharp = corner_sharpness(edge_vertices, edge_sharp, vertex_sharp, vertex_count)
    creased = edge_sharp > 0.0
    pointed = vertex_sharp > 0.0
    return (np.ascontiguousarray(edge_vertices[creased], dtype=np.intc), edge_sharp[creased],
            np.flatnonzero(pointed).astype(np.intc), vertex_sharp[pointed])


def cage_arrays(mesh, use_creases=True, uv_channels=1):
    """Everything about a cage the native module refines, in Blender's space. numpy arrays:
    `coords` (flat xyz), `face_sizes`, `corners`, `materials` (per face), `uvs` (a list, the
    render map first), `colors` (sRGB bytes per corner, or None) and the creases."""
    vertex_count = len(mesh.vertices)
    face_count = len(mesh.polygons)
    corner_count = len(mesh.loops)
    starts = np.empty(face_count, dtype=np.intc)
    mesh.polygons.foreach_get("loop_start", starts)
    face_sizes = np.diff(starts, append=corner_count).astype(np.intc)
    materials = _face_materials(mesh, face_count)
    if materials is None:
        materials = np.zeros(face_count, dtype=np.intc)
    uvs = []
    for layer in uv_layers(mesh, corner_count, uv_channels):
        values = np.empty(corner_count * 2, dtype=np.float32)
        layer.uv.foreach_get("vector", values)
        uvs.append(values)
    corner_vertices = corner_vertex_indices(mesh, corner_count)
    colors = None
    found = render_colors(mesh, corner_count)
    if found is not None:
        values = np.empty(len(found.data) * 4, dtype=np.float32)
        found.data.foreach_get("color_srgb", values)
        values = values.reshape(-1, 4)
        if found.domain == "POINT":
            values = values[corner_vertices]
        colors = srgb_bytes(values).reshape(-1)
    creases = cage_creases(mesh, vertex_count) if use_creases else _no_creases()
    return {"coords": vertex_positions(mesh), "face_sizes": face_sizes, "corners": corner_vertices,
            "materials": materials, "uvs": uvs, "colors": colors,
            "crease_edges": creases[0], "crease_edge_sharpness": creases[1],
            "crease_vertices": creases[2], "crease_vertex_sharpness": creases[3]}


def subdivided_quads(corner_count, levels):
    """Faces a cage subdivides into: each face of n corners becomes n quads, then every level
    after the first quarters them. Pure."""
    return int(corner_count) * 4 ** (max(1, int(levels)) - 1)


def cage_bytes(vertices, faces, corners, uv, colors, crease_edges, crease_vertices):
    """Size of a cage in the layout `BULinkLibrary.ApplySubdivMesh` reads. Pure."""
    return (vertices * 12 + faces * 8 + corners * 4 + corners * 8 * int(uv)
            + (corners * 4 if colors else 0) + crease_edges * 12 + crease_vertices * 8)


def write_cage_positions(arena, coords):
    """Write a cage's positions alone (`BULinkLibrary.ApplySubdivPositions`): Blender's flat
    float32 vertex positions, in Unreal's space. Returns the offset, or None with no room."""
    vertex_count = len(coords) // 3
    offset = arena.alloc(vertex_count * 12)
    if offset is None:
        return None
    positions = arena.floats(offset, vertex_count * 3)
    positions[:] = coords
    positions.reshape(-1, 3)[:] *= _TO_UNREAL
    return offset


def extract_cage(mesh, arena, modifier, levels, max_triangles=0, uv_channels=1):
    """Write a cage into shared memory for `BULinkLibrary.ApplySubdivMesh`:

        positions       f32 x 3 x vertices (Unreal's space)
        face sizes      i32 x faces           corner vertices  i32 x corners
        face materials  i32 x faces           uvs              f32 x 2 x corners, per UV map
        colors          u8 x 4 x corners (if any)
        crease edges    i32 x 2 x n, then f32 x n sharpness
        crease vertices i32 x m, then f32 x m sharpness

    Returns fields like `extract_native`'s (`triangles` and `vertices` are what it subdivides
    into) plus `subd`, or None when the arena has no room.
    """
    _packed, settings = subdiv_settings(modifier, levels)
    arrays = cage_arrays(mesh, settings["creases"], uv_channels)
    quads = subdivided_quads(len(arrays["corners"]), settings["levels"])
    fields = {"uv": False, "triangles": quads * 2, "vertices": quads * 4, "skipped": "",
              "offset": None}
    if max_triangles and quads * 2 > max_triangles:
        fields["skipped"] = "{0:,} triangles is over the live-link limit of {1:,}".format(
            quads * 2, max_triangles)
        return fields
    vertex_count = len(arrays["coords"]) // 3
    face_count = len(arrays["face_sizes"])
    corner_count = len(arrays["corners"])
    uvs, colors = arrays["uvs"], arrays["colors"]
    crease_edge_count = len(arrays["crease_edge_sharpness"])
    crease_vertex_count = len(arrays["crease_vertex_sharpness"])
    offset = arena.alloc(cage_bytes(vertex_count, face_count, corner_count, len(uvs),
                                    colors is not None, crease_edge_count, crease_vertex_count))
    if offset is None:
        return None

    cursor = offset
    positions = arena.floats(cursor, vertex_count * 3)
    positions[:] = arrays["coords"]
    positions.reshape(-1, 3)[:] *= _TO_UNREAL
    cursor += vertex_count * 12
    for values in (arrays["face_sizes"], arrays["corners"], arrays["materials"]):
        arena.ints(cursor, len(values))[:] = values
        cursor += len(values) * 4
    for values in uvs:
        out = arena.floats(cursor, corner_count * 2)
        out[:] = values
        flipped = out[1::2]
        np.subtract(1.0, flipped, out=flipped)
        cursor += corner_count * 8
    if colors is not None:
        arena.view[cursor:cursor + corner_count * 4] = colors
        cursor += corner_count * 4
    arena.ints(cursor, crease_edge_count * 2)[:] = arrays["crease_edges"].reshape(-1)
    cursor += crease_edge_count * 8
    arena.floats(cursor, crease_edge_count)[:] = arrays["crease_edge_sharpness"]
    cursor += crease_edge_count * 4
    arena.ints(cursor, crease_vertex_count)[:] = arrays["crease_vertices"]
    cursor += crease_vertex_count * 4
    arena.floats(cursor, crease_vertex_count)[:] = arrays["crease_vertex_sharpness"]

    fields.update(uv=bool(uvs), offset=offset)
    if uvs:
        fields["uv_channels"] = len(uvs)
    if colors is not None:
        fields["colors"] = True
    settings.update(cage_vertices=vertex_count, faces=face_count, corners=corner_count,
                    crease_edges=crease_edge_count, crease_vertices=crease_vertex_count)
    fields["subd"] = settings
    return fields
