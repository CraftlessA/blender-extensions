# SPDX-License-Identifier: GPL-3.0-or-later
"""Instances for the real-time link: Geometry Nodes instances, particles, collection instances.

Blender draws many copies of one piece of geometry without making a mesh of each (a pipe
generator's 18,599 sections, an emitter's embers). `to_mesh` leaves them out, so on their own
they never reached Unreal. Here each distinct piece is sent once, as a hidden "prototype" mesh,
and every instancer as a list of matrices, one per copy. Unreal draws each list with one
Instanced Static Mesh component (`bu_link_instances` on its side).

What a prototype is: an instance's mesh, known by a digest of its contents. Blender hands out a
new copy of a Geometry Nodes instance's mesh at each evaluation, so its address says nothing
from one scan to the next; the same pipe section found again has the same digest and is not
sent again.
"""

import hashlib

import numpy as np

try:
    from . import link_mesh
except ImportError:  # loaded by path in the plain-CPython tests
    import link_mesh

PROTO_PREFIX = "BU instance source "
GROUP_INFIX = " instances "
KEY_LENGTH = 12


def proto_name(key):
    """The Unreal-side name of a prototype mesh. Pure."""
    return PROTO_PREFIX + key[:KEY_LENGTH]


def group_name(parent, key):
    """The Unreal-side name of one instancer's copies of one prototype. Pure."""
    return "{0}{1}{2}".format(parent, GROUP_INFIX, key[:KEY_LENGTH])


def is_proto(name):
    return str(name).startswith(PROTO_PREFIX)


def to_unreal(matrices):
    """(n, 4, 4) Blender world matrices -> (n, 16) float32, laid out as `link_mesh.
    matrix_to_unreal` lays out one. Pure."""
    m = np.asarray(matrices, dtype=np.float64).reshape(-1, 4, 4)
    converted = link_mesh._FLIP @ m @ link_mesh._FLIP
    converted[:, :3, 3] *= link_mesh.SCALE
    return np.ascontiguousarray(np.transpose(converted, (0, 2, 1)).reshape(-1, 16),
                                dtype=np.float32)


def materials_of(obj, mesh):
    """The material names an instance's mesh wears, slot by slot."""
    slots = getattr(obj, "material_slots", None) or ()
    if len(slots):
        return tuple(slot.material.name if slot.material else "" for slot in slots)
    return tuple(m.name if m is not None else "" for m in getattr(mesh, "materials", ()) or ())


def mesh_key(mesh, materials):
    """A digest of what Unreal would be sent for this mesh: its points, corners, faces'
    materials, normals and render UV map, and the materials by name."""
    digest = hashlib.sha1()
    counts = (len(mesh.vertices), len(mesh.loops), len(mesh.polygons))
    digest.update(repr((counts, materials)).encode("utf-8"))
    if counts[0]:
        coords = np.empty(counts[0] * 3, dtype=np.float32)
        mesh.vertices.foreach_get("co", coords)
        digest.update(coords.tobytes())
    if counts[1]:
        corners = np.empty(counts[1], dtype=np.intc)
        mesh.loops.foreach_get("vertex_index", corners)
        digest.update(corners.tobytes())
        normals = np.empty(counts[1] * 3, dtype=np.float32)
        mesh.corner_normals.foreach_get("vector", normals)
        digest.update(normals.round(4).tobytes())
        layer = link_mesh.render_uv_layer(mesh, counts[1])
        if layer is not None:
            uv = np.empty(counts[1] * 2, dtype=np.float32)
            layer.uv.foreach_get("vector", uv)
            digest.update(uv.tobytes())
    if counts[2]:
        starts = np.empty(counts[2], dtype=np.intc)
        mesh.polygons.foreach_get("loop_start", starts)
        digest.update(starts.tobytes())
        slots = np.empty(counts[2], dtype=np.intc)
        mesh.polygons.foreach_get("material_index", slots)
        digest.update(slots.tobytes())
    return digest.hexdigest()


class Found(object):
    """What one pass over the depsgraph's instances found."""

    def __init__(self):
        self.groups = {}     # group name -> {"parent", "key", "matrices": [Matrix]}
        self.protos = {}     # key -> (fields, blob, materials), read for keys not known yet
        self.keys = set()    # every prototype key in use
        self.skipped = {}    # instancer name -> why some of its instances are not sent


# `persistent_id[1]` of the entry Blender (5.x) lists for a non-mesh object's own evaluated mesh:
# a curve, surface, text or metaball appears in `object_instances` as an "instance" of itself.
OWN_GEOMETRY_ID = 0x7FFFFFFF


def own_geometry(instance, parent):
    """Whether this instance is just `parent`'s own evaluated geometry, which `_send_mesh`
    already sends as the object itself (through `to_mesh`). Collected too, every curve was drawn
    twice in Unreal, and one deformed by hooks was a new prototype every frame: 24 MB a frame
    through the socket on Ennard and Unreal building a static mesh per curve, which choked it
    (3 ticks a second, pictures stopping for seconds)."""
    ids = tuple(instance.persistent_id)
    obj = instance.object
    original = getattr(obj, "original", None) or obj
    return (len(ids) > 1 and ids[1] == OWN_GEOMETRY_ID and original is not None
            and original.name == parent.name)


def collect(depsgraph, shows, known, read, max_triangles=0):
    """Walk the depsgraph's instances. `shows(parent)` says whether an instancer's copies are
    drawn; `known` holds prototype keys Unreal already has; `read(mesh)` returns what to send for
    a new one (`(fields, blob)`), and is only called while the instance is alive."""
    found = Found()
    by_address = {}
    for instance in depsgraph.object_instances:
        if not instance.is_instance:
            continue
        parent = instance.parent
        if parent is None:
            continue
        parent = getattr(parent, "original", None) or parent
        if not shows(parent) or own_geometry(instance, parent):
            continue
        obj = instance.object
        if obj is None or obj.type != "MESH" or obj.data is None:
            if obj is not None:
                found.skipped.setdefault(
                    parent.name, "{0} instances are not sent".format(obj.type.lower()))
            continue
        mesh = obj.data
        address = mesh.as_pointer()
        key = by_address.get(address)
        if key is None:
            if not len(mesh.polygons):
                by_address[address] = ""
                continue
            if max_triangles and len(mesh.loop_triangles) > max_triangles:
                found.skipped[parent.name] = "an instanced mesh over the live-link limit"
                by_address[address] = ""
                continue
            materials = materials_of(obj, mesh)
            key = mesh_key(mesh, materials)
            by_address[address] = key
            if key not in known and key not in found.protos:
                fields, blob = read(mesh)
                found.protos[key] = (fields, blob, materials)
        if not key:
            continue
        found.keys.add(key)
        name = group_name(parent.name, key)
        group = found.groups.get(name)
        if group is None:
            group = found.groups[name] = {"parent": parent.name, "key": key, "matrices": []}
        group["matrices"].append(instance.matrix_world.copy())
    return found


def matrices_blob(matrices):
    """(bytes, digest) for a group's matrices in Unreal's layout."""
    data = to_unreal(np.array(matrices, dtype=np.float64) if len(matrices)
                     else np.zeros((0, 4, 4)))
    blob = data.tobytes()
    return blob, hashlib.sha1(blob).hexdigest()
