# SPDX-License-Identifier: GPL-3.0-or-later
"""A surface for each material Blender's USD exporter would write empty, for the export only.

The exporter writes a material from the first Principled BSDF (or Diffuse) among the material's
own top-level nodes, and nothing else. Two common shapes leave it with none, so the material
reaches Unreal with no surface at all and the geometry arrives untextured:

- **a hair shader** (Principled Hair BSDF): Springtrap's suit fur, 54 objects;
- **a Principled BSDF inside a node group**: Springtrap's procedural eyes, Iris and Sclera.

The exporter takes a Principled BSDF that is not connected to anything (checked: an unconnected
one is what it writes), so one is added for the export, which leaves Blender's own render as it
was, and removed afterwards. Each of its inputs is filled from what really feeds the shader,
followed out through group inputs and reroutes:

- a typed-in value, as is;
- an image texture at the material's top level, linked as is;
- anything `link_flatten` can work out (an image through Brightness/Contrast, Hue/Saturation,
  Mix and so on): worked out into a picture, or a single value;
- anything else (a procedural noise inside a group): the colour left at the material's viewport
  colour, and the material reported as approximated rather than as lost.
"""

import contextlib

# Tag on the added nodes, so a leaked one is recognisable and a rerun can find them.
MARKER = "BU export surface"

# Principled BSDF inputs that a UsdPreviewSurface can carry.
_INPUTS = ("Base Color", "Metallic", "Roughness", "Alpha", "Emission Color",
           "Emission Strength", "IOR")
# A Principled Hair BSDF's equivalents (`Color` only in its Direct Coloring mode).
_HAIR = {"Base Color": "Color", "Roughness": "Roughness"}


def _follow(socket, stack):
    """What feeds an input `socket` inside the tree reached through `stack` (group nodes from
    the material's top level in): ("value", socket, stack) for a typed-in value, or ("node",
    output socket, stack) for the node output feeding it, through reroutes and group bounds."""
    for _ in range(256):
        if not socket.is_linked:
            return "value", socket, stack
        link = socket.links[0]
        if getattr(link, "is_muted", False) or not getattr(link, "is_valid", True):
            return "value", socket, stack
        node, out = link.from_node, link.from_socket
        if node.type == "REROUTE":
            socket = node.inputs[0]
            continue
        if node.type == "GROUP_INPUT":
            if not stack:
                return "value", socket, stack
            outer = stack[-1]
            index = list(node.outputs).index(out)
            if index >= len(outer.inputs):
                return "value", socket, stack
            socket, stack = outer.inputs[index], stack[:-1]
            continue
        if node.type == "GROUP" and node.node_tree is not None:
            inner = [n for n in node.node_tree.nodes if n.type == "GROUP_OUTPUT"
                     and getattr(n, "is_active_output", True)]
            index = list(node.outputs).index(out)
            if not inner or index >= len(inner[0].inputs):
                return "value", socket, stack
            socket, stack = inner[0].inputs[index], stack + [node]
            continue
        return "node", out, stack
    return "value", socket, stack


def _shader(material):
    """(shader node, group stack) of what the material's surface really is: the node feeding
    Material Output's Surface, followed into groups. None when there is none."""
    from . import capture

    surface = capture._output_surface_node(material)
    if surface is None:
        return None
    output = None
    for link in surface.id_data.links:
        if link.from_node == surface and link.to_node.type == "OUTPUT_MATERIAL"                 and link.to_socket.name == "Surface":
            output = link.to_socket
            break
    if output is None:
        return surface, []
    return _descend(output, [], 0)


_WANTED = ("BSDF_PRINCIPLED", "BSDF_HAIR_PRINCIPLED", "BSDF_DIFFUSE")


def _descend(socket, stack, depth):
    """The shader behind a shader socket: through Mix and Add Shaders, a Principled (or hair, or
    Diffuse) before anything else; else the first shader found."""
    kind, found, stack = _follow(socket, stack)
    if kind != "node" or depth > 16:
        return None
    node = found.node
    if node.type not in ("MIX_SHADER", "ADD_SHADER"):
        return node, stack
    found = []
    for inner in node.inputs:
        if inner.type != "SHADER":
            continue
        got = _descend(inner, stack, depth + 1)
        if got is not None:
            found.append(got)
    wanted = [g for g in found if g[0].type in _WANTED]
    if wanted:
        # The opaque one: an eye mixes a clear cornea over its iris, and the cornea (white,
        # glossy, see-through) is not the colour anyone sees.
        return min(wanted, key=lambda g: _clearness(g[0]))
    return found[0] if found else None


def _clearness(node):
    """How see-through a shader's typed-in values make it (0: opaque)."""
    clear = 0.0
    for name in ("Transmission Weight", "Transmission"):
        socket = node.inputs.get(name)
        if socket is not None:
            clear += 1.0 if socket.is_linked else float(socket.default_value)
            break
    alpha = node.inputs.get("Alpha")
    if alpha is not None and not alpha.is_linked:
        clear += 1.0 - float(alpha.default_value)
    return clear


def _representative_colour(socket, stack, limit=200, wanted=6):
    """A colour for a procedural one nothing can work out: the first few colours typed in
    upstream (a Color Ramp's stops among them), averaged, leaving out black ones unless all
    are (an iris's nearest colour is its black pupil). None if none."""
    found = []
    queue = [(socket, stack)]
    seen = 0
    while queue and seen < limit and len(found) < wanted:
        current, where = queue.pop(0)
        seen += 1
        kind, out, where = _follow(current, where)
        if kind == "value":
            if out.type == "RGBA":
                found.append(tuple(out.default_value)[:3])
            continue
        node = out.node
        if node.type == "VALTORGB":
            found.extend(tuple(e.color)[:3] for e in node.color_ramp.elements)
            continue
        if node.type == "RGB":
            found.append(tuple(node.outputs[0].default_value)[:3])
            continue
        for inner in node.inputs:
            # Colour inputs only, and only those in use: a Mix node keeps its float and vector
            # inputs too, unavailable and black.
            if inner.type == "RGBA" and getattr(inner, "enabled", True):
                queue.append((inner, where))
    if not found:
        return None
    lit = [c for c in found if max(c) > 0.01] or found
    return tuple(sum(c[i] for c in lit) / len(lit) for i in range(3))


def _value(socket):
    value = socket.default_value
    try:
        return tuple(value)
    except TypeError:
        return float(value)


def _set(target, value):
    if isinstance(value, tuple):
        size = len(target.default_value)
        target.default_value = (value + (1.0,) * size)[:size]
    else:
        target.default_value = value


def _write_png(pixels, path, colour):
    """(h, w, 3) linear colour or (h, w) data, bottom row first, as an 8-bit PNG at `path`."""
    import numpy as np

    from . import link_flatten, link_material

    rgba = np.ones(pixels.shape[:2] + (4,), dtype=np.float32)
    if colour:
        rgba[..., :3] = link_flatten._linear_to_srgb(np.clip(pixels, 0.0, None))
    else:
        rgba[..., :3] = np.clip(pixels, 0.0, 1.0)[..., None]
    data = link_material.png_bytes((np.clip(rgba[::-1], 0.0, 1.0) * 255.0 + 0.5)
                                   .astype(np.uint8))
    with open(path, "wb") as handle:
        handle.write(data)


def _image_node(tree, pixels, name, colour, made_images, folder):
    """An Image Texture node on a picture written next to the USD, so the stage carries it."""
    import os
    import re

    import bpy

    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, re.sub(r"[^\w.-]", "_", name) + ".png")
    _write_png(pixels, path, colour)
    image = bpy.data.images.load(path, check_existing=False)
    image.name = name
    image.colorspace_settings.name = "sRGB" if colour else "Non-Color"
    made_images.append(image)
    node = tree.nodes.new("ShaderNodeTexImage")
    node.image = image
    node.label = MARKER
    return node


def _fill(tree, principled, target_name, source, shader_input, made_nodes, made_images,
          material, folder):
    """Fill one input of the added Principled from `source` (`_follow` of the real shader's
    `shader_input`). True if exact."""
    import numpy as np

    from . import link_flatten

    target = principled.inputs[target_name]
    kind, socket, stack = source
    if kind == "value":
        if socket.type in ("RGBA", "VALUE", "VECTOR", "INT"):
            _set(target, _value(socket))
        return True
    node = socket.node
    if not stack and node.type == "TEX_IMAGE" and node.image is not None:
        tree.links.new(socket, target)  # the exporter reads a top-level image itself
        return True
    # Worked out where it is: the input it feeds, on the shader that input belongs to.
    holder = principled if not stack else None
    if not stack:
        tree.links.new(socket, target)
        feeding = target
    else:
        feeding = shader_input  # worked out inside the group, from the shader's own input
    constant = link_flatten.constant(feeding)
    if constant is not None:
        if holder is not None:
            for link in list(target.links):
                tree.links.remove(link)
        _set(target, constant if isinstance(constant, tuple) else float(constant))
        return True
    worked = link_flatten.work_out(feeding.node, feeding.name)
    if worked is not None:
        pixels, strength = worked
        if holder is not None:
            for link in list(target.links):
                tree.links.remove(link)
        colour = np.ndim(pixels) == 3
        name = "{0}_{1}".format(material.name, target_name.replace(" ", ""))
        image = _image_node(tree, pixels, name, colour, made_images, folder)
        made_nodes.append(image)
        tree.links.new(image.outputs["Color"], target)
        return True
    if holder is not None:
        for link in list(target.links):
            tree.links.remove(link)
    return False


def _stand_in(material, made_nodes, made_images, folder):
    """Add and fill the Principled for one material. Returns "exact" or "approximate"."""
    found = _shader(material)
    tree = material.node_tree
    principled = tree.nodes.new("ShaderNodeBsdfPrincipled")
    principled.label = MARKER
    principled.name = MARKER
    principled.location = (-2000.0, 0.0)
    made_nodes.append(principled)
    colour = tuple(material.diffuse_color)[:3]
    principled.inputs["Base Color"].default_value = colour + (1.0,)
    if found is None:
        return "approximate"
    shader, stack = found
    exact = True
    if shader.type == "BSDF_HAIR_PRINCIPLED":
        from . import link_nodes

        if getattr(shader, "parametrization", "COLOR") != "COLOR":
            _set(principled.inputs["Base Color"], tuple(link_nodes.hair_colour(shader))[:3])
            pairs = [("Roughness", "Roughness")]
        else:
            pairs = list(_HAIR.items())
    elif shader.type == "BSDF_PRINCIPLED":
        pairs = [(name, name) for name in _INPUTS]
    elif shader.type == "BSDF_DIFFUSE":
        pairs = [("Base Color", "Color"), ("Roughness", "Roughness")]
        _set(principled.inputs["Roughness"], 1.0)
    else:
        # Another shader (Toon, Glossy, Emission...): its colour, where it has one.
        pairs = [("Base Color", "Color"), ("Roughness", "Roughness")]
        exact = False
    for target_name, source_name in pairs:
        socket = shader.inputs.get(source_name)
        if socket is None or target_name not in principled.inputs:
            continue
        source = _follow(socket, stack)
        if not _fill(tree, principled, target_name, source, socket, made_nodes, made_images,
                     material, folder):
            exact = False
            if target_name == "Base Color":
                near = _representative_colour(socket, stack)
                _set(principled.inputs["Base Color"], near if near is not None else colour)
    return "exact" if exact else "approximate"


@contextlib.contextmanager
def stood_in(context, materials, evaluation_mode="RENDER", selected_only=False, enabled=True,
             folder=None):
    """Give each material the exporter would write empty a surface, then take it away again.
    Pictures worked out for it go into `folder` (the USD's own textures folder), so the stage
    carries them wherever it goes.

    Yields {material name: "exact" | "approximate"}."""
    import os
    import tempfile

    import bpy

    from . import capture

    done = {}
    if not enabled:
        yield done
        return
    made_nodes, made_images = [], []
    folder = folder or os.path.join(tempfile.gettempdir(), "bu_export_surfaces")
    try:
        risk = capture.surface_export_risk(context, materials, evaluation_mode, selected_only)
        for entry in risk["empty"]:
            material = bpy.data.materials.get(entry["material"])
            if material is None or material.node_tree is None or material.library is not None:
                continue
            try:
                done[material.name] = _stand_in(material, made_nodes, made_images, folder)
            except Exception as exc:  # noqa: BLE001 - a graph set up in a way not foreseen
                print("BU: no stand-in surface for {0}: {1}".format(material.name, exc))
        yield done
    finally:
        for node in reversed(made_nodes):
            try:
                node.id_data.nodes.remove(node)
            except Exception:  # noqa: BLE001
                pass
        for image in made_images:
            try:
                bpy.data.images.remove(image)
            except Exception:  # noqa: BLE001
                pass
