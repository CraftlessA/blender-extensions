# SPDX-License-Identifier: GPL-3.0-or-later
"""Framing for BU's real-time link. Standard library only.

**This file exists twice** — `blender/bu_bridge/link_wire.py` and
`unreal/bu_bridge/bu_link_wire.py` — because the two halves ship as separate packages and
neither can import from the other. `tests/test_link_wire.py` asserts the copies are identical;
edit one, copy it over the other.

A message is a small JSON header plus an optional binary blob:

    magic "BUL1" | uint32 header length | uint32 blob length | header (UTF-8 JSON) | blob

JSON for the header because it is tiny and debuggable; a raw blob for the payload because a
mesh is megabytes of floats, and JSON-encoding those costs more than extracting them did.
"""

import json
import struct

MAGIC = b"BUL1"
_PREFIX = struct.Struct("<4sII")
PREFIX_SIZE = _PREFIX.size

# Refuse anything larger rather than allocating for it. A corrupt or foreign stream otherwise
# reads four random bytes as a length and waits forever for gigabytes that never arrive.
MAX_HEADER = 1 << 20
MAX_BLOB = 1 << 30

DEFAULT_PORT = 47823


class WireError(Exception):
    pass


def pack(header, blob=b""):
    """One message as bytes, ready to send."""
    head = json.dumps(header, separators=(",", ":")).encode("utf-8")
    if len(head) > MAX_HEADER:
        raise WireError("header too large: {0} bytes".format(len(head)))
    if len(blob) > MAX_BLOB:
        raise WireError("blob too large: {0} bytes".format(len(blob)))
    return b"".join((_PREFIX.pack(MAGIC, len(head), len(blob)), head, bytes(blob)))


class Decoder(object):
    """Turns an arbitrary chunking of the byte stream back into whole messages."""

    def __init__(self):
        self._buffer = bytearray()

    def pending(self):
        return len(self._buffer)

    def feed(self, data):
        """Add received bytes. Returns the list of complete `(header, blob)` messages."""
        if data:
            self._buffer += data

        messages = []
        while True:
            if len(self._buffer) < PREFIX_SIZE:
                break
            magic, head_len, blob_len = _PREFIX.unpack_from(self._buffer, 0)
            if magic != MAGIC:
                raise WireError("not a BU link stream (bad magic {0!r})".format(bytes(magic)))
            if head_len > MAX_HEADER or blob_len > MAX_BLOB:
                raise WireError(
                    "implausible message size ({0} + {1} bytes)".format(head_len, blob_len))

            total = PREFIX_SIZE + head_len + blob_len
            if len(self._buffer) < total:
                break

            head = bytes(self._buffer[PREFIX_SIZE:PREFIX_SIZE + head_len])
            blob = bytes(self._buffer[PREFIX_SIZE + head_len:total])
            del self._buffer[:total]

            try:
                header = json.loads(head.decode("utf-8"))
            except ValueError as exc:
                raise WireError("unreadable header: {0}".format(exc))
            if not isinstance(header, dict):
                raise WireError("header is not an object")
            messages.append((header, blob))
        return messages
