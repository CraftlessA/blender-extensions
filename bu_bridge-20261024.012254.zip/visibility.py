# SPDX-License-Identifier: GPL-3.0-or-later
"""Make a written visibility flag stick, even when a rig is driving it.

Everything BU does to shape an export — include/exclude lists, dropping zero-vertex meshes,
freeing a marker-bound camera — works by writing `hide_render` and putting it back afterwards.
That mechanism has a hole in it: **`hide_render` is animatable.**

A character rig routinely drives it. Outfit swaps, mouth-shape sets and eye variants are all
built by driving the visibility of alternate meshes from a bone or a custom property. When BU
writes `hide_render = True` on such an object the write succeeds and reads back correctly — and
then the next depsgraph evaluation runs the driver and overwrites it. The export sees the
driver's value, not BU's.

Measured on a real five-character scene: an export filtered to one character arrived holding 17
meshes of the character asked for and **34 meshes of two other characters**, every one of them
carrying `driver:hide_render`. Nothing in the export reported a problem, because from BU's side
the flag had been set. Reading the flag back after the export showed `False` — the driver had
already put it back.

So a flag write is only reliable once the animation that owns it is muted. `frozen()` mutes the
visibility channels — drivers *and* keyframes — of the objects BU is about to write to, and
restores every mute state afterwards.

Only the objects BU actually writes to are muted, never the scene at large. Muting a driver
makes the object fall back to its stored flag, which for an untouched object may be the wrong
answer: the leaked meshes above were all stored `hide_render = False` with a driver that hides
them at some frames. Muting those without also writing the flag would export them.
"""

import contextlib

import bpy

# Both, not just the one the current evaluation mode reads: a scene can be exported in either
# mode, and a rig that drives one of these usually drives the other alongside it.
VISIBILITY_PATHS = ("hide_render", "hide_viewport")


def _action_curves(action):
    """Fcurves of an action, across both the legacy flat list and 5.x slotted layers."""
    seen = []
    for curve in getattr(action, "fcurves", ()) or ():
        seen.append(curve)
    # Blender 4.4+ moved keyframes into layers -> strips -> channelbags, and `action.fcurves`
    # is empty for a slotted action. Walk both so this works either way.
    for layer in getattr(action, "layers", ()) or ():
        for strip in getattr(layer, "strips", ()) or ():
            for bag in getattr(strip, "channelbags", ()) or ():
                for curve in getattr(bag, "fcurves", ()) or ():
                    seen.append(curve)
    return seen


def visibility_curves(obj):
    """Every curve — driver, action or NLA — that writes this object's visibility."""
    anim = getattr(obj, "animation_data", None)
    if anim is None:
        return []

    curves = []
    for curve in getattr(anim, "drivers", ()) or ():
        curves.append(curve)
    if anim.action is not None:
        curves.extend(_action_curves(anim.action))
    for track in getattr(anim, "nla_tracks", ()) or ():
        for strip in getattr(track, "strips", ()) or ():
            if strip.action is not None:
                curves.extend(_action_curves(strip.action))

    return [c for c in curves if getattr(c, "data_path", "") in VISIBILITY_PATHS]


def _action_curve_owners(action):
    """Every fcurve in an action alongside the collection that owns it.

    Same traversal as `_action_curves`, but keeps the owning collection so a curve found this way
    can be removed correctly afterward. A slotted (4.4+) action's real fcurves live inside a
    channelbag, not in `action.fcurves` — removing from the wrong collection is a silent no-op,
    not an error, so the owner has to travel with the curve rather than be re-derived later.
    """
    owners = []
    for curve in getattr(action, "fcurves", ()) or ():
        owners.append((action.fcurves, curve))
    for layer in getattr(action, "layers", ()) or ():
        for strip in getattr(layer, "strips", ()) or ():
            for bag in getattr(strip, "channelbags", ()) or ():
                for curve in getattr(bag, "fcurves", ()) or ():
                    owners.append((bag.fcurves, curve))
    return owners


def driven(objects):
    """The subset whose visibility is animated. Cheap enough to call for reporting."""
    return [o for o in objects if visibility_curves(o)]


def never_visible(objects, scene, start=None, end=None):
    """The subset the rig hides on *every* frame of the range. Order is preserved.

    `forced_visible` exists to keep a partly-hidden mesh's point stream continuous, and it is worth
    the cost: a mesh that renders when it should not still beats one that freezes out of place. But
    an object hidden for the entire range has no such trade to make. It cannot be seen in Blender
    at any frame, so the artist has no way to know it is there, and holding it visible puts it in
    Unreal permanently.

    Measured on the scene that prompted this: five objects were hidden for all 346 frames, and BU
    exported every one. Four were two 224-poly body skins per character sitting exactly on top of
    the visible body — doubled surfaces that read as inverted or broken normals, invisible in
    Blender and impossible to find there. The artist reported it as normals being wrong and as
    geometry they had deleted coming back.

    Visibility here is driven, not keyframed, so the curves cannot be evaluated directly — a driver
    F-curve maps its variable to an output, not the frame. Frames are sampled instead, with the
    frame loop outermost so the scene is stepped once rather than once per object, and the scan
    stops as soon as every object has been seen visible at least once. Anything not resolved by
    then genuinely needs the full range to prove a negative.
    """
    candidates = [o for o in objects if visibility_curves(o)]
    if not candidates:
        return []

    start = scene.frame_start if start is None else start
    end = scene.frame_end if end is None else end

    unseen = {o.name: o for o in candidates}
    original = scene.frame_current
    try:
        for frame in range(start, end + 1):
            if not unseen:
                break
            scene.frame_set(frame)
            for name, obj in list(unseen.items()):
                if not any(getattr(obj, path, False) for path in VISIBILITY_PATHS):
                    del unseen[name]
    finally:
        scene.frame_set(original)

    return [o for o in candidates if o.name in unseen]


@contextlib.contextmanager
def forced_visible(objects):
    """Mute visibility animation on `objects` AND hold them visible for the duration.

    A Geometry Cache is a raw stream of point positions, one sample per frame, with no concept of
    "this frame is absent." When a mesh's `hide_render` is genuinely driven — a mouth-shape rig
    hiding teeth while the mouth is closed, say — Blender's exporter has nowhere good to put the
    hidden frames, and the observed result is worse than a missing object: the mesh freezes at its
    last-baked position while the rig keeps moving, then snaps back when visibility returns. That
    reads as "the teeth don't stay in the head," not as "the teeth disappear."

    Forcing the object visible for the whole export keeps its point stream continuous and
    correctly following its rig on every frame, at the cost of losing the driven hide entirely —
    it renders throughout in Unreal. That trade is deliberate: a mesh that is always slightly
    wrong (visible when it should be hidden) reads far better than one that is sometimes in the
    wrong place entirely.

    Only objects whose visibility is actually driven are touched — `visibility_curves(obj)` is
    empty for anything hidden by a plain, unanimated flag, so a deliberately, permanently hidden
    mesh is left alone. Restores every curve's mute state and every flag's original value exactly.
    """
    muted = []
    restored_flags = []
    frozen_names = []
    try:
        for obj in objects:
            curves = visibility_curves(obj)
            if not curves:
                continue
            frozen_names.append(obj.name)
            for curve in curves:
                muted.append((curve, curve.mute))
                curve.mute = True
            for path in VISIBILITY_PATHS:
                current = getattr(obj, path, False)
                restored_flags.append((obj, path, current))
                if current:
                    setattr(obj, path, False)
        yield frozen_names
    finally:
        for obj, path, value in restored_flags:
            try:
                setattr(obj, path, value)
            except (ReferenceError, AttributeError):
                pass
        for curve, was_muted in muted:
            try:
                curve.mute = was_muted
            except Exception:  # noqa: BLE001 - restore must never mask the export result
                pass


@contextlib.contextmanager
def shrunk_when_hidden(objects, scene, start=None, end=None, epsilon=0.001):
    """Shrink driven-visibility objects to near-zero scale on the frames the rig hides them.

    `forced_visible` solves the Geometry Cache's real constraint — no concept of an absent frame —
    by holding the render/viewport flags off for the whole export. That is still necessary; this
    adds a second layer on top rather than replacing it. Its cost was that the mesh then rendered
    at *full size* on every frame, including the ones the rig means to hide. Measured on the scene
    that prompted this: two 224-poly body skins per character were held fully visible through
    frames the rig hides them, sitting exactly on top of the real body and reading as broken
    normals in Unreal, invisible and unfindable in Blender.

    At the exact frames the rig's own driven state would hide the object, `delta_scale` is keyed
    down to `epsilon` instead of leaving the mesh at full size. The point stream stays continuous
    — nothing about `forced_visible`'s fix changes — but the mesh is now optically absent rather
    than fully rendered, which is what a driven hide actually means.

    A keyframe is written at **every** frame in the range, not just at the frames where the state
    changes. The first version only keyframed the transitions, and it measurably broke: on a real
    scene, Blender's exporter wrote only 19 scale samples across a 346-frame range (bracketing each
    transition with a matching pair one frame apart, its own trick for faking a step in a format
    that otherwise interpolates linearly). The Geometry Cache's own points get a dense sample every
    single frame; a sparse scale track left long gaps for a reader to interpolate across or land in
    ambiguously near a boundary. A keyframe on every frame removes that gap entirely — the exported
    scale is a literal, unambiguous mirror of what Blender itself evaluates at that frame, matching
    the density the mesh data already has.

    `delta_scale` rather than `scale`: it is the layer Blender itself reserves for a tool to apply
    an extra scale on top of whatever the artist authored, so it cannot collide with an existing
    scale animation. An object whose `delta_scale` is *already* keyframed is left alone entirely —
    baking over it could not be restored exactly — and its name comes back in `"skipped"` so the
    caller can fall back to plain `forced_visible` for it and say so.

    Interpolation is CONSTANT at every inserted keyframe. With a dense keyframe on every frame this
    barely matters for the exported result — there is no gap left to interpolate across — but it
    keeps Blender's own evaluation exact too, rather than relying on adjacent identical values to
    make interpolation mode irrelevant.

    Yields `{"shrunk": [...], "skipped": [...]}` — "shrunk" only lists objects that were actually
    hidden on at least one frame in the range; an object with a driver that never toggles here
    still gets (harmless, later removed) dense keyframes but is not reported as shrunk.
    """
    candidates = [o for o in objects if visibility_curves(o)]
    if not candidates:
        yield {"shrunk": [], "skipped": []}
        return

    start = scene.frame_start if start is None else start
    end = scene.frame_end if end is None else end

    skipped = []
    targets = []
    for obj in candidates:
        anim = obj.animation_data
        if anim is not None and anim.action is not None and any(
            fc.data_path == "delta_scale" for _, fc in _action_curve_owners(anim.action)
        ):
            skipped.append(obj.name)
        else:
            targets.append(obj)

    created = []   # (collection, fcurve) pairs we added, removed on exit
    restore = []   # (obj, original delta_scale) pairs, applied on exit
    ever_hidden = {obj.name: False for obj in targets}

    try:
        if targets:
            originals = {}
            existing_before = {}
            for obj in targets:
                originals[obj.name] = tuple(obj.delta_scale)
                restore.append((obj, originals[obj.name]))
                existing_before[obj.name] = set()
                if obj.animation_data is not None and obj.animation_data.action is not None:
                    existing_before[obj.name] = {
                        id(fc) for _, fc in _action_curve_owners(obj.animation_data.action)
                    }

            original_frame = scene.frame_current
            try:
                for frame in range(start, end + 1):
                    scene.frame_set(frame)
                    for obj in targets:
                        hidden = any(getattr(obj, path, False) for path in VISIBILITY_PATHS)
                        if hidden:
                            ever_hidden[obj.name] = True
                        obj.delta_scale = (
                            (epsilon, epsilon, epsilon) if hidden else originals[obj.name]
                        )
                        obj.keyframe_insert(data_path="delta_scale", frame=frame)
            finally:
                scene.frame_set(original_frame)

            for obj in targets:
                action = obj.animation_data.action
                new_owners = [
                    (coll, fc) for coll, fc in _action_curve_owners(action)
                    if fc.data_path == "delta_scale" and id(fc) not in existing_before[obj.name]
                ]
                for coll, fc in new_owners:
                    created.append((coll, fc))
                    for kp in fc.keyframe_points:
                        kp.interpolation = 'CONSTANT'

        shrunk = [obj.name for obj in targets if ever_hidden[obj.name]]
        yield {"shrunk": shrunk, "skipped": skipped}
    finally:
        for coll, fc in created:
            try:
                coll.remove(fc)
            except Exception:  # noqa: BLE001 - restore must never mask the export result
                pass
        for obj, original in restore:
            try:
                obj.delta_scale = original
            except (ReferenceError, AttributeError):
                pass


@contextlib.contextmanager
def frozen(objects):
    """Mute visibility animation on `objects`, then restore every mute flag exactly.

    Yields the names of the objects that actually had something to mute, so callers can report
    how much of the scene was fighting them.
    """
    muted = []
    frozen_names = []
    try:
        for obj in objects:
            curves = visibility_curves(obj)
            if not curves:
                continue
            frozen_names.append(obj.name)
            for curve in curves:
                muted.append((curve, curve.mute))
                curve.mute = True
        yield frozen_names
    finally:
        for curve, was_muted in muted:
            try:
                curve.mute = was_muted
            except Exception:  # noqa: BLE001 - restore must never mask the export result
                pass
