# SPDX-License-Identifier: GPL-3.0-or-later
"""Import from Unreal: the actors selected there (or a whole level), into this scene, once.

Blender asks over the link (`{"type": "export", ...}`) and names the file; Unreal writes the
actors to it as glTF — meshes, UVs, and every material baked down to PBR textures — and answers
`export_done`; Blender imports it with its own glTF importer. Objects land where Unreal has them,
in the link's convention, so a live object and an imported one line up.

Imported objects go in a **From Unreal** collection and carry `bu_from_unreal`, which the link
reads as "already in Unreal": it does not send them back, where they would sit on top of the
originals. Each also carries `bu_unreal_actor`, the path of the actor it came from (matched by
label and position, from the list Unreal sends with the export). Instead of being sent, an
imported object **drives** that actor: moving it in Blender moves the actor in Unreal
(`bu_link_drive`). If the actor is deleted in Unreal, Unreal says so (`gone`) and the object
becomes an ordinary live object, sent like any other. *Let the Link Send These* does the same
by hand.

The files are kept — next to the .blend in `Unreal Imports/` when it is saved, otherwise in the
temp folder — because the imported images are read from them.
"""

import os
import re
import time

import bpy

FLAG = "bu_from_unreal"
ACTOR = "bu_unreal_actor"
COLLECTION = "From Unreal"
TEXTURE_SIZES = (("512", "512", "Fastest; fine for props seen from a distance"),
                 ("1024", "1024", "Unreal's materials baked at 1024 x 1024"),
                 ("2048", "2048", "Sharper, and slower to export"),
                 ("4096", "4096", "Close-ups; slow, and large files"))


def is_imported(obj):
    try:
        return bool(obj.get(FLAG))
    except Exception:  # noqa: BLE001 - a removed object
        return False


def actor_of(obj):
    """The path of the Unreal actor an imported object stands for, or ""."""
    try:
        return str(obj.get(ACTOR) or "") if obj.get(FLAG) else ""
    except Exception:  # noqa: BLE001 - a removed object
        return ""


def is_driver(obj):
    """Whether moving this object moves its actor: the topmost object standing for it."""
    path = actor_of(obj)
    return bool(path) and (obj.parent is None or actor_of(obj.parent) != path)


def release(obj):
    """Make an imported object an ordinary one, which the link sends."""
    for key in (FLAG, ACTOR):
        if key in obj:
            del obj[key]


def _base_name(name):
    return re.sub(r"\.\d{3,}$", "", name)


def assign(objects, actors):
    """Tie imported objects to the actors they came from. Returns {object name: actor path}.

    `objects` have `.name`, `.parent` and a world location (`location_of`); `actors` are the
    export reply's {label, path, location (Unreal cm)}. A label can repeat, so among objects
    named after it the nearest wins. Objects below a matched one (a multi-component actor's
    parts) stand for the same actor.
    """
    taken, found = set(), {}
    for actor in actors or ():
        x, y, z = (list(actor.get("location") or (0.0, 0.0, 0.0)) + [0.0, 0.0, 0.0])[:3]
        target = (x / 100.0, -y / 100.0, z / 100.0)
        candidates = [obj for obj in objects if obj.name not in taken
                      and _base_name(obj.name) == str(actor.get("label") or "")]
        if not candidates:
            continue
        best = min(candidates, key=lambda obj: sum(
            (a - b) ** 2 for a, b in zip(location_of(obj), target)))
        taken.add(best.name)
        found[best.name] = str(actor.get("path") or "")
    by_name = {obj.name: obj for obj in objects}
    for obj in objects:
        if obj.name in found:
            continue
        parent = obj.parent
        while parent is not None and parent.name in by_name and parent.name not in found:
            parent = parent.parent
        if parent is not None and parent.name in found:
            found[obj.name] = found[parent.name]
    return found


def location_of(obj):
    matrix = getattr(obj, "matrix_world", None)
    if matrix is not None:
        return tuple(matrix.translation)
    return tuple(getattr(obj, "location", (0.0, 0.0, 0.0)))


def export_path(blend_path, now=None, temp=None):
    """Where Unreal should write the next export. Pure."""
    stamp = time.strftime("%Y%m%d-%H%M%S", time.localtime(now))
    if blend_path:
        root = os.path.join(os.path.dirname(blend_path), "Unreal Imports")
    else:
        import tempfile

        root = os.path.join(temp or tempfile.gettempdir(), "bu_from_unreal")
    return os.path.join(root, stamp, "unreal.gltf")


def request(client, scope, source_model=False, texture_size=1024):
    """Ask Unreal for an export. Returns the path it will write."""
    path = export_path(bpy.data.filepath)
    client.send("export", {"type": "export", "scope": scope, "path": path,
                           "source_model": bool(source_model),
                           "texture_size": int(texture_size)})
    return path


def _collection(scene):
    found = bpy.data.collections.get(COLLECTION)
    if found is None:
        found = bpy.data.collections.new(COLLECTION)
    if found.name not in scene.collection.children:
        scene.collection.children.link(found)
    return found


def import_file(path, scene=None, actors=None):
    """Import an export Unreal wrote. Returns the new objects."""
    scene = scene or bpy.context.scene
    before = set(bpy.data.objects)
    window = bpy.context.window_manager.windows[0] if bpy.context.window_manager.windows else None
    if window is not None:
        with bpy.context.temp_override(window=window):
            bpy.ops.import_scene.gltf(filepath=path)
    else:
        bpy.ops.import_scene.gltf(filepath=path)
    created = [obj for obj in bpy.data.objects if obj not in before]
    target = _collection(scene)
    bpy.context.view_layer.update()  # world matrices, for matching objects to actors
    paths = assign(created, actors)
    for obj in created:
        obj[FLAG] = True
        if paths.get(obj.name):
            obj[ACTOR] = paths[obj.name]
        for owner in list(obj.users_collection):
            owner.objects.unlink(obj)
        target.objects.link(obj)
    return created


class BU_OT_link_import(bpy.types.Operator):
    bl_idname = "bu.link_import_from_unreal"
    bl_label = "Import from Unreal"
    bl_description = ("Bring actors from Unreal into this scene, with their materials baked to "
                      "textures. Moving one in Blender moves the actor in Unreal")

    scope: bpy.props.EnumProperty(
        items=(("selected", "Selected in Unreal", "The actors selected in Unreal's level"),
               ("level", "Whole Level", "Every actor in Unreal's level")),
        default="selected",
    )
    source_model: bpy.props.BoolProperty(
        name="Full-Detail Nanite",
        description=("Export Nanite meshes at their full source detail rather than their "
                     "fallback mesh. Can be millions of triangles"),
        default=False,
    )
    texture_size: bpy.props.EnumProperty(
        name="Texture Size",
        description=("Size Unreal bakes each material's textures at. Larger is sharper and "
                     "makes Unreal pause longer while it exports"),
        items=TEXTURE_SIZES,
        default="1024",
    )

    @classmethod
    def poll(cls, context):
        from . import link

        return link.is_running()

    def execute(self, context):
        from . import link

        link.request_export(self.scope, self.source_model, int(self.texture_size))
        self.report({"INFO"}, "Asked Unreal to export; it imports when Unreal is done")
        return {"FINISHED"}


class BU_OT_link_send_imported(bpy.types.Operator):
    bl_idname = "bu.link_send_imported"
    bl_label = "Let the Link Send These"
    bl_description = ("Selected objects imported from Unreal: send them over the link like any "
                      "other object, instead of moving their Unreal actors (the actors stay in "
                      "Unreal's level)")

    @classmethod
    def poll(cls, context):
        return any(is_imported(obj) for obj in context.selected_objects)

    def execute(self, context):
        from . import link

        count = 0
        for obj in context.selected_objects:
            if is_imported(obj):
                release(obj)
                count += 1
        link.rescan_scene()
        self.report({"INFO"}, "{0} object(s) will be sent live".format(count))
        return {"FINISHED"}


_classes = (BU_OT_link_import, BU_OT_link_send_imported)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
