# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender's hair, for Unreal's grooms (`bu_link_hair` on the Unreal side).

A particle system of type Hair, drawn as paths, goes as its own object: `hair_name(emitter,
system)`, at its emitter's transform, so bone-parented fur moves with its part as the part's
transform does, without being read again. What Blender draws is read through the evaluated
system (`ParticleSystem.co_hair`): its children when it has them, its parents otherwise, each
with the viewport's display steps; then put in the emitter's space (Unreal's axes and
centimetres, as `link_mesh` puts a mesh) and written to shared memory for `ApplyGroom`.

The width along a strand is Cycles' (`shaperadius` in its curves.cpp): Diameter Root to Tip,
times Radius Scaling, bent by Strand Shape. The colour is the material's, worked out at each
strand's root UV: a Principled Hair BSDF's Color (Direct Coloring), its melanin or absorption
colour otherwise (`link_nodes.hair_colour`), or a surface shader's Base Color. A chain from one
image is worked out on its pixels (`link_flatten.work_out`) and sampled at the roots.

While F12 renders, each system is read with its Render Steps and render child amount
(`link.render_particles` puts them in place of the viewport's, and back after).

Not yet: a hair Curves object (Blender's new hair), Simplify's child amount, and Unreal's own
hair simulation.
"""

import hashlib

import numpy as np

try:
    from . import link_flatten, link_mesh, link_nodes
except ImportError:  # loaded by path in the tests
    import link_flatten
    import link_mesh
    import link_nodes

SEPARATOR = "|hair|"
# Strands sampled to tell whether a system changed (`signature`): reading all of a big one took
# a second, and a bone-parented emitter is flagged as changed every frame without changing.
SAMPLED = 24
# A strand is drawn with at most this many points (Unreal's builder takes 1024); 2^10 + 1.
MAX_POINTS = 1025
DEFAULT_COLOUR = (0.8, 0.8, 0.8)
DEFAULT_ROUGHNESS = 0.5


def hair_name(emitter, system):
    """The link's name for one particle system's hair. Pure."""
    return "{0}{1}{2}".format(emitter, SEPARATOR, system)


def is_hair_name(name):
    return SEPARATOR in str(name)


def shown_systems(obj, final=False):
    """(modifier name, system name) of each hair system Blender draws as strands on `obj`."""
    found = []
    for modifier in getattr(obj, "modifiers", ()):
        if modifier.type != "PARTICLE_SYSTEM":
            continue
        if not (modifier.show_render if final else modifier.show_viewport):
            continue
        settings = modifier.particle_system.settings
        if settings.type == "HAIR" and settings.render_type == "PATH":
            found.append((modifier.name, modifier.particle_system.name))
    return found


def shape_widths(fractions, settings):
    """Each point's full width in metres, from where it lies along its strand (0 root, 1 tip):
    Cycles' `shaperadius`, times Radius Scaling (Cycles halves it for a radius). Pure."""
    t = np.clip(np.asarray(fractions, dtype=np.float32), 0.0, 1.0)
    shape = float(settings.shape)
    radius = 1.0 - t
    if shape < 0.0:
        radius = np.power(radius, 1.0 + shape)
    elif shape > 0.0:
        radius = np.power(radius, 1.0 / (1.0 - shape))
    root, tip = float(settings.root_radius), float(settings.tip_radius)
    widths = (radius * (root - tip) + tip) * float(settings.radius_scale)
    if getattr(settings, "use_close_tip", False):
        widths[..., -1] = 0.0
    return widths.astype(np.float32)


def length_fractions(points):
    """(strands, points) how far along its strand each point lies, by length. Pure."""
    steps = np.linalg.norm(np.diff(points, axis=1), axis=2)
    along = np.concatenate([np.zeros(steps.shape[:1] + (1,), dtype=np.float32),
                            np.cumsum(steps, axis=1)], axis=1)
    total = along[:, -1:]
    with np.errstate(all="ignore"):
        return np.where(total > 0.0, along / np.where(total > 0.0, total, 1.0),
                        np.linspace(0.0, 1.0, points.shape[1])[None, :]).astype(np.float32)


def _strand_numbers(system):
    """The `co_hair` numbers of the strands Blender draws: its children (numbered after the
    parents) when it has them, unless it also draws the parents."""
    parents = len(system.particles)
    children = len(system.child_particles)
    if children and system.settings.child_type != "NONE":
        numbers = list(range(parents, parents + children))
        if system.settings.use_parent_particles:
            numbers = list(range(parents)) + numbers
        return numbers
    return list(range(parents))


def points_per_strand(system, final=False):
    settings = system.settings
    steps = settings.render_step if final else settings.display_step
    return min(MAX_POINTS, 2 ** int(steps) + 1)


def _read(evaluated, system, numbers, count):
    """(len(numbers), count, 3) world positions, read point by point (`co_hair`)."""
    co = system.co_hair
    out = np.empty((len(numbers), count, 3), dtype=np.float32)
    for row, number in enumerate(numbers):
        strand = out[row]
        for step in range(count):
            strand[step] = co(evaluated, particle_no=number, step=step)
    return out


def _modifier(evaluated, modifier_name):
    found = evaluated.modifiers.get(modifier_name)
    return found if found is not None and found.type == "PARTICLE_SYSTEM" else None


def signature(evaluated, modifier_name, final=False, material_key=""):
    """A cheap key for what a system would send: its settings, its counts, a few strands' points
    in the emitter's space, and its material's colour. None if it draws nothing."""
    modifier = _modifier(evaluated, modifier_name)
    if modifier is None:
        return None
    system = modifier.particle_system
    numbers = _strand_numbers(system)
    if not numbers:
        return None
    count = points_per_strand(system, final)
    picks = [numbers[int(i)] for i in np.linspace(0, len(numbers) - 1, min(SAMPLED, len(numbers)))]
    points = _read(evaluated, system, picks, count)
    inverse = np.asarray(evaluated.matrix_world.inverted(), dtype=np.float32)
    local = points @ inverse[:3, :3].T + inverse[:3, 3]
    settings = system.settings
    parts = [repr((len(numbers), count, round(float(settings.root_radius), 6),
                   round(float(settings.tip_radius), 6), round(float(settings.radius_scale), 6),
                   round(float(settings.shape), 6), bool(settings.use_close_tip),
                   int(settings.material))), material_key,
             np.round(local, 5).tobytes()]
    digest = hashlib.sha1()
    for part in parts:
        digest.update(part if isinstance(part, bytes) else str(part).encode("utf-8"))
    return digest.hexdigest()


def material_of(evaluated, system):
    """The material a system's strands wear: its Material slot on the emitter, clamped to the
    slots there as Cycles does. None if it has none."""
    slots = evaluated.material_slots
    if not len(slots):
        return None
    index = min(max(int(system.settings.material) - 1, 0), len(slots) - 1)
    return slots[index].material


def _shader(material):
    """The shader node a material's surface shows, or None."""
    if material is None or not material.use_nodes or material.node_tree is None:
        return None
    for node in material.node_tree.nodes:
        if node.type == "OUTPUT_MATERIAL" and node.is_active_output:
            socket = node.inputs.get("Surface")
            if socket is not None and socket.is_linked:
                found = socket.links[0].from_node
                return found
    return None


def colour_source(material):
    """(socket or None, constant colour, roughness) for a hair material: what to sample at the
    roots, or the one colour every strand has."""
    node = _shader(material)
    if node is None:
        colour = tuple(getattr(material, "diffuse_color", DEFAULT_COLOUR))[:3] if material else DEFAULT_COLOUR
        return None, colour, DEFAULT_ROUGHNESS
    roughness = DEFAULT_ROUGHNESS
    found = node.inputs.get("Roughness")
    if found is not None and not found.is_linked:
        roughness = float(found.default_value)
    if node.type == "BSDF_HAIR_PRINCIPLED" and getattr(node, "parametrization", "COLOR") != "COLOR":
        return None, tuple(link_nodes.hair_colour(node))[:3], roughness
    socket = node.inputs.get("Color") or node.inputs.get("Base Color")
    if socket is None:
        return None, DEFAULT_COLOUR, roughness
    if not socket.is_linked:
        return None, tuple(socket.default_value)[:3], roughness
    worked = link_flatten.constant(socket)
    if worked is not None:
        return None, tuple(worked)[:3], roughness
    return socket, DEFAULT_COLOUR, roughness


# colour_key -> the worked-out colour image: Springtrap's 42 systems share one 4K map, worked
# out once rather than 42 times (a third of a second each).
_PIXELS = {}
_PIXELS_KEPT = 4


def _worked_pixels(material, socket):
    key = colour_key(material)
    if key in _PIXELS:
        return _PIXELS[key]
    worked = link_flatten.work_out(socket.node, socket.name)
    pixels = worked[0] if worked is not None else None
    while len(_PIXELS) >= _PIXELS_KEPT:
        _PIXELS.pop(next(iter(_PIXELS)))
    _PIXELS[key] = pixels
    return pixels


def sample_colours(pixels, uvs):
    """(strands, 3) colours of (h, w, 3) pixels (bottom row first) at Blender UVs, repeating
    as Blender's image textures do by default. Pure."""
    height, width = pixels.shape[:2]
    u = np.mod(np.asarray(uvs[:, 0], dtype=np.float64), 1.0)
    v = np.mod(np.asarray(uvs[:, 1], dtype=np.float64), 1.0)
    x = np.minimum((u * width).astype(np.int64), width - 1)
    y = np.minimum((v * height).astype(np.int64), height - 1)
    return np.asarray(pixels[y, x, :3], dtype=np.float32)


def root_uvs(evaluated, system, modifier, numbers):
    """(strands, 2) each strand's root on the emitter's render UV map, Blender's way up."""
    out = np.zeros((len(numbers), 2), dtype=np.float32)
    if not len(getattr(evaluated.data, "uv_layers", ())) or not len(system.particles):
        return out
    first = system.particles[0]
    uv_on = system.uv_on_emitter
    for row, number in enumerate(numbers):
        out[row] = uv_on(modifier, particle=first, particle_no=number, uv_no=0)
    return out


def extract(evaluated, modifier_name, final=False):
    """One system's strands as arrays for `ApplyGroom`, in the emitter's space, Unreal's axes
    and centimetres: (strands, points, positions, widths, colours, roughness, uvs), or None."""
    modifier = _modifier(evaluated, modifier_name)
    if modifier is None:
        return None
    system = modifier.particle_system
    numbers = _strand_numbers(system)
    if not numbers:
        return None
    count = points_per_strand(system, final)
    world = _read(evaluated, system, numbers, count)
    # Children past the display amount, or unborn, come back at the origin: left out.
    drawn = np.abs(world).reshape(len(numbers), -1).max(axis=1) > 0.0
    if not drawn.all():
        world = world[drawn]
        numbers = [n for n, keep in zip(numbers, drawn) if keep]
    if not len(numbers):
        return None
    matrix = evaluated.matrix_world
    inverse = np.asarray(matrix.inverted(), dtype=np.float32)
    local = world @ inverse[:3, :3].T + inverse[:3, 3]
    # Neither Blender nor Unreal scales a strand's width with its object ("the hair width is
    # not scaled by the transform scale", GroomComponent.cpp): it goes as it is. Divided by the
    # emitter's scale (0.187 on Springtrap's parts), the fur came out five times too thick.
    widths = shape_widths(length_fractions(world), system.settings) * np.float32(link_mesh.SCALE)
    positions = link_mesh.points_to_unreal(local.reshape(-1, 3))
    uvs = root_uvs(evaluated, system, modifier, numbers)
    material = material_of(evaluated, system)
    socket, colour, roughness = colour_source(material)
    colours = None
    if socket is not None:
        pixels = _worked_pixels(material, socket)
        if pixels is not None:
            colours = sample_colours(pixels, uvs)
    if colours is None:
        colours = np.tile(np.asarray(colour, dtype=np.float32)[:3], (len(numbers), 1))
    rough = np.full(len(numbers), float(roughness), dtype=np.float32)
    unreal_uvs = link_mesh.uvs_to_unreal(uvs)
    return (len(numbers), count, positions, widths.reshape(-1), colours, rough, unreal_uvs)


def floats_needed(strands, points):
    return strands * points * 4 + strands * 6


def write(arena, arrays):
    """Write `extract`'s arrays into the arena in `ApplyGroom`'s order. The offset, or None
    when there is no room yet."""
    strands, points, positions, widths, colours, rough, uvs = arrays
    total = floats_needed(strands, points)
    offset = arena.alloc(total * 4)
    if offset is None:
        return None
    out = arena.floats(offset, total)
    at = 0
    for block in (positions, widths, colours, rough, uvs):
        flat = np.asarray(block, dtype=np.float32).reshape(-1)
        out[at:at + flat.size] = flat
        at += flat.size
    return offset


def colour_key(material):
    """What a material's hair colour depends on, for `signature`."""
    if material is None:
        return ""
    node = _shader(material)
    sockets = [node.inputs.get(n) for n in ("Color", "Base Color", "Roughness", "Melanin",
                                             "Melanin Redness", "Tint")] if node else []
    return link_flatten.signature([s for s in sockets if s is not None]) + str(
        getattr(node, "parametrization", ""))


def matrix_scale_ok(matrix):
    """False for an emitter scaled flat, which has no space to put strands in. Pure."""
    try:
        return abs(float(np.linalg.det(np.asarray(matrix, dtype=np.float64)[:3, :3]))) > 1e-12
    except (TypeError, ValueError):
        return False


def finite(arrays):
    return all(np.isfinite(np.asarray(block, dtype=np.float32)).all() for block in arrays[2:])

