# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender's panoramic cameras (Cycles' fisheyes, equirectangular...), rendered as Cycles does.

A scene capture only draws straight lines straight: a perspective picture. So the camera's
surroundings are rendered as the faces of a cube, each a 90-degree perspective picture from the
camera's own place, square to its own axes (`FACES`), and a material then makes the picture
Blender asked for out of them (`warp_hlsl`): for each pixel, the direction Cycles' camera sends
its ray (`kernel/camera/projection.h`, as `direction` here), and that direction's colour in the
cube. The result is an ordinary picture of the view's size, sent as every other is.

Only the faces some pixel looks into are rendered (`plan`): a 180-degree fisheye never sees
behind it. A face is as big as the finest detail the picture asks of it.

The view's `pano` field (Blender's `link_view.pano_lens`): {"type", "fov", "lens", "sensor",
"k", "range", "raster"}. Directions are in the camera's own axes: x right, y up, z forward.
"""

import math

VERSION = 2
PACKAGE = "/Game/BU/Materials"
TYPES = ("EQUIRECTANGULAR", "EQUIANGULAR_CUBEMAP_FACE", "MIRRORBALL", "FISHEYE_EQUIDISTANT",
         "FISHEYE_EQUISOLID", "FISHEYE_LENS_POLYNOMIAL", "CENTRAL_CYLINDRICAL")
# Each face's (forward, up, right) in the camera's axes: front, back, right, left, up, down.
FACES = (((0, 0, 1), (0, 1, 0), (1, 0, 0)),
         ((0, 0, -1), (0, 1, 0), (-1, 0, 0)),
         ((1, 0, 0), (0, 1, 0), (0, 0, -1)),
         ((-1, 0, 0), (0, 1, 0), (0, 0, 1)),
         ((0, 1, 0), (0, 0, -1), (1, 0, 0)),
         ((0, -1, 0), (0, 0, 1), (1, 0, 0)))
FACE_NAMES = ("front", "back", "right", "left", "up", "down")
# A face is rendered a little wider than 90 degrees, so a pixel at its edge still has its
# neighbours to filter with: MARGIN pixels each side.
MARGIN = 2
MIN_FACE, MAX_FACE = 64, 4096
# Points across the picture where `plan` looks for what it needs.
PLAN_STEPS = 48


def _number(value, fallback=0.0):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return fallback
    return value if value == value else fallback


def _numbers(value, count, fallback):
    try:
        found = [float(v) for v in value][:count]
    except (TypeError, ValueError):
        return list(fallback)
    return found if len(found) == count else list(fallback)


def kernel(lens):
    """A `pano` field as the warp reads it: (type index, P0, P1, P2, P3), four numbers each.
    P0: the range, or k1-k4; P1: k0; P2: sensor width, height (mm), fov (radians), lens (mm);
    P3: `raster`. None for no panorama. Pure."""
    if not isinstance(lens, dict) or lens.get("type") not in TYPES:
        return None
    kind = TYPES.index(lens["type"])
    k = _numbers(lens.get("k"), 5, (0.0,) * 5)
    sensor = _numbers(lens.get("sensor"), 2, (36.0, 24.0))
    fov = _number(lens.get("fov"), math.pi)
    if kind == TYPES.index("FISHEYE_LENS_POLYNOMIAL"):
        p0 = k[1:]
    else:
        p0 = _numbers(lens.get("range"), 4, (-2.0 * math.pi, math.pi, -math.pi, math.pi)
                      if kind == 0 else (math.pi, -math.pi, -1.0, 1.0))
    p1 = [k[0], 0.0, 0.0, 0.0]
    p2 = [sensor[0], sensor[1], fov, _number(lens.get("lens"), 10.5)]
    p3 = _numbers(lens.get("raster"), 4, (1.0, 0.0, 1.0, 0.0))
    return kind, p0, p1, p2, p3


def _fisheye(theta, x, y, r):
    phi = math.acos(max(-1.0, min(1.0, x / r))) if r != 0.0 else math.acos(0.0)
    if y < 0.0:
        phi = -phi
    return (math.cos(theta), -math.cos(phi) * math.sin(theta), math.sin(phi) * math.sin(theta))


def direction(params, u, v):
    """Where Cycles' panorama camera looks at its point (u, v) (`panorama_to_direction`), in the
    camera's axes (x right, y up, z forward), not normalised; None outside the lens. `params`:
    `kernel`'s. Pure: the warp's HLSL is the same, line for line."""
    kind, p0, p1, p2, _p3 = params
    d = None
    if kind == 0:
        phi = p0[0] * u + p0[1]
        theta = p0[2] * v + p0[3]
        d = (math.sin(theta) * math.cos(phi), math.sin(theta) * math.sin(phi), math.cos(theta))
    elif kind == 1:
        a = math.tan((0.5 - u) * math.pi / 2.0)
        b = math.tan((v - 0.5) * math.pi / 2.0)
        d = (1.0, a, b)
    elif kind == 2:
        x, z = 2.0 * u - 1.0, 2.0 * v - 1.0
        if x * x + z * z <= 1.0:
            m = (x, -math.sqrt(max(1.0 - x * x - z * z, 0.0)), z)
            i = (0.0, -1.0, 0.0)
            dot = sum(a * b for a, b in zip(m, i))
            d = tuple(2.0 * dot * a - b for a, b in zip(m, i))
    elif kind == 6:
        theta = p0[0] + (p0[1] - p0[0]) * u
        d = (math.cos(theta), math.sin(theta), p0[2] + (p0[3] - p0[2]) * v)
    else:
        if kind == 3:
            x, y = (u - 0.5) * 2.0, (v - 0.5) * 2.0
            r = math.hypot(x, y)
            if r <= 1.0:
                d = _fisheye(r * p2[2] * 0.5, x, y, r)
        elif kind == 5:
            x, y = (u - 0.5) * p2[0], (v - 0.5) * p2[1]
            r = math.hypot(x, y)
            theta = -(p1[0] + p0[0] * r + p0[1] * r ** 2 + p0[2] * r ** 3 + p0[3] * r ** 4)
            if abs(theta) <= 0.5 * p2[2]:
                d = _fisheye(theta, x, y, r)
        else:
            x, y = (u - 0.5) * p2[0], (v - 0.5) * p2[1]
            r = math.hypot(x, y)
            if r <= 2.0 * p2[3] * math.sin(p2[2] * 0.25):
                d = _fisheye(2.0 * math.asin(min(1.0, r / (2.0 * p2[3]))), x, y, r)
    if d is None or not any(d):
        return None
    # Cycles' panorama axes to the camera's: x forward, y left, z up (`blender_camera_matrix`);
    # the mirror ball's looks along -y with z up.
    if kind == 2:
        return (d[0], d[2], -d[1])
    return (-d[1], d[2], d[0])


def picture_direction(params, s, t):
    """`direction` at the picture's point (s, t), 0-1 from its left and its top. Pure."""
    p3 = params[4]
    return direction(params, p3[0] * s + p3[1], p3[2] * (1.0 - t) + p3[3])


def face_of(d):
    """(face index, x, y): the cube face a camera-axes direction looks into, and where on it,
    -1 to 1 across its 90 degrees (x to its right, y up). Pure."""
    a = [abs(c) for c in d]
    if a[2] >= a[0] and a[2] >= a[1]:
        index = 0 if d[2] > 0.0 else 1
    elif a[0] >= a[1]:
        index = 2 if d[0] > 0.0 else 3
    else:
        index = 4 if d[1] > 0.0 else 5
    forward, up, right = FACES[index]
    depth = sum(p * q for p, q in zip(d, forward))
    return (index, sum(p * q for p, q in zip(d, right)) / depth,
            sum(p * q for p, q in zip(d, up)) / depth)


def _angle(a, b):
    la = math.sqrt(sum(c * c for c in a))
    lb = math.sqrt(sum(c * c for c in b))
    cos = sum(p * q for p, q in zip(a, b)) / max(la * lb, 1e-30)
    return math.acos(max(-1.0, min(1.0, cos)))


def plan(lens, size, max_face=MAX_FACE):
    """What to render for a panorama picture of `size` (w, h) pixels: {"faces": [indices],
    "size": pixels a face, "tan": tan of half a face's view (a little over 1: `MARGIN`)}, or
    None for no panorama, or one with nothing in view. Pure.

    Each face as big as the finest angle between two neighbouring pixels anywhere in the picture
    asks of it: a face's own pixels shrink towards its edges (cos² of the angle off its middle).
    """
    params = kernel(lens)
    if params is None:
        return None
    width, height = max(2, int(size[0])), max(2, int(size[1]))
    steps_x = PLAN_STEPS
    steps_y = max(8, int(round(PLAN_STEPS * height / float(width))))
    faces = set()
    need = 0.0
    for j in range(steps_y + 1):
        for i in range(steps_x + 1):
            # Pixel centres, from the corners' to the corners'.
            s = (0.5 + i * (width - 1) / float(steps_x)) / width
            t = (0.5 + j * (height - 1) / float(steps_y)) / height
            d = picture_direction(params, s, t)
            if d is None:
                continue
            index, x, y = face_of(d)
            faces.add(index)
            nearest = None
            for ds, dt in ((1.0 / width, 0.0), (0.0, 1.0 / height)):
                for sign in (1.0, -1.0):
                    other = picture_direction(params, s + sign * ds, t + sign * dt)
                    if other is not None:
                        angle = _angle(d, other)
                        if angle > 1e-9 and (nearest is None or angle < nearest):
                            nearest = angle
            if nearest is not None:
                # A face pixel's angle here: (2 / N) cos² off the face's middle.
                cos2 = 1.0 / (1.0 + x * x + y * y)
                need = max(need, 2.0 * cos2 / nearest)
    if not faces:
        return None
    # `need` is the 90 degrees' own pixels; the margin is round them.
    pixels = int(math.ceil(need)) + 2 * MARGIN if need > 0.0 else MIN_FACE
    pixels = max(MIN_FACE, min(int(max_face), pixels))
    pixels += pixels % 2
    inner = max(2, pixels - 2 * MARGIN)
    return {"faces": sorted(faces), "size": pixels, "tan": pixels / float(inner)}


def face_axes(index, right, up, forward):
    """A face's (forward, up) in the world, from the camera's right, up and forward (Unreal's
    vectors, as (x, y, z)). Pure."""
    face_forward, face_up, _right = FACES[index]

    def world(local):
        return tuple(right[k] * local[0] + up[k] * local[1] + forward[k] * local[2]
                     for k in range(3))

    return world(face_forward), world(face_up)


def face_fov(plan_):
    """A face's horizontal field of view in degrees (`plan`'s "tan"). Pure."""
    return math.degrees(2.0 * math.atan(float(plan_["tan"])))


# The warp: `direction` and `face_of`, as the material computes them per pixel. Inputs: UV (the
# picture's 0-1, from its top left), Kind, P0-P3 (`kernel`), Tan, Decode (a power for Unreal's
# display colour: 1 for linear pictures), F0-F5 (the faces).
WARP_HLSL = r"""
float s = UV.x;
float t = 1.0 - UV.y;
float u = P3.x * s + P3.y;
float v = P3.z * t + P3.w;
int k = (int)(Kind + 0.5);
float3 d = float3(0.0, 0.0, 0.0);
if (k == 0) {
    float phi = P0.x * u + P0.y;
    float theta = P0.z * v + P0.w;
    d = float3(sin(theta) * cos(phi), sin(theta) * sin(phi), cos(theta));
} else if (k == 1) {
    d = float3(1.0, tan((0.5 - u) * 1.5707963), tan((v - 0.5) * 1.5707963));
} else if (k == 2) {
    float mx = 2.0 * u - 1.0;
    float mz = 2.0 * v - 1.0;
    if (mx * mx + mz * mz <= 1.0) {
        float3 m = float3(mx, -sqrt(max(1.0 - mx * mx - mz * mz, 0.0)), mz);
        float3 i = float3(0.0, -1.0, 0.0);
        d = 2.0 * dot(m, i) * m - i;
    }
} else if (k == 6) {
    float th = lerp(P0.x, P0.y, u);
    d = float3(cos(th), sin(th), lerp(P0.z, P0.w, v));
} else {
    float x;
    float y;
    float theta = 0.0;
    bool inside = false;
    if (k == 3) {
        x = (u - 0.5) * 2.0;
        y = (v - 0.5) * 2.0;
        float r3 = sqrt(x * x + y * y);
        inside = r3 <= 1.0;
        theta = r3 * P2.z * 0.5;
    } else if (k == 5) {
        x = (u - 0.5) * P2.x;
        y = (v - 0.5) * P2.y;
        float r5 = sqrt(x * x + y * y);
        float r2 = r5 * r5;
        theta = -(P1.x + dot(P0, float4(r5, r2, r2 * r5, r2 * r2)));
        inside = abs(theta) <= 0.5 * P2.z;
    } else {
        x = (u - 0.5) * P2.x;
        y = (v - 0.5) * P2.y;
        float r4 = sqrt(x * x + y * y);
        inside = r4 <= 2.0 * P2.w * sin(P2.z * 0.25);
        theta = 2.0 * asin(min(1.0, r4 / (2.0 * P2.w)));
    }
    if (inside) {
        float r = sqrt(x * x + y * y);
        float phi = acos(clamp(r != 0.0 ? x / r : 0.0, -1.0, 1.0));
        if (y < 0.0) {
            phi = -phi;
        }
        d = float3(cos(theta), -cos(phi) * sin(theta), sin(phi) * sin(theta));
    }
}
if (!any(d != 0.0)) {
    return float3(0.0, 0.0, 0.0);
}
float3 c = (k == 2) ? float3(d.x, d.z, -d.y) : float3(-d.y, d.z, d.x);
float3 a = abs(c);
float fx;
float fy;
float3 colour;
if (a.z >= a.x && a.z >= a.y) {
    if (c.z > 0.0) {
        fx = c.x / c.z; fy = c.y / c.z;
        colour = Texture2DSampleLevel(F0, F0Sampler, float2(0.5 + 0.5 * fx / Tan, 0.5 - 0.5 * fy / Tan), 0.0).rgb;
    } else {
        fx = c.x / c.z; fy = -c.y / c.z;
        colour = Texture2DSampleLevel(F1, F1Sampler, float2(0.5 + 0.5 * fx / Tan, 0.5 - 0.5 * fy / Tan), 0.0).rgb;
    }
} else if (a.x >= a.y) {
    if (c.x > 0.0) {
        fx = -c.z / c.x; fy = c.y / c.x;
        colour = Texture2DSampleLevel(F2, F2Sampler, float2(0.5 + 0.5 * fx / Tan, 0.5 - 0.5 * fy / Tan), 0.0).rgb;
    } else {
        fx = -c.z / c.x; fy = -c.y / c.x;
        colour = Texture2DSampleLevel(F3, F3Sampler, float2(0.5 + 0.5 * fx / Tan, 0.5 - 0.5 * fy / Tan), 0.0).rgb;
    }
} else {
    if (c.y > 0.0) {
        fx = c.x / c.y; fy = -c.z / c.y;
        colour = Texture2DSampleLevel(F4, F4Sampler, float2(0.5 + 0.5 * fx / Tan, 0.5 - 0.5 * fy / Tan), 0.0).rgb;
    } else {
        fx = -c.x / c.y; fy = c.z / -c.y;
        colour = Texture2DSampleLevel(F5, F5Sampler, float2(0.5 + 0.5 * fx / Tan, 0.5 - 0.5 * fy / Tan), 0.0).rgb;
    }
}
return pow(max(colour, 0.0), Decode);
"""

SCALARS = ("Kind", "Tan", "Decode")
VECTORS = ("P0", "P1", "P2", "P3")
TEXTURES = tuple("F{0}".format(i) for i in range(6))


def master_name():
    return "M_BU_Live_Pano_v{0}".format(VERSION)


def master_path():
    return "{0}/{1}.{1}".format(PACKAGE, master_name())


def ensure_master(unreal, compile_material, linear_default=None):
    """The warp material, built on first use, or None. `compile_material(unreal, material)`;
    `linear_default()`: a linear texture for the faces' defaults."""
    path = master_path()
    if unreal.EditorAssetLibrary.does_asset_exist(path.split(".")[0]):
        found = unreal.EditorAssetLibrary.load_asset(path)
        if found is not None:
            return found
    material = unreal.AssetToolsHelpers.get_asset_tools().create_asset(
        master_name(), PACKAGE, unreal.Material, unreal.MaterialFactoryNew())
    if material is None:
        unreal.log_error("BU: could not create " + path)
        return None
    library = unreal.MaterialEditingLibrary
    material.set_editor_property("shading_model", unreal.MaterialShadingModel.MSM_UNLIT)

    def node(cls, x, y, **props):
        found = library.create_material_expression(material, cls, x, y)
        for name, value in props.items():
            found.set_editor_property(name, value)
        return found

    custom = node(unreal.MaterialExpressionCustom, -300, 0, code=WARP_HLSL,
                  output_type=unreal.CustomMaterialOutputType.CMOT_FLOAT3,
                  description="Blender panorama")
    names = ("UV",) + SCALARS + VECTORS + TEXTURES
    inputs = []
    for name in names:
        found = unreal.CustomInput()
        found.set_editor_property("input_name", name)
        inputs.append(found)
    custom.set_editor_property("inputs", inputs)
    failed = []
    uv = node(unreal.MaterialExpressionTextureCoordinate, -700, -200)
    sources = {"UV": (uv, "")}
    for row, name in enumerate(SCALARS):
        sources[name] = (node(unreal.MaterialExpressionScalarParameter, -700, -100 + 60 * row,
                              parameter_name=name, default_value=1.0), "")
    for row, name in enumerate(VECTORS):
        vector = node(unreal.MaterialExpressionVectorParameter, -900, 100 + 60 * row,
                      parameter_name=name)
        # All four numbers: the parameter's own pin is its RGB alone.
        four = node(unreal.MaterialExpressionAppendVector, -700, 100 + 60 * row)
        if not (library.connect_material_expressions(vector, "", four, "A")
                and library.connect_material_expressions(vector, "A", four, "B")):
            failed.append(name + " (its alpha)")
        sources[name] = (four, "")
    default = linear_default() if linear_default is not None else None
    for row, name in enumerate(TEXTURES):
        texture = node(unreal.MaterialExpressionTextureObjectParameter, -700, 400 + 80 * row,
                       parameter_name=name,
                       sampler_type=unreal.MaterialSamplerType.SAMPLERTYPE_LINEAR_COLOR)
        if default is not None:
            texture.set_editor_property("texture", default)
        sources[name] = (texture, "")
    for name in names:
        source, output = sources[name]
        if not library.connect_material_expressions(source, output, custom, name):
            failed.append(name)
    if not library.connect_material_property(custom, "",
                                             unreal.MaterialProperty.MP_EMISSIVE_COLOR):
        failed.append("EmissiveColor")
    if failed:
        unreal.log_warning("BU: {0}: could not connect {1}".format(master_name(),
                                                                   ", ".join(failed)))
    compile_material(unreal, material)
    unreal.EditorAssetLibrary.save_loaded_asset(material, only_if_is_dirty=False)
    unreal.log("BU: created {0} for Blender's panoramic cameras".format(master_name()))
    return material


def warp_values(lens, plan_, decode=1.0):
    """The warp's parameters: ({scalar: value}, {vector: (r, g, b, a)}). Pure."""
    kind, p0, p1, p2, p3 = kernel(lens)
    return ({"Kind": float(kind), "Tan": float(plan_["tan"]), "Decode": float(decode)},
            {"P0": tuple(p0), "P1": tuple(p1), "P2": tuple(p2), "P3": tuple(p3)})
