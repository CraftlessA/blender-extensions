# SPDX-License-Identifier: GPL-3.0-or-later
"""BU — Blender to Unreal Bridge.

Exports USD plus a sidecar manifest carrying everything USD cannot: per-texture
filtering, camera filmback, and marker-driven camera cuts. See NOTES.md for the
verification behind each of those.
"""

import importlib
import os
import sys
import time

from . import agent, bake, filter_ui, link, material_slots, operator, prefs, shots, usd_hook  # noqa: F401

# prefs first: the operators and panel read preferences at draw time, and `agent` reads the
# checkbox that decides whether its poll runs at all.
# filter_ui before operator: it defines the Scene.bu_* properties that the operator's panel draws.
# bake before operator: the sidebar panel draws its operator.
# link after operator: its panel sits below the export panel in the same sidebar tab.
_modules = (prefs, filter_ui, usd_hook, bake, operator, link, agent)
_IMPORTED = ("agent", "bake", "filter_ui", "link", "material_slots", "operator", "prefs", "shots",
             "usd_hook")
_loaded_at = time.time()


def changed_on_disk(modules, loaded_at):
    """Whether any of `modules` (sys.modules entries) has a file newer than `loaded_at`."""
    for module in modules:
        path = getattr(module, "__file__", None)
        try:
            if path and os.path.getmtime(path) > loaded_at:
                return True
        except OSError:
            continue
    return False


def _fresh():
    """BU's modules as they are on disk.

    Turning BU off and on in Preferences only registers again what is already imported, and a
    changed __init__ is reloaded alone: the rest stays the code Blender first loaded. A tester's
    Blender ran the old live view against a new Unreal side that way for hours. So when any of
    BU's files is newer than what was imported, every one of BU's modules is dropped and
    imported again before registering.
    """
    global _modules, _loaded_at
    prefix = __name__ + "."
    ours = [module for name, module in list(sys.modules.items()) if name.startswith(prefix)]
    if not changed_on_disk(ours, _loaded_at):
        return
    package = sys.modules[__name__]
    for name in [name for name in sys.modules if name.startswith(prefix)]:
        sys.modules.pop(name, None)
        # `from . import x` takes the package's attribute when there is one, old or not.
        short = name[len(prefix):]
        if "." not in short and hasattr(package, short):
            delattr(package, short)
    fresh = {name: importlib.import_module(prefix + name) for name in _IMPORTED}
    globals().update(fresh)
    _modules = tuple(fresh[module.__name__.rsplit(".", 1)[1]] for module in _modules)
    _loaded_at = time.time()
    print("BU: its files changed since Blender loaded them; loaded them again")


def register():
    _fresh()
    for module in _modules:
        module.register()


def unregister():
    for module in reversed(_modules):
        module.unregister()
