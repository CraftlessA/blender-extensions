# SPDX-License-Identifier: GPL-3.0-or-later
"""A request inbox, so a tool outside Blender can ask the running session to save itself.

BU's headless paths — `tools/roundtrip.py`, any scripted export — run Blender against the
**.blend on disk**. That is deliberate: it means an editing session can stay open while the
pipeline runs. The cost is that the file on disk can be older than what is on screen, and the
export silently reflects the older one. Measured once: a scene saved at 04:51 was exported at
06:04 with an autosave from 05:57 sitting between them, and nothing in the result said so.

Unreal solves the equivalent problem with a remote-execution channel. Blender has no such thing,
and adding a socket listener to an add-on is a much bigger commitment than the problem deserves.
So this is a file inbox: a `bpy.app.timers` poll picks up request files, acts on them, and writes
a result file back. No ports, no daemon, nothing listening on a network.

Scope is deliberately narrow. The only verb is `save`, and it saves the currently open file to
its existing path — it will not save-as, will not overwrite a different file, and refuses when
the session has never been saved (there is no path to save *to*, and inventing one would put a
file somewhere the artist did not choose).
"""

import glob
import json
import os
import time

import bpy

POLL_SECONDS = 1.0
_REQUEST_SUFFIX = ".bu-request.json"
_RESULT_SUFFIX = ".bu-result.json"


def inbox_dir():
    """Where requests are dropped. Under the system temp dir, created on demand.

    Not `bpy.app.tempdir` — that is a per-session directory that is deleted when Blender quits,
    and its name is not predictable from outside, which makes it useless as a rendezvous point.
    """
    import tempfile

    path = os.path.join(tempfile.gettempdir(), "bu_bridge_inbox")
    os.makedirs(path, exist_ok=True)
    return path


def _write_result(request_path, payload):
    result_path = request_path[: -len(_REQUEST_SUFFIX)] + _RESULT_SUFFIX
    payload["completed"] = time.time()
    try:
        with open(result_path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
    except OSError:
        pass
    return result_path


def _handle_save(request):
    """Save the open file to its own path. Returns the result payload."""
    path = bpy.data.filepath
    if not path:
        return {
            "ok": False,
            "error": (
                "This Blender session has never been saved, so there is no path to save to. "
                "Save it once from Blender first."
            ),
        }

    expected = request.get("expect_path")
    if expected and os.path.normcase(os.path.abspath(expected)) != os.path.normcase(path):
        # Guards against saving the wrong session when several Blenders are open — they all
        # share one inbox, and without this whichever polled first would answer.
        return {"ok": False, "skipped": True, "error": "different file open: " + path}

    # Saves unconditionally by default. `bpy.data.is_dirty` looks like the obvious optimisation
    # and is a trap: in `--background` it stays False through edits that plainly changed the
    # scene, so a dirty-check default would sometimes skip the save and hand the caller a stale
    # file — the exact failure this whole module exists to prevent. Callers that would rather
    # have the false negative can ask for it.
    if request.get("skip_if_clean") and not bpy.data.is_dirty:
        return {"ok": True, "path": path, "saved": False, "reason": "no unsaved changes"}

    try:
        bpy.ops.wm.save_mainfile()
    except RuntimeError as exc:
        return {"ok": False, "path": path, "error": str(exc)}

    return {"ok": True, "path": path, "saved": True, "mtime": os.path.getmtime(path)}


def _handle_status(_request):
    return {
        "ok": True,
        "path": bpy.data.filepath,
        "scene": bpy.context.scene.name if bpy.context.scene else "",
        "dirty": bool(bpy.data.is_dirty),
        "blender": bpy.app.version_string,
    }


def _handle_bake(request):
    """Bake textures trapped in node groups, from inside the running UI.

    Baking is the one BU operation that genuinely cannot be verified headlessly: run under
    `--background` the bake operator returns success and writes nothing at all, producing an image
    that is uniformly black. Exposing it here is what makes it testable in the only context where
    it works, and it does not widen the channel's surface — it runs one named BU operator, not
    arbitrary code.
    """
    from . import bake

    pending = bake.targets(bpy.context)
    if not pending:
        return {"ok": True, "baked": [], "note": "nothing to bake"}

    baked, failed = [], []
    for material, entry in pending:
        try:
            image, path = bake.bake_material(
                bpy.context, material, int(request.get("resolution") or bake.DEFAULT_RESOLUTION))
        except RuntimeError as exc:
            failed.append({"material": material.name, "error": str(exc)})
            continue
        baked.append({
            "material": material.name,
            "image": image.name,
            "path": path,
            "size": os.path.getsize(path) if os.path.exists(path) else 0,
            "was_losing": entry["buried"],
        })
    return {"ok": not failed, "baked": baked, "failed": failed}


_HANDLERS = {"save": _handle_save, "status": _handle_status, "bake": _handle_bake}


def process_once():
    """Handle every pending request. Returns the number handled."""
    handled = 0
    for request_path in sorted(glob.glob(os.path.join(inbox_dir(), "*" + _REQUEST_SUFFIX))):
        try:
            with open(request_path, "r", encoding="utf-8") as handle:
                request = json.load(handle)
        except (OSError, ValueError) as exc:
            request = {}
            payload = {"ok": False, "error": "unreadable request: {0}".format(exc)}
        else:
            handler = _HANDLERS.get(request.get("action"))
            if handler is None:
                payload = {
                    "ok": False,
                    "error": "unknown action {0!r}; known: {1}".format(
                        request.get("action"), ", ".join(sorted(_HANDLERS))
                    ),
                }
            else:
                try:
                    payload = handler(request)
                except Exception as exc:  # noqa: BLE001 - a bad request must not kill the timer
                    payload = {"ok": False, "error": "{0}: {1}".format(type(exc).__name__, exc)}

        payload["action"] = request.get("action")
        _write_result(request_path, payload)
        try:
            os.remove(request_path)
        except OSError:
            pass
        handled += 1
    return handled


def _tick():
    try:
        process_once()
    except Exception:  # noqa: BLE001 - a timer that raises is unregistered by Blender
        pass
    return POLL_SECONDS


def enabled():
    try:
        from . import prefs

        return bool(prefs.get().agent_inbox)
    except Exception:  # noqa: BLE001 - usable before preferences exist
        return False


def start():
    if not bpy.app.timers.is_registered(_tick):
        bpy.app.timers.register(_tick, first_interval=POLL_SECONDS, persistent=True)


def stop():
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)


def register():
    if enabled():
        start()


def unregister():
    stop()
