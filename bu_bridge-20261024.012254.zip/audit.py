# SPDX-License-Identifier: GPL-3.0-or-later
"""Compare what Blender *should* have exported against what actually reached the USD.

Blender's USD exporter drops objects silently when they do not meet its expectations, and a
missing object is far harder to notice than a wrong one — it just is not there. This turns that
silence into a named list with a diagnosed reason per object, so "USD lost my model" becomes a
specific, checkable claim rather than a suspicion.

Runs after export, so it compares against the real file rather than predicting behaviour.
"""

import os

# Object types Blender's USD exporter can represent as geometry.
EXPORTABLE_TYPES = ("MESH", "CURVE", "SURFACE", "META", "FONT")


def _usd_object_names(usd_path):
    """Every Blender object name recorded in the stage.

    Blender tags each exported object's Xform with `userProperties:blender:object_name`, which is
    the only reliable way back to the original name — prim names are sanitised.
    """
    try:
        from pxr import Usd
    except ImportError:
        return None

    if not os.path.isfile(usd_path):
        return None

    stage = Usd.Stage.Open(usd_path)
    if stage is None:
        return None

    names = set()
    for prim in stage.Traverse():
        attr = prim.GetAttribute("userProperties:blender:object_name")
        if attr:
            value = attr.Get()
            if value:
                names.add(value)
    return names


def _diagnose(obj, context, evaluation_mode, selected_only):
    """Why this object is probably absent, in the user's terms."""
    from . import capture

    reasons = capture.export_blockers(obj, context, evaluation_mode, selected_only)
    if reasons:
        return reasons[0]

    if obj.type == "MESH":
        if len(obj.data.vertices) == 0:
            return "it has zero vertices"
        # An evaluated mesh can be empty even when the base mesh is not, e.g. a modifier that
        # culls everything at render resolution.
        try:
            depsgraph = context.evaluated_depsgraph_get()
            evaluated = obj.evaluated_get(depsgraph)
            mesh = evaluated.to_mesh()
            empty = mesh is None or len(mesh.vertices) == 0
            evaluated.to_mesh_clear()
            if empty:
                modifiers = [m.type for m in obj.modifiers if m.show_render]
                return "its evaluated geometry is empty (modifiers: {0})".format(
                    ", ".join(modifiers) or "none"
                )
        except Exception:  # noqa: BLE001
            pass

    if obj.type not in EXPORTABLE_TYPES:
        return "its type ({0}) is not exported as geometry".format(obj.type)

    if obj.instance_type != "NONE":
        return "it is an instancer ({0}); geometry may live on its children".format(
            obj.instance_type
        )

    library = getattr(obj, "library", None) or getattr(obj.data, "library", None)
    if library is not None:
        return "it is linked from an external .blend ({0})".format(
            os.path.basename(getattr(library, "filepath", "") or "?")
        )

    return "reason unknown — Blender's exporter skipped it without saying why"


def audit(context, usd_path, evaluation_mode="RENDER", selected_only=False):
    """Return a report dict describing export completeness."""
    exported = _usd_object_names(usd_path)
    if exported is None:
        return {"available": False, "missing": [], "expected": 0, "exported": 0}

    expected = []
    for obj in context.scene.objects:
        if obj.type not in EXPORTABLE_TYPES:
            continue
        expected.append(obj)

    missing = []
    for obj in expected:
        if obj.name in exported:
            continue
        missing.append({"object": obj.name, "type": obj.type, "reason": _diagnose(
            obj, context, evaluation_mode, selected_only
        )})

    return {
        "available": True,
        "expected": len(expected),
        "exported": sum(1 for o in expected if o.name in exported),
        "missing_count": len(missing),
        "missing": missing,
    }


# Reasons that mean "somebody left a toggle off", as opposed to "this is how rigs work".
#
# Only view-layer exclusion qualifies. An object's own camera icon does NOT: every rig in these
# files hides its widgets that way, and Chica alone loses 22 objects to it by design. A
# collection's camera icon is already escalated by `capture.hidden_geometry`, which can name the
# collection — a better message than anything reachable from here.
_ACCIDENTAL_REASONS = ("excluded from the view layer",)


def _is_real_geometry(obj):
    """A mesh an artist would notice the absence of.

    Same definition the hidden-geometry survey uses: real vertices, and a material slot, which is
    what separates a model from a rig widget. Without it a rig's control shapes dominate the count
    and the rule fires on files that are perfectly fine.
    """
    if obj is None or obj.type != "MESH":
        return False
    data = getattr(obj, "data", None)
    if data is None or not len(data.vertices):
        return False
    return any(slot.material is not None for slot in obj.material_slots)


def escalate(report, context):
    """Errors for losses shaped like an accident rather than an authoring choice.

    Measured on `Ennard.blend`: 219 objects were excluded from the view layer against 207
    exported, and it stayed a warning among a dozen others. A collection's camera icon costing
    that much is already an error; the Outliner checkbox above it is the same accident with the
    same cost, so it gets the same severity.

    Deliberately proportional with no absolute threshold. `giblet_mc_model.blend` excludes 26
    objects against 57 exported — all rig widgets — and must stay quiet.
    """
    if not report.get("available") or not report.get("missing"):
        return []

    objects = context.scene.objects
    lost = [
        entry["object"] for entry in report["missing"]
        if any(reason in entry["reason"] for reason in _ACCIDENTAL_REASONS)
        and _is_real_geometry(objects.get(entry["object"]))
    ]
    if not lost:
        return []

    exported_real = sum(
        1 for obj in objects
        if _is_real_geometry(obj) and obj.name not in {e["object"] for e in report["missing"]}
    )
    if len(lost) < exported_real:
        return []

    return [
        "{0} mesh object(s) are excluded from this export by a collection's checkbox in the "
        "Outliner, against {1} exported: {2}{3}. Tick the checkbox to bring them back — this is "
        "the checkbox left of the collection name, not the camera icon.".format(
            len(lost), exported_real, ", ".join(sorted(lost)[:8]),
            " (+{0} more)".format(len(lost) - 8) if len(lost) > 8 else "",
        )
    ]


def _composition(names, context):
    """How much of a missing group is geometry an artist would actually miss.

    A raw count is alarming out of proportion to what it means. The real scene reports 1551
    objects absent from the view layer, which reads like a catastrophe; 1476 of them are rig
    widgets and only 37 are meshes with materials, against 603 exported. Same number, opposite
    conclusion, so the count alone is not enough to act on.
    """
    if context is None:
        return ""
    objects = context.scene.objects
    real = sum(1 for name in names if _is_real_geometry(objects.get(name)))
    if real == len(names):
        return ""
    if not real:
        return " — none of them are meshes with materials, so this is most likely rig widgets " \
               "and helpers rather than lost model geometry"
    return (" — {0} of them are meshes with materials; the rest are rig widgets, curves or "
            "helpers".format(real))


def summarise(report, limit=12, context=None):
    """Warning strings for the manifest, grouped so one cause is not repeated 70 times."""
    if not report.get("available") or not report.get("missing"):
        return []

    grouped = {}
    for entry in report["missing"]:
        grouped.setdefault(entry["reason"], []).append(entry["object"])

    lines = []
    for reason, names in sorted(grouped.items(), key=lambda kv: -len(kv[1])):
        shown = ", ".join(names[:limit])
        if len(names) > limit:
            shown += " (+{0} more)".format(len(names) - limit)
        lines.append(
            "{0} object(s) did not reach the USD because {1}{2}: {3}".format(
                len(names), reason, _composition(names, context), shown
            )
        )
    return lines
