# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender's light linking as Unreal's three lighting channels.

Blender links a light to the objects it lights (Object → Light Linking → Light Linking): a
collection whose objects, or child collections, are each Included or Excluded. With anything
included the light lights only those; with only exclusions, everything but them.

Unreal has three lighting channels. A light lights an object when they share one, and only
then does the object cast that light's shadow either (`FLightSceneInfoCompact::
AffectsPrimitive`); Lumen's surface cache and the path tracer keep to them too. So objects are
put in groups by which linked lights reach them, each group gets channels, and each light the
channels of the groups it lights (an unlinked light, all of them). Three groups or fewer always
fit, one channel each; more can when groups share channels in a way no light minds (`assign`).

Shadows. Blender's light linking only picks what a light lights: everything still blocks it,
unless Shadow Linking says otherwise. Unreal's shadow maps only draw the objects that share the
light's channels, so a linked light shone through everything outside its groups (t1110: a point
light tucked inside a desk lit a face the desk hides it from). Its ray-traced shadow hits every
object, whatever its channels, so a light that misses some group asks for that (`excludes`;
Unreal's `bu_link_light.ray_traced_shadow`). Without a ray-tracing GPU it is shadow maps again.
Shadow Linking is not read. An emissive mesh with linking is not a light here.

Fog. Unreal's volumetric fog takes every light, whatever its channels. In Blender a linked light
lights a fog volume only if its collection reaches it, so a light whose channels miss every
fog volume is kept out of the fog by its own Volume visibility (`lights_volumes`). seq100's rim
light, linked to the frog alone, threw a bright glow in the God Ray fog behind him that Cycles
never had.

Bounce. Lumen's scene lighting takes every light too, whatever its channels: that rim light lit
the couch and walls in Lumen's scene cache, and their bounce lit the room and the frog's face. A
light that misses the set (the objects no linking names) gives no bounce light (`bounces`); one
lighting the set keeps it, since losing all of a key light's bounce for one prop it excludes
would cost far more than that prop's bit of stray bounce.
"""

DEFAULT = (True, False, False)  # Unreal's own: channel 0
# Masks to try, as bits of channels 0, 1, 2: single channels first, so groups get one each when
# they can, and the first group (everything no linking names) channel 0, as Unreal already has.
MASKS = (1, 2, 4, 3, 5, 6, 7)


def channels(mask):
    return (bool(mask & 1), bool(mask & 2), bool(mask & 4))


def receivers(collection):
    """({object name: lit}, anything included) for a light's linking collection.

    An object listed directly keeps its own state; one inside a child collection takes the
    child's (as the collection's row in the Light Linking list shows it)."""
    found = {}
    included = [False]

    def walk(coll, inherited):
        for obj, member in zip(coll.objects, coll.collection_objects):
            state = inherited or member.light_linking.link_state
            included[0] = included[0] or state == "INCLUDE"
            found.setdefault(obj.name, state == "INCLUDE")
        for child, member in zip(coll.children, coll.collection_children):
            state = inherited or member.light_linking.link_state
            included[0] = included[0] or state == "INCLUDE"
            walk(child, state)

    walk(collection, None)
    return found, included[0]


def fits(groups, masks):
    """True when giving each group (a tuple: lit by each linked light) its mask lights exactly
    what Blender does: every light's channels, the union of its groups', miss all the others."""
    for light in range(len(groups[0]) if groups else 0):
        union = 0
        for group, mask in zip(groups, masks):
            if group[light]:
                union |= mask
        if any(not group[light] and mask & union for group, mask in zip(groups, masks)):
            return False
    return True


def assign(groups):
    """A mask (1-7) for each group so that `fits`, or None. Distinct groups need distinct masks
    (two with the same would be lit alike), so more than seven never fit."""
    if len(groups) > len(MASKS):
        return None
    chosen = []

    def search(index):
        if index == len(groups):
            return fits(groups, chosen)
        for mask in MASKS:
            if mask in chosen:
                continue
            chosen.append(mask)
            if fits(groups[:index + 1], chosen) and search(index + 1):
                return True
            chosen.pop()
        return False

    return list(chosen) if search(0) else None


def plan(lights, objects, volumes=()):
    """Channels for `lights` ([(name, light object)]) and `objects` (the names BU sends), of
    which `volumes` are fog volumes (`lights_volumes`).

    None when no light is linked: each light's own Unreal channels stand. Otherwise
    {"lights": {name: channels}, "objects": {name: channels} (only those not on DEFAULT),
    "groups": how many, "fits": bool}. When they do not fit, every light lights everything
    (as with no linking) and `fits` says so."""
    linked = []
    for name, light in lights:
        linking = getattr(light, "light_linking", None)
        collection = getattr(linking, "receiver_collection", None)
        if collection is None:
            continue
        lit, included = receivers(collection)
        linked.append((name, lit, not included))
    if not linked:
        return None
    unnamed = tuple(otherwise for _name, _lit, otherwise in linked)
    named = {}
    for _name, lit, _otherwise in linked:
        named.update(dict.fromkeys(lit))
    signature = {name: tuple(lit.get(name, otherwise) for _n, lit, otherwise in linked)
                 for name in named if name in objects}
    groups = sorted(set(signature.values()) - {unnamed})
    if len(signature) < len(objects) or unnamed in signature.values():
        groups.insert(0, unnamed)  # objects lit as if nothing named them
    found = {"lights": {}, "objects": {}, "groups": len(groups), "fits": True}
    masks = assign(groups) if groups else []
    if masks is None:
        found["fits"] = False
        return found
    by_group = dict(zip(groups, masks))
    for name, group in signature.items():
        if by_group[group] != 1:
            found["objects"][name] = channels(by_group[group])
    unnamed_mask = by_group.get(unnamed, 1)
    if unnamed_mask != 1:
        found["unnamed"] = channels(unnamed_mask)
    everything = 0
    for mask in masks:
        everything |= mask
    for index, (name, _lit, _otherwise) in enumerate(linked):
        union = 0
        for group, mask in by_group.items():
            if group[index]:
                union |= mask
        found["lights"][name] = channels(union)
    found["all"] = channels(everything or 1)
    if volumes:
        found["volumes"] = tuple(sorted(volumes))
    return found


def object_channels(found, name):
    """An object's channels under a plan: None for Unreal's default."""
    if not found or not found.get("fits"):
        return None
    return found["objects"].get(name) or found.get("unnamed")


def excludes(found, name):
    """True when a light, under a plan, misses some objects' channels, so Unreal's shadow maps
    would not let those objects block it (the module's Shadows)."""
    lit = light_channels(found, name)
    if lit is None or not found.get("fits"):
        return False
    return tuple(lit) != tuple(found.get("all") or lit)


def lights_volumes(found, name):
    """False when, under a plan, a light lights none of the scene's fog volumes, so it should
    not scatter in Unreal's fog (the module's Fog). True with no plan, no fog volumes, or a plan
    that does not fit (every light lights everything)."""
    lit = light_channels(found, name)
    volumes = (found or {}).get("volumes")
    if lit is None or not found.get("fits") or not volumes:
        return True
    for volume in volumes:
        reached = object_channels(found, volume) or DEFAULT
        if any(a and b for a, b in zip(lit, reached)):
            return True
    return False


def bounces(found, name):
    """False when, under a plan, a light misses the objects no linking names (the set), so its
    Lumen bounce, which ignores channels, would light what Blender never lets it (the module's
    Bounce). True with no plan or one that does not fit."""
    lit = light_channels(found, name)
    if lit is None or not found.get("fits"):
        return True
    unnamed = found.get("unnamed") or DEFAULT
    return any(a and b for a, b in zip(lit, unnamed))


def light_channels(found, name):
    """A light's channels under a plan, or None to leave its own setting."""
    if not found:
        return None
    if not found.get("fits"):
        return (True, True, True)  # could not be matched: lights light everything
    return found["lights"].get(name, found["all"])
