# SPDX-License-Identifier: GPL-3.0-or-later
"""Wires imported textures into imported materials.

Unreal's USD importer generates a UMaterialInstanceConstant per material, parented to
`/USDCore/Materials/UsdPreviewSurface`, whose texture parameters follow a fixed naming
convention (verified in `USDShadeConversion.cpp` L1215-1227):

    <Channel>Texture       the texture parameter, e.g. "BaseColorTexture"
    Use<Channel>Texture    a scalar switch, 1.0 when a texture is bound, 0.0 when not

When a model imports untextured, it is nearly always because the texture asset came in fine
but `UseBaseColorTexture` is still 0 and/or `BaseColorTexture` was never bound. So rather
than rebuilding materials from scratch, we bind the parameters the importer already
provides -- working with the importer instead of around it.

The manifest tells us which channel each texture feeds, traced from the Blender node graph.
"""

import unreal

from . import bu_names

USD_PREVIEW_SURFACE = "/USDCore/Materials/UsdPreviewSurface"

# Channels we know how to bind. Anything else in the manifest is reported, not guessed at.
KNOWN_CHANNELS = (
    "BaseColor",
    "Normal",
    "Roughness",
    "Metallic",
    "EmissiveColor",
    "Opacity",
    "SpecularColor",
)


def _load_assets(content_path):
    """Load everything under a content path once, bucketed by type."""
    textures, materials = [], []
    for asset_path in unreal.EditorAssetLibrary.list_assets(content_path, recursive=True):
        asset = unreal.EditorAssetLibrary.load_asset(asset_path)
        if isinstance(asset, unreal.Texture):
            textures.append(asset)
        elif isinstance(asset, unreal.MaterialInterface):
            materials.append(asset)
    return textures, materials


def _texture_index(textures, manifest):
    """Map manifest texture keys to the actual imported texture assets."""
    index = {}
    for texture in textures:
        names = [texture.get_name()]
        import_data = texture.get_editor_property("asset_import_data")
        if import_data:
            try:
                names.extend(import_data.extract_filenames())
            except Exception:  # noqa: BLE001 - editor API, stay forgiving
                pass

        entry = manifest.texture_for(*names)
        if entry is not None:
            index.setdefault(entry["key"], texture)
    return index


def _material_index(materials):
    """Map both exact and lowercased names to imported material assets."""
    index = {}
    for material in materials:
        name = material.get_name()
        index.setdefault(name, material)
        index.setdefault(name.lower(), material)
    return index


def _find_material(entry, index):
    """Resolve a manifest material entry to an imported material asset.

    Blender `stone.002` becomes prim `stone_002` and then asset `MI_stone_002`, so the raw
    Blender name never matches. Try the prefixed and sanitised forms, then compare with the
    type prefix stripped from both sides.
    """
    candidates = bu_names.material_name_candidates(entry)

    for candidate in candidates:
        hit = index.get(candidate) or index.get(candidate.lower())
        if hit is not None:
            return hit

    bare = {bu_names.strip_asset_prefix(c).lower() for c in candidates}
    for key, asset in index.items():
        if bu_names.strip_asset_prefix(key).lower() in bare:
            return asset

    # Last resort: prefix match, which catches Unreal's disambiguating suffixes.
    for candidate in candidates:
        lowered = candidate.lower()
        for key, asset in index.items():
            if key.lower().startswith(lowered):
                return asset
    return None


def _current_binding(instance, channel):
    """What this instance currently has for a channel: (texture, use_flag).

    Either may be None when the value cannot be read.
    """
    library = unreal.MaterialEditingLibrary
    try:
        texture = library.get_material_instance_texture_parameter_value(
            instance, "{0}Texture".format(channel)
        )
    except Exception:  # noqa: BLE001
        texture = None
    try:
        use = library.get_material_instance_scalar_parameter_value(
            instance, "Use{0}Texture".format(channel)
        )
    except Exception:  # noqa: BLE001
        use = None
    return texture, use


def _same_texture(a, b):
    """Compare two texture assets by path, never with `==`.

    Unreal's Python proxies do not compare reliably: `==` on two handles to the same asset can be
    False, which is the same trap that made a `unreal.Guid` diagnostic report "NO MATCH" for
    identical GUIDs. Using it here made `wire_materials` claim it could not bind a channel that was
    already bound correctly.
    """
    if a is None or b is None:
        return a is None and b is None
    try:
        return a.get_path_name() == b.get_path_name()
    except Exception:  # noqa: BLE001
        return False


def _bind_channel(instance, channel, texture):
    """Ensure a channel is bound to `texture` with its Use<Channel>Texture switch on.

    Returns one of "already", "bound", "no-parameter", or "failed".

    Unreal's USD importer normally does this itself, so the common case is that everything is
    already correct and we must do nothing. Reporting a no-op as a failure was actively
    misleading: `set_material_instance_texture_parameter_value` returning False does *not*
    imply the parameter is absent, so the old code claimed materials had no
    `BaseColorTexture` when inspection showed they did.
    """
    library = unreal.MaterialEditingLibrary
    texture_param = "{0}Texture".format(channel)
    use_param = "Use{0}Texture".format(channel)

    existing, use = _current_binding(instance, channel)
    # `use is None` means the parent exposes no switch for this channel at all, which is normal:
    # BU's own masked material wires the texture straight into the graph and has no scalars. That
    # is nothing to fix, so it must not be reported as a failure.
    texture_ok = _same_texture(existing, texture)
    use_ok = use is None or use >= 1.0

    if texture_ok and use_ok:
        return "already"

    changed = False
    if not texture_ok:
        if library.set_material_instance_texture_parameter_value(instance, texture_param, texture):
            changed = True
        elif existing is None:
            # Nothing there and we could not put anything there: only now is it fair to
            # conclude the parent has no such parameter.
            return "no-parameter"

    # Without this the parent material ignores the texture entirely.
    if use is not None and use < 1.0:
        if library.set_material_instance_scalar_parameter_value(instance, use_param, 1.0):
            changed = True

    if changed:
        return "bound"

    # Unreal's setters return False when the value already equals what was asked for, so a
    # "nothing changed" result does not mean failure. Re-read before blaming the material.
    existing, use = _current_binding(instance, channel)
    if _same_texture(existing, texture) and (use is None or use >= 1.0):
        return "already"
    return "failed"


def _channel_is_real(instance, param, content_path):
    """True when this channel is driven by a texture from *this import*.

    Unreal binds shared placeholders (`127grey`, `BaseFlattenNormalMap`) for unused channels, so
    the presence of a texture proves nothing -- only one inside the imported folder counts.
    """
    try:
        texture = unreal.MaterialEditingLibrary.get_material_instance_texture_parameter_value(
            instance, param
        )
    except Exception:  # noqa: BLE001
        return False
    return texture is not None and content_path in texture.get_path_name()


def apply_constant_opacity(content_path, manifest):
    """Carry a flat Principled Alpha across, which USD cannot express.

    Blender writes `inputs:opacity = 1.0` for *every* constant Alpha — measured across value,
    connection state and render method — so a material sitting at Alpha 0 arrives fully opaque.
    Only a connected Alpha survives, as `inputs:opacity.connect`. The manifest carries the
    constant so it can be reapplied here.

    Measured on `Intro (3).blend`: seven pupil materials are fully transparent in Blender and
    were importing as solid blobs, which is worse than either the artist's intent or a plain
    missing texture — the geometry is meant to be invisible.

    Returns (applied, failed).
    """
    wanted = {}
    for entry in manifest.data.get("materials", []):
        alpha = (entry.get("alpha") or {})
        value = alpha.get("constant_alpha")
        if value is None or alpha.get("uses_alpha"):
            continue
        wanted[entry["name"]] = float(value)

    if not wanted:
        return 0, 0

    # Refuse when the answer is unknowable rather than guess it.
    #
    # Dropping the constant alpha makes materials that differ *only* in alpha byte-identical in
    # USD, so they arrive merged into a single instance. Measured with four cubes at alpha
    # 0.0/0.0/0.5/1.0: all four collapsed onto one material, and applying any single value to it
    # blanked out the other three. Nothing in the imported asset records which originals were
    # folded together, so a merged instance cannot be resolved by name or any other means.
    #
    # A merge is detectable though: the materials that lost the race leave no asset bearing their
    # name. That is a much narrower test than "do all the values agree" — materials differing in
    # colour, roughness or texture stay distinct in USD and keep their own instances, so they can
    # take different opacities safely. Only refuse when something actually merged *and* the values
    # in play disagree, because silently turning opaque geometry invisible is the worst outcome
    # available.

    # Every variant of a material shares its base name: MI_pupil, MI_pupil_2_TwoSided, ...
    prefixes = {}
    for name, value in wanted.items():
        sanitized = bu_names._BLENDER_PRIM_UNSAFE.sub("_", name)
        for prefix in ("MI_" + sanitized, "M_" + sanitized, sanitized):
            prefixes[prefix.lower()] = (name, value)

    # Pass one: find which instances belong to which material. No writes yet — the decision to
    # apply at all depends on what this pass turns up.
    targets = []
    matched_names = set()
    for path in unreal.EditorAssetLibrary.list_assets(content_path, recursive=True):
        asset = unreal.EditorAssetLibrary.load_asset(path)
        if not isinstance(asset, unreal.MaterialInstanceConstant):
            continue
        name = asset.get_name().lower()
        for prefix, (source, candidate) in prefixes.items():
            if name == prefix or name.startswith(prefix + "_"):
                targets.append((asset, candidate))
                matched_names.add(source)
                break

    # The question is not "do all the values agree" — that would refuse a scene where glass at
    # 0.25 and bubbles at 0.12 keep their own instances (they differ in colour and roughness, so
    # USD keeps them apart) merely because some pupils merged among themselves at 0.0.
    #
    # What matters is only the materials that actually vanished into someone else:
    #   * if they disagree with each other, at least one is landing on an instance that wants a
    #     different opacity;
    #   * if one of their values matches no surviving instance, it certainly merged into an
    #     instance that wants something else.
    # Either way BU cannot say which, so it says nothing and leaves them opaque.
    merged_away = sorted(set(wanted) - matched_names)
    merged_values = {wanted[name] for name in merged_away}
    matched_values = {value for name, value in wanted.items() if name in matched_names}
    if merged_away and (len(merged_values) > 1 or not merged_values <= matched_values):
        unreal.log_warning(
            "BU: {0} material(s) carry a flat alpha that USD drops, and {1} of them ({2}) "
            "arrived merged into another instance because they differ from it only in alpha. "
            "Their opacity ({3}) cannot be matched to a surviving instance, so BU is leaving "
            "them opaque rather than guessing. Give each a distinct base colour, roughness or "
            "texture to keep them separate.".format(
                len(wanted), len(merged_away), ", ".join(merged_away[:6]),
                ", ".join(str(v) for v in sorted(merged_values)),
            )
        )
        return 0, 0
    if merged_away:
        unreal.log(
            "BU: {0} flat-alpha material(s) merged into others ({1}); every one wants opacity "
            "{2}, which a surviving instance also wants, so the result is the same either "
            "way.".format(
                len(merged_away), ", ".join(merged_away[:6]),
                ", ".join(str(v) for v in sorted(merged_values))))

    applied, failed = 0, 0
    for asset, value in targets:
        try:
            library = unreal.MaterialEditingLibrary
            library.set_material_instance_scalar_parameter_value(asset, "Opacity", value)
            # The scalar only reaches the shader when the texture switch is off; an imported
            # instance may have it on from a bound OpacityTexture that is not really driving it.
            library.set_material_instance_scalar_parameter_value(asset, "UseOpacityTexture", 0.0)

            overrides = asset.get_editor_property("base_property_overrides")
            overrides.set_editor_property("override_blend_mode", True)
            overrides.set_editor_property("blend_mode", unreal.BlendMode.BLEND_TRANSLUCENT)
            asset.set_editor_property("base_property_overrides", overrides)
            library.update_material_instance(asset)
            unreal.EditorAssetLibrary.save_loaded_asset(asset, only_if_is_dirty=False)
            applied += 1
            unreal.log("BU: {0} -> opacity {1} (constant alpha, which USD drops)".format(
                asset.get_name(), value))
        except Exception as exc:  # noqa: BLE001
            failed += 1
            unreal.log_warning("BU: could not set constant opacity on '{0}' ({1})".format(
                asset.get_name(), exc))

    unreal.log(
        "BU: constant-alpha pass — {0} instance(s) given a flat opacity, {1} failed".format(
            applied, failed))
    return applied, failed


def fix_alpha_blending(content_path, manifest):
    """Switch cutout materials from translucent blending to alpha clip.

    Unreal's `IsMaterialTranslucent` returns true for **any** texture-driven opacity,
    regardless of `opacityThreshold`, so every alpha-linked material gets a
    `UsdPreviewSurfaceTranslucent` parent. Translucent surfaces do not depth-sort, so a
    Minecraft skin renders as smeared, dark, self-overlapping garbage.

    Authoring `opacityThreshold` in the USD would not help — the decision ignores it. There is
    no "masked" reference material either. So override the blend mode on the *instance*:
    `BLEND_Masked` plus an opacity mask clip value, which gives proper alpha clip and restores
    sorting.

    Only materials Blender marked as cutout are touched. `surface_render_method == "BLENDED"`
    means the artist wanted real transparency (glass, water), and those stay translucent.
    """
    wanted = {}
    for entry in manifest.data.get("materials", []):
        alpha = entry.get("alpha") or {}
        if alpha.get("uses_alpha") and alpha.get("unreal_blend") == "Masked":
            wanted[entry["name"]] = float(alpha.get("alpha_threshold", 0.5))

    if not wanted:
        return 0, 0

    # Every variant of a material shares its base name: MI_skin, MI_skin_4_TwoSided, ...
    prefixes = {}
    for name, threshold in wanted.items():
        sanitized = bu_names._BLENDER_PRIM_UNSAFE.sub("_", name)
        for prefix in ("MI_" + sanitized, "M_" + sanitized, sanitized):
            prefixes[prefix.lower()] = threshold

    masked = 0
    skipped_translucent = 0
    fixed_textures = set()
    for path in unreal.EditorAssetLibrary.list_assets(content_path, recursive=True):
        asset = unreal.EditorAssetLibrary.load_asset(path)
        if not isinstance(asset, unreal.MaterialInstanceConstant):
            continue

        name = asset.get_name().lower()
        threshold = None
        for prefix, value in prefixes.items():
            if name == prefix or name.startswith(prefix + "_"):
                threshold = value
                break
        if threshold is None:
            continue

        try:
            # Reparenting is the part that actually clips. Setting BLEND_MASKED on a
            # UsdPreviewSurface instance does nothing at all -- every variant is an instance of
            # one shared graph whose OpacityMask input is unconnected, so a Masked material
            # samples nothing and clips nothing. Proven with a two-cube repro: both parents,
            # both overridden to Masked, both rendered solid black across every alpha-0 region.
            # The blend/clip overrides below are still set, because they are what BU's own
            # masked material reads for its threshold.
            from . import bu_presets  # local: avoids a circular import at module load

            # If the material has already been adopted onto BU's surface, its parent is correct
            # and reparenting it back onto the older masked-only material would undo that.
            parent_name = asset.parent.get_name() if asset.parent else ""
            if parent_name.startswith("MI_BU_Surface"):
                masked_parent = None
            else:
                masked_parent = masked_parent_for(asset)
            if masked_parent is not None and (
                asset.parent is None
                or asset.parent.get_path_name() != masked_parent.get_path_name()
            ):
                dropped = [
                    name for name in bu_presets._CHANNELS_LOST_BY_MASKED
                    if _channel_is_real(asset, name, content_path)
                ]
                if dropped:
                    unreal.log_warning(
                        "BU: '{0}' has {1} bound, which BU's masked material does not carry; "
                        "that channel will stop contributing.".format(
                            asset.get_name(), ", ".join(dropped)
                        )
                    )
                asset.set_editor_property("parent", masked_parent)

            overrides = asset.get_editor_property("base_property_overrides")
            overrides.set_editor_property("override_blend_mode", True)
            overrides.set_editor_property("blend_mode", unreal.BlendMode.BLEND_MASKED)
            overrides.set_editor_property("override_opacity_mask_clip_value", True)
            overrides.set_editor_property("opacity_mask_clip_value", threshold)
            asset.set_editor_property("base_property_overrides", overrides)
            unreal.MaterialEditingLibrary.update_material_instance(asset)
            unreal.EditorAssetLibrary.save_loaded_asset(asset, only_if_is_dirty=False)
            masked += 1
        except Exception as exc:  # noqa: BLE001
            unreal.log_warning(
                "BU: could not set masked blend on '{0}' ({1})".format(asset.get_name(), exc)
            )

        # A masked material clips on a hard threshold, so its alpha must be exact. TC_DEFAULT
        # is BC3/DXT5: alpha is quantised across 4x4 blocks, and on a 64x64 skin that smears
        # binary alpha into gradients. Whole blocks then fall the wrong side of the threshold
        # and punch holes -- which is why "masked" has historically eaten characters' arms.
        # Mips do the same thing as objects recede. The source alpha here is verified binary
        # (0 or 1, no partial values), so the only lossy step is Unreal's own compression.
        library = unreal.MaterialEditingLibrary
        opacity_texture = library.get_material_instance_texture_parameter_value(
            asset, "OpacityTexture"
        )
        use_opacity = library.get_material_instance_scalar_parameter_value(
            asset, "UseOpacityTexture"
        )

        # Only touch a texture that is actually driving opacity. Unreal binds shared
        # placeholders like `127grey` when a channel is unused, and those live outside the
        # imported folder -- making one uncompressed would waste memory globally and affect
        # every other material that references it.
        placeholder = opacity_texture is not None and content_path not in opacity_texture.get_path_name()
        if placeholder:
            unreal.log(
                "BU: leaving shared texture '{0}' alone (not part of this import)".format(
                    opacity_texture.get_name()
                )
            )

        if (
            opacity_texture is not None
            and not placeholder
            and use_opacity
            and use_opacity >= 1.0
            and opacity_texture.get_path_name() not in fixed_textures
        ):
            try:
                opacity_texture.set_editor_property(
                    "compression_settings", unreal.TextureCompressionSettings.TC_EDITOR_ICON
                )
                opacity_texture.set_editor_property(
                    "mip_gen_settings", unreal.TextureMipGenSettings.TMGS_NO_MIPMAPS
                )
                unreal.EditorAssetLibrary.save_loaded_asset(opacity_texture, only_if_is_dirty=False)
                fixed_textures.add(opacity_texture.get_path_name())
                unreal.log(
                    "BU: {0} -> uncompressed, no mips (exact alpha for masking)".format(
                        opacity_texture.get_name()
                    )
                )
            except Exception as exc:  # noqa: BLE001
                unreal.log_warning(
                    "BU: could not make '{0}' alpha-exact ({1})".format(
                        opacity_texture.get_name(), exc
                    )
                )

    unreal.log(
        "BU: alpha pass — {0} instance(s) masked/alpha-clip, {1} opacity texture(s) made "
        "alpha-exact, {2} left translucent by intent".format(
            masked, len(fixed_textures), skipped_translucent
        )
    )
    return masked, skipped_translucent


def refresh_render_state(content_path):
    """Force components to pick up material parameter values.

    Setting parameters on a `UMaterialInstanceConstant` does **not** by itself update what
    already-registered components render — they keep drawing the pre-change state. Proven with a
    minimal one-cube scene: making a material fully emissive with a bright checker texture
    produced *no visible change* until the material was recompiled and reassigned to the
    component, after which the texture appeared correctly and immediately.

    This matters on import because Unreal's USD importer creates components and sets material
    parameters in an order that can leave the components rendering stale, flat-looking
    materials. Reassigning the same material is enough to re-register it.
    """
    recompiled = set()
    reassigned = 0

    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    for actor in subsystem.get_all_level_actors():
        # PrimitiveComponent, not StaticMeshComponent: a rigged character is a
        # SkeletalMeshComponent and a deforming mesh is a GeometryCacheUsdComponent, so a
        # StaticMesh-only sweep silently skips exactly the objects most likely to look wrong.
        for component in actor.get_components_by_class(unreal.PrimitiveComponent):
            for index in range(component.get_num_materials()):
                material = component.get_material(index)
                if material is None:
                    continue
                if content_path not in material.get_path_name():
                    continue

                # Recompile each base material once -- it is shared by every instance.
                try:
                    base = material.get_base_material()
                    if base is not None and base.get_path_name() not in recompiled:
                        unreal.MaterialEditingLibrary.recompile_material(base)
                        recompiled.add(base.get_path_name())
                except Exception:  # noqa: BLE001
                    pass

                # Reassigning the identical material re-registers it with the renderer.
                try:
                    component.set_material(index, material)
                    reassigned += 1
                except Exception:  # noqa: BLE001
                    pass

    unreal.log(
        "BU: refreshed render state — {0} base material(s) recompiled, {1} component slot(s) "
        "reassigned".format(len(recompiled), reassigned)
    )
    return len(recompiled), reassigned


def wire_materials(content_path, manifest):
    """Bind every texture the manifest assigns to a channel. Returns (bound, problems)."""
    textures, materials = _load_assets(content_path)
    tex_index = _texture_index(textures, manifest)
    mat_index = _material_index(materials)

    bound_count = 0
    already_count = 0
    problems = []
    touched = set()

    for material_entry in manifest.data.get("materials", []):
        name = material_entry["name"]
        assignments = material_entry.get("textures", [])
        if not assignments:
            continue

        material = _find_material(material_entry, mat_index)
        if material is None:
            problems.append(
                "No imported material found for '{0}' (tried {1})".format(
                    name, bu_names.material_name_candidates(material_entry)
                )
            )
            continue

        if not isinstance(material, unreal.MaterialInstanceConstant):
            problems.append(
                "'{0}' imported as {1}, not a material instance; cannot bind parameters. "
                "Its textures were still imported and filtered correctly.".format(
                    name, type(material).__name__
                )
            )
            continue

        for assignment in assignments:
            channel = assignment.get("channel") or ""
            key = assignment.get("texture", "")

            if channel not in KNOWN_CHANNELS:
                problems.append(
                    "'{0}' uses texture '{1}' in a way BU could not trace to a known "
                    "channel; bind it by hand if needed.".format(name, key)
                )
                continue

            texture = tex_index.get(key)
            if texture is None:
                problems.append(
                    "Texture '{0}' for material '{1}' was not found among imported "
                    "assets.".format(key, name)
                )
                continue

            result = _bind_channel(material, channel, texture)

            if result == "already":
                already_count += 1
            elif result == "bound":
                bound_count += 1
                touched.add(material)
                unreal.log("BU: {0}.{1}Texture <- {2}".format(name, channel, texture.get_name()))
            elif result == "no-parameter":
                problems.append(
                    "Parent material of '{0}' ({1}) has no '{2}Texture' parameter.".format(
                        name, material.get_name(), channel
                    )
                )
            else:
                problems.append(
                    "Could not bind {0}Texture on '{1}'.".format(channel, material.get_name())
                )

    for material in touched:
        unreal.MaterialEditingLibrary.update_material_instance(material)
        unreal.EditorAssetLibrary.save_loaded_asset(material, only_if_is_dirty=False)

    unreal.log(
        "BU: material pass complete — {0} bindings added, {1} already correct, {2} materials "
        "changed, {3} problems".format(bound_count, already_count, len(touched), len(problems))
    )
    if already_count and not bound_count:
        unreal.log(
            "BU: Unreal's USD importer had already wired every material correctly, so nothing "
            "needed changing. If the scene still looks untextured, it is not a material "
            "binding problem — check the viewport view mode (Lit vs Lighting Only)."
        )
    for problem in problems:
        unreal.log_warning("BU: " + problem)

    return bound_count, problems


def _load_all_partitioned_actors():
    """Load every World Partition actor so an actor scan sees the whole level.

    Returns the number of actors it had to load, or None if the level has unloaded actors that
    could not be loaded -- in which case a caller that reasons about "unused" must give up rather
    than guess.

    A non-partitioned level needs nothing: everything is already loaded, so this returns 0.
    """
    try:
        library = unreal.WorldPartitionBlueprintLibrary
        # list() forces iteration now: a non-partitioned level (or an engine without this API)
        # fails here rather than part-way through, and "no partition data" means nothing to load.
        descs = list(library.get_actor_descs())
    except Exception:  # noqa: BLE001 - not a World Partition level, or no such API
        return 0
    if not descs:
        return 0

    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    loaded_names = {a.get_name() for a in subsystem.get_all_level_actors()}
    missing = [d for d in descs if str(d.name) not in loaded_names]
    if not missing:
        return 0

    try:
        library.load_actors([d.guid for d in missing])
    except Exception as exc:  # noqa: BLE001
        unreal.log_warning("BU: could not load streamed-out actors ({0})".format(exc))
        return None

    now_loaded = {a.get_name() for a in subsystem.get_all_level_actors()}
    remaining = [d for d in missing if str(d.name) not in now_loaded]

    # Landscape streaming proxies and HLOD actors never load as ordinary actors, and they cannot
    # reference an imported material -- their materials are the landscape's own. Requiring them
    # would mean never pruning again in any World Partition level, so exclude them by class and
    # bail only on content actors that genuinely could hold a reference.
    blocking = [d for d in remaining if not any(
        marker in str(d.native_class)
        for marker in ("LandscapeStreamingProxy", "LandscapeProxy", "WorldPartitionHLOD")
    )]
    if blocking:
        unreal.log_warning(
            "BU: {0} content actor(s) remain unloaded after asking World Partition to load "
            "them, e.g. {1}".format(
                len(blocking), ", ".join(str(d.label) for d in blocking[:3])
            )
        )
        return None
    if remaining:
        unreal.log(
            "BU: {0} landscape/HLOD actor(s) stayed unloaded; they cannot reference imported "
            "materials, so this does not affect the prune".format(len(remaining))
        )

    unreal.log(
        "BU: loaded {0} streamed-out World Partition actor(s) so the whole level is "
        "visible".format(len(missing))
    )
    return len(missing)


def prune_material_variants(content_path, dry_run=False):
    """Delete the one-sided material instances Unreal made but nothing uses.

    Unreal's USD importer creates a material instance per *sidedness* it encounters, so a single
    Blender material arrives as both `MI_stone` and `MI_stone_4_TwoSided`. Blender leaves backface
    culling off by default, which makes every mesh double-sided, so in practice the TwoSided variant
    is the one assigned to every component and the plain one is dead weight.

    Measured on a real scene: **195 instances, 98 plain and 97 TwoSided — and all 97 unused ones
    were plain**, every TwoSided variant being in use. There is no import option to suppress this,
    so the fix is to prune afterwards.

    Safe because the variants are independent siblings: a TwoSided instance parents to a *reference
    material*, never to the plain instance, so removing one cannot orphan the other. Anything with a
    package referencer is skipped regardless.

    Returns (deleted, kept_because_used, kept_because_referenced).
    """
    instances = {}
    for path in unreal.EditorAssetLibrary.list_assets(content_path, recursive=True):
        asset = unreal.EditorAssetLibrary.load_asset(path)
        if isinstance(asset, unreal.MaterialInstanceConstant):
            instances[asset.get_name()] = path

    if not instances:
        unreal.log("BU: no material instances under {0}".format(content_path))
        return 0, 0, 0

    # In a World Partition level, `get_all_level_actors()` returns only the actors currently
    # *loaded*. Judging "unused" from that set would delete materials that streamed-out actors
    # still render, and the damage would only surface when those cells load again. Observed for
    # real: saving a World Partition level streamed the imported cameras and sequence actor out,
    # after which they were invisible to every actor scan while existing perfectly well on disk.
    unloaded = _load_all_partitioned_actors()
    if unloaded is None:
        unreal.log_warning(
            "BU: this level has actors that are not loaded and they could not be loaded, so "
            "'unused' cannot be judged safely. Skipping the material variant prune rather than "
            "risk deleting a material a streamed-out actor still uses."
        )
        return 0, 0, 0

    # What is actually assigned to something in the level?
    assigned = set()
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    for actor in subsystem.get_all_level_actors():
        try:
            components = actor.get_components_by_class(unreal.PrimitiveComponent)
        except Exception:  # noqa: BLE001
            continue
        for component in components:
            for index in range(component.get_num_materials()):
                material = component.get_material(index)
                if material is not None:
                    assigned.add(material.get_name())

    deleted = kept_used = kept_referenced = 0
    for name, path in sorted(instances.items()):
        if name.endswith("_TwoSided"):
            continue  # Only ever prune the plain side; the TwoSided one is what gets used.
        if name in assigned:
            kept_used += 1
            continue

        # Only prune when a TwoSided sibling exists -- otherwise this is the only copy of the
        # material and something may reference it in a way this sweep cannot see.
        siblings = [n for n in instances if n != name and n.startswith(name) and
                    n.endswith("_TwoSided")]
        if not siblings:
            kept_used += 1
            continue

        try:
            referencers = unreal.EditorAssetLibrary.find_package_referencers_for_asset(path, False)
        except Exception:  # noqa: BLE001
            referencers = []
        if referencers:
            kept_referenced += 1
            unreal.log(
                "BU: keeping '{0}' — still referenced by {1}".format(name, len(referencers))
            )
            continue

        if dry_run:
            unreal.log("BU: would delete unused variant '{0}' (kept {1})".format(
                name, siblings[0]))
            deleted += 1
            continue

        if unreal.EditorAssetLibrary.delete_asset(path):
            deleted += 1
        else:
            kept_referenced += 1

    unreal.log(
        "BU: material variant prune{0} — {1} unused one-sided instance(s) removed, {2} kept "
        "(in use), {3} kept (still referenced)".format(
            " [DRY RUN]" if dry_run else "", deleted, kept_used, kept_referenced
        )
    )
    return deleted, kept_used, kept_referenced


# BU authors its own masked material because Unreal has none that works.
#
# `/USDCore/Materials` contains exactly two real `Material` assets -- `UsdPreviewSurface` and
# `UsdPreviewSurfaceVT`. Everything that looks like a variant (`UsdPreviewSurfaceTranslucent`,
# `...TwoSided`, `...TranslucentTwoSidedVT`) is a **MaterialInstanceConstant** of that one graph
# with base property overrides. Epic ships no Masked variant, and that is the tell: the shared
# graph connects `Opacity` but leaves **`OpacityMask` unconnected**.
#
# A Material reads `Opacity` when its blend mode is Translucent and `OpacityMask` when it is
# Masked. Overriding an instance to `BLEND_MASKED` therefore samples an unconnected input, which
# constant-folds to 1.0, and *nothing is ever clipped*.
#
# Proven with a minimal repro: two cubes, one parented to the Translucent instance and one to the
# opaque instance, both overridden to BLEND_MASKED, both textured with a 64x64 skin whose alpha is
# perfectly binary. Both rendered **solid black across every alpha-0 region** with the sky not
# visible through them. That is the mechanism behind "when a model has alpha it kinda just dies",
# the arm second-layer showing when it should be invisible, and the mystery black cubes.
BU_MATERIAL_PACKAGE = "/Game/BU/Materials"
BU_MASKED_MATERIAL = "M_BU_MaskedSurface"
BU_MASKED_TWO_SIDED = "MI_BU_MaskedSurface_TwoSided"


def _masked_material_path():
    return "{0}/{1}.{1}".format(BU_MATERIAL_PACKAGE, BU_MASKED_MATERIAL)


def _masked_two_sided_path():
    return "{0}/{1}.{1}".format(BU_MATERIAL_PACKAGE, BU_MASKED_TWO_SIDED)


def _add_emissive(material, library, black):
    """Wire an optional emissive channel: EmissiveColorTexture * UseEmissiveColorTexture.

    Voxel scenes are full of surfaces that are cutout *and* glowing -- lava, glowstone, torches,
    sea lanterns -- and reparenting those onto a BaseColor-only masked material silently killed the
    glow. Measured on a real scene: `MI_lava_still` lost its `EmissiveColorTexture`.

    The scalar gate matters as much as the texture. Defaulting the texture to black would work, but
    the scalar keeps the parameter names identical to Unreal's UsdPreviewSurface, so
    `wire_materials` and the Emissive preset drive this material with no special-casing. It
    defaults to 0, so nothing glows until something asks it to.
    """
    texture = library.create_material_expression(
        material, unreal.MaterialExpressionTextureSampleParameter2D, -400, 500
    )
    texture.set_editor_property("parameter_name", "EmissiveColorTexture")
    if black is not None:
        texture.set_editor_property("texture", black)

    switch = library.create_material_expression(
        material, unreal.MaterialExpressionScalarParameter, -400, 700
    )
    switch.set_editor_property("parameter_name", "UseEmissiveColorTexture")
    switch.set_editor_property("default_value", 0.0)

    multiply = library.create_material_expression(
        material, unreal.MaterialExpressionMultiply, -180, 560
    )
    library.connect_material_expressions(texture, "RGB", multiply, "A")
    library.connect_material_expressions(switch, "", multiply, "B")
    library.connect_material_property(multiply, "", unreal.MaterialProperty.MP_EMISSIVE_COLOR)


def ensure_masked_material():
    """Create, once, a material whose OpacityMask really is connected.

    Parameter names deliberately mirror Unreal's own UsdPreviewSurface (`BaseColorTexture`,
    `OpacityTexture`) so an instance reparented onto this keeps every texture binding the importer
    already made -- material instance overrides are keyed by name, so nothing has to be re-bound.

    Returns (material, two_sided_instance), or (None, None) if it could not be built.
    """
    existing = unreal.EditorAssetLibrary.load_asset(_masked_material_path())
    if existing is not None:
        # An earlier build of this material had no emissive channel. Rebuild rather than return a
        # material that would silently drop the glow from lava, glowstone and torches.
        try:
            params = {
                str(n) for n in unreal.MaterialEditingLibrary.get_texture_parameter_names(existing)
            }
        except Exception:  # noqa: BLE001
            params = {"EmissiveColorTexture"}
        if "EmissiveColorTexture" in params:
            return existing, unreal.EditorAssetLibrary.load_asset(_masked_two_sided_path())

        # Upgrade in place. Deleting and recreating would orphan every material instance already
        # parented to this one, so add the missing channel to the existing graph instead.
        unreal.log(
            "BU: adding the emissive channel to {0} (in place, so existing instances keep their "
            "parent)".format(BU_MASKED_MATERIAL)
        )
        library = unreal.MaterialEditingLibrary
        _add_emissive(
            existing, library, unreal.EditorAssetLibrary.load_asset(
                "/Engine/EngineResources/Black")
        )
        library.recompile_material(existing)
        unreal.EditorAssetLibrary.save_loaded_asset(existing, only_if_is_dirty=False)
        return existing, unreal.EditorAssetLibrary.load_asset(_masked_two_sided_path())

    tools = unreal.AssetToolsHelpers.get_asset_tools()
    material = tools.create_asset(
        BU_MASKED_MATERIAL, BU_MATERIAL_PACKAGE, unreal.Material, unreal.MaterialFactoryNew()
    )
    if material is None:
        unreal.log_error("BU: could not create {0}".format(_masked_material_path()))
        return None, None

    library = unreal.MaterialEditingLibrary

    # A texture parameter with no default compiles against Unreal's checkerboard placeholder, so
    # the material renders the checker and -- worse -- masks against that placeholder's opaque
    # alpha, clipping nothing. Verified: the first build of this material produced exactly that.
    # White is the right default: alpha 1 everywhere means "fully opaque until told otherwise".
    default_texture = unreal.EditorAssetLibrary.load_asset(
        "/Engine/EngineResources/WhiteSquareTexture"
    )

    base = library.create_material_expression(
        material, unreal.MaterialExpressionTextureSampleParameter2D, -400, -200
    )
    base.set_editor_property("parameter_name", "BaseColorTexture")
    if default_texture is not None:
        base.set_editor_property("texture", default_texture)

    opacity = library.create_material_expression(
        material, unreal.MaterialExpressionTextureSampleParameter2D, -400, 200
    )
    opacity.set_editor_property("parameter_name", "OpacityTexture")
    if default_texture is not None:
        opacity.set_editor_property("texture", default_texture)

    library.connect_material_property(base, "RGB", unreal.MaterialProperty.MP_BASE_COLOR)
    # The whole point: alpha drives OPACITY_MASK, the input a Masked material actually reads.
    library.connect_material_property(opacity, "A", unreal.MaterialProperty.MP_OPACITY_MASK)

    _add_emissive(material, library, unreal.EditorAssetLibrary.load_asset(
        "/Engine/EngineResources/Black"))

    material.set_editor_property("blend_mode", unreal.BlendMode.BLEND_MASKED)
    library.recompile_material(material)
    unreal.EditorAssetLibrary.save_loaded_asset(material, only_if_is_dirty=False)

    two_sided = tools.create_asset(
        BU_MASKED_TWO_SIDED, BU_MATERIAL_PACKAGE, unreal.MaterialInstanceConstant,
        unreal.MaterialInstanceConstantFactoryNew(),
    )
    if two_sided is not None:
        two_sided.set_editor_property("parent", material)
        overrides = two_sided.get_editor_property("base_property_overrides")
        overrides.set_editor_property("override_two_sided", True)
        overrides.set_editor_property("two_sided", True)
        two_sided.set_editor_property("base_property_overrides", overrides)
        library.update_material_instance(two_sided)
        unreal.EditorAssetLibrary.save_loaded_asset(two_sided, only_if_is_dirty=False)

    unreal.log(
        "BU: created {0} — a masked material with OpacityMask connected, which Unreal's "
        "UsdPreviewSurface does not have".format(_masked_material_path())
    )
    return material, two_sided


def masked_parent_for(instance):
    """The BU masked material matching this instance's sidedness, creating it if needed."""
    material, two_sided = ensure_masked_material()
    if material is None:
        return None

    wants_two_sided = "TwoSided" in (instance.parent.get_name() if instance.parent else "")
    if not wants_two_sided:
        try:
            overrides = instance.get_editor_property("base_property_overrides")
            wants_two_sided = bool(overrides.get_editor_property("two_sided"))
        except Exception:  # noqa: BLE001
            pass
    if wants_two_sided and two_sided is not None:
        return two_sided
    return material
