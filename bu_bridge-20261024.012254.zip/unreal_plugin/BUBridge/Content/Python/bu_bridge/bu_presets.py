# SPDX-License-Identifier: GPL-3.0-or-later
"""One-click material presets for voxel art, applied from the Content Browser right-click menu.

Almost every material fault in this pipeline has been the same shape: Unreal picked the wrong
*render state* for a kind of block. It cannot know the difference between glass, leaves and a
character's skin -- they are all "a texture with an alpha channel" -- so it makes one conservative
guess and gets most of them wrong.

The specific trap, verified in the engine source: `IsMaterialTranslucent` returns true for **any**
texture-driven opacity and ignores `opacityThreshold` entirely. So a stone block whose texture
merely *has* an alpha channel gets a `UsdPreviewSurfaceTranslucent` parent, loses depth sorting,
and renders as smeared self-overlapping garbage. Authoring the threshold in the USD does not help,
and there is no "masked" reference material to point at.

Minecraft-style content falls into a handful of archetypes, and each needs a specific combination
of blend mode, clip threshold, sidedness and texture compression. That is exactly what a preset
is for -- and per-material, because the right answer differs between two materials in the same
import.

Two rules the presets exist to enforce, both learned expensively:

* **A masked material's alpha must be uncompressed.** `TC_DEFAULT` is BC3/DXT5, which quantises
  alpha across 4x4 blocks. On a 64x64 skin that smears binary alpha into gradients, whole blocks
  fall the wrong side of the threshold, and holes appear -- which is why "masked" has historically
  eaten characters' arms. Mips do the same thing as an object recedes.
* **Parameter changes alone do not update what is already on screen.** Components keep drawing the
  pre-change state until the material is recompiled and reassigned, so every preset ends with a
  render-state refresh. Three separate "that made no difference" conclusions were stale renders.
"""

import unreal

# Never modify a texture outside /Game/. Unreal binds shared placeholders (`127grey`,
# `WhiteSquareTexture`, `BaseFlattenNormalMap`) for unused channels, and those live in /Engine/.
# Making one of those uncompressed would waste memory globally and change every other material in
# the project that references it -- a mistake already made once here, on
# /Engine/ArtTools/RenderToTexture/Textures/127grey.
SAFE_TEXTURE_ROOT = "/Game/"

# Channels whose texture a preset may retune.
OPACITY_PARAM = "OpacityTexture"
BASE_COLOR_PARAM = "BaseColorTexture"
EMISSIVE_PARAM = "EmissiveColorTexture"
USE_OPACITY_PARAM = "UseOpacityTexture"

# Unreal's opaque reference materials do have Opacity parameters, but nothing drives the Opacity
# output, so overriding the blend mode on one produces a surface that is still solid. Measured on a
# real glass pane: BLEND_TRANSLUCENT applied correctly, Opacity constant 1.0, rendered opaque.
# Reparenting to the Translucent counterpart is what actually makes transparency possible.
REFERENCE_MATERIAL_ROOT = "/USDCore/Materials"
_SURFACE_PREFIX = "UsdPreviewSurface"


PRESETS = {
    "solid": {
        "label": "Solid Block (opaque)",
        "tooltip": (
            "Force fully opaque. Use for stone, dirt, planks, wool — any block with no "
            "transparency. Fixes the common case where Unreal chose translucent just because "
            "the texture has an alpha channel, which costs depth sorting and performance."
        ),
        "blend": "opaque",
        "scalars": {"UseOpacityTexture": 0.0, "Opacity": 1.0},
        "two_sided": False,
    },
    "cutout": {
        "label": "Cutout — Leaves / Grass / Glass Pane",
        "tooltip": (
            "Alpha-clipped and two-sided, with exact (uncompressed, mip-free) alpha. Use for "
            "leaves, tall grass, ladders, glass panes, flowers — anything that is either fully "
            "there or fully absent, and is thin enough to be seen from both sides."
        ),
        "blend": "masked",
        "clip": 0.333,
        "two_sided": True,
        "alpha_exact": True,
        "needs_opacity": "mask",
    },
    "character": {
        "label": "Character Skin (masked alpha)",
        "tooltip": (
            "Alpha-clipped at 0.5, two-sided, exact alpha. Use for skins and their overlay "
            "layers (hat / jacket / sleeve). Two-sided matters because the second layer is a "
            "shell only fractionally larger than the body."
        ),
        "blend": "masked",
        "clip": 0.5,
        "two_sided": True,
        "alpha_exact": True,
        "needs_opacity": "mask",
    },
    "glass": {
        "label": "Glass / Ice (translucent)",
        "tooltip": (
            "Real partial transparency, two-sided. Use for stained glass, ice and water, where "
            "you want to see through the surface rather than through holes in it. Prefer the "
            "Cutout preset for plain glass, which is binary and sorts properly."
        ),
        "blend": "translucent",
        "two_sided": True,
        "needs_opacity": "blend",
    },
    "emissive": {
        "label": "Emissive (glowstone / lava / torch)",
        "tooltip": (
            "Drive emission from the base colour texture so the block glows its own colours. "
            "Use for glowstone, lava, sea lanterns, torches, magma. Lighting still comes from "
            "your own lights — this only makes the surface itself bright."
        ),
        "emissive_from_base": True,
        "scalars": {"UseEmissiveColorTexture": 1.0},
    },
    "reset": {
        "label": "Clear BU Overrides",
        "tooltip": (
            "Remove every blend / sidedness override BU or a preset applied, returning the "
            "instance to whatever its parent material says. Texture compression is left alone."
        ),
        "reset": True,
    },
}

# Menu order — presets are a dict, and the most-used ones should come first.
PRESET_ORDER = ("solid", "cutout", "character", "glass", "emissive", "reset")

_BLEND_MODES = {
    "opaque": "BLEND_OPAQUE",
    "masked": "BLEND_MASKED",
    "translucent": "BLEND_TRANSLUCENT",
}


def _blend_mode(name):
    return getattr(unreal.BlendMode, _BLEND_MODES[name])


def selected_material_instances():
    """Material instances currently selected in the Content Browser."""
    try:
        selected = unreal.EditorUtilityLibrary.get_selected_assets()
    except Exception:  # noqa: BLE001
        return []
    return [a for a in selected if isinstance(a, unreal.MaterialInstanceConstant)]


def _texture_param(instance, param):
    try:
        return unreal.MaterialEditingLibrary.get_material_instance_texture_parameter_value(
            instance, param
        )
    except Exception:  # noqa: BLE001
        return None


def _is_safe_to_retune(texture):
    """True when a texture belongs to the project rather than being a shared engine placeholder."""
    return texture is not None and texture.get_path_name().startswith(SAFE_TEXTURE_ROOT)


def _make_alpha_exact(texture, done):
    """Uncompressed, mip-free — so a hard alpha threshold cuts where the artist drew it."""
    key = texture.get_path_name()
    if key in done:
        return False
    texture.set_editor_property(
        "compression_settings", unreal.TextureCompressionSettings.TC_EDITOR_ICON
    )
    texture.set_editor_property("mip_gen_settings", unreal.TextureMipGenSettings.TMGS_NO_MIPMAPS)
    unreal.EditorAssetLibrary.save_loaded_asset(texture, only_if_is_dirty=False)
    done.add(key)
    return True


def _translucent_counterpart(parent):
    """The Translucent sibling of a reference material, or None if it needs no change.

    `UsdPreviewSurfaceTwoSided` -> `UsdPreviewSurfaceTranslucentTwoSided`, keeping any `TwoSided`
    or `VT` suffix, because losing sidedness while gaining transparency trades one bug for another.
    """
    if parent is None:
        return None
    name = parent.get_name()
    if "Translucent" in name or not name.startswith(_SURFACE_PREFIX):
        return None

    suffix = name[len(_SURFACE_PREFIX):]
    wanted = "{0}Translucent{1}".format(_SURFACE_PREFIX, suffix)
    path = "{0}/{1}.{1}".format(REFERENCE_MATERIAL_ROOT, wanted)
    if not unreal.EditorAssetLibrary.does_asset_exist(path):
        return None
    return unreal.EditorAssetLibrary.load_asset(path)


def _ensure_translucent_parent(instance):
    """Reparent to a Translucent reference material so opacity can actually take effect."""
    replacement = _translucent_counterpart(instance.parent)
    if replacement is None:
        return []
    previous = instance.parent.get_name()
    try:
        instance.set_editor_property("parent", replacement)
    except Exception as exc:  # noqa: BLE001
        unreal.log_warning("BU: could not reparent '{0}' ({1})".format(instance.get_name(), exc))
        return []
    return ["reparented {0} -> {1}".format(previous, replacement.get_name())]


# Channels BU's masked material does not carry. Reparenting a material that genuinely uses one of
# these would silently drop it, so say so rather than quietly losing work.
# Emissive is deliberately absent: BU's masked material carries it, because voxel scenes are full
# of surfaces that are both cutout and glowing (lava, glowstone, torches, sea lanterns).
_CHANNELS_LOST_BY_MASKED = (
    "NormalTexture", "RoughnessTexture", "MetallicTexture", "AmbientOcclusionTexture",
)


def _ensure_masked_parent(instance):
    """Reparent onto BU's masked material, the only one here that actually clips.

    Overriding an instance's blend mode to `BLEND_MASKED` does **nothing**, because every
    UsdPreviewSurface variant is an instance of one shared graph whose `OpacityMask` input is
    unconnected -- so a Masked material samples nothing and clips nothing. Proven with a two-cube
    repro: both parents, both overridden to Masked, both rendered solid black across every alpha-0
    region. BU's own material connects the alpha to `OpacityMask` and cuts correctly.

    Parameter names match Unreal's, so texture bindings carry over untouched.
    """
    from . import bu_materials

    parent = bu_materials.masked_parent_for(instance)
    if parent is None:
        unreal.log_warning(
            "BU: could not build a masked material; '{0}' will keep its current parent and "
            "will not clip".format(instance.get_name())
        )
        return []
    if instance.parent is not None and instance.parent.get_path_name() == parent.get_path_name():
        return []

    dropped = [
        name for name in _CHANNELS_LOST_BY_MASKED
        if _is_safe_to_retune(_texture_param(instance, name))
    ]
    if dropped:
        unreal.log_warning(
            "BU: '{0}' has {1} bound, which BU's masked material does not carry; that channel "
            "will stop contributing. Use the Glass preset instead if you need it.".format(
                instance.get_name(), ", ".join(dropped)
            )
        )

    previous = instance.parent.get_name() if instance.parent else "<none>"
    try:
        instance.set_editor_property("parent", parent)
    except Exception as exc:  # noqa: BLE001
        unreal.log_warning("BU: could not reparent '{0}' ({1})".format(instance.get_name(), exc))
        return []
    return ["reparented {0} -> {1} (real alpha clipping)".format(previous, parent.get_name())]


def _ensure_opacity_wired(instance):
    """Make sure something actually drives opacity.

    Unreal binds the shared `127grey` placeholder and leaves `UseOpacityTexture = 0` whenever the
    USD carried no opacity input -- which happens whenever the Blender material's Alpha socket was
    left unconnected. Measured: `glass_pane_top.001` had Alpha unlinked at a constant 1.0, so the
    pane arrived with no opacity at all and stayed solid however the blend mode was set.

    For voxel textures the transparency lives in the base colour texture's own alpha channel, so
    routing base colour into opacity is the correct repair rather than a guess.
    """
    existing = _texture_param(instance, OPACITY_PARAM)
    if _is_safe_to_retune(existing):
        # Already driven by a project texture; just be sure the switch is on.
        try:
            current = unreal.MaterialEditingLibrary.get_material_instance_scalar_parameter_value(
                instance, USE_OPACITY_PARAM
            )
        except Exception:  # noqa: BLE001
            current = None
        if current is not None and current >= 1.0:
            return []
        unreal.MaterialEditingLibrary.set_material_instance_scalar_parameter_value(
            instance, USE_OPACITY_PARAM, 1.0
        )
        return ["enabled {0}".format(USE_OPACITY_PARAM)]

    base = _texture_param(instance, BASE_COLOR_PARAM)
    if not _is_safe_to_retune(base):
        unreal.log_warning(
            "BU: '{0}' has no project texture to take opacity from, so it cannot be made "
            "transparent. Connect Alpha on the Blender material and re-export.".format(
                instance.get_name()
            )
        )
        return []

    unreal.MaterialEditingLibrary.set_material_instance_texture_parameter_value(
        instance, OPACITY_PARAM, base
    )
    unreal.MaterialEditingLibrary.set_material_instance_scalar_parameter_value(
        instance, USE_OPACITY_PARAM, 1.0
    )
    return ["opacity wired from {0} (Blender left Alpha unconnected)".format(base.get_name())]


def _apply_overrides(instance, preset):
    """Set the instance's base property overrides. Returns a list of what changed."""
    changed = []
    overrides = instance.get_editor_property("base_property_overrides")

    if preset.get("reset"):
        for flag in ("override_blend_mode", "override_opacity_mask_clip_value",
                     "override_two_sided"):
            try:
                overrides.set_editor_property(flag, False)
            except Exception:  # noqa: BLE001
                pass  # Not every engine version exposes every override flag.
        instance.set_editor_property("base_property_overrides", overrides)
        return ["cleared overrides"]

    blend = preset.get("blend")
    if blend:
        overrides.set_editor_property("override_blend_mode", True)
        overrides.set_editor_property("blend_mode", _blend_mode(blend))
        changed.append(blend)

    clip = preset.get("clip")
    if clip is not None:
        overrides.set_editor_property("override_opacity_mask_clip_value", True)
        overrides.set_editor_property("opacity_mask_clip_value", float(clip))
        changed.append("clip {0}".format(clip))

    two_sided = preset.get("two_sided")
    if two_sided is not None:
        try:
            overrides.set_editor_property("override_two_sided", True)
            overrides.set_editor_property("two_sided", bool(two_sided))
            changed.append("two-sided" if two_sided else "single-sided")
        except Exception:  # noqa: BLE001
            unreal.log_warning(
                "BU: this engine build does not expose a two-sided override; skipping that "
                "part of the preset"
            )

    instance.set_editor_property("base_property_overrides", overrides)
    return changed


def _apply_scalars(instance, preset):
    changed = []
    for param, value in (preset.get("scalars") or {}).items():
        try:
            unreal.MaterialEditingLibrary.set_material_instance_scalar_parameter_value(
                instance, param, float(value)
            )
            changed.append("{0}={1}".format(param, value))
        except Exception:  # noqa: BLE001
            pass  # A parent material without this parameter is not an error.
    return changed


def _apply_emissive(instance, preset):
    """Route the base colour texture into emission, so the surface glows its own colours."""
    if not preset.get("emissive_from_base"):
        return []
    base = _texture_param(instance, BASE_COLOR_PARAM)
    if not _is_safe_to_retune(base):
        unreal.log_warning(
            "BU: '{0}' has no project base-colour texture to emit from".format(instance.get_name())
        )
        return []
    try:
        unreal.MaterialEditingLibrary.set_material_instance_texture_parameter_value(
            instance, EMISSIVE_PARAM, base
        )
        return ["emissive from {0}".format(base.get_name())]
    except Exception as exc:  # noqa: BLE001
        unreal.log_warning("BU: could not set emissive on '{0}' ({1})".format(
            instance.get_name(), exc))
        return []


def refresh_instances(instances):
    """Re-register these materials with the renderer.

    Parameter changes do not update already-registered components; they keep drawing the previous
    state until the base material is recompiled and the material reassigned. Without this a preset
    appears to do nothing at all.
    """
    wanted = {i.get_path_name() for i in instances}
    recompiled = set()
    reassigned = 0

    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    for actor in subsystem.get_all_level_actors():
        try:
            components = actor.get_components_by_class(unreal.PrimitiveComponent)
        except Exception:  # noqa: BLE001
            continue  # Some level actors expose no components at all.
        for component in components:
            for index in range(component.get_num_materials()):
                material = component.get_material(index)
                if material is None or material.get_path_name() not in wanted:
                    continue
                try:
                    base = material.get_base_material()
                    if base is not None and base.get_path_name() not in recompiled:
                        unreal.MaterialEditingLibrary.recompile_material(base)
                        recompiled.add(base.get_path_name())
                except Exception:  # noqa: BLE001
                    pass
                try:
                    component.set_material(index, material)
                    reassigned += 1
                except Exception:  # noqa: BLE001
                    pass

    return len(recompiled), reassigned


def apply_preset(name, instances=None):
    """Apply a named preset. Defaults to the Content Browser selection.

    Returns (applied, failed).
    """
    preset = PRESETS.get(name)
    if preset is None:
        unreal.log_error("BU: no such material preset '{0}' (have: {1})".format(
            name, ", ".join(PRESET_ORDER)))
        return 0, 0

    if instances is None:
        instances = selected_material_instances()
    if not instances:
        unreal.log_warning(
            "BU: select one or more material instances in the Content Browser first "
            "(nothing to apply '{0}' to)".format(preset["label"])
        )
        return 0, 0

    applied = 0
    failed = 0
    retuned = set()

    for instance in instances:
        try:
            # Order matters: reparent and wire opacity *before* the overrides, so the blend mode
            # lands on a parent whose Opacity output is actually connected.
            changed = []
            mode = preset.get("needs_opacity")
            if mode == "mask":
                changed += _ensure_masked_parent(instance)
                changed += _ensure_opacity_wired(instance)
            elif mode == "blend":
                changed += _ensure_translucent_parent(instance)
                changed += _ensure_opacity_wired(instance)

            changed += _apply_overrides(instance, preset)
            changed += _apply_scalars(instance, preset)
            changed += _apply_emissive(instance, preset)

            if preset.get("alpha_exact"):
                texture = _texture_param(instance, OPACITY_PARAM)
                if _is_safe_to_retune(texture):
                    if _make_alpha_exact(texture, retuned):
                        changed.append("{0} uncompressed, no mips".format(texture.get_name()))
                elif texture is not None:
                    unreal.log(
                        "BU: leaving shared texture '{0}' alone (outside {1})".format(
                            texture.get_name(), SAFE_TEXTURE_ROOT
                        )
                    )

            unreal.MaterialEditingLibrary.update_material_instance(instance)
            unreal.EditorAssetLibrary.save_loaded_asset(instance, only_if_is_dirty=False)
            applied += 1
            unreal.log("BU: {0} -> {1} [{2}]".format(
                instance.get_name(), preset["label"], ", ".join(changed) or "no change"))
        except Exception as exc:  # noqa: BLE001
            failed += 1
            unreal.log_warning("BU: could not apply '{0}' to '{1}' ({2})".format(
                preset["label"], instance.get_name(), exc))

    recompiled, reassigned = refresh_instances(instances)
    unreal.log(
        "BU: preset '{0}' — {1} material(s) updated, {2} failed, {3} base material(s) "
        "recompiled, {4} component slot(s) refreshed".format(
            preset["label"], applied, failed, recompiled, reassigned
        )
    )
    return applied, failed
