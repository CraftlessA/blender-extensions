# SPDX-License-Identifier: GPL-3.0-or-later
"""One-call Blender-to-Unreal scene handoff.

Imports the USD, then applies everything USD could not carry: texture filtering, camera
filmback, and a Level Sequence with marker-driven camera cuts. The intent is that after
this runs the only thing left to do in Unreal is light the scene.
"""

import os

import unreal

from . import bu_manifest, bu_materials, bu_names, bu_sequence, bu_surface, bu_textures


def current_level_path():
    """Path of the open level, or "" if it cannot be read."""
    try:
        world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
    except Exception:  # noqa: BLE001
        return ""
    if world is None:
        return ""
    try:
        return str(world.get_path_name())
    except Exception:  # noqa: BLE001
        return ""


def level_is_unsaved(path=None):
    """True when the open level has never been saved to disk.

    Unreal names an unsaved level `/Temp/Untitled_N`. Importing into one *looks* fine -- the assets
    are created under /Game and survive -- but the **actors do not**: they live only in a level that
    has no file, so closing the editor or opening any other level throws the whole scene away.

    That happened repeatedly during development and cost an entire session: every import landed in
    `/Temp/Untitled_N`, and the artist eventually reported that they could not find their scene at
    all. Refusing is much kinder than discovering it later.
    """
    return (path if path is not None else current_level_path()).startswith("/Temp/")


def _import_options(manifest):
    options = unreal.UsdStageImportOptions()
    options.set_editor_property("import_actors", True)
    options.set_editor_property("import_geometry", True)
    options.set_editor_property("import_materials", True)

    # Explicit rather than relying on defaults: the generated Level Sequence is where the
    # animation lives, and it is also where BU adds the camera cut track.
    for prop in ("import_level_sequences", "import_skeletal_animations"):
        try:
            options.set_editor_property(prop, True)
        except Exception:  # noqa: BLE001 - property names vary across UE versions
            unreal.log_warning("BU: could not set import option '{0}'".format(prop))

    # Collect prim metadata so the filtering we embedded in the USD is visible on the
    # imported assets too. The sidecar is what we actually read, because Unreal gives a
    # texture the *material's* prim path rather than its own shader prim -- but having
    # both means the stage stays self-describing.
    try:
        metadata = options.get_editor_property("metadata_options")
        metadata.set_editor_property("collect_metadata", True)
        metadata.set_editor_property("collect_from_entire_subtrees", True)
        metadata.set_editor_property("collect_on_components", True)
    except Exception as exc:  # noqa: BLE001 - option layout differs across UE versions
        unreal.log_warning("BU: could not enable USD metadata collection ({0})".format(exc))

    # Unreal's SubdivisionLevel defaults to 0, which means "don't subdivide" -- so a stage
    # exported with catmullClark arrives as its blocky base cage. If Blender preserved the
    # subdivision rather than baking it, tell Unreal what level to use.
    if manifest is not None:
        subdiv = manifest.data.get("subdivision", {})
        if subdiv.get("export_mode") == "BEST_MATCH" and subdiv.get("max_render_level"):
            level = int(subdiv["max_render_level"])
            try:
                options.set_editor_property("subdivision_level", level)
                unreal.log("BU: set Unreal SubdivisionLevel to {0}".format(level))
            except Exception as exc:  # noqa: BLE001
                unreal.log_warning("BU: could not set subdivision_level ({0})".format(exc))

    if manifest is not None:
        try:
            options.set_editor_property("override_stage_options", True)
            stage_options = options.get_editor_property("stage_options")
            stage_options.set_editor_property("meters_per_unit", 1.0)
        except Exception:  # noqa: BLE001
            pass

    return options


def _actors_referencing(destination):
    """Every loaded level actor whose geometry or sequence comes from `destination`.

    Matches on the asset paths a component actually references, not on the actor's label: the
    label is derived from the USD file stem, so two different .blend files can produce identically
    named actors, and one file can produce several ('root' appears once per import). The asset path
    is the only thing that reliably identifies which import an actor belongs to.

    Cameras and the sequence player are matched separately -- they carry no mesh assets, so they
    are identified by being bound into a Level Sequence living under `destination`. Every import
    recreates them, so leaving them behind would accumulate duplicates just as the geometry does.

    Only *loaded* actors are visible here. In a World Partition level actors live in external
    packages and stream in and out, so this can legitimately return nothing while stale geometry is
    still in the world -- which is why the caller sweeps again after the import, once the level has
    been forced to load.
    """
    prefix = destination.rstrip("/").lower() + "/"
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)

    def belongs(actor):
        for component in actor.get_components_by_class(unreal.SceneComponent):
            asset = None
            if isinstance(component, unreal.StaticMeshComponent):
                asset = component.get_editor_property("static_mesh")
            elif isinstance(component, unreal.GeometryCacheComponent):
                asset = component.get_editor_property("geometry_cache")
            elif isinstance(component, unreal.SkeletalMeshComponent):
                asset = component.get_editor_property("skeletal_mesh")
            if asset is not None and asset.get_path_name().lower().startswith(prefix):
                return True
        if isinstance(actor, unreal.LevelSequenceActor):
            sequence = actor.get_editor_property("level_sequence_asset")
            if sequence is not None:
                return sequence.get_path_name().lower().startswith(prefix)
        return False

    return [actor for actor in subsystem.get_all_level_actors() if belongs(actor)]


def _remove_actors_referencing(destination, keep=()):
    """Destroy every level actor whose geometry comes from `destination`. Returns the count.

    `keep` is a set of actor *names* to spare, so the post-import sweep can remove the previous
    import's leftovers without touching the copy that was just created.
    """
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    keep = set(keep)

    doomed = [a for a in _actors_referencing(destination) if a.get_name() not in keep]

    # An import's root Xform actor holds no geometry itself, so it is only reachable by attachment
    # from the actors above. Same for the cameras, which parent under the root.
    seen = {a.get_name() for a in doomed} | keep
    for actor in list(doomed):
        parent = actor.get_attach_parent_actor()
        while parent is not None and parent.get_name() not in seen:
            seen.add(parent.get_name())
            doomed.append(parent)
            parent = parent.get_attach_parent_actor()
        for child in actor.get_attached_actors():
            if child.get_name() not in seen:
                seen.add(child.get_name())
                doomed.append(child)

    removed = 0
    for actor in doomed:
        try:
            subsystem.destroy_actor(actor)
            removed += 1
        except Exception as exc:  # noqa: BLE001 - one stubborn actor must not stop the import
            unreal.log_warning("BU: could not remove '{0}' ({1})".format(
                actor.get_actor_label(), exc))
    return removed


def _fix_mirrored_components(manifest):
    """Set reverse_culling on components whose Blender object was mirrored. Returns the count.

    A negative-scale object reverses handedness. Blender compensates when shading and the USD is
    written correctly -- the negative scale sits on the Xform, and the mesh's winding matches its
    authored normals. Unreal's USD importer bakes the mirror into the vertex positions instead
    (the component arrives at scale 1,1,1) and neither reverses the winding nor sets
    bReverseCulling, so every triangle ends up back-facing. With a two-sided material -- which is
    what Blender's backface-culling-off default produces -- Unreal flips the shading normal on
    back-faces, and the mesh renders inside-out.

    Verified end to end on the artist's scene: four mirrored objects, correct in Blender, correct
    in the USD (winding agreed with authored normals on 60 of 60 sampled faces), inverted in
    Unreal, arriving as StaticMeshComponents with det +1.00 and reverse_culling False.

    Reversing culling on the component fixes the facing without touching the geometry, so nothing
    is baked and re-importing stays idempotent.
    """
    mirrored = {
        entry.get("usd_name") or entry.get("name")
        for entry in manifest.data.get("objects", [])
        if entry.get("mirrored")
    }
    mirrored.discard(None)
    if not mirrored:
        return 0

    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    fixed = 0
    for actor in subsystem.get_all_level_actors():
        for component in actor.get_components_by_class(unreal.SceneComponent):
            if component.get_name() not in mirrored:
                continue

            # The mirrored prim is an Xform, and Blender puts the mesh in a child prim named after
            # the mesh datablock -- so the component carrying the geometry is usually a child with
            # a completely different name. Applying only to the named component silently fixes
            # nothing for those. Descendants inherit the parent's mirror, so they all need it.
            targets = [component]
            try:
                targets.extend(component.get_children_components(True))
            except Exception:  # noqa: BLE001 - older component types may not expose children
                pass

            for target in targets:
                try:
                    target.set_editor_property("reverse_culling", True)
                    fixed += 1
                except Exception:  # noqa: BLE001 - a geometry-less Xform has no such flag
                    continue
    return fixed


def import_scene(usd_path, destination="/Game/BU", pixel_art_preset=False, sequence_name=None,
                 prune_variants=True, adopt_surface=True, allow_unsaved_level=False,
                 replace_previous=True):
    """Import a BU-exported USD and finish the Unreal-side setup.

    Refuses to run if the open level is unsaved (`/Temp/Untitled_N`), because the imported actors
    would be lost with it. `allow_unsaved_level=True` overrides that.

    `adopt_surface` reparents every imported material onto BU's own surface material, replacing
    UsdPreviewSurface: 3 textures and 3 floats against Unreal's 8 and 31. On by default, confirmed
    correct in the viewport by the artist. Pass False to keep Unreal's materials.

    `prune_variants` deletes the unused one-sided material duplicates Unreal creates. It is on by
    default because they are pure clutter, and it only ever removes an instance that no component
    renders and nothing else references. Pass False to keep them.

    `replace_previous` removes the actors from the last import into the same destination before
    adding this one. On by default: without it every live export stacks another copy of the scene
    at the origin, and the artist sees old geometry layered over new -- which is indistinguishable
    from a stale export without listing the level. Pass False to keep earlier copies in place.

    Returns the created Level Sequence, or None if there was nothing to build.
    """
    if not os.path.exists(usd_path):
        unreal.log_error("BU: USD not found — " + usd_path)
        return None

    # Refuse an unsaved level. The assets would import fine and the actors would be lost the moment
    # the level closed, which is a confusing way to lose a scene.
    level = current_level_path()
    if level_is_unsaved(level) and not allow_unsaved_level:
        unreal.log_error(
            "BU: refusing to import into '{0}', which is an unsaved level. The assets would be "
            "created, but every actor lives only in this level and would be lost as soon as it "
            "closed. Save it first (File > Save Current Level As...) and run the import again. "
            "Pass allow_unsaved_level=True only if you genuinely want a throwaway "
            "import.".format(level)
        )
        return None

    # Content paths reject spaces too, so a destination like "/Game/BU/Set v2" would fail
    # every asset operation downstream.
    safe_destination = bu_names.sanitize_package_path(destination)
    if safe_destination != destination:
        unreal.log("BU: sanitised destination '{0}' -> '{1}'".format(destination, safe_destination))
    destination = safe_destination

    manifest = bu_manifest.Manifest.find_for_usd(usd_path)
    if manifest is None:
        unreal.log_warning(
            "BU: no .bu.json sidecar next to {0}. Importing anyway, but texture filtering "
            "and camera cuts will not be applied.".format(os.path.basename(usd_path))
        )

    for warning in (manifest.warnings if manifest else []):
        unreal.log_warning("BU (from Blender): " + warning)

    # Clear the previous import's actors before adding this one.
    #
    # Without this, every Live Export stacks another full copy of the scene at the world origin.
    # The artist sees the old, unfixed geometry sitting on top of the new -- which reads exactly
    # like "the exporter is still writing the old version", and is impossible to tell apart from
    # a stale export without listing the level. Observed with three copies stacked: two from an
    # earlier blend, one current, all overlapping.
    #
    # Live export is explicitly an iterate-repeatedly workflow, so replacing is the only sane
    # default. Actors are matched by the assets they reference rather than by label, because the
    # label comes from the USD stem and two different files can produce the same one.
    #
    # Reported unconditionally, including zero. A silent zero is exactly how this hid: the level
    # held two full copies (401 mesh components each), the older one drawn over the newer, and the
    # artist reasonably read that as "the exporter is writing the old file" -- fixed normals and a
    # deleted object both appeared to have no effect, because the copy they were looking at was the
    # old one. Nothing in the log said the replace had found nothing.
    survivors = set()
    if replace_previous:
        before = _actors_referencing(destination)
        replaced = _remove_actors_referencing(destination)
        unreal.log("BU: previous import — {0} actor(s) matched, {1} removed".format(
            len(before), replaced))
        survivors = {a.get_name() for a in _actors_referencing(destination)}
        if survivors:
            unreal.log_warning(
                "BU: {0} actor(s) from a previous import survived removal and will be swept "
                "again after the import".format(len(survivors)))

    actor_subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    pre_existing = {a.get_name() for a in actor_subsystem.get_all_level_actors()}

    task = unreal.AssetImportTask()
    task.set_editor_property("filename", usd_path)
    task.set_editor_property("destination_path", destination)
    task.set_editor_property("automated", True)
    task.set_editor_property("replace_existing", True)
    task.set_editor_property("save", True)
    task.set_editor_property("options", _import_options(manifest))

    unreal.AssetToolsHelpers.get_asset_tools().import_asset_tasks([task])

    imported = task.get_editor_property("imported_object_paths")
    if not imported:
        unreal.log_error("BU: USD import produced no assets")
        return None
    unreal.log("BU: imported {0} assets from {1}".format(len(imported), os.path.basename(usd_path)))

    # Sweep again, now that the import has forced the level to load.
    #
    # The pre-import pass only sees *loaded* actors, and in a World Partition level actors live in
    # external packages that stream in and out -- so a previous import can be genuinely invisible
    # beforehand and present afterwards. Anything referencing this destination that already existed
    # before the import is, by definition, not what we just created.
    if replace_previous:
        fresh = {a.get_name() for a in actor_subsystem.get_all_level_actors()} - pre_existing
        swept = _remove_actors_referencing(destination, keep=fresh)
        if swept:
            unreal.log_warning(
                "BU: swept {0} leftover actor(s) from a previous import that were not visible "
                "before importing — the level had stacked copies of this scene".format(swept))

    if manifest is None:
        return None

    # Before anything material-related: a mirrored object arrives back-facing, which reads as
    # inverted normals and sends you looking at shading when the cause is winding.
    mirrored = _fix_mirrored_components(manifest)
    if mirrored:
        unreal.log(
            "BU: reversed culling on {0} mirrored component(s) — Unreal bakes a negative-scale "
            "transform into the vertices without reversing the winding, so they would otherwise "
            "render inside-out".format(mirrored)
        )

    bu_textures.apply_to_path(destination, manifest, pixel_art_preset)

    # Bind textures into material parameters. The USD importer sometimes leaves
    # Use<Channel>Texture at 0, which reads as "texture imported but not applied".
    bu_materials.wire_materials(destination, manifest)

    # Move every material onto BU's own surface: 3 textures and 3 floats, against
    # UsdPreviewSurface's 8 and 31. Runs after wire_materials so the texture bindings already
    # exist -- they survive the reparent because instance overrides are keyed by name and BU
    # deliberately reuses Unreal's parameter names. Blend mode comes from the manifest, so a
    # cutout gets Masked and glass gets Translucent rather than Unreal's one-size guess.
    if adopt_surface:
        bu_surface.adopt_all(destination, manifest)

    # Still needed even after adoption: a masked material clips on a hard threshold, so its
    # opacity texture has to be uncompressed and mip-free or BC3 smears binary alpha into holes.
    bu_materials.fix_alpha_blending(destination, manifest)

    # A flat Principled Alpha never reaches USD — Blender writes opacity 1.0 for every constant,
    # whatever its value. Reapply it from the manifest, or fully transparent geometry arrives as
    # a solid blob. Must run after adoption, which sets the parent this overrides against.
    bu_materials.apply_constant_opacity(destination, manifest)

    # Components can render a stale, flat-looking version of their materials because setting
    # instance parameters does not re-register them. Verified with a minimal scene: an emissive
    # checker was invisible until the material was recompiled and reassigned.
    bu_materials.refresh_render_state(destination)

    # Unreal creates one instance per (material, sidedness) combination it meets, so a scene whose
    # meshes are all double-sided -- which is Blender's default, backface culling off -- gets a
    # one-sided twin of every material that nothing ever uses. Measured on a real scene: 195
    # instances, of which 96 were dead one-sided duplicates. Runs last, so "unused" is judged
    # against the finished scene rather than a half-configured one.
    if prune_variants:
        bu_materials.prune_material_variants(destination)

    if sequence_name is None:
        stem = os.path.splitext(os.path.basename(usd_path))[0]
        sequence_name = bu_names.sanitize_asset_name("BU_" + stem, "BU_Shot")

    # Pass the USD filename and the freshly imported asset paths so the cut track lands on
    # the sequence the importer just built -- the one that already holds the animation --
    # rather than a separate one.
    sequence = bu_sequence.build_sequence(
        manifest,
        destination,
        sequence_name,
        usd_filename=os.path.basename(usd_path),
        imported_paths=[str(p) for p in imported],
    )

    anim = manifest.animation
    if anim.get("geometry_cache"):
        names = ", ".join(e["object"] for e in anim["geometry_cache"])
        if anim.get("skeletal_exported"):
            # Skeletal export was on, so a geometry cache means something fell back to
            # point-caching -- worth flagging, since caches are far heavier than a rig.
            unreal.log_warning(
                "BU: {0} object(s) came in as geometry cache rather than skeletal mesh: {1}. "
                "These are heavy — consider rigging them if that was not intended.".format(
                    len(anim["geometry_cache"]), names
                )
            )
        else:
            unreal.log(
                "BU: {0} animated object(s) imported as geometry cache: {1}. This is expected "
                "with skeletal export off — the deformed geometry is baked per frame.".format(
                    len(anim["geometry_cache"]), names
                )
            )

    unreal.log("BU: handoff complete — scene is ready to light.")
    return sequence


def reapply_settings(
    manifest_path, destination="/Game/BU", pixel_art_preset=False, rebuild_cuts=True
):
    """Re-run the post-import fixes without re-importing the USD.

    Useful after tweaking interpolation in Blender and re-exporting only the manifest, or
    after Unreal has reimported textures and reset them to default filtering.

    With rebuild_cuts, the camera cut track is rebuilt on the imported sequence too, which
    is the quickest way to fix cuts without a full reimport.
    """
    manifest = bu_manifest.Manifest.load(manifest_path)
    destination = bu_names.sanitize_package_path(destination)

    bu_textures.apply_to_path(destination, manifest, pixel_art_preset)
    bu_materials.wire_materials(destination, manifest)

    if rebuild_cuts:
        bu_sequence.build_sequence(
            manifest,
            destination,
            usd_filename=manifest.data.get("usd_file", ""),
        )
    return manifest
