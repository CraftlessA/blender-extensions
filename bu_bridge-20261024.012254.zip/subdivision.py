# SPDX-License-Identifier: GPL-3.0-or-later
"""Cap Subdivision Surface levels for the duration of an export.

Subdivision is nearly free on static geometry: the exporter tessellates it once and writes one
mesh. On *animated* geometry it is paid again on every frame, because the deformed result is
written as point timeSamples. That asymmetry is what turns a normal scene into an unopenable one.

Measured on the scene this was written for: 624 subdivision modifiers, 158 animated meshes, 187
frames. Each level multiplies faces by about four, so the level-2 modifiers carry 16x and the
level-3 ones 64x — an average around 17x — and the animated meshes pay that 187 times over. The
export reached **8.52 GB** and the import killed the GPU.

Capping is a render-quality decision the artist owns, so nothing here is automatic: the cap is an
explicit export option, it is reported in the manifest, and every modifier is restored to its
exact original level afterwards.
"""

import contextlib

# Catmull-Clark quadruples face count per level. Used only for the pre-flight estimate, which
# exists to make the cap's effect legible before spending twenty minutes on an export.
FACES_PER_LEVEL = 4.0


def modifiers(scene):
    """Every enabled Subdivision Surface modifier in the scene, as (object, modifier)."""
    found = []
    for obj in scene.objects:
        for modifier in getattr(obj, "modifiers", ()):
            if modifier.type == "SUBSURF" and modifier.show_render:
                found.append((obj, modifier))
    return found


def _is_animated(obj):
    """Whether this object's geometry is rewritten per frame, which is what makes it expensive."""
    if any(m.type == "ARMATURE" for m in getattr(obj, "modifiers", ())):
        return True
    for source in (obj, getattr(obj, "data", None), getattr(obj, "parent", None)):
        anim = getattr(source, "animation_data", None)
        if anim is not None and (anim.action is not None or anim.nla_tracks):
            return True
    if getattr(obj, "parent", None) is not None and obj.parent.type == "ARMATURE":
        return True
    return bool(getattr(getattr(obj, "data", None), "shape_keys", None))


def survey(scene, cap):
    """What a cap would change, without changing anything.

    `ratio` is the change in **subdivided faces on animated meshes** — the part that scales with
    frame count. It is not a file-size prediction and consistently overstates the saving, because
    a stage also holds static geometry, transforms, UVs and normals that a cap does not touch.

    Measured on the real scene: an animated-face ratio of 0.63 produced a file ratio of 0.80
    (8.52 GB -> 6.80 GB). Treat `ratio` as the optimistic end, not the expected one.

    1.0 means the cap is a no-op and would save nothing at all.
    """
    affected, animated_affected = [], []
    before = after = 0.0
    for obj, modifier in modifiers(scene):
        level = modifier.render_levels
        capped_level = min(level, cap) if cap >= 0 else level
        if _is_animated(obj):
            before += FACES_PER_LEVEL ** level
            after += FACES_PER_LEVEL ** capped_level
        if capped_level != level:
            affected.append((obj.name, modifier.name, level, capped_level))
            if _is_animated(obj):
                animated_affected.append(obj.name)

    return {
        "cap": cap,
        "modifiers": len(modifiers(scene)),
        "affected": len(affected),
        "affected_animated": len(set(animated_affected)),
        "detail": affected,
        # Ratio of animated subdivided face work after vs before.
        "ratio": round(after / before, 4) if before else 1.0,
    }


@contextlib.contextmanager
def capped(scene, cap):
    """Lower every Subdivision Surface `render_levels` to `cap`, then restore exactly.

    A cap below zero is "no cap" and touches nothing. Restoration writes back the original value
    unconditionally rather than only where a change was made, so an exception midway cannot leave
    a modifier half-lowered.
    """
    if cap is None or cap < 0:
        yield []
        return

    original = []
    lowered = []
    try:
        for obj, modifier in modifiers(scene):
            original.append((modifier, modifier.render_levels))
            if modifier.render_levels > cap:
                lowered.append((obj.name, modifier.name, modifier.render_levels, cap))
                modifier.render_levels = cap
        yield lowered
    finally:
        for modifier, level in original:
            try:
                modifier.render_levels = level
            except (ReferenceError, AttributeError):
                # The modifier or its object was removed mid-export. Nothing to restore, and
                # raising here would mask whatever actually went wrong.
                pass
