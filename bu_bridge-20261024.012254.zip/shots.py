# SPDX-License-Identifier: GPL-3.0-or-later
"""Export one shot instead of the whole sequence.

A full export of the reference scene is 7.2 GB and 187 frames, and the cost that hurts is not the
export (4 minutes) but the import and what it asks of the GPU. Three levers cut it, and they
multiply:

* **one cut instead of all of them** — cost is linear in frames, and the reference scene's cuts are
  0-96, 96-145 and 145-187, so a single shot is roughly a third;
* **animated geometry only** — 158 of its 666 exported meshes are animated. The set never changes
  between iterations, so re-exporting 508 static meshes every time is pure waste; export it once,
  then iterate on characters alone;
* **a subdivision cap** — measured on the same scene, cap 1 leaves 0.16x the per-frame animated
  geometry of no cap at all (see `subdivision.survey`).

Stacked, that turns a 7.2 GB import into something in the low hundreds of MB. Nothing here changes
the scene: every mutation is a context manager that restores exactly what it found.
"""

import contextlib

import bpy

from . import capture, visibility


def shots(scene):
    """The scene's shots, one per camera-bound timeline marker.

    Frame ranges are **inclusive** here, unlike `capture.collect_camera_cuts`, whose `frame_end`
    is exclusive because that is what Unreal's cut sections want. Mixing the two conventions up
    silently drops or duplicates a frame at every boundary, so they are named differently and
    converted in exactly one place.
    """
    found = []
    for index, cut in enumerate(capture.collect_camera_cuts(scene)):
        found.append({
            "index": index,
            "marker": cut["marker"],
            "camera": cut["camera"],
            "frame_start": cut["frame_start"],
            "frame_end": cut["frame_end"] - 1,
            "frames": cut["frame_end"] - cut["frame_start"],
        })
    return found


def find(scene, key):
    """A shot by index, marker name or camera name. Returns None if nothing matches."""
    available = shots(scene)
    if not available:
        return None

    if isinstance(key, int) or (isinstance(key, str) and key.lstrip("-").isdigit()):
        index = int(key)
        if 0 <= index < len(available):
            return available[index]
        return None

    lowered = str(key).lower()
    for shot in available:
        if lowered in (shot["marker"].lower(), shot["camera"].lower()):
            return shot
    return None


@contextlib.contextmanager
def framed(scene, frame_start, frame_end):
    """Narrow the scene's frame range, then put it back exactly."""
    if frame_start is None or frame_end is None:
        yield None
        return

    original = (scene.frame_start, scene.frame_end, scene.frame_current)
    try:
        # Order matters: setting start above the current end, or end below the current start,
        # is clamped by Blender rather than rejected, which silently gives the wrong range.
        scene.frame_end = max(int(frame_end), int(frame_start))
        scene.frame_start = int(frame_start)
        scene.frame_end = int(frame_end)
        yield (scene.frame_start, scene.frame_end)
    finally:
        scene.frame_start, scene.frame_end = original[0], original[1]
        try:
            scene.frame_set(original[2])
        except Exception:  # noqa: BLE001 - restoring the playhead must not mask the export
            pass


def animated_names(scene):
    """Objects whose geometry is rewritten per frame — the ones worth re-exporting."""
    classified = capture.classify_animation(scene)
    names = {entry["object"] for entry in classified.get("geometry_cache", ())}
    names |= {entry["object"] for entry in classified.get("skeletal", ())}
    # Transform-only objects are cheap and often carry the shot (cameras, a moving prop), so they
    # stay in. The saving comes from dropping *static geometry*, not from dropping everything.
    names |= {entry["object"] for entry in classified.get("transform_only", ())}
    return names


ALL = "ALL"
ANIMATED = "ANIMATED"
STATIC = "STATIC"


@contextlib.contextmanager
def only_geometry(scene, mode=ALL):
    """Hide the half of the scene this export is not for.

    The two halves are complementary and meant to be exported separately: the set changes once in
    a session, the characters change every iteration. Importing the set once and re-importing only
    the characters is the whole point — it turns a 7 GB round trip into a sub-gigabyte one.

    `ANIMATED` keeps anything whose geometry or transform changes over time, plus cameras.
    `STATIC` keeps the complement, and wants `export_animation=False` alongside it: static
    geometry has nothing to say per frame, and writing timeSamples for it is pure waste.

    Yields the names hidden, so the manifest can state what was left out rather than letting the
    artist discover half a scene in Unreal.

    Visibility is frozen first: `hide_render` is animatable, and a driver would otherwise undo
    these writes on the next depsgraph evaluation — the trap `visibility.py` exists for.
    """
    if mode not in (ANIMATED, STATIC):
        yield []
        return

    moving = animated_names(scene)
    victims = []
    for obj in scene.objects:
        if obj.type != "MESH" or obj.hide_render:
            continue
        is_moving = obj.name in moving
        if (mode == ANIMATED and not is_moving) or (mode == STATIC and is_moving):
            victims.append(obj)

    with visibility.frozen(victims):
        restore = [(obj, obj.hide_render) for obj in victims]
        try:
            for obj in victims:
                obj.hide_render = True
            yield [obj.name for obj in victims]
        finally:
            for obj, was in restore:
                try:
                    obj.hide_render = was
                except ReferenceError:
                    pass


def only_animated(scene, enabled=True):
    """Backwards-compatible shim for the boolean form."""
    return only_geometry(scene, ANIMATED if enabled else ALL)


def menu_items(scene, context=None):
    """EnumProperty items for the shot picker. Always non-empty, so the UI cannot break."""
    items = [("ALL", "Whole sequence", "Export every frame of the scene")]
    for shot in shots(scene):
        items.append((
            str(shot["index"]),
            "{0} — {1} ({2}-{3})".format(
                shot["marker"], shot["camera"], shot["frame_start"], shot["frame_end"]),
            "{0} frames through {1}".format(shot["frames"], shot["camera"]),
        ))
    return items


def geometry_items(scene=None, context=None):
    return [
        (ALL, "Everything", "Export the whole scene"),
        (ANIMATED, "Animated only",
         "Characters and anything that moves. Pair with a Static-only export of the set, "
         "imported once"),
        (STATIC, "Static only",
         "The set. Exports a single frame with no animation, so it is small and fast — import it "
         "once, then iterate on Animated-only exports"),
    ]


def plan(scene, shot=None, cap=-1, animated_only=False, mode=None):
    """What a shot export would cost relative to exporting everything with no levers set.

    `frames` and `meshes_kept` are exact — they are counts, not predictions, and they are what the
    UI should lead with.

    `relative` multiplies the three ratios and is **optimistic by roughly an order of magnitude**.
    Measured: one shot of the reference scene at cap 1, animated only, planned 0.012 and produced
    0.65 GB against a 7.2 GB baseline. Each ratio is a geometry ratio, every one overstates file
    savings on its own (`subdivision.survey` documents 0.63 planned -> 0.80 actual), and
    multiplying three of them compounds the error. Treat it as a floor, never as a size.
    """
    from . import subdivision

    if mode is None:
        mode = ANIMATED if animated_only else ALL

    total_frames = max(1, scene.frame_end - scene.frame_start + 1)
    # A static-only export is one frame by definition — there is nothing to sample per frame.
    frames = 1 if mode == STATIC else (shot["frames"] if shot else total_frames)
    frame_ratio = frames / float(total_frames)

    subdiv_ratio = subdivision.survey(scene, cap)["ratio"] if cap >= 0 else 1.0

    # Count against what would *actually* export, not every mesh in the file. The reference scene
    # holds 2318 mesh objects but exports 666 of them — the rest are rig widgets and deliberately
    # hidden geometry. Using the raw total made the estimate claim 0.5% of a full export where the
    # measured result was 9%, an eighteen-fold overstatement, because the meshes being "saved"
    # were mostly ones that cost nothing in the first place.
    animated = animated_names(scene)
    meshes = [
        o for o in scene.objects
        if o.type == "MESH" and not o.hide_render and o.name in scene.view_layers[0].objects
    ]
    if mode == ANIMATED:
        kept = [o for o in meshes if o.name in animated]
    elif mode == STATIC:
        kept = [o for o in meshes if o.name not in animated]
    else:
        kept = meshes
    mesh_ratio = (len(kept) / float(len(meshes))) if meshes else 1.0

    return {
        "shot": shot,
        "mode": mode,
        "frames": frames,
        "total_frames": total_frames,
        "frame_ratio": round(frame_ratio, 4),
        "subdivision_ratio": round(subdiv_ratio, 4),
        "mesh_ratio": round(mesh_ratio, 4),
        "meshes_kept": len(kept),
        "meshes_total": len(meshes),
        "relative": round(frame_ratio * subdiv_ratio * mesh_ratio, 4),
    }
