# SPDX-License-Identifier: GPL-3.0-or-later
"""Name sanitising for Unreal asset paths, and Blender->USD->Unreal name matching.

Two distinct problems, both observed in real logs:

1. **Unreal asset names cannot contain spaces.** A USD called `Set v2.usdc` produced the
   sequence name `BU_Set v2`, and `DoesAssetExist` failed outright with *"contains invalid
   characters (probably spaces)"* -- which aborted sequence creation, so cameras were
   imported but no cut track was ever built.

2. **Blender sanitises object names when writing prims** (`.`, ` `, `-` all become `_`), and
   Unreal names actors after prims. So `Camera.001` in Blender is `Camera_001` in Unreal and
   a direct name lookup always misses.
"""

import re

# Unreal object names: letters, digits and underscore are always safe.
_UNSAFE = re.compile(r"[^A-Za-z0-9_]")

# Blender's prim-name sanitisation, mirrored for use as a fallback when the manifest has no
# recorded usd_name (older manifests, or a stage we could not read back).
_BLENDER_PRIM_UNSAFE = re.compile(r"[^A-Za-z0-9_]")


def sanitize_asset_name(name, fallback="Asset"):
    """Make a string safe to use as an Unreal asset name."""
    cleaned = _UNSAFE.sub("_", str(name or "")).strip("_")
    # Collapse runs of underscores introduced by the substitution.
    cleaned = re.sub(r"_{2,}", "_", cleaned)
    if not cleaned:
        return fallback
    # An asset name may not begin with a digit.
    if cleaned[0].isdigit():
        cleaned = "_" + cleaned
    return cleaned


def sanitize_package_path(path, fallback="/Game/BU"):
    """Sanitise each component of a content path, preserving the leading root."""
    text = str(path or "").replace("\\", "/").strip()
    if not text:
        return fallback

    parts = [p for p in text.split("/") if p]
    if not parts:
        return fallback

    cleaned = [sanitize_asset_name(part, "Folder") for part in parts]
    return "/" + "/".join(cleaned)


# Unreal's USD importer prefixes generated assets by type (USDObjectUtils.cpp L304-356):
# SM_ static mesh, SK_ skeletal mesh, SKEL_ skeleton, PHYS_ physics asset, GR_ groom,
# MI_ material instance, M_ material, T_ texture, LS_ level sequence.
IMPORTED_ASSET_PREFIXES = ("LS_", "SM_", "SK_", "SKEL_", "PHYS_", "GR_", "MI_", "M_", "T_")

LEVEL_SEQUENCE_PREFIX = "LS_"


def strip_asset_prefix(name):
    """Remove Unreal's USD-importer type prefix, if present."""
    for prefix in IMPORTED_ASSET_PREFIXES:
        if name.startswith(prefix):
            return name[len(prefix):]
    return name


def sequence_name_candidates(usd_filename):
    """Names the importer may have given the Level Sequence for this stage, best first.

    The main sequence is named after the sanitised USD basename, then prefixed `LS_` -- so
    `dman scene.usdc` becomes `LS_dman_scene`, not `dman_scene`.
    """
    import os

    stem = os.path.splitext(os.path.basename(str(usd_filename or "")))[0]
    if not stem:
        return []
    safe = sanitize_asset_name(stem, "")
    if not safe:
        return []
    return [LEVEL_SEQUENCE_PREFIX + safe, safe]


def material_name_candidates(entry):
    """Names Unreal may have given the imported material, best first.

    Blender material `stone.002` becomes prim `stone_002`, which the importer then publishes
    as a material instance named `MI_stone_002`. Matching the raw Blender name finds nothing.
    """
    candidates = []

    def add(value):
        if value and value not in candidates:
            candidates.append(value)

    if isinstance(entry, str):
        entry = {"name": entry}

    original = entry.get("name") or entry.get("object_name") or ""
    usd_name = entry.get("usd_name") or ""

    # Exact prim name recovered from the exported stage, if we have it.
    for base in (usd_name, _BLENDER_PRIM_UNSAFE.sub("_", original)):
        if not base:
            continue
        add("MI_" + base)
        add("M_" + base)
        add(base)

    add(original)
    return candidates


def prim_name_candidates(entry):
    """Every name an Unreal actor for this manifest entry might carry, best first.

    `usd_name` comes from reading the exported stage, so it is exact when present.
    """
    candidates = []

    def add(value):
        if value and value not in candidates:
            candidates.append(value)

    add(entry.get("usd_name"))
    for child in entry.get("usd_child_names") or []:
        add(child)

    original = entry.get("object_name") or entry.get("name") or ""
    add(original)
    # Mirror Blender's sanitisation for manifests that predate usd_name.
    add(_BLENDER_PRIM_UNSAFE.sub("_", original))

    return candidates
