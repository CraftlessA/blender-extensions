# SPDX-License-Identifier: GPL-3.0-or-later
"""Smoke and fire from Blender's simulations, as Heterogeneous Volumes.

Blender sends a gas simulation's domain already shaded as Cycles shades it, cell by cell
(`link_smoke`): one 3D texture of half floats, emission RGB and extinction per metre, and a
second of albedo when the colour varies. `UBULinkLibrary::ApplyVolumeGrid` uploads it (in place
on the GPU when the size stays, as a playing simulation's does).

A Heterogeneous Volume ray marches its own box, `VolumeResolution` local units wide, evaluating
its material at every step: the grid's resolution, so a local unit is a cell, centred
(`pivot_at_centroid`), and the actor scaled to the cell size in centimetres. Its ray march takes
lengths in those local units (`HeterogeneousVolumesLiveShadingPipeline.usf` normalises the local
ray), so extinction and emission are per cell: per metre x the cell's size (`CellMetres`).
Emission is radiance, x 683 to nits as every light is.

The master `M_BU_Live_Smoke_v1` (Volume domain, used with Heterogeneous Volumes): the texture
coordinate is the local position over the resolution, plus a half.
"""

from . import bu_link_graph, bu_link_material

VERSION = 2
NITS_PER_UNIT = bu_link_material.NITS_PER_UNIT
DEFAULT_GRID = "/Engine/EngineResources/DefaultVolumeTexture.DefaultVolumeTexture"
# Parameters of the master.
GRID, ALBEDO_GRID, USE_ALBEDO_GRID = "Grid", "AlbedoGrid", "UseAlbedoGrid"
ALBEDO, RESOLUTION, CELL, EMISSION_SCALE = "Albedo", "Resolution", "CellMetres", "EmissionScale"
ERRORS = "no volume grid: the counts or the shared memory were wrong (see the log)"


def master_name():
    return "M_BU_Live_Smoke_v{0}{1}".format(VERSION, "_S" if bu_link_material.substrate() else "")


def master_path():
    return "{0}/{1}.{1}".format(bu_link_material.PACKAGE, master_name())


def can_draw():
    """Whether this Unreal has what smoke needs: the native upload and Heterogeneous Volumes."""
    import unreal

    return (hasattr(getattr(unreal, "BULinkLibrary", None), "apply_volume_grid")
            and hasattr(unreal, "HeterogeneousVolume"))


def parameters(header):
    """({scalar: value}, {vector: (r, g, b)}) for a smoke volume's material instance. Pure."""
    header = header or {}
    res = [max(1, int(v)) for v in (header.get("res") or (1, 1, 1))][:3]
    albedo = [float(v) for v in (header.get("albedo") or (1.0, 1.0, 1.0))][:3]
    grid = header.get("grid") or {}
    scalars = {CELL: max(0.0, float(header.get("cell") or 0.0)), EMISSION_SCALE: NITS_PER_UNIT,
               USE_ALBEDO_GRID: 1.0 if "albedo_offset" in grid else 0.0}
    vectors = {ALBEDO: tuple(albedo), RESOLUTION: tuple(float(v) for v in res)}
    return scalars, vectors


def build(unreal, material):
    """Wire the master: Volume domain, additive, used with Heterogeneous Volumes. Returns the
    connections that failed."""
    library = unreal.MaterialEditingLibrary
    quiet = bu_link_material._quiet
    quiet(material, "material_domain", unreal.MaterialDomain.MD_VOLUME, unreal)
    quiet(material, "blend_mode", unreal.BlendMode.BLEND_ADDITIVE, unreal)
    quiet(material, "use_material_attributes", False, unreal)
    quiet(material, "used_with_heterogeneous_volumes", True, unreal)
    e = bu_link_graph.Emitter(unreal, material, {"nodes": [], "out": {}})
    default = unreal.load_asset(DEFAULT_GRID)

    def scalar(name, value):
        return (e._new("MaterialExpressionScalarParameter", parameter_name=name,
                       default_value=float(value)), "")

    def vector(name, value):
        return (e._new("MaterialExpressionVectorParameter", parameter_name=name,
                       default_value=unreal.LinearColor(*value, 1.0)), "RGB")

    local = (e.expr("MaterialExpressionLocalPosition")[0], "XYZ")
    uvw = e.add(e.div(local, vector(RESOLUTION, (1.0, 1.0, 1.0))), e.const(0.5, 0.5, 0.5))

    def sample(name):
        found = e._new("MaterialExpressionTextureSampleParameterVolume", parameter_name=name,
                       texture=default,
                       # The default texture's own: an sRGB sampler reads the grid's half
                       # floats as they are (a float texture has no sRGB view to decode).
                       sampler_type=unreal.MaterialSamplerType.SAMPLERTYPE_COLOR)
        e._connect(uvw, found, "UVs")
        return found

    grid = sample(GRID)
    cell = scalar(CELL, 0.0)
    thick = e.mul((grid, "A"), cell)
    emissive = e.mul(e.mul((grid, "RGB"), cell), scalar(EMISSION_SCALE, NITS_PER_UNIT))
    albedo = e.lerp(vector(ALBEDO, (1.0, 1.0, 1.0)), (sample(ALBEDO_GRID), "RGB"),
                    scalar(USE_ALBEDO_GRID, 0.0))
    failed = []
    if bu_link_material.substrate():
        cloud = e._new("MaterialExpressionSubstrateVolumetricFogCloudBSDF")
        names = list(library.get_material_expression_input_names(cloud) or [])
        for source, wanted in ((albedo, "Albedo"), (thick, "Extinction"),
                               (emissive, "Emissive Color")):
            name = next((n for n in names if n.replace(" ", "") == wanted.replace(" ", "")), None)
            if name is None:
                failed.append("FogCloud." + wanted)
                continue
            e._connect(source, cloud, name)
        if not library.connect_material_property(cloud, "",
                                                 unreal.MaterialProperty.MP_FRONT_MATERIAL):
            failed.append("FrontMaterial")
    else:
        # As Unreal's own volume materials: Base Color the albedo, Subsurface Color the extinction.
        for (expression, output), pin in ((albedo, unreal.MaterialProperty.MP_BASE_COLOR),
                                          (thick, unreal.MaterialProperty.MP_SUBSURFACE_COLOR),
                                          (emissive, unreal.MaterialProperty.MP_EMISSIVE_COLOR)):
            if not library.connect_material_property(expression, output, pin):
                failed.append(str(pin))
    return failed + list(e.failed)


def ensure_master():
    """The smoke master, created on first use, or None."""
    import unreal

    path = master_path()
    if unreal.EditorAssetLibrary.does_asset_exist(path.split(".")[0]):
        found = unreal.EditorAssetLibrary.load_asset(path)
        if found is not None:
            return found
    material = unreal.AssetToolsHelpers.get_asset_tools().create_asset(
        master_name(), bu_link_material.PACKAGE, unreal.Material, unreal.MaterialFactoryNew())
    if material is None:
        unreal.log_error("BU: could not create " + path)
        return None
    failed = build(unreal, material)
    if failed:
        unreal.log_warning("BU: {0}: could not connect {1}".format(master_name(),
                                                                   ", ".join(failed)))
    bu_link_material.compile_material(unreal, material)
    unreal.EditorAssetLibrary.save_loaded_asset(material, only_if_is_dirty=False)
    unreal.log("BU: created {0} for Blender's smoke and fire".format(master_name()))
    return material


def apply(actor, header, held):
    """Give a smoke volume's actor (a HeterogeneousVolume) its grid and material. `held`: the
    link's {name: {"instance", "grid", "albedo"}}, reused while the textures keep their size.
    Raises ValueError when the grid could not be read."""
    import unreal

    name = str(header.get("name") or "")
    component = actor.get_component_by_class(unreal.HeterogeneousVolumeComponent)
    if component is None:
        raise ValueError("the volume actor has no HeterogeneousVolumeComponent")
    entry = held.setdefault(name, {})
    res = [max(1, int(v)) for v in header.get("res") or (1, 1, 1)][:3]
    grid = header.get("grid") or {}
    library = unreal.BULinkLibrary
    texture = library.apply_volume_grid(entry.get("grid"), grid.get("name", ""),
                                        int(grid.get("offset", 0)), *res)
    if texture is None:
        raise ValueError(ERRORS)
    entry["grid"] = texture
    tint = None
    if "albedo_offset" in grid:
        tint = library.apply_volume_grid(entry.get("albedo"), grid.get("name", ""),
                                         int(grid["albedo_offset"]), *res)
        if tint is None:
            raise ValueError(ERRORS)
        entry["albedo"] = tint
    if entry.get("res") != res:
        component.set_volume_resolution(unreal.IntVector(*res))
        entry["res"] = res
    for prop, value in (("pivot_at_centroid", True), ("playing", False),
                        ("cast_shadow", True)):
        try:
            component.set_editor_property(prop, value)
        except Exception:  # noqa: BLE001 - a build without one
            pass
    instance = entry.get("instance")
    if instance is None:
        parent = ensure_master()
        if parent is None:
            return None
        component.set_material(0, parent)
        instance = component.create_dynamic_material_instance(0, parent)
        entry["instance"] = instance
    scalars, vectors = parameters(header)
    for key, value in scalars.items():
        instance.set_scalar_parameter_value(key, value)
    for key, value in vectors.items():
        instance.set_vector_parameter_value(key, unreal.LinearColor(*value, 1.0))
    instance.set_texture_parameter_value(GRID, texture)
    if tint is not None:
        instance.set_texture_parameter_value(ALBEDO_GRID, tint)
    return instance
