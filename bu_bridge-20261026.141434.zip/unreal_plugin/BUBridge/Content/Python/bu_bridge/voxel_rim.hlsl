// BU's copy of the VoxelRim overlay's Custom node body (bu_link_overlay builds the
// material around it). From the project author's VoxelRim_SilhouetteNormal.hlsl; the one
// change is Width scaling with the picture's height (marked BU below).
//==============================================================================
// VoxelRim_SilhouetteNormal.hlsl
//
// Body for a Material Custom node.  Verified against UE 5.8 engine source at
// C:/Program Files/Epic Games/UE_5.8/Engine/Shaders/.
//
//   Output type : CMOT_Float4  (xyz = world-space normal, w = silhouette mask)
//   Inputs      : ScreenUV  float2  <- ScreenPosition.ViewportUV
//                 PixDepth  float   <- PixelDepth
//                 Params    float4  <- (Width, Bias, Feather, Lean)
//
//------------------------------------------------------------------------------
// WHY NOT FRESNEL
//
// pow(1 - saturate(dot(N,V)), P) is CONSTANT across a voxel face, because every
// pixel of that face shares one normal.  You get whole faces popping on and off,
// never a rim.  Do not reintroduce it.
//
// This is a port of a Blender setup that avoided normals entirely: a raycast
// along the view vector asked "does this ray escape the mesh?", and a very high
// subsurface value turned thin regions into wraparound bleed.  Both halves are
// reproduced here:
//
//   raycast          -> screen-space depth discontinuity.  Sample scene depth a
//                       few pixels away, compare to PixelDepth.  A large POSITIVE
//                       gap means the neighbour is behind us: we are on the
//                       silhouette.  Entirely normal-independent, so a flat voxel
//                       face behaves exactly like smooth geometry.
//
//   high subsurface  -> a SYNTHESISED grazing normal.  We do not hand-roll a
//                       transmission term and we do not walk the light grid.  We
//                       reconstruct the normal the voxel mesh does not have and
//                       hand it to the engine's Default Lit path, which then
//                       evaluates every light in the scene for free - colour,
//                       intensity, direction, attenuation, shadows, all of it.
//
// The edge-weighted sum of the tap directions points outward from the silhouette
// in screen space.  That IS the grazing normal.  Tilting it away from the camera
// by `Lean` is what lets a light BEHIND the model wrap the silhouette into a halo
// instead of extinguishing it.
//==============================================================================


//------------------------------------------------------------------------------
// Which depth buffer to probe.
//
//   PPI_SceneDepth  = 1   (MaterialTemplate.ush:68)
//   PPI_CustomDepth = 13  (MaterialTemplate.ush:80)
//
// SceneDepth  : zero setup, but the rim also fires wherever the model silhouettes
//               against DISTANT geometry, since any far neighbour reads as a gap.
// CustomDepth : a true self-silhouette (only meshes in the custom depth pass are
//               in the buffer), but every rimmed mesh component needs
//               "Render CustomDepth Pass" ticked.
//------------------------------------------------------------------------------
#ifndef VOXELRIM_SCENETEX_ID
#define VOXELRIM_SCENETEX_ID 1
#endif


// Unpack the packed parameter vector.
float Width   = Params.x;   // rim thickness, in screen pixels
float Bias    = Params.y;   // world-unit gap that must be exceeded to count as an edge
float Feather = Params.z;   // world-unit range over which the edge ramps 0 -> 1
float Lean    = Params.w;   // how far the synthesised normal tips away from the camera


//------------------------------------------------------------------------------
// One texel step, in viewport-UV units, scaled to the requested pixel width.
//
// View.ViewSizeAndInvSize is FVector4f (SceneView.h:950), .xy = size in pixels,
// .zw = 1/size.  ScreenUV here is VIEWPORT UV, so .zw is the matching inverse -
// this keeps the rim a constant pixel width at any resolution.
//------------------------------------------------------------------------------
// BU: Width is in pixels of a picture 1080 tall, so the rim is as thick in a viewport
// rendered at 960 as in a 2160 still (ViewSizeAndInvSize.y is the rendered height).
float2 Texel = View.ViewSizeAndInvSize.zw * Width * (View.ViewSizeAndInvSize.y / 1080.0);


//------------------------------------------------------------------------------
// 16 unit-length tap directions, one every 22.5 degrees.
//
// WHY 16 AND NOT 8:
// `Outward` is an edge-weighted sum of these fixed vectors, so normalize(Outward)
// can only ever point at angles this set can express. With 8 taps the synthesised
// normal snaps toward whichever few taps dominate, i.e. it is quantised in angle.
// A diffuse (cosine) response is broad enough to smear those steps together and
// hide them completely. A narrow specular lobe does the opposite - it magnifies
// small normal differences - so 8 taps showed up as hard-edged banded segments
// along the rim. Doubling the angular resolution halves that step size.
//
// Cost: 16 depth fetches per pixel instead of 8. Fine for stills, less so for
// realtime - drop back to every other entry if this ever needs to be cheap.
//
// All entries are unit length (cos/sin of the angle), so every tap probes the
// same distance and the weighted sum is not biased toward any direction.
//------------------------------------------------------------------------------
float2 Taps[16];
Taps[ 0] = float2( 1.0,         0.0       );   //    0 deg
Taps[ 1] = float2( 0.92387953,  0.38268343);   //   22.5
Taps[ 2] = float2( 0.70710678,  0.70710678);   //   45
Taps[ 3] = float2( 0.38268343,  0.92387953);   //   67.5
Taps[ 4] = float2( 0.0,         1.0       );   //   90
Taps[ 5] = float2(-0.38268343,  0.92387953);   //  112.5
Taps[ 6] = float2(-0.70710678,  0.70710678);   //  135
Taps[ 7] = float2(-0.92387953,  0.38268343);   //  157.5
Taps[ 8] = float2(-1.0,         0.0       );   //  180
Taps[ 9] = float2(-0.92387953, -0.38268343);   //  202.5
Taps[10] = float2(-0.70710678, -0.70710678);   //  225
Taps[11] = float2(-0.38268343, -0.92387953);   //  247.5
Taps[12] = float2( 0.0,        -1.0       );   //  270
Taps[13] = float2( 0.38268343, -0.92387953);   //  292.5
Taps[14] = float2( 0.70710678, -0.70710678);   //  315
Taps[15] = float2( 0.92387953, -0.38268343);   //  337.5


float  Mask    = 0.0;               // accumulated edge response - see note below
float2 Outward = float2(0.0, 0.0);  // edge-weighted sum of tap directions

//------------------------------------------------------------------------------
// MASK: SUM, NOT MAX.
//
// This used to be Mask = max(Mask, Edge), which made the rim read as a hard
// OUTLINE rather than a rim. Edge saturates almost instantly - against a distant
// background the depth gap is hundreds or thousands of units, so any Feather in
// a sane range divides out to 1 - and taking the max meant a single escaping tap
// lit the pixel at full strength. Every pixel in the band got exactly 1.0, so the
// band had no falloff: a constant-width stroke.
//
// Summing instead makes the value proportional to HOW MANY taps escape, which
// falls off naturally with distance from the silhouette: right on the edge about
// half the taps land off-model, fewer as you move inward, none deeper in. That
// gradient is the difference between a rim and an outline.
//
// Normalised by half the tap count so the outermost pixels land near 1.0.
//------------------------------------------------------------------------------
#define VOXELRIM_TAP_COUNT 16

[unroll]
for (int i = 0; i < VOXELRIM_TAP_COUNT; ++i)
{
    // Viewport UV -> scene-texture (buffer) UV, then clamp as a clamp sampler
    // would.  Both are declared in MaterialTemplate.ush (1289 and 1316) and are
    // in scope inside a Custom node.  The clamp matters: taps near the screen
    // border would otherwise read outside the valid view rect.
    float2 TapUV = ScreenUV + Taps[i] * Texel;
    TapUV = ClampSceneTextureUV(ViewportUVToSceneTextureUV(TapUV, VOXELRIM_SCENETEX_ID), VOXELRIM_SCENETEX_ID);

    // MaterialTemplate.ush:3237  float4 SceneTextureLookup(float2 UV, int Index, bool bFiltered)
    // For PPI_SceneDepth / PPI_CustomDepth this returns CalcSceneDepth /
    // CalcSceneCustomDepth (3316, 3318), i.e. LINEAR depth in world units,
    // splatted across the channels - so .r is the depth.
    // bFiltered = false: point sampling.  Bilinear would smear depth across the
    // silhouette and soften exactly the discontinuity we are trying to detect.
    float D = SceneTextureLookup(TapUV, VOXELRIM_SCENETEX_ID, false).r;

    // Positive gap only.  D - PixDepth > 0 means the neighbour is FARTHER than
    // us, so we are the near side of a silhouette.  A negative gap means the
    // neighbour is in front of us - that is someone else's rim, not ours, so
    // saturate() clamps it to zero and it contributes nothing.
    // max(Feather, 1) guards a divide by zero if Feather is authored at 0.
    float Edge = saturate((D - PixDepth - Bias) / max(Feather, 1.0));

    Mask    += Edge;                  // count how many taps escape (see note above)
    Outward += Taps[i] * Edge;        // weighted sum -> points away from the surface
}

// Half the tap count: on a straight silhouette roughly half the taps land
// off-model, so the outermost pixels sit near 1.0 and it tapers inward from there.
Mask = saturate(Mask / (VOXELRIM_TAP_COUNT * 0.5));


//------------------------------------------------------------------------------
// Turn the outward screen-space direction into a world-space normal.
//
// VIEW-SPACE HANDEDNESS - derived, not guessed.
// SceneView.cpp:1275 builds the view rotation with
//     FMatrix(FPlane(0,0,1,0), FPlane(1,0,0,0), FPlane(0,1,0,0), FPlane(0,0,0,1))
// Reading it as rows: world X (forward) -> view Z, world Y (right) -> view X,
// world Z (up) -> view Y.  So UE 5.8 view space is:
//
//     +X = right,  +Y = up,  +Z = forward (INTO the screen, away from camera)
//
// Consequences:
//   O.x  keeps its sign - viewport UV +X is right and view +X is right.
//   O.y  is NEGATED     - viewport UV +Y is DOWN, view +Y is UP.
//   Lean is POSITIVE    - +Z points away from the camera, which is what tips the
//                         normal toward lights behind the model and produces the
//                         wraparound halo.  A negative Lean would tip it toward
//                         the camera and kill back lighting.
//
// (Confirm both of these visually - see the two checks in the accompanying notes.)
//------------------------------------------------------------------------------

// Guard the normalize: interior pixels have Outward == 0 and normalize(0) is NaN,
// which would poison the GBuffer normal.  Below the threshold we fall back to a
// pure lean direction; Mask is ~0 there anyway so it is never actually shaded.
float2 O = (dot(Outward, Outward) > 1e-8) ? normalize(Outward) : float2(0.0, 0.0);

float3 NView = normalize(float3(O.x, -O.y, Lean));

// View -> world.  UE uses row-vector convention: mul(vector, matrix).
// View.ViewToTranslatedWorld is FMatrix44f in the view uniform buffer
// (SceneView.h:889).  w = 0 discards the translation row, leaving pure rotation,
// so translated-world and world directions are identical - no rebasing needed.
float3 NWorld = normalize(mul(float4(NView, 0.0), View.ViewToTranslatedWorld).xyz);

// xyz -> Normal pin (material must have Tangent Space Normal UNCHECKED).
// w   -> Opacity pin, via a saturate. SHAPE ONLY - w is a 0..1 coverage mask and
//        must never carry brightness, because Substrate clamps the Opacity pin to
//        [0,1] as slab coverage (Substrate.ush:4451). Rim brightness is the Gain
//        parameter on Base Color instead. See build_voxel_rim_material.py.
return float4(NWorld, Mask);
