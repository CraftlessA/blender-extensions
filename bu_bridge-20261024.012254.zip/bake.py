# SPDX-License-Identifier: GPL-3.0-or-later
"""Bake textures that are trapped inside node groups down to one image the export can carry.

Blender's USD exporter reads a Principled BSDF's **directly connected** inputs. A texture inside a
node group reaches the Principled across the group boundary, which the exporter does not follow,
so the material exports with flat values and the image never reaches Unreal. Layered painting
addons (Ucupaint and friends) are built entirely on that shape, so their work vanishes silently.

`capture.buried_textures()` detects it. This bakes the result down so it can travel.

Two deliberate choices:

* **EMIT, not DIFFUSE.** A diffuse-colour bake of a real Ucupaint material came back pure black
  even with the object visible, UV'd and selected. EMIT evaluates whatever is wired into an
  Emission shader and writes it out literally, which is exactly "give me this colour graph as a
  texture" and avoids the pass semantics entirely.
* **Nothing is destroyed.** The original nodes stay in the tree, only unlinked, and the baked
  Image Texture node is tagged so a second run reuses it instead of piling up. Reconnecting one
  link restores the artist's graph exactly.

This is UI-only by design: baking needs a real depsgraph, and the same code run under
`--background` writes nothing at all while reporting success.
"""

import os

import bpy

from . import capture

MARKER = "BU Baked Base Color"
DEFAULT_RESOLUTION = 2048


def targets(context, evaluation_mode="RENDER"):
    """Materials whose textures are all trapped in groups, with the objects wearing them."""
    materials = capture.materials_in_use(context, evaluation_mode)
    found = []
    for entry in capture.buried_textures(context, materials, evaluation_mode):
        # Only a total loss is worth rewriting someone's material over. A partial loss still has
        # a texture reaching Unreal, and baking would overwrite the one that already works.
        if entry["top_level"]:
            continue
        material = bpy.data.materials.get(entry["material"])
        if material is not None:
            found.append((material, entry))
    return found


def _objects_for(context, material):
    return [
        obj for obj in context.scene.objects
        if obj.type == "MESH" and any(s.material is material for s in obj.material_slots)
    ]


def missing_uvs(context, material):
    """Objects wearing `material` that cannot be baked because they have no UV map."""
    return [o.name for o in _objects_for(context, material) if not len(o.data.uv_layers)]


def looks_blank(image, samples=4096):
    """True when the baked image carries no information — every sampled pixel identical.

    This is not paranoia. `bpy.ops.object.bake` has been observed returning success and writing
    **nothing at all** three times running here (headless, and from a timer callback), leaving the
    cleared black buffer behind. Without this check the operator would then wire that black image
    into Base Color and destroy the artist's material in Blender as well as in Unreal — turning a
    cosmetic export problem into a real one.

    Sampled rather than exhaustive: a 2048x2048 RGBA image is 16.7 million floats, and reading all
    of them to answer a yes/no question is not worth the stall.
    """
    try:
        pixels = image.pixels
        total = len(pixels)
    except (AttributeError, RuntimeError):
        return False
    if total < 4:
        return True

    step = max(4, (total // max(1, samples)) // 4 * 4)
    first = None
    for index in range(0, total - 3, step):
        pixel = (pixels[index], pixels[index + 1], pixels[index + 2])
        if first is None:
            first = pixel
            continue
        if any(abs(a - b) > 1e-4 for a, b in zip(pixel, first)):
            return False
    return True


def _image_for(material, resolution):
    name = "T_{0}_BaseColor".format(material.name.replace(" ", "_").replace(".", "_"))
    image = bpy.data.images.get(name)
    if image is None:
        image = bpy.data.images.new(name, resolution, resolution, alpha=True)
    return image


def bake_material(context, material, resolution=DEFAULT_RESOLUTION, directory=""):
    """Bake `material`'s Base Color graph to an image and wire it in. Returns (image, path).

    Raises RuntimeError with a user-facing message if it cannot proceed.
    """
    tree = material.node_tree
    principled = next(
        (n for n in tree.nodes if n.bl_idname == "ShaderNodeBsdfPrincipled"), None)
    if principled is None:
        raise RuntimeError("'{0}' has no Principled BSDF to bake into".format(material.name))

    objects = _objects_for(context, material)
    if not objects:
        raise RuntimeError("nothing in the scene uses '{0}'".format(material.name))
    bare = [o.name for o in objects if not len(o.data.uv_layers)]
    if bare:
        raise RuntimeError(
            "'{0}' is on object(s) with no UV map, which cannot be baked: {1}".format(
                material.name, ", ".join(bare[:4]))
        )

    image = _image_for(material, resolution)
    node = next((n for n in tree.nodes if n.name == MARKER), None)
    if node is None:
        node = tree.nodes.new("ShaderNodeTexImage")
        node.name = node.label = MARKER
        node.location = (principled.location.x - 400, principled.location.y + 320)
    node.image = image
    tree.nodes.active = node
    for other in tree.nodes:
        other.select = (other is node)

    output = tree.get_output_node("ALL")
    surface = output.inputs["Surface"]
    original = surface.links[0].from_node if surface.is_linked else None
    colour = principled.inputs["Base Color"]
    source_socket = colour.links[0].from_socket if colour.is_linked else None

    emission = tree.nodes.new("ShaderNodeEmission")
    if source_socket is not None:
        tree.links.new(source_socket, emission.inputs["Color"])
    else:
        emission.inputs["Color"].default_value = colour.default_value
    tree.links.new(emission.outputs["Emission"], surface)

    scene = context.scene
    engine, samples = scene.render.engine, None
    scene.render.engine = "CYCLES"
    try:
        samples = scene.cycles.samples
        scene.cycles.samples = 1
    except AttributeError:
        pass

    selected = [o for o in context.selected_objects]
    active = context.view_layer.objects.active
    try:
        bpy.ops.object.select_all(action="DESELECT")
        for obj in objects:
            obj.select_set(True)
        context.view_layer.objects.active = objects[0]
        bpy.ops.object.bake(type="EMIT", margin=8, use_clear=True)
    finally:
        # The artist's surface goes back before anything else can see the scene, even on failure.
        if original is not None:
            tree.links.new(original.outputs[0], surface)
        tree.nodes.remove(emission)
        scene.render.engine = engine
        if samples is not None:
            try:
                scene.cycles.samples = samples
            except AttributeError:
                pass
        bpy.ops.object.select_all(action="DESELECT")
        for obj in selected:
            try:
                obj.select_set(True)
            except ReferenceError:
                pass
        context.view_layer.objects.active = active

    # Refuse to ship a blank bake. Checked *before* anything is written or rewired, so a silent
    # bake failure leaves the material exactly as the artist authored it.
    if looks_blank(image):
        node.image = None
        raise RuntimeError(
            "the bake of '{0}' came back blank — every pixel identical. Blender's bake operator "
            "sometimes reports success and writes nothing, so BU has left your material "
            "untouched rather than wire a flat image into Base Color. Bake it from the addon "
            "that owns the layers (Ucupaint's own Bake Channels) instead.".format(material.name)
        )

    directory = directory or os.path.dirname(bpy.data.filepath)
    if not directory:
        raise RuntimeError("save the .blend first — BU writes the baked image beside it")
    path = os.path.join(directory, image.name + ".png")
    image.filepath_raw = path
    image.file_format = "PNG"
    image.save()

    if colour.is_linked:
        tree.links.remove(colour.links[0])
    tree.links.new(node.outputs["Color"], colour)
    return image, path


class BU_OT_bake_buried(bpy.types.Operator):
    """Bake textures trapped inside node groups so the export can carry them"""

    bl_idname = "bu.bake_buried_textures"
    bl_label = "Bake Trapped Textures"
    bl_options = {"REGISTER", "UNDO"}

    resolution: bpy.props.IntProperty(
        name="Resolution",
        description="Size of the baked image, in pixels",
        default=DEFAULT_RESOLUTION,
        min=64,
        max=8192,
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and bool(bpy.data.filepath)

    def execute(self, context):
        pending = targets(context)
        if not pending:
            self.report({"INFO"}, "No trapped textures to bake")
            return {"CANCELLED"}

        done, failed = 0, 0
        for material, entry in pending:
            try:
                image, path = bake_material(context, material, self.resolution)
            except RuntimeError as exc:
                failed += 1
                self.report({"ERROR"}, "BU bake: " + str(exc))
                continue
            done += 1
            self.report(
                {"INFO"},
                "Baked '{0}' -> {1} (was losing {2})".format(
                    material.name, os.path.basename(path), ", ".join(entry["buried"][:2])),
            )

        if not done:
            return {"CANCELLED"}
        self.report(
            {"WARNING"},
            "Baked {0} material(s); {1} failed. Your original nodes are still there, just "
            "unlinked — reconnect them to Base Color to undo this.".format(done, failed),
        )
        return {"FINISHED"}


_classes = (BU_OT_bake_buried,)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
