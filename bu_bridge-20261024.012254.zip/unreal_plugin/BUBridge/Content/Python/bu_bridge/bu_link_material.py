# SPDX-License-Identifier: GPL-3.0-or-later
"""Materials for the real-time link: Blender's own values, not a guess by name.

The link first matched materials by name against earlier BU imports and sent nothing else. That
is right for a textured scene imported once already, and wrong everywhere else: Blender's default
material names (`Material`, `Material.001`) match whatever unrelated import happens to own an
`MI_Material`, so an untextured scene arrived wearing another project's textures.

So Blender describes each material, and Unreal shows exactly that on a dynamic instance of a
master material. The instances are transient and live only as long as the link's actors do. The
masters are saved assets beside BU's other materials, built once.

**One set of channels, eight surfaces.** Every master has the same channels, each a typed-in
value or a texture switched by `Use<Channel>Texture`:

    BaseColor        colour, or BaseColorTexture's RGB
    Metallic         value, or one channel of MetallicTexture (`MetallicChannel` picks which)
    Roughness        value, or one channel of RoughnessTexture
    Specular         value
    Normal           NormalTexture (flat by default, so no switch), scaled by NormalScale
    EmissiveColor    colour, or EmissiveColorTexture's RGB, times EmissiveStrength (in nits:
                     Blender's strength x `NITS_PER_UNIT`)
    Opacity          value, or one channel of OpacityTexture: a cutout's mask, or blended alpha

A "channel" is a weight vector dotted with the sample: (0,0,0,1) is the alpha, (1,0,0,0) the red
of a packed map, and Rec. 709 weights the brightness Blender reads when an image's Color is
plugged into a value socket — how a black-and-white JPG becomes a cutout.

What differs between surfaces is what a material instance cannot change — blend mode and shading
model — so each surface is its own master: opaque, masked (cutout), translucent, glass (thin
translucent with refraction), subsurface, foliage, clear coat and unlit. Blender says which with
`surface`, or leaves it to `auto_surface`, which reads the same signals Blender's own panel shows.
`surface: "unreal"` names a material asset in the project to use as it is.

Everything is wired through one Make Material Attributes node, because two of the pins clear coat
needs (CustomData0 and 1) have no name in Unreal's Python.

Images arrive as file paths (see Blender's `link_material`). Each is imported once as a real
texture asset under `TEXTURE_PACKAGE` — imported, not loaded with `ImportFileAsTexture2D`, which
makes a single mip that shimmers into noise at a distance — and again only when the file changes.
A normal map is its own asset: Unreal's normal-map compression, linear, and its green channel
flipped, because Blender's normal maps are OpenGL-style (+Y) and Unreal's are DirectX-style (-Y).
"""

import hashlib
import os
import re
import struct
import time

from . import bu_link_cache

PACKAGE = "/Game/BU/Materials"
# A master is only ever built when missing, so a changed graph needs a new name. The earlier
# masters (`M_BU_Live`, `M_BU_LiveMasked`, ...) are left where they are, unused.
GRAPH_VERSION = 3
# A surface whose master changed on its own, so only its master is built again. Subsurface 4:
# the scattered colour is the base colour (texture and all) times a tint, where it was one
# fixed colour, the base colour's unplugged value: textured skin scattered white.
SURFACE_VERSIONS = {"subsurface": 4}
# Blender's emission is radiance, W/(m² sr); Unreal's is luminance, nits. 683 lm/W, as the lights
# and the sky are converted (`bu_link_light`): without it a strength-1 glow was 683 times dimmer
# than the light around it, and a white tile of emission 1 came out darker than the sunlit floor
# it lay on (EEVEE: 1.0 against 0.25).
NITS_PER_UNIT = 683.0
SURFACES = ("opaque", "masked", "translucent", "glass", "subsurface", "foliage", "clearcoat",
            "unlit")
MASTERS = {surface: "M_BU_Live_{0}_v{1}".format(surface.capitalize(),
                                               SURFACE_VERSIONS.get(surface, GRAPH_VERSION))
           for surface in SURFACES}
# Translucent, front faces only: Blender's Blended material with Transparency Overlap off draws
# only its nearest surface. Two-sided, Unreal blended the far inside of Toy Freddy's eyeball,
# dark, over the white. Not a choice in Blender's panel; picked by `kind`.
FRONT = "translucent_front"
MASTERS[FRONT] = "M_BU_Live_TranslucentFront_v{0}".format(SURFACE_VERSIONS.get(FRONT, GRAPH_VERSION))
# The same for glass: a see-through surface that still reflects, picked by `kind` (below).
GLASS_FRONT = "glass_front"
MASTERS[GLASS_FRONT] = "M_BU_Live_GlassFront_v{0}".format(
    SURFACE_VERSIONS.get(GLASS_FRONT, GRAPH_VERSION))
ONE_SIDED = (FRONT, GLASS_FRONT)
GLASS_SURFACES = ("glass", GLASS_FRONT)
# Older callers' names for the opaque master.
ALIASES = {"plain": "opaque", "textured": "opaque"}
MATERIAL = MASTERS["opaque"]
TRANSLUCENT_SURFACES = ("translucent", "glass", FRONT, GLASS_FRONT)
MASKED_SURFACES = ("masked", "foliage")

BASE_COLOR_PARAM = "BaseColor"
EMISSIVE_PARAM = "EmissiveColor"
EMISSIVE_STRENGTH_PARAM = "EmissiveStrength"
METALLIC_PARAM = "Metallic"
ROUGHNESS_PARAM = "Roughness"
SPECULAR_PARAM = "Specular"
OPACITY_PARAM = "Opacity"
NORMAL_PARAM = "Normal"
NORMAL_SCALE_PARAM = "NormalScale"
IOR_PARAM = "IOR"
TRANSMITTANCE_PARAM = "TransmittanceColor"
SUBSURFACE_COLOR_PARAM = "SubsurfaceColor"
SUBSURFACE_TINT_PARAM = "SubsurfaceTint"
SUBSURFACE_AMOUNT_PARAM = "SubsurfaceAmount"
CLEAR_COAT_PARAM = "ClearCoat"
CLEAR_COAT_ROUGHNESS_PARAM = "ClearCoatRoughness"
SHEEN_PARAM = "SheenWeight"
SHEEN_ROUGHNESS_PARAM = "SheenRoughness"
SHEEN_TINT_PARAM = "SheenTint"
# With Substrate on (BU's render project always has it), these surfaces are built on a Substrate
# Slab: Blender's Principled inputs that Unreal's old shading models have no place for (Sheen,
# as Unreal's Fuzz, first) go straight in. Their masters and node materials get their own names
# (`slab_suffix`), so a project with Substrate off keeps the old ones.
SLAB_SURFACES = ("opaque", "masked", "clearcoat")
SLAB_VERSION = 4
# Blender's sheen roughness over which Unreal's Fuzz fades in, and the Fuzz roughness it stops at
# (`_slab`, measured).
SHEEN_FADE = (0.1, 0.4)
SHEEN_ROUGHEST = 0.5
# Past the Fuzz's reach (`_slab`), how far the diffuse colour is blended to the sheen's tint:
# SHEEN_VEIL evenly, reached over the roughness span SHEEN_VEIL_SPAN, and up to SHEEN_EDGE more
# at the silhouette, most at a middling roughness (none at 0.3 or 1.0). Fitted to Cycles' dark red
# spheres by the colour each roughness adds where the sphere is lit, from the middle to the edge:
# roughness 0.7, Cycles 0.15 to 0.35, Unreal 0.18 to 0.30; 1.0, 0.38 to 0.30, 0.38 to 0.28.
SHEEN_VEIL = 0.48
SHEEN_VEIL_SPAN = (0.55, 1.0)
SHEEN_EDGE = 0.7
TEXTURE_PARAM = "BaseColorTexture"  # the name earlier code and tests know it by


def texture_param(channel):
    return channel + "Texture"


def use_param(channel):
    return "Use{0}Texture".format(channel)


def channel_param(channel):
    return channel + "Channel"


# Blender turns a colour plugged into a value socket into its luminance, with Rec. 709 weights
# on linear values; a texture sample is linear by the time it is read.
LUMINANCE = (0.2126, 0.7152, 0.0722)
CHANNEL_WEIGHTS = {
    "color": LUMINANCE + (0.0,),
    "alpha": (0.0, 0.0, 0.0, 1.0),
    "r": (1.0, 0.0, 0.0, 0.0),
    "g": (0.0, 1.0, 0.0, 0.0),
    "b": (0.0, 0.0, 1.0, 0.0),
}
# Uncompressed and without mips costs 4 bytes a pixel: fine for a pixel-art texture, not for a
# 4K photo that merely happens to use Closest.
EXACT_NEAREST_MAX = 1024
TEXTURE_PACKAGE = "/Game/BU/Live/Textures"
STAMP_TAG = "BULinkSource"
DEFAULT_TEXTURE = "/Engine/EngineResources/DefaultTexture.DefaultTexture"
# A flat tangent-space normal. Not `DefaultNormal`: that is the normal map of Unreal's grey
# default material, tiles and plaster bumps, and it showed on every surface without a map.
DEFAULT_NORMAL = "/Engine/EngineMaterials/FlatNormal.FlatNormal"
# A linear-colour sampler needs a linear default texture: Unreal's own DefaultTexture is sRGB,
# and the material fails to compile ("Sampler type is Linear Color, should be Color").
LINEAR_DEFAULTS = (
    "/Engine/Functions/Engine_MaterialFunctions02/PivotPainter2/Black_1x1_EXR_Texture."
    "Black_1x1_EXR_Texture",
    "/Engine/ArtTools/RenderToTexture/Textures/127grey.127grey",
)
# How many project materials Blender's "Use Unreal Material" list offers.
MATERIAL_LIST_LIMIT = 5000

try:
    _TEXTURES  # noqa: B018 - survives importlib.reload on purpose
except NameError:
    _TEXTURES = {}  # (path, stamp, nearest, role) -> texture asset
    # Textures asked for but not imported yet, oldest first (see `bu_link_pace`), the instances
    # to show again when each one is in, and what every instance was last asked to show.
    _PENDING = {}   # key -> (texture field, role)
    _WAITING = {}   # key -> {id(instance)}
    _SHOWN = {}     # id(instance) -> (instance, spec)
    _PACE = {"last": float("-inf"), "held": ""}
    _DECODING = {}  # queue key -> BeginImageLoad token (0: the importer's)
    _UNSAVED = {}   # asset path -> texture made this session and not saved yet
try:
    _FAILED  # noqa: B018
except NameError:
    _FAILED = {}  # path -> (why it is not shown: "not found" or "could not import", stamp)
# How many names each list sends Blender with the stats (it shows them on hover).
TEXTURE_NAMES_SENT = 40

DEFAULTS = {
    "color": (0.8, 0.8, 0.8),
    "metallic": 0.0,
    "roughness": 0.5,
    "specular": 0.5,
    "emission": (0.0, 0.0, 0.0),
    "textured": False,
    "ior": 1.5,
}


def material_path(kind="opaque"):
    surface = ALIASES.get(kind, kind)
    name = MASTERS.get(surface, MATERIAL) + slab_suffix(surface)
    return "{0}/{1}.{1}".format(PACKAGE, name)


_SUBSTRATE = {}


def substrate():
    """True when the project renders with Substrate (`r.Substrate`, fixed at start-up)."""
    if "on" not in _SUBSTRATE:
        try:
            import unreal

            # `is True`: a stand-in `unreal` (the tests) answers with something else.
            _SUBSTRATE["on"] = unreal.SystemLibrary.get_console_variable_bool_value(
                "r.Substrate") is True
        except Exception:  # noqa: BLE001 - outside Unreal (tests): the old masters
            _SUBSTRATE["on"] = False
    return _SUBSTRATE["on"]


def slab_suffix(surface):
    """"_S<version>" for a surface built on a Substrate Slab in this project, else ""."""
    return "_S{0}".format(SLAB_VERSION) if surface in SLAB_SURFACES and substrate() else ""


def _number(value, fallback):
    try:
        return float(value)
    except (TypeError, ValueError):
        return fallback


def _has_file(found):
    return isinstance(found, dict) and bool(found.get("path"))


def auto_surface(spec):
    """The surface Blender's settings imply, when the artist has not picked one. Pure.

    Must match Blender's `link_material.auto_surface`, which shows the answer in the material
    panel (`tests/test_link.py` checks the two agree).
    """
    spec = spec or {}
    if spec.get("shader") == "glass" or _number(spec.get("transmission"), 0.0) > 0.01:
        return "glass"
    if _number(spec.get("opacity", 1.0), 1.0) < 0.999:
        return "translucent"
    if mask_of(spec) is not None or spec.get("alpha_graph"):
        return "translucent" if spec.get("alpha_blend") else "masked"
    if _number(spec.get("subsurface"), 0.0) > 0.01:
        return "subsurface"
    if _number(spec.get("coat"), 0.0) > 0.01:
        return "clearcoat"
    return "opaque"


def kind(spec):
    """Which master a material message needs: one of `SURFACES`, or "unreal". Pure."""
    spec = spec or {}
    surface = str(spec.get("surface") or "auto").lower()
    if surface == "unreal":
        return "unreal" if spec.get("unreal_material") else auto_surface(spec)
    if surface not in SURFACES:
        surface = auto_surface(spec)
    if surface == "translucent" and spec.get("clear_gloss") and spec.get("alpha_graph"):
        # See-through where a Transparent BSDF is, but with a glossy surface added over it
        # (Toy Freddy's corneas): Unreal's translucency reflects nothing where it is clear;
        # its thin translucent glass does, as Blender does.
        surface = "glass"
    if spec.get("front_only") and surface == "translucent":
        return FRONT
    if spec.get("front_only") and surface == "glass" and spec.get("clear_gloss"):
        return GLASS_FRONT
    return surface


def identity(spec):
    """What decides whether an existing instance can be updated in place. Pure."""
    which = kind(spec)
    if which == "unreal":
        return "unreal:" + str(spec.get("unreal_material"))
    if graph_driven(spec):
        # Another wiring is another compiled material; new values are not.
        return "{0}:graph:{1}".format(which, spec.get("graph_key"))
    return which


def graph_driven(spec):
    """The channels Blender's translated nodes drive. Pure."""
    graph = (spec or {}).get("graph")
    if not isinstance(graph, dict) or not (spec or {}).get("graph_key"):
        return set()
    return set((graph.get("out") or {}).keys())


def mask_of(spec):
    """The texture field the opacity reads, with its `channel`, or None. Pure.

    Newer Blender sends `mask` (the image behind Alpha, which may not be the colour image). An
    older one sent only `cutout`, meaning the colour image's own alpha.
    """
    spec = spec or {}
    mask = spec.get("mask")
    if _has_file(mask):
        return dict(mask, channel=mask.get("channel") or "alpha")
    found = spec.get("texture")
    if spec.get("cutout") and _has_file(found):
        return dict(found, channel="alpha")
    return None


def channel_weights(channel):
    """The weight vector that picks a channel out of an RGBA sample. Pure."""
    return CHANNEL_WEIGHTS.get(str(channel or "color").lower(), CHANNEL_WEIGHTS["color"])


def texture_plan(spec):
    """[(channel, texture field, role, channel weights)] for what this material samples. Pure.

    `role` decides how the image is stored: "color" as it is, "mask" exact (a cutout's alpha
    must not be compressed or mipped), "data" as it is, "normal" as a normal map.
    """
    spec = spec or {}
    which = kind(spec)
    if which == "unreal":
        return []
    plan = []
    mask = mask_of(spec)
    found = spec.get("texture")
    exact_colour = (mask is not None and which in MASKED_SURFACES and _has_file(found)
                    and mask.get("path") == found.get("path"))
    if _has_file(found):
        plan.append((BASE_COLOR_PARAM, found, "mask" if exact_colour else "color",
                     channel_weights("color")))
    if mask is not None and which in MASKED_SURFACES + ("translucent", FRONT):
        plan.append((OPACITY_PARAM, mask, "mask" if which in MASKED_SURFACES else "color",
                     channel_weights(mask.get("channel"))))
    maps = spec.get("maps") if isinstance(spec.get("maps"), dict) else {}
    for channel, key, role in ((METALLIC_PARAM, "metallic", "data"),
                               (ROUGHNESS_PARAM, "roughness", "data"),
                               (NORMAL_PARAM, "normal", "normal"),
                               (EMISSIVE_PARAM, "emission", "color")):
        field = maps.get(key)
        if _has_file(field):
            plan.append((channel, field, role, channel_weights(field.get("channel"))))
    return plan


def wants_exact(cutout, nearest, width, height):
    """Whether a texture should be stored uncompressed and without mips. Pure."""
    return bool(cutout) or (bool(nearest) and max(int(width), int(height)) <= EXACT_NEAREST_MAX)


def integer_bits(path):
    """Bits per channel of a PNG, PSD or TIFF of whole numbers, or None (another format, a float
    TIFF, or a file that cannot be read). Pure apart from reading the file's header."""
    try:
        with open(path, "rb") as handle:
            head = handle.read(32)
            if head[:8] == b"\x89PNG\r\n\x1a\n" and head[12:16] == b"IHDR":
                return head[24]
            if head[:4] == b"8BPS":
                return struct.unpack(">H", head[22:24])[0]
            if head[:4] in (b"II*\x00", b"MM\x00*"):
                return _tiff_bits(handle, "<" if head[:2] == b"II" else ">", head)
    except (OSError, struct.error, IndexError):
        return None
    return None


def _tiff_bits(handle, order, head):
    handle.seek(struct.unpack(order + "I", head[4:8])[0])
    count = struct.unpack(order + "H", handle.read(2))[0]
    entries = handle.read(count * 12)
    bits, float_samples = None, False
    for index in range(count):
        tag, kind, number = struct.unpack(order + "HHI", entries[index * 12:index * 12 + 8])
        value = entries[index * 12 + 8:index * 12 + 12]
        if tag not in (258, 339) or kind != 3:  # BitsPerSample, SampleFormat; SHORT values
            continue
        if number > 2:  # more than fits in the entry: it holds where they are
            here = handle.tell()
            handle.seek(struct.unpack(order + "I", value)[0])
            value = handle.read(2)
            handle.seek(here)
        first = struct.unpack(order + "H", value[:2])[0]
        if tag == 258:
            bits = first
        elif first == 3:
            float_samples = True
    return None if float_samples else bits


def source_encoding(path, linear=False, colorspace=None):
    """"srgb" when Unreal must be told an image's pixels are sRGB, else None. Pure.

    Unreal reads every 16-bit image as linear whatever its sRGB box says (it only decides how
    the platform texture is stored), so a 16-bit PNG Blender reads as sRGB colour came out pale
    and too bright: Toy Freddy's orange suit turned yellow. Its source encoding override fixes
    that. Eight bits per channel follow the sRGB box as they always did.
    """
    if linear or (colorspace and "srgb" not in str(colorspace).lower()):
        return None
    bits = integer_bits(path)
    return "srgb" if bits and bits > 8 else None


def encoding_override(unreal, encoding):
    """The TextureSourceEncoding value for `source_encoding`'s answer."""
    kinds = unreal.TextureSourceEncoding
    if encoding != "srgb":
        return kinds.TSE_NONE
    for name in ("TSE_SRGB", "TSE_S_RGB"):
        if hasattr(kinds, name):
            return getattr(kinds, name)
    return next(getattr(kinds, n) for n in dir(kinds) if n.upper().replace("_", "") == "TSESRGB")


def _source_colour(texture, encoding):
    """The texture's source colour settings with `encoding` (`source_encoding`), or None when
    they already say that."""
    import unreal

    try:
        colour = texture.get_editor_property("source_color_settings")
        want = encoding_override(unreal, encoding)
        if colour.get_editor_property("encoding_override") == want:
            return None
        colour.set_editor_property("encoding_override", want)
        return colour
    except Exception:  # noqa: BLE001 - an engine without colour management keeps the old way
        return None


def texture_asset_name(path, role="color"):
    """A stable asset name for an image file: readable, and unique per path. Pure.

    A normal map gets its own asset: its compression and green channel differ, and the same file
    used as a colour elsewhere must not change underneath.
    """
    stem = re.sub(r"[^A-Za-z0-9_]", "_", os.path.splitext(os.path.basename(path))[0])[:40]
    digest = hashlib.sha1(os.path.normcase(os.path.normpath(path)).encode("utf-8")).hexdigest()[:8]
    return "T_BU_{0}_{1}{2}".format(stem or "image", digest,
                                    {"normal": "_N", "height": "_H"}.get(role, ""))


def _triple(value, fallback):
    try:
        values = [float(v) for v in value][:3]
    except (TypeError, ValueError):
        return tuple(fallback)
    if len(values) != 3:
        return tuple(fallback)
    return tuple(max(0.0, v) for v in values)


def _unit(value, fallback):
    try:
        return min(1.0, max(0.0, float(value)))
    except (TypeError, ValueError):
        return fallback


def glass_reflectance(ior):
    """Head-on (Fresnel F0) reflectance of a dielectric with this IOR. Pure."""
    return ((ior - 1.0) / (ior + 1.0)) ** 2


def parameters(spec):
    """A material message -> ({vector parameter: (r, g, b)}, {scalar parameter: value}).

    Tolerant of missing and malformed fields: a bad value falls back to the default for that one
    field rather than costing the whole material. Texture switches are set by `apply`, once it
    knows the texture really loaded.
    """
    spec = spec or {}
    maps = spec.get("maps") if isinstance(spec.get("maps"), dict) else {}
    colour = _triple(spec.get("color"), DEFAULTS["color"])
    vectors = {
        BASE_COLOR_PARAM: colour,
        EMISSIVE_PARAM: _triple(spec.get("emission"), DEFAULTS["emission"]),
    }
    scalars = {
        METALLIC_PARAM: _unit(spec.get("metallic"), DEFAULTS["metallic"]),
        ROUGHNESS_PARAM: _unit(spec.get("roughness"), DEFAULTS["roughness"]),
        SPECULAR_PARAM: _unit(spec.get("specular"), DEFAULTS["specular"]),
        OPACITY_PARAM: _unit(spec.get("opacity", 1.0), 1.0),
    }
    which = kind(spec)
    normal = maps.get("normal") if isinstance(maps.get("normal"), dict) else None
    if normal is not None:
        strength = max(0.0, _number(normal.get("strength", 1.0), 1.0))
        vectors[NORMAL_SCALE_PARAM] = (strength, strength, 1.0)
    emission = maps.get("emission") if isinstance(maps.get("emission"), dict) else None
    strength = 1.0
    if emission is not None:
        strength = max(0.0, _number(emission.get("strength", 1.0), 1.0))
    if EMISSIVE_PARAM in graph_driven(spec):
        strength = max(0.0, _number(spec.get("emission_strength"), 1.0))
    scalars[EMISSIVE_STRENGTH_PARAM] = strength * NITS_PER_UNIT
    if which in GLASS_SURFACES:
        transmission = _unit(spec.get("transmission", 1.0), 1.0)
        if spec.get("shader") == "glass":
            transmission = 1.0
        # Thin translucent: Opacity is the share that behaves as a solid surface; the rest is
        # transmitted, tinted by the base colour as Blender's glass tints what it lets through.
        scalars[OPACITY_PARAM] = round(1.0 - transmission, 4)
        # Unreal refracts at one surface, offsetting the picture behind by the IOR: a flat pane
        # came out crinkled (the same on Unreal's own plane, raster or ray-traced; gone at IOR
        # 1), where Blender bends light in and back out and shows it clear. So no refraction
        # unless the material asks for it, for solid glass.
        ior = max(1.0, _number(spec.get("ior"), DEFAULTS["ior"]))
        scalars[IOR_PARAM] = ior if spec.get("refraction") else 1.0
        # Blender's glass reflects by its IOR, ((n - 1) / (n + 1))^2 head-on, scaled by Specular
        # IOR Level (0.5 = as the IOR says); Unreal's Specular is that reflectance / 0.08. A
        # fixed 0.5 made IOR 1.3 window glass reflect the room 2.4 times as strongly as Blender.
        level = _unit(spec.get("specular"), DEFAULTS["specular"])
        scalars[SPECULAR_PARAM] = round(min(1.0, glass_reflectance(ior) * 2.0 * level / 0.08), 4)
        vectors[TRANSMITTANCE_PARAM] = colour
    elif which == "subsurface":
        vectors[SUBSURFACE_TINT_PARAM] = _triple(spec.get("subsurface_tint"), (1.0, 1.0, 1.0))
        scalars[SUBSURFACE_AMOUNT_PARAM] = _unit(spec.get("subsurface", 1.0), 1.0)
    elif which == "foliage":
        vectors[SUBSURFACE_COLOR_PARAM] = _triple(spec.get("subsurface_color"),
                                                  tuple(c * 0.5 for c in colour))
    elif which == "clearcoat":
        scalars[CLEAR_COAT_PARAM] = _unit(spec.get("coat", 1.0), 1.0)
        scalars[CLEAR_COAT_ROUGHNESS_PARAM] = _unit(spec.get("coat_roughness"), 0.03)
    if which in SLAB_SURFACES and substrate():
        scalars[SHEEN_PARAM] = _unit(spec.get("sheen", 0.0), 0.0)
        scalars[SHEEN_ROUGHNESS_PARAM] = _unit(spec.get("sheen_roughness", 0.5), 0.5)
        vectors[SHEEN_TINT_PARAM] = _triple(spec.get("sheen_tint"), (1.0, 1.0, 1.0))
    return vectors, scalars


# -- the masters ---------------------------------------------------------------------------------

def ensure(kind="opaque"):
    """The master material for a surface, created on first use. None if it cannot be made."""
    import unreal

    surface = ALIASES.get(kind, kind)
    if surface not in MASTERS:
        surface = "opaque"
    name = MASTERS[surface] + slab_suffix(surface)
    path = material_path(surface)
    if unreal.EditorAssetLibrary.does_asset_exist(path):
        material = unreal.EditorAssetLibrary.load_asset(path)
        if material is not None:
            return material

    material = unreal.AssetToolsHelpers.get_asset_tools().create_asset(
        name, PACKAGE, unreal.Material, unreal.MaterialFactoryNew())
    if material is None:
        unreal.log_error("BU: could not create " + path)
        return None
    failed = _build(unreal, material, surface)
    if failed:
        unreal.log_warning("BU: {0}: could not connect {1}".format(name, ", ".join(failed)))
    compile_material(unreal, material)
    unreal.EditorAssetLibrary.save_loaded_asset(material, only_if_is_dirty=False)
    unreal.log("BU: created {0} for the real-time link".format(name))
    return material


def compile_material(unreal, material):
    """Compile a material just built. Through the native module when it has the call: Unreal's
    `recompile_material` also ran two full garbage collections and compiled debug shaders for
    texture streaming data, 180-760 ms of the game thread a material on a big level. Its shaders
    compile in the background either way."""
    library = getattr(unreal, "BULinkLibrary", None)
    native = getattr(library, "compile_new_material", None)
    if native is not None:
        try:
            if native(material):
                return
        except Exception:  # noqa: BLE001 - fall back to the editor's way
            pass
    unreal.MaterialEditingLibrary.recompile_material(material)


def _quiet(target, name, value, unreal=None):
    """Set a property of a material, or of one of its nodes, while building it.

    Set the ordinary way, every node property is an edit of the whole material: Unreal translates
    and compiles it again each time (`UMaterialExpression::PostEditChangeProperty`). A node
    material of a few hundred nodes compiled its half-built self hundreds of times, and Unreal
    kept 0.3 to 2 GB for each; twenty of them ran Windows out of memory. The material is
    compiled once when it is finished (`recompile_material`).
    """
    if unreal is None:
        import unreal

    try:
        target.set_editor_property(name, value, unreal.PropertyAccessChangeNotifyMode.NEVER)
    except (TypeError, AttributeError):
        target.set_editor_property(name, value)


def _build(unreal, material, surface, graph=None):
    """Wire one master's graph. Returns the connections that failed, for the log.

    `graph` (a `bu_link_graph.Emitter`) feeds the channels Blender's nodes drive; the rest are
    the usual value-or-texture switches.
    """
    library = unreal.MaterialEditingLibrary
    failed = []
    column = {"x": -1400, "y": -900}

    def node(cls, x=None, y=None):
        if x is None:
            x, y = column["x"], column["y"]
            column["y"] += 140
        return library.create_material_expression(material, cls, x, y)

    def connect(source, output, target, name):
        if not library.connect_material_expressions(source, output, target, name):
            failed.append("{0}.{1}".format(name, output or "out"))

    def scalar(name, value):
        found = node(unreal.MaterialExpressionScalarParameter)
        _quiet(found, "parameter_name", name, unreal)
        _quiet(found, "default_value", float(value), unreal)
        return found

    def vector(name, value):
        found = node(unreal.MaterialExpressionVectorParameter)
        _quiet(found, "parameter_name", name, unreal)
        _quiet(found, "default_value", unreal.LinearColor(*value), unreal)
        return found

    def sampler(channel, normal=False):
        found = node(unreal.MaterialExpressionTextureSampleParameter2D)
        _quiet(found, "parameter_name", texture_param(channel), unreal)
        default = unreal.load_asset(DEFAULT_NORMAL if normal else DEFAULT_TEXTURE)
        if default is not None:
            _quiet(found, "texture", default, unreal)
        _quiet(found, "sampler_type", unreal.MaterialSamplerType.SAMPLERTYPE_NORMAL
               if normal else unreal.MaterialSamplerType.SAMPLERTYPE_COLOR, unreal)
        return found

    def lerp(a, a_out, b, b_out, alpha):
        found = node(unreal.MaterialExpressionLinearInterpolate)
        connect(a, a_out, found, "A")
        connect(b, b_out, found, "B")
        connect(alpha, "", found, "Alpha")
        return found

    def colour_channel(channel, default):
        """lerp(the colour, the texture's RGB, Use<channel>Texture)."""
        return lerp(vector(channel, tuple(default) + (1.0,)), "RGB", sampler(channel), "RGB",
                    scalar(use_param(channel), 0.0))

    def value_channel(channel, default):
        """lerp(the value, dot(the texture, <channel>Channel), Use<channel>Texture)."""
        picked = node(unreal.MaterialExpressionDotProduct)
        connect(sampler(channel), "RGBA", picked, "A")
        connect(vector(channel_param(channel), CHANNEL_WEIGHTS["color"]), "RGBA", picked, "B")
        return lerp(scalar(channel, default), "", picked, "", scalar(use_param(channel), 0.0))

    def multiply(a, a_out, b, b_out):
        found = node(unreal.MaterialExpressionMultiply)
        connect(a, a_out, found, "A")
        connect(b, b_out, found, "B")
        return found

    slab = surface in SLAB_SURFACES and substrate()
    pins = {}
    if slab:
        # Collected, then wired into a Substrate Slab (`_slab`).
        _quiet(material, "use_material_attributes", False, unreal)
    else:
        attributes = node(unreal.MaterialExpressionMakeMaterialAttributes, -200, 0)
        _quiet(material, "use_material_attributes", True, unreal)
        library.connect_material_property(attributes, "",
                                          unreal.MaterialProperty.MP_MATERIAL_ATTRIBUTES)

    def pin(source, output, name):
        if slab:
            pins[name] = (source, output)
        else:
            connect(source, output, attributes, name)

    def driven(channel, fallback):
        """(expression, output): from Blender's nodes when they drive it, else `fallback()`."""
        found = graph.channel(channel) if graph is not None else None
        return found if found is not None else (fallback(), "")

    base, base_out = driven(BASE_COLOR_PARAM,
                            lambda: colour_channel(BASE_COLOR_PARAM, DEFAULTS["color"]))
    glow, glow_out = driven(EMISSIVE_PARAM,
                            lambda: colour_channel(EMISSIVE_PARAM, DEFAULTS["emission"]))
    emissive = multiply(glow, glow_out, scalar(EMISSIVE_STRENGTH_PARAM, NITS_PER_UNIT), "")
    if surface == "unlit":
        # An unlit surface shows its colour as Blender's emission of strength 1 would.
        nits = node(unreal.MaterialExpressionConstant)
        _quiet(nits, "r", NITS_PER_UNIT, unreal)
        glow = node(unreal.MaterialExpressionAdd)
        connect(multiply(base, base_out, nits, ""), "", glow, "A")
        connect(emissive, "", glow, "B")
        pin(glow, "", "EmissiveColor")
        _quiet(material, "shading_model", unreal.MaterialShadingModel.MSM_UNLIT, unreal)
    else:
        pin(base, base_out, "BaseColor")
        pin(emissive, "", "EmissiveColor")
        pin(*driven(METALLIC_PARAM, lambda: value_channel(METALLIC_PARAM, DEFAULTS["metallic"])),
            "Metallic")
        pin(*driven(ROUGHNESS_PARAM,
                    lambda: value_channel(ROUGHNESS_PARAM, DEFAULTS["roughness"])), "Roughness")
        pin(*driven(SPECULAR_PARAM, lambda: scalar(SPECULAR_PARAM, DEFAULTS["specular"])),
            "Specular")
        pin(*driven("Normal", lambda: multiply(
            sampler(NORMAL_PARAM, normal=True), "RGB",
            vector(NORMAL_SCALE_PARAM, (1.0, 1.0, 1.0, 1.0)), "RGB")), "Normal")

    if surface in MASKED_SURFACES:
        pin(*driven(OPACITY_PARAM, lambda: value_channel(OPACITY_PARAM, 1.0)), "OpacityMask")
        _quiet(material, "blend_mode", unreal.BlendMode.BLEND_MASKED, unreal)
    elif surface in ("translucent", FRONT):
        pin(*driven(OPACITY_PARAM, lambda: value_channel(OPACITY_PARAM, 1.0)), "Opacity")
        _quiet(material, "blend_mode", unreal.BlendMode.BLEND_TRANSLUCENT, unreal)
        # Lit per pixel like an opaque surface, rather than from the coarse lighting volume
        # translucency defaults to, which flattens it into a uniform tint.
        _quiet(
            material, "translucency_lighting_mode",
            unreal.TranslucencyLightingMode.TLM_SURFACE_PER_PIXEL_LIGHTING, unreal)
    elif surface in GLASS_SURFACES:
        # Blender's alpha, when its nodes drive it, is the share that is a solid surface.
        pin(*driven(OPACITY_PARAM, lambda: scalar(OPACITY_PARAM, 0.0)), "Opacity")
        pin(scalar(IOR_PARAM, DEFAULTS["ior"]), "", "Refraction")
        transmitted = node(unreal.MaterialExpressionThinTranslucentMaterialOutput)
        connect(vector(TRANSMITTANCE_PARAM, (1.0, 1.0, 1.0, 1.0)), "RGB", transmitted,
                "TransmittanceColor")
        _quiet(material, "blend_mode", unreal.BlendMode.BLEND_TRANSLUCENT, unreal)
        # Thin translucency compiles only with "Surface ForwardShading", which Python calls
        # TLM_SURFACE_PER_PIXEL_LIGHTING (TLM_SURFACE is "Surface TranslucencyVolume", and
        # fails: "ThinTranslucent materials must use Surface Per Pixel Lighting"). Set before
        # the shading model: each property change compiles, and the other order logged that
        # failure for the moment in between, which reads as the master being broken.
        _quiet(
            material, "translucency_lighting_mode",
            unreal.TranslucencyLightingMode.TLM_SURFACE_PER_PIXEL_LIGHTING, unreal)
        _quiet(material, "shading_model", unreal.MaterialShadingModel.MSM_THIN_TRANSLUCENT,
               unreal)
        _quiet(material, "refraction_method", unreal.RefractionMode.RM_INDEX_OF_REFRACTION, unreal)
    elif surface == "subsurface":
        # Blender scatters the base colour itself, tinted by how far each channel travels.
        pin(multiply(base, base_out, vector(SUBSURFACE_TINT_PARAM, (1.0, 1.0, 1.0, 1.0)), "RGB"),
            "", "SubsurfaceColor")
        pin(scalar(SUBSURFACE_AMOUNT_PARAM, 1.0), "", "Opacity")
        _quiet(material, "shading_model", unreal.MaterialShadingModel.MSM_SUBSURFACE, unreal)
    elif surface == "clearcoat":
        pin(*driven(CLEAR_COAT_PARAM, lambda: scalar(CLEAR_COAT_PARAM, 1.0)), "ClearCoat")
        pin(*driven(CLEAR_COAT_ROUGHNESS_PARAM,
                    lambda: scalar(CLEAR_COAT_ROUGHNESS_PARAM, 0.03)), "ClearCoatRoughness")
        _quiet(material, "shading_model", unreal.MaterialShadingModel.MSM_CLEAR_COAT, unreal)
    if surface == "foliage":
        pin(vector(SUBSURFACE_COLOR_PARAM, (0.4, 0.5, 0.2, 1.0)), "RGB", "SubsurfaceColor")
        _quiet(material, "shading_model", unreal.MaterialShadingModel.MSM_TWO_SIDED_FOLIAGE,
               unreal)
    if slab:
        sheen = (driven(SHEEN_PARAM, lambda: scalar(SHEEN_PARAM, 0.0)),
                 driven(SHEEN_ROUGHNESS_PARAM, lambda: scalar(SHEEN_ROUGHNESS_PARAM, 0.5)),
                 driven(SHEEN_TINT_PARAM,
                        lambda: vector(SHEEN_TINT_PARAM, (1.0, 1.0, 1.0, 1.0))))
        _slab(unreal, library, material, node, connect, pins, sheen)
    # Blender's default is backface culling off, so a mesh that says nothing is double-sided.
    _quiet(material, "two_sided", surface not in ONE_SIDED, unreal)
    return failed


def _slab(unreal, library, material, node, connect, pins, sheen):
    """Wire the collected channels into a Substrate Slab and make it the material's surface.

    Base Color, Metallic and Specular become the Slab's diffuse albedo and F0 through Unreal's
    own conversion (what Substrate does for an old material). Sheen is the Slab's Fuzz. A coat is
    a second, glossy Slab of IOR 1.5 laid over it, weighted by the coat amount. Opacity Mask goes
    to the material as before.
    """
    def wire(source, target, name):
        expression, output = source
        connect(expression, output, target, name)

    convert = node(unreal.MaterialExpressionSubstrateMetalnessToDiffuseAlbedoF0, -500, 0)
    for name in ("BaseColor", "Metallic", "Specular"):
        if name in pins:
            wire(pins[name], convert, name)
    surface = node(unreal.MaterialExpressionSubstrateSlabBSDF, -250, 0)
    connect(convert, "F0", surface, "F0")
    for name, target in (("Roughness", "Roughness"), ("Normal", "Normal"),
                         ("EmissiveColor", "Emissive Color")):
        if name in pins:
            wire(pins[name], surface, target)
    # Blender's sheen and Unreal's Fuzz are both microfiber sheens, but they answer roughness
    # differently. Measured on dark red spheres (brightening of the picture over the same sphere
    # without sheen, Cycles / Unreal at amount 1): roughness 0.2: 0.03 / 0.09; 0.4: 0.28 / 0.29; 0.7: 0.90 /
    # 0.28; 1.0: 0.85 / 0.17. So the amount fades in from roughness 0.1 to 0.4 (a third at 0.2),
    # and the Fuzz roughness stops at 0.5, where Unreal's is strongest: above it Blender's sheen
    # whitens more than Unreal's can.
    (amount, roughness, tint) = sheen

    def op(cls, a, b, x, y):
        found = node(cls, x, y)
        wire(a, found, "A")
        wire(b, found, "B")
        return (found, "")

    def constant(value, x, y):
        found = node(unreal.MaterialExpressionConstant, x, y)
        _quiet(found, "r", float(value), unreal)
        return (found, "")

    fade_in = node(unreal.MaterialExpressionSaturate, -700, 300)
    wire(op(unreal.MaterialExpressionMultiply,
            op(unreal.MaterialExpressionSubtract, roughness, constant(SHEEN_FADE[0], -900, 320),
               -800, 300),
            constant(1.0 / (SHEEN_FADE[1] - SHEEN_FADE[0]), -900, 360), -750, 300),
         fade_in, (list(library.get_material_expression_input_names(fade_in) or []) or [""])[0])
    wire(op(unreal.MaterialExpressionMultiply, amount, (fade_in, ""), -600, 300),
         surface, "Fuzz Amount")
    wire(op(unreal.MaterialExpressionMin, roughness, constant(SHEEN_ROUGHEST, -700, 380),
            -600, 380), surface, "Fuzz Roughness")
    wire(tint, surface, "Fuzz Color")
    # Past the Fuzz's reach, a rough sheen is close to a veil of its tint over the diffuse colour
    # (lit as the diffuse is): even, growing with roughness, plus more towards the silhouette at
    # a middling roughness, as Blender's does.
    def ramp(low, high, x, y):  # saturate((roughness - low) / (high - low)), or falling if high < low
        found = node(unreal.MaterialExpressionSaturate, x, y)
        wire(op(unreal.MaterialExpressionMultiply,
                op(unreal.MaterialExpressionSubtract, roughness, constant(low, x - 200, y + 20),
                   x - 100, y),
                constant(1.0 / (high - low), x - 200, y + 60), x - 50, y),
             found, (list(library.get_material_expression_input_names(found) or []) or [""])[0])
        return (found, "")

    facing = node(unreal.MaterialExpressionDotProduct, -1000, 640)
    connect(node(unreal.MaterialExpressionVertexNormalWS, -1100, 620), "", facing, "A")
    connect(node(unreal.MaterialExpressionCameraVectorWS, -1100, 680), "", facing, "B")
    grazing = node(unreal.MaterialExpressionOneMinus, -900, 640)
    connect(facing, "", grazing,
            (list(library.get_material_expression_input_names(grazing) or []) or [""])[0])
    edge = op(unreal.MaterialExpressionMultiply,
              op(unreal.MaterialExpressionMultiply, ramp(0.3, 0.6, -800, 560),
                 ramp(1.0, 0.7, -800, 620), -650, 580),
              op(unreal.MaterialExpressionMultiply, (grazing, ""),
                 constant(SHEEN_EDGE, -800, 700), -650, 660), -550, 600)
    even = op(unreal.MaterialExpressionMultiply,
              ramp(SHEEN_VEIL_SPAN[0], SHEEN_VEIL_SPAN[1], -800, 460),
              constant(SHEEN_VEIL, -700, 520), -600, 480)
    # Blended, not added: like Blender's sheen layer, it covers the colour beneath as it shows.
    cover = node(unreal.MaterialExpressionSaturate, -450, 500)
    wire(op(unreal.MaterialExpressionMultiply, amount,
            op(unreal.MaterialExpressionAdd, even, edge, -600, 540), -500, 500),
         cover, (list(library.get_material_expression_input_names(cover) or []) or [""])[0])
    veiled = node(unreal.MaterialExpressionLinearInterpolate, -350, 480)
    connect(convert, "DiffuseAlbedo", veiled, "A")
    wire(tint, veiled, "B")
    connect(cover, "", veiled, "Alpha")
    connect(veiled, "", surface, "Diffuse Albedo")
    front = surface
    if "ClearCoat" in pins:
        coat = node(unreal.MaterialExpressionSubstrateSlabBSDF, -250, 400)
        black = node(unreal.MaterialExpressionConstant3Vector, -500, 400)
        _quiet(black, "constant", unreal.LinearColor(0.0, 0.0, 0.0, 1.0), unreal)
        connect(black, "", coat, "Diffuse Albedo")
        reflect = node(unreal.MaterialExpressionConstant, -500, 520)
        _quiet(reflect, "r", 0.04, unreal)  # IOR 1.5 head-on, Blender's default coat
        connect(reflect, "", coat, "F0")
        # A Slab with no mean free path is opaque: on top, a coat of black paint that hid the
        # whole surface. Clear: everything through, over Unreal's default coat thickness.
        clear = node(unreal.MaterialExpressionConstant3Vector, -700, 640)
        _quiet(clear, "constant", unreal.LinearColor(1.0, 1.0, 1.0, 1.0), unreal)
        through = node(unreal.MaterialExpressionSubstrateTransmittanceToMFP, -500, 640)
        connect(clear, "", through, "TransmittanceColor")
        connect(through, "MFP", coat, "SSS MFP")
        if "ClearCoatRoughness" in pins:
            wire(pins["ClearCoatRoughness"], coat, "Roughness")
        weighted = node(unreal.MaterialExpressionSubstrateWeight, -100, 400)
        connect(coat, "", weighted, "A")
        wire(pins["ClearCoat"], weighted, "Weight")
        layered = node(unreal.MaterialExpressionSubstrateVerticalLayering, 0, 200)
        connect(weighted, "", layered, "Top")
        connect(surface, "", layered, "Bottom")
        connect(through, "Thickness", layered, "Top Thickness")
        front = layered
    library.connect_material_property(front, "", unreal.MaterialProperty.MP_FRONT_MATERIAL)
    if "OpacityMask" in pins:
        expression, output = pins["OpacityMask"]
        library.connect_material_property(expression, output,
                                          unreal.MaterialProperty.MP_OPACITY_MASK)


# -- textures ------------------------------------------------------------------------------------

def linear_default():
    """An engine texture that is not sRGB, for a linear sampler's default, or None."""
    import unreal

    for path in LINEAR_DEFAULTS:
        default = unreal.load_asset(path)
        if default is not None and not default.get_editor_property("srgb"):
            return default
    return None


def texture_key(found, role):
    """What `_TEXTURES` and the waiting list know a texture by. Pure."""
    return (str(found.get("path") or ""), str(found.get("stamp") or ""),
            bool(found.get("nearest")), role)


def load_texture(found, cutout=False, role=None, wait=False, decoded=0):
    """The texture asset for a message's texture field, imported if needed. None on failure,
    and None for now when it must be imported: it joins the queue `service_textures` works
    through, unless `wait` asks for it at once.

    A cutout's alpha must be exact: compressed (BC3 quantises alpha over 4x4 blocks) or mipped,
    binary alpha smears into gradients that fall either side of the clip threshold, and holes
    open or close as the camera moves — what `bu_materials` learned on imported skins. So a
    cutout ("mask"), and a small pixel-art texture, are stored uncompressed without mips.

    `decoded` is a `BULinkLibrary.BeginImageLoad` token whose file is already decoded: the
    texture is made from those pixels (9 ms) instead of by Unreal's importer (160-225 ms of the
    game thread for a 2K PNG).
    """
    import unreal

    role = role or ("mask" if cutout else "color")
    path = str(found.get("path") or "")
    stamp = str(found.get("stamp") or "")
    nearest = bool(found.get("nearest"))
    key = texture_key(found, role)
    texture = _TEXTURES.get(key)
    if texture is not None:
        return texture
    if not os.path.isfile(path):
        _FAILED[path] = ("not found", stamp)
        return None

    asset_name = texture_asset_name(path, role)
    bu_link_cache.note_used(asset_name)  # so the cache keeps it (`bu_link_cache.prune_files`)
    asset = "{0}/{1}".format(TEXTURE_PACKAGE, asset_name)
    texture = None
    if unreal.EditorAssetLibrary.does_asset_exist(asset):
        existing = unreal.EditorAssetLibrary.load_asset(asset)
        if existing is not None and unreal.EditorAssetLibrary.get_metadata_tag(
                existing, STAMP_TAG) == stamp:
            texture = existing  # imported by an earlier session from this same file
    if texture is None and not wait:
        if _failed_entry(path)[1] == stamp:
            # Failed before and unchanged since: queued again by every re-description (each
            # frame for an animated material), it was imported again, seconds at a time.
            return None
        _PENDING.setdefault(key, (found, role))
        return None
    _PENDING.pop(key, None)
    if texture is not None and decoded:
        _cancel_decode(decoded)
    if texture is None and decoded:
        texture = unreal.BULinkLibrary.finish_image_texture(decoded, TEXTURE_PACKAGE, asset_name)
        if texture is not None:
            unreal.EditorAssetLibrary.set_metadata_tag(texture, STAMP_TAG, stamp)
    if texture is None:
        task = unreal.AssetImportTask()
        task.set_editor_property("filename", path)
        task.set_editor_property("destination_path", TEXTURE_PACKAGE)
        task.set_editor_property("destination_name", asset_name)
        task.set_editor_property("automated", True)
        task.set_editor_property("replace_existing", True)
        task.set_editor_property("save", False)
        unreal.AssetToolsHelpers.get_asset_tools().import_asset_tasks([task])
        imported = list(task.get_editor_property("imported_object_paths") or [])
        texture = unreal.EditorAssetLibrary.load_asset(imported[0]) if imported else None
        if texture is None:
            unreal.log_warning("BU: could not import {0} as a texture".format(path))
            _FAILED[path] = ("could not import", stamp)
            return None
        unreal.EditorAssetLibrary.set_metadata_tag(texture, STAMP_TAG, stamp)
    _FAILED.pop(path, None)

    wanted = unreal.TextureFilter.TF_NEAREST if nearest else unreal.TextureFilter.TF_DEFAULT
    settings = [("filter", wanted)]
    if role == "normal":
        settings += [("compression_settings", unreal.TextureCompressionSettings.TC_NORMALMAP),
                     ("srgb", False), ("flip_green_channel", True)]
    elif role == "hdr":
        # The World's HDRI for the sky dome: linear float, and no mips, which would blur the
        # seam where the equirectangular look-up wraps.
        hdr = getattr(unreal.TextureCompressionSettings, "TC_HDR_COMPRESSED",
                      unreal.TextureCompressionSettings.TC_HDR)
        settings += [("srgb", False), ("compression_settings", hdr),
                     ("mip_gen_settings", unreal.TextureMipGenSettings.TMGS_NO_MIPMAPS)]
    elif role == "lut":
        # A Color Ramp: read at its exact colours, clamped at both ends, never mipped.
        settings += [("srgb", True),
                     ("compression_settings", unreal.TextureCompressionSettings.TC_EDITOR_ICON),
                     ("mip_gen_settings", unreal.TextureMipGenSettings.TMGS_NO_MIPMAPS),
                     ("address_x", unreal.TextureAddress.TA_CLAMP),
                     ("address_y", unreal.TextureAddress.TA_CLAMP)]
    elif role == "height":
        # Read by a Bump, which shows every step between neighbouring pixels: BC1 (the default)
        # stores each 4x4 block as two colours and blends of them, and the bump came out soft
        # and blocky next to Blender's. BC7 keeps the detail, at the same size in memory as a
        # colour map with alpha, and samples like any colour texture. Its own asset (`_H`), so
        # the same file used as a colour is not changed.
        settings += [("compression_settings", unreal.TextureCompressionSettings.TC_BC7),
                     ("lod_group", unreal.TextureGroup.TEXTUREGROUP_WORLD),
                     ("srgb", not found.get("linear"))]
    else:
        # Unreal's importer looks at the pixels and makes anything blue-ish a normal map
        # (two-channel BC5, no sRGB, blue rebuilt). An image Blender reads as colour or height,
        # such as the cafe floor's `T_Floor_A_Normal.png` fed to a Bump, must stay a plain one.
        settings += [("compression_settings", unreal.TextureCompressionSettings.TC_DEFAULT),
                     ("lod_group", unreal.TextureGroup.TEXTUREGROUP_WORLD)]
        # Non-Color in Blender: the values are data, not colour, and Unreal must not decode them.
        settings.append(("srgb", not found.get("linear")))
        if wants_exact(role == "mask", nearest, texture.blueprint_get_size_x(),
                       texture.blueprint_get_size_y()):
            # Only ever made exact, never back: the same file may also be a cutout elsewhere.
            settings += [
                ("compression_settings", unreal.TextureCompressionSettings.TC_EDITOR_ICON),
                ("mip_gen_settings", unreal.TextureMipGenSettings.TMGS_NO_MIPMAPS)]
    # All at once: each property set on its own rebuilt the texture, up to four background
    # compressions of the same image, each holding hundreds of MB.
    wanted = dict(settings)  # the last word on a setting named twice
    changed = {name: value for name, value in wanted.items()
               if texture.get_editor_property(name) != value}
    if role not in ("normal", "hdr", "lut"):
        colour = _source_colour(texture, source_encoding(
            path, found.get("linear"), found.get("colorspace")))
        if colour is not None:
            changed["source_color_settings"] = colour
    if changed:
        texture.set_editor_properties(changed)
    # Saved later (`service_saves`, `save_textures`), so a next session finds it: saved here,
    # each one held the game thread 100-120 ms, most of it waiting for its own build.
    _UNSAVED[asset] = texture
    _TEXTURES[key] = texture
    return texture


def service_saves(limit=1):
    """Save up to `limit` textures whose build has finished. Returns how many were saved."""
    if not _UNSAVED:
        return 0
    import unreal

    library = getattr(unreal, "BULinkLibrary", None)
    built = getattr(library, "is_texture_built", None)
    saved = 0
    for asset, texture in list(_UNSAVED.items()):
        if saved >= limit:
            break
        try:
            if built is not None and not built(texture):
                continue  # saving it now would wait for its build
            unreal.EditorAssetLibrary.save_loaded_asset(texture, only_if_is_dirty=True)
        except Exception:  # noqa: BLE001 - replaced or gone since
            pass
        _UNSAVED.pop(asset, None)
        saved += 1
    return saved


def save_textures():
    """Save every texture made this session: when Blender disconnects, before the editor goes."""
    while _UNSAVED:
        asset, texture = _UNSAVED.popitem()
        try:
            import unreal

            unreal.EditorAssetLibrary.save_loaded_asset(texture, only_if_is_dirty=True)
        except Exception:  # noqa: BLE001
            pass


def textures_waiting():
    return len(_PENDING)


def _failed_entry(path):
    """(why, stamp) a texture failed, or ("", None). An entry from before stamps were kept
    (a reloaded module) is a bare reason."""
    entry = _FAILED.get(path)
    if isinstance(entry, tuple) and len(entry) == 2:
        return entry
    return (str(entry), None) if entry else ("", None)


def textures_report(limit=TEXTURE_NAMES_SENT):
    """For Blender's hover list: the file names still to import, the next one first, and the
    textures that will not show, as [name, why]. At most `limit` of each. Pure but for the
    queues."""
    waiting = []
    for found, _role in _PENDING.values():
        name = os.path.basename(str(found.get("path") or "")) or "(unnamed)"
        if name not in waiting:
            waiting.append(name)
    failed = sorted([os.path.basename(path) or path, _failed_entry(path)[0]] for path in _FAILED)
    return {"textures_names": waiting[:limit], "textures_failed": failed[:limit],
            "textures_failed_count": len(failed)}


def textures_held():
    """Why the next texture is not being imported: "memory", "busy" or ""."""
    return _PACE["held"] if _PENDING else ""


def forget_waiting():
    """Drop the queue and the instances it would update: the connection they were for ended."""
    for token in _DECODING.values():
        _cancel_decode(token)
    _DECODING.clear()
    _PENDING.clear()
    _WAITING.clear()
    _SHOWN.clear()
    _FAILED.clear()
    _PACE["held"] = ""


# Files the native module decodes (`FImageUtils::LoadImage`); anything else goes to the importer.
DECODED_EXTENSIONS = (".png", ".jpg", ".jpeg", ".tga", ".bmp", ".exr", ".hdr")
# Files decoded ahead of the one being made, and the decoded megabytes they may hold.
DECODE_AHEAD = 6
DECODE_LIMIT_MB = 1024
# Game-thread time a tick may spend making textures from decoded files.
MAKE_BUDGET = 0.012


def _cancel_decode(token):
    if token:
        try:
            import unreal

            unreal.BULinkLibrary.cancel_image_load(token)
        except Exception:  # noqa: BLE001
            pass


def _decoder():
    """BULinkLibrary if its native module decodes files, else None."""
    import unreal

    library = getattr(unreal, "BULinkLibrary", None)
    return library if library is not None and hasattr(library, "begin_image_load") else None


def _decode_ahead(library):
    """Start decoding the next few queued files on workers."""
    try:
        loads = library.get_image_loads()
        if float(loads.z) >= DECODE_LIMIT_MB:
            return
    except Exception:  # noqa: BLE001
        pass
    started = sum(1 for key in _PENDING if key in _DECODING)
    for key, (found, _role) in _PENDING.items():
        if started >= DECODE_AHEAD:
            break
        if key in _DECODING:
            continue
        path = str(found.get("path") or "")
        if not path.lower().endswith(DECODED_EXTENSIONS):
            _DECODING[key] = 0  # the importer's
            continue
        _DECODING[key] = int(library.begin_image_load(path))
        started += 1


def _next_ready(library):
    """(queue key, token) of the first queued texture that can be made now, or (None, 0):
    decoded, or one the importer must take. Failed decodes go to the importer."""
    for key in list(_PENDING):
        token = _DECODING.get(key)
        if token is None:
            return None, 0  # the queue's head is not even decoding yet
        if token == 0:
            return key, 0
        state = int(library.poll_image_load(token))
        if state == 1:
            return key, token
        if state < 0:
            _DECODING[key] = 0
            return key, 0
    return None, 0


def service_textures(now, gauge=None):
    """Make the next textures in the queue if Unreal has room for them, and show them on every
    instance that asked. Returns how many instances changed.

    With the native module, files are decoded on workers ahead of time and several textures may
    be made in one tick (`MAKE_BUDGET`); without it, Unreal's importer takes one a tick.
    """
    if not _PENDING:
        return 0
    from . import bu_link_pace

    library = _decoder()
    if library is not None:
        _decode_ahead(library)
    started = time.perf_counter()
    shown = 0
    while _PENDING:
        compiles, memory = (gauge or bu_link_pace.gauge)()
        held, ok = bu_link_pace.may_start(compiles, memory, now, _PACE["last"],
                                          bu_link_pace.compile_limit(memory))
        _PACE["held"] = held
        if not ok:
            break
        if library is None:
            key, token = next(iter(_PENDING)), 0
        else:
            key, token = _next_ready(library)
            if key is None:
                break  # still decoding
        shown += _make_texture(key, token)
        _PACE["last"] = now
        if library is None or time.perf_counter() - started >= MAKE_BUDGET:
            break
    return shown


def _make_texture(key, token):
    """Make one queued texture (from its decoded file, or by the importer) and show it."""
    found, role = _PENDING.pop(key)  # made, or failed: either way not asked again
    _DECODING.pop(key, None)
    try:
        load_texture(found, role=role, wait=True, decoded=token)
    except Exception as exc:  # noqa: BLE001
        # Left at the head of the queue, it raised again every tick, and the tick's capture and
        # replies never ran: Unreal's picture stopped for good.
        _FAILED[str(found.get("path") or "")] = (
            "could not import ({0})".format(type(exc).__name__), str(found.get("stamp") or ""))
        _WAITING.pop(key, None)
        return 0
    shown = 0
    for ident in _WAITING.pop(key, ()):
        entry = _SHOWN.get(ident)
        if entry is None:
            continue
        try:
            apply(*entry)
        except Exception:  # noqa: BLE001 - an instance replaced since, and gone
            _SHOWN.pop(ident, None)
            continue
        shown += 1
    return shown


def _wait_for(instance, field, role):
    key = texture_key(field, role or "color")
    if key in _PENDING:
        _WAITING.setdefault(key, set()).add(id(instance))


# -- instances -----------------------------------------------------------------------------------

def unreal_material(spec):
    """The project material Blender picked with "Use Unreal Material", or None."""
    import unreal

    path = str((spec or {}).get("unreal_material") or "")
    if not path.startswith("/"):
        return None
    found = unreal.EditorAssetLibrary.load_asset(path)
    if found is None or not isinstance(found, unreal.MaterialInterface):
        unreal.log_warning("BU: {0} is not a material in this project".format(path))
        return None
    return found


def create(world, spec):
    """A dynamic instance of the right master showing `spec`, or None."""
    import unreal

    which = kind(spec)
    if which == "unreal":
        picked = unreal_material(spec)
        if picked is not None:
            return picked
        which = auto_surface(spec)
    parent = None
    if graph_driven(spec):
        from . import bu_link_graph

        parent = bu_link_graph.ensure(which, spec)
    if parent is None:
        parent = ensure(which)
    if parent is None:
        return None
    # `MaterialLibrary` is the Python name of `UKismetMaterialLibrary` (a ScriptName); the C++
    # name does not exist in Python, which a mocked `unreal` cannot tell you.
    instance = unreal.MaterialLibrary.create_dynamic_material_instance(world, parent)
    if instance is not None:
        apply(instance, spec)
    return instance


def apply(instance, spec):
    """Show `spec` on an instance `create` made. A project material is left as it is."""
    import unreal

    if kind(spec) == "unreal" or not hasattr(instance, "set_scalar_parameter_value"):
        return
    _SHOWN[id(instance)] = (instance, spec)
    vectors, scalars = parameters(spec)
    for name, value in vectors.items():
        instance.set_vector_parameter_value(name, unreal.LinearColor(*value, 1.0))
    for name, value in scalars.items():
        instance.set_scalar_parameter_value(name, value)
    driven = graph_driven(spec)
    plan = [entry for entry in texture_plan(spec) if entry[0] not in driven]
    planned = {channel for channel, _field, _role, _weights in plan}
    for channel, field, role, weights in plan:
        texture = load_texture(field, role=role)
        if texture is None:
            _wait_for(instance, field, role)  # its plain colour until the texture is in
            planned.discard(channel)
            continue
        instance.set_texture_parameter_value(texture_param(channel), texture)
        instance.set_vector_parameter_value(channel_param(channel), unreal.LinearColor(*weights))
    # Every switch is written, on or off: an instance updated in place may have had a texture.
    for channel in (BASE_COLOR_PARAM, METALLIC_PARAM, ROUGHNESS_PARAM, EMISSIVE_PARAM,
                    OPACITY_PARAM):
        instance.set_scalar_parameter_value(use_param(channel), 1.0 if channel in planned else 0.0)
    if NORMAL_PARAM not in planned:
        flat = unreal.load_asset(DEFAULT_NORMAL)
        if flat is not None:
            instance.set_texture_parameter_value(texture_param(NORMAL_PARAM), flat)
    if driven:
        _apply_graph(unreal, instance, spec)


def graph_parameters(spec):
    """({scalar name: value}, {vector name: (r, g, b)}, {texture name: (field, role)}). Pure."""
    from . import bu_link_graph

    graph = spec.get("graph") or {}
    kinds = bu_link_graph.parameter_kinds(graph)
    values = spec.get("graph_values") if isinstance(spec.get("graph_values"), dict) else {}
    scalars, vectors = {}, {}
    for name, kind_ in kinds.items():
        value = values.get(name)
        if kind_ == "f":
            scalars[name] = _number(value, 0.0)
        else:
            vectors[name] = _triple(value, (0.0, 0.0, 0.0)) if kind_ == "c" else _vector(value)
    ramps = {node["opt"]["tex"] for node in graph.get("nodes") or ()
             if node.get("op") == "ramp" and "tex" in (node.get("opt") or {})}
    normals = bu_link_graph.normal_textures(graph)
    found = spec.get("graph_textures") if isinstance(spec.get("graph_textures"), dict) else {}
    textures = {name: (found[name], "lut" if name in ramps else "normal" if name in normals
                       else "height" if found[name].get("height") else "color")
                for name in bu_link_graph.texture_names(graph) if _has_file(found.get(name))}
    return scalars, vectors, textures


def _vector(value):
    """Three floats, negatives kept (a vector, unlike a colour). Pure."""
    try:
        values = [float(v) for v in value][:3]
    except (TypeError, ValueError):
        return (0.0, 0.0, 0.0)
    return tuple(values) if len(values) == 3 else (0.0, 0.0, 0.0)


def with_values(spec, values):
    """`spec` with some graph values replaced. Pure."""
    merged = dict(spec.get("graph_values") if isinstance(spec.get("graph_values"), dict) else {})
    merged.update(values)
    return dict(spec, graph_values=merged)


def value_parameters(spec, names):
    """({scalar name: value}, {vector name: (r, g, b)}) for the named graph values. Pure."""
    from . import bu_link_graph

    kinds = bu_link_graph.parameter_kinds(spec.get("graph") or {})
    values = spec.get("graph_values") if isinstance(spec.get("graph_values"), dict) else {}
    scalars, vectors = {}, {}
    for name in names:
        kind_ = kinds.get(name)
        if kind_ is None:
            continue
        value = values.get(name)
        if kind_ == "f":
            scalars[name] = _number(value, 0.0)
        else:
            vectors[name] = _triple(value, (0.0, 0.0, 0.0)) if kind_ == "c" else _vector(value)
    return scalars, vectors


def apply_values(instance, spec, names):
    """Set only the named graph values on an instance already made for this spec."""
    import unreal

    scalars, vectors = value_parameters(spec, names)
    for name, value in scalars.items():
        instance.set_scalar_parameter_value(name, value)
    for name, value in vectors.items():
        instance.set_vector_parameter_value(name, unreal.LinearColor(*value, 1.0))


def _apply_graph(unreal, instance, spec):
    scalars, vectors, textures = graph_parameters(spec)
    for name, value in scalars.items():
        instance.set_scalar_parameter_value(name, value)
    for name, value in vectors.items():
        instance.set_vector_parameter_value(name, unreal.LinearColor(*value, 1.0))
    for name, (field, role) in textures.items():
        texture = load_texture(field, role=role)
        if texture is not None:
            instance.set_texture_parameter_value(name, texture)
        else:
            _wait_for(instance, field, role)


ASSET_KINDS = {
    "ies": ("TextureLightProfile",),
    "light_function": ("Material", "MaterialInstanceConstant"),
    "texture": ("Texture2D",),
}


def project_assets(kind, limit=MATERIAL_LIST_LIMIT):
    """Object paths of one kind of project asset, for the Unreal Light panel's pickers."""
    import unreal

    registry = unreal.AssetRegistryHelpers.get_asset_registry()
    found = []
    for class_name in ASSET_KINDS.get(kind, ()):
        try:
            assets = registry.get_assets_by_class(
                unreal.TopLevelAssetPath("/Script/Engine", class_name), False)
        except Exception:  # noqa: BLE001
            assets = []
        for data in assets:
            package = str(data.package_name)
            if package.startswith("/Game/") and not package.startswith(PACKAGE + "/") \
                    and not package.startswith(TEXTURE_PACKAGE + "/"):
                found.append("{0}.{1}".format(package, data.asset_name))
    return sorted(set(found), key=lambda path: path.lower())[:limit]


def project_materials(limit=MATERIAL_LIST_LIMIT):
    """Object paths of the project's materials, for Blender's "Use Unreal Material" list."""
    import unreal

    registry = unreal.AssetRegistryHelpers.get_asset_registry()
    found = []
    for class_name in ("Material", "MaterialInstanceConstant"):
        try:
            assets = registry.get_assets_by_class(
                unreal.TopLevelAssetPath("/Script/Engine", class_name), False)
        except Exception:  # noqa: BLE001 - an older registry API
            assets = []
        for data in assets:
            package = str(data.package_name)
            # The link's own masters are not something to pick.
            if package.startswith("/Game/") and not package.startswith(PACKAGE + "/"):
                found.append("{0}.{1}".format(package, data.asset_name))
    return sorted(set(found), key=lambda path: path.lower())[:limit]
