# SPDX-License-Identifier: GPL-3.0-or-later
"""BU in an editor someone opened themselves: the link listens by itself, Blender finds it, and
the project is asked once about the render settings BU wants.

`init_unreal.py` calls `begin()` in every editor BU did not start. BU's own hidden editor has
BU_HOST_PORT in its environment and runs `bu_host` instead; nothing here touches it.

* **Listening.** A few engine frames after the editor is up, once the asset registry's first
  scan is done (the link's mesh cache looks assets up), the link listens: on 47823, or on a free
  port when another editor has that one. Not in an editor nobody sees (`-unattended`,
  `-RenderOffscreen`, a commandlet), nor with BU_LINK_AUTO=0 in the environment, nor in a
  project where Tools > BU turned it off (`"listen": false` in the project's
  Config/BUBridge.json).
* **Being found.** While the link listens, the editor keeps a small file in the user's
  %LOCALAPPDATA%/BU/editors (BU_EDITORS_DIR overrides the folder): the project and its
  .uproject, the port, the process, the engine version, when it started and when its window
  last had the focus. Blender reads these (`link_find.py`) and connects with no port to type.
  The file goes when the link stops or the editor closes. One left behind by a crash names a
  process that has ended, and Blender skips it.
* **The project's render settings.** The first time Blender connects, if the project lacks
  settings BU renders with (ray tracing, Substrate, Lumen, virtual shadow maps...), one question
  lists them. Yes adds them to Config/DefaultEngine.ini, leaving every other line as it was, and
  restarts the editor once. No is remembered in Config/BUBridge.json and never asked again.
  Cancel asks again next time. BU_NO_PROMPT=1 never asks; nor does an editor nobody sees.

The pure parts (the settings, reading and writing the ini, the files) need nothing but the
standard library, and are tested without Unreal (`tests/test_link_host.py`).
"""

import json
import os
import re
import subprocess
import sys
import time

ENV_HOST_PORT = "BU_HOST_PORT"   # BU's own editor (`bu_host`)
ENV_AUTO = "BU_LINK_AUTO"        # "0": never listen by itself
ENV_NO_PROMPT = "BU_NO_PROMPT"   # "1": never ask about the render settings
ENV_DIR = "BU_EDITORS_DIR"       # where the editors' files go (Blender's `link_find.ENV_DIR`)

DEFAULT_PORT = 47823             # `bu_link_wire.DEFAULT_PORT`
CHOICES_FILE = "BUBridge.json"   # in the project's Config folder: shared with the project
ENGINE_INI = "DefaultEngine.ini"

# Editors that nobody sits at: started for a test, a build or a cook. They never listen by
# themselves and never ask anything.
QUIET_SWITCHES = ("-unattended", "-renderoffscreen", "-nullrhi", "-run=", "-game", "-server")

# Engine frames from the first tick to listening, as `bu_host.STEP_FRAMES`: Slate also ticks
# inside engine frame 0 while the editor is still starting.
STEP_FRAMES = 10
TICK_SECONDS = 1.0

RENDERER = "/Script/Engine.RendererSettings"
WINDOWS = "/Script/WindowsTargetPlatform.WindowsTargetSettings"

# What BU renders with, from the settings it writes into its own render project
# (`link_host.ENGINE_INI`), less what only suits a project nobody works in (its startup map,
# Nanite and static lighting off, auto exposure). Each: (id, words for the question, lines).
# A line is (section, key, value, accepted): `accepted` are the values (lower case, booleans as
# "1"/"0") that already count as right, and "" among them means a project that does not say is
# right too. A key starting "+" adds to a list, and is right when that very line is there.
# When any line of a setting is wanting, all of its lines are written.
RENDER_SETTINGS = (
    ("ray_tracing", "Hardware ray tracing",
     ((RENDERER, "r.RayTracing", "True", ("1",)),
      (RENDERER, "r.SkinCache.CompileShaders", "True", ("1",)))),
    ("lumen", "Lumen global illumination and reflections",
     ((RENDERER, "r.DynamicGlobalIlluminationMethod", "1", ("1",)),
      (RENDERER, "r.ReflectionMethod", "1", ("1",)))),
    ("substrate", "Substrate materials (with every layer, so sheen shows)",
     ((RENDERER, "r.Substrate", "True", ("1",)),
      (RENDERER, "r.Substrate.ProjectGBufferFormat", "1", ("0", "1")))),
    ("virtual_shadows", "Virtual shadow maps",
     ((RENDERER, "r.Shadow.Virtual.Enable", "1", ("1",)),)),
    ("distance_fields", "Mesh distance fields",
     ((RENDERER, "r.GenerateMeshDistanceFields", "True", ("1",)),)),
    ("translucent_lights", "Area lights, shadows, IES and light functions on glass",
     ((RENDERER, "r.Translucent.UsesRectLights", "True", ("1",)),
      (RENDERER, "r.Translucent.UsesShadowedLocalLights", "True", ("1",)),
      (RENDERER, "r.Translucent.UsesIESProfiles", "True", ("1",)),
      (RENDERER, "r.Translucent.UsesLightFunctionAtlas", "True", ("1",)))),
    ("dx12_sm6", "DirectX 12 with Shader Model 6 (ray tracing needs it)",
     ((WINDOWS, "DefaultGraphicsRHI", "DefaultGraphicsRHI_DX12",
       ("defaultgraphicsrhi_dx12", "defaultgraphicsrhi_default", "")),
      (WINDOWS, "+D3D12TargetedShaderFormats", "PCD3D_SM6", None))),
)
SETTING_IDS = tuple(setting[0] for setting in RENDER_SETTINGS)

# Said by Tools > BU's project entries in BU's own editor (its window shown): Blender sets that
# project up and runs its link itself.
HOSTED_LINE = ("This is BU's own editor, which Blender started: Blender sets up its project and "
               "starts its link itself. These choices are for your own projects.")


# -- the files -----------------------------------------------------------------------------------

def editors_dir(environ=None):
    """Where each listening editor keeps its file. Blender's `link_find.editors_dir` agrees."""
    environ = os.environ if environ is None else environ
    if environ.get(ENV_DIR):
        return environ[ENV_DIR]
    base = environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local")
    return os.path.join(base, "BU", "editors")


def record_path(folder, pid):
    return os.path.join(folder, "{0}.json".format(int(pid)))


def editor_record(project, uproject, port, pid, engine, started, focused):
    """What an editor's file says about it. Pure."""
    return {"kind": "bu-editor", "version": 1, "project": str(project or ""),
            "uproject": str(uproject or ""), "port": int(port), "pid": int(pid),
            "engine": str(engine or ""), "started": float(started), "focused": float(focused)}


def write_json(path, data):
    """Written whole or not at all: Blender may read it at any moment."""
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    temporary = path + ".tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=1)
    os.replace(temporary, path)


def remove_file(path):
    if path:
        try:
            os.remove(path)
        except OSError:
            pass


def read_choices(path):
    """The project's answers ({} when it has none): `listen`, `settings_answered`,
    `settings_answer`."""
    try:
        with open(path, encoding="utf-8-sig") as handle:
            data = json.load(handle)
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def save_choices(path, choices):
    data = dict(choices)
    data.setdefault("about", "BU (Blender to Unreal) keeps its answers for this project here.")
    write_json(path, data)


# -- when to listen and ask ----------------------------------------------------------------------

def quiet_switch(command_line):
    """The switch that says nobody sits at this editor ("-unattended"...), or "". Pure."""
    for token in str(command_line or "").lower().split():
        token = token.strip('"')
        for switch in QUIET_SWITCHES:
            if token == switch or (switch.endswith("=") and token.startswith(switch)):
                return switch
    return ""


def listen_wanted(environ, command_line, choices):
    """(whether the link listens by itself, why not). Pure."""
    if environ.get(ENV_HOST_PORT):
        return False, "BU's own editor starts its link itself"
    if str(environ.get(ENV_AUTO, "")).strip() == "0":
        return False, ENV_AUTO + "=0"
    switch = quiet_switch(command_line)
    if switch:
        return False, "started with " + switch
    if choices.get("listen") is False:
        return False, "turned off for this project (Tools > BU)"
    return True, ""


def ask_wanted(environ, command_line):
    """Whether this editor may ask anything at all. Pure."""
    return (not environ.get(ENV_HOST_PORT) and str(environ.get(ENV_NO_PROMPT, "")) != "1"
            and not quiet_switch(command_line))


# -- the project's settings ----------------------------------------------------------------------

def _normal(value):
    value = str(value if value is not None else "").strip().strip('"').lower()
    return {"true": "1", "false": "0"}.get(value, value)


def _sections(rows):
    """[(name lower case, first row, end row)] for every section header in `rows`."""
    found = []
    for index, row in enumerate(rows):
        text = row.strip()
        if text.startswith("[") and text.endswith("]"):
            if found:
                found[-1][2] = index
            found.append([text[1:-1].strip().lower(), index + 1, len(rows)])
    return found


def _key(row):
    text = row.strip()
    if not text or text[0] in ";#" or "=" not in text:
        return ""
    return text.split("=", 1)[0].strip().lower()


def ini_value(text, section, key):
    """The last value `text` gives `key` in `section`, or None when it does not say. Pure."""
    rows = str(text or "").splitlines()
    value = None
    for name, first, end in _sections(rows):
        if name != section.lower():
            continue
        for row in rows[first:end]:
            if _key(row) == key.lower():
                value = row.split("=", 1)[1].strip()
    return value


def ini_has_line(text, section, key, value):
    """Whether `section` holds exactly `key=value` (a list entry such as "+Formats=SM6"). Pure."""
    rows = str(text or "").splitlines()
    wanted = "{0}={1}".format(key, value).replace(" ", "").lower()
    for name, first, end in _sections(rows):
        if name == section.lower() and any(row.replace(" ", "").lower() == wanted
                                           for row in rows[first:end]):
            return True
    return False


def line_right(line, ini_text, effective=None):
    """Whether one line of a setting is already as BU wants it. Pure.

    Right when the running editor's console variable says so (`effective`: key -> value, for
    what the engine can be asked), or the project's DefaultEngine.ini does, or it says nothing
    and the engine's default is right."""
    section, key, value, accepted = line
    if key.startswith("+"):
        return ini_has_line(ini_text, section, key, value)
    if effective and effective.get(key) is not None and _normal(effective[key]) in accepted:
        return True
    written = ini_value(ini_text, section, key)
    if written is None:
        return "" in accepted
    return _normal(written) in accepted


def settings_wanted(ini_text, effective=None):
    """The ids of BU's render settings this project lacks, in RENDER_SETTINGS' order. Pure."""
    return [ident for ident, _words, lines in RENDER_SETTINGS
            if not all(line_right(line, ini_text, effective) for line in lines)]


def settings_to_ask(wanted, choices):
    """Those not already answered, yes or no, in this project. Pure."""
    answered = set(choices.get("settings_answered") or ())
    return [ident for ident in wanted if ident not in answered]


def _set_line(rows, section, key, value):
    """`rows` with `key=value` in `section`: a scalar's existing lines rewritten, a list entry
    added unless it is there; at the end of the section's last appearance, or a new section."""
    line = "{0}={1}".format(key, value)
    blocks = [block for block in _sections(rows) if block[0] == section.lower()]
    if key.startswith("+"):
        if ini_has_line("\n".join(rows), section, key, value):
            return rows
    else:
        found = False
        for _name, first, end in blocks:
            for index in range(first, end):
                if _key(rows[index]) == key.lower():
                    rows[index] = line
                    found = True
        if found:
            return rows
    if not blocks:
        while rows and not rows[-1].strip():
            rows.pop()
        return rows + ([""] if rows else []) + ["[{0}]".format(section), line]
    _name, first, end = blocks[-1]
    at = end
    while at > first and not rows[at - 1].strip():
        at -= 1
    return rows[:at] + [line] + rows[at:]


def apply_settings(ini_text, idents):
    """DefaultEngine.ini's text with BU's settings `idents` in it, every other line as it was.
    Its line endings are kept. Applying twice changes nothing more. Pure."""
    text = str(ini_text or "")
    newline = "\r\n" if "\r\n" in text else "\n"
    rows = text.splitlines()
    for ident, _words, lines in RENDER_SETTINGS:
        if ident in idents:
            for section, key, value, _accepted in lines:
                rows = _set_line(rows, section, key, value)
    return newline.join(rows) + newline if rows else ""


def read_text_kept(path):
    """(text, encoding) of a config file, "" for one not there. Unreal writes UTF-8, or UTF-16
    with a byte-order mark when a value needs it; it is written back the same way."""
    try:
        with open(path, "rb") as handle:
            data = handle.read()
    except OSError:
        return "", "utf-8"
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16"), "utf-16"
    if data.startswith(b"\xef\xbb\xbf"):
        return data.decode("utf-8-sig"), "utf-8-sig"
    try:
        return data.decode("utf-8"), "utf-8"
    except UnicodeDecodeError:
        return data.decode("latin-1"), "latin-1"


def write_text_kept(path, text, encoding):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding=encoding, newline="") as handle:
        handle.write(text)


def question(idents):
    """The question's text, for the settings `idents`. Pure."""
    words = {ident: text for ident, text, _lines in RENDER_SETTINGS}
    listed = "\n".join("    • " + words[ident] for ident in idents if ident in words)
    return ("Blender is connected. BU renders its scenes with these project settings, which "
            "this project does not have yet:\n\n{0}\n\n"
            "Yes: BU adds them to Config/DefaultEngine.ini (nothing else in it changes) and "
            "restarts Unreal, asking first about anything unsaved. The first start afterwards "
            "compiles shaders, which can take a while.\n\n"
            "No: BU works without them, with less of Blender's lighting, and does not ask "
            "again. Tools > BU > Apply BU's Render Settings asks again whenever you want.\n\n"
            "Cancel: ask next time.").format(listed)


def restart_command(pid, editor_exe, uproject, wait_seconds=600):
    """The command that starts the editor again once this one (`pid`) has closed. Pure.

    A hidden PowerShell waits for the editor to end, then starts it on the same project. If it
    is still open after `wait_seconds` (the person said Cancel to saving), nothing starts."""
    def quoted(text):
        return "'" + str(text).replace("'", "''") + "'"

    script = ("$p = Get-Process -Id {pid} -ErrorAction SilentlyContinue; "
              "if ($p -and -not $p.WaitForExit({ms})) {{ exit }}; "
              "Start-Process -FilePath {exe} -ArgumentList {arguments}").format(
                  pid=int(pid), ms=int(wait_seconds * 1000), exe=quoted(editor_exe),
                  arguments=quoted('"{0}"'.format(uproject)))
    return ["powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden",
            "-Command", script]


# -- the running editor --------------------------------------------------------------------------

class _State(object):
    def __init__(self, environ):
        self.environ = environ
        self.phase = "waiting"     # "waiting" for the editor to be up, then "running"
        self.step_frame = None
        self.ticks = 0
        self.last_tick = 0.0
        self.handle = None
        self.started = time.time()
        self.focused = 0.0
        self.foreground = False
        self.folder = editors_dir(environ)
        self.path = record_path(self.folder, os.getpid())
        self.published = 0         # the port the file names, 0 for no file
        self.asked = False         # the question was considered for this connection
        self.busy = False          # the question is up: its own loop ticks Slate too
        self.why_not = ""


try:
    _STATE  # noqa: B018 - survives bu_bridge.reload() on purpose
except NameError:
    _STATE = None


def _log(text):
    import unreal

    unreal.log("BU: " + text)


def _warn(text):
    import unreal

    unreal.log_warning("BU: " + text)


def _command_line():
    import unreal

    try:
        return str(unreal.SystemLibrary.get_command_line())
    except Exception:  # noqa: BLE001 - an engine without it: taken as someone's editor
        return " ".join(sys.argv[1:])


def _full(path):
    import unreal

    try:
        return os.path.normpath(unreal.Paths.convert_relative_path_to_full(path))
    except Exception:  # noqa: BLE001
        return os.path.normpath(os.path.abspath(path))


def project_file():
    import unreal

    return _full(unreal.Paths.get_project_file_path())


def config_dir():
    return os.path.join(os.path.dirname(project_file()), "Config")


def choices_path():
    return os.path.join(config_dir(), CHOICES_FILE)


def _engine_version():
    import unreal

    try:
        return str(unreal.SystemLibrary.get_engine_version())
    except Exception:  # noqa: BLE001
        return ""


def _editor_exe():
    import unreal

    try:
        engine = _full(unreal.Paths.engine_dir())
    except Exception:  # noqa: BLE001
        return ""
    exe = os.path.join(engine, "Binaries", "Win64", "UnrealEditor.exe")
    return exe if os.path.isfile(exe) else ""


def _frame_count(state):
    import unreal

    try:
        return int(unreal.SystemLibrary.get_frame_count())
    except Exception:  # noqa: BLE001
        return state.ticks


def _assets_loading():
    import unreal

    try:
        return bool(unreal.AssetRegistryHelpers.get_asset_registry().is_loading_assets())
    except Exception:  # noqa: BLE001
        return False


def _in_front():
    """Whether this editor's window has the focus. Windows only; elsewhere never."""
    if sys.platform != "win32":
        return False
    try:
        import ctypes

        user32 = ctypes.windll.user32
        window = user32.GetForegroundWindow()
        if not window:
            return False
        owner = ctypes.c_ulong(0)
        user32.GetWindowThreadProcessId(window, ctypes.byref(owner))
        return owner.value == os.getpid()
    except Exception:  # noqa: BLE001
        return False


def _link():
    from . import bu_link

    return bu_link


def link_port():
    """The port the link listens on, or 0."""
    state = getattr(_link(), "_STATE", None)
    return int(getattr(state, "port", 0) or 0) if state is not None else 0


def _free_port():
    import socket

    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        probe.bind(("127.0.0.1", 0))
        return probe.getsockname()[1]
    finally:
        probe.close()


def listen_now():
    """Have the link listen: on 47823, or on a free port when another editor has that one.
    Returns the port, or 0 when it could not."""
    bu_link = _link()
    port = link_port()
    if port:
        return port
    last = None
    for wanted in (DEFAULT_PORT, None):
        try:
            wanted = wanted or _free_port()
            bu_link.start(wanted)
            _log("listening for Blender on port {0}".format(wanted))
            if _STATE is not None:
                _publish(_STATE)
            return wanted
        except (RuntimeError, OSError) as exc:
            last = exc
    _warn("the link could not listen: {0}".format(last))
    return 0


def _publish(state):
    """Keep this editor's file naming the port the link listens on; none while it does not."""
    port = link_port()
    if port == state.published:
        return
    if not port:
        remove_file(state.path)
        state.published = 0
        return
    try:
        uproject = project_file()
        record = editor_record(os.path.splitext(os.path.basename(uproject))[0], uproject, port,
                               os.getpid(), _engine_version(), state.started, state.focused)
        write_json(state.path, record)
        state.published = port
    except Exception as exc:  # noqa: BLE001 - Blender then needs the port typed, as before
        _warn("could not note this editor for Blender ({0}): {1}".format(state.path, exc))
        state.published = port


def _unpublish():
    state = _STATE
    if state is not None:
        remove_file(state.path)
        state.published = 0


def _trampoline(delta_seconds):
    module = sys.modules.get(__name__)
    if module is not None:
        module._tick(delta_seconds)


def begin(environ=None):
    """Start, from `init_unreal.py`, in an editor BU did not start. Returns whether it did."""
    global _STATE
    environ = os.environ if environ is None else environ
    if environ.get(ENV_HOST_PORT) or _STATE is not None:
        return False
    import unreal

    state = _State(environ)
    state.handle = unreal.register_slate_post_tick_callback(_trampoline)
    _STATE = state
    # The file goes as the editor closes; atexit too, for an engine without the callback.
    register = getattr(unreal, "register_python_shutdown_callback", None)
    if register is not None:
        try:
            register(_unpublish)
        except Exception:  # noqa: BLE001
            pass
    import atexit

    atexit.register(_unpublish)
    return True


def _tick(_delta_seconds):
    state = _STATE
    if state is None or state.busy:
        return
    now = time.time()
    try:
        if state.phase == "waiting":
            state.ticks += 1
            frame = _frame_count(state)
            if state.step_frame is None:
                state.step_frame = frame
            if frame - state.step_frame < STEP_FRAMES or _assets_loading():
                return
            state.phase = "running"
            state.last_tick = now
            wanted, state.why_not = listen_wanted(state.environ, _command_line(),
                                                  read_choices(choices_path()))
            if wanted:
                listen_now()
            else:
                _log("the link does not listen by itself here: " + state.why_not)
            return
        if now - state.last_tick < TICK_SECONDS:
            return
        state.last_tick = now
        front = _in_front()
        if front and not state.foreground:
            state.focused = now
            state.published = -1  # written again, with the new time
        state.foreground = front
        _publish(state)
        _watch_connection(state)
    except Exception as exc:  # noqa: BLE001 - a raising tick callback would spam every frame
        if str(exc) != state.why_not:
            state.why_not = str(exc)
            _warn("{0}: {1}".format(type(exc).__name__, exc))


def _watch_connection(state):
    """Blender has connected: ask about the project's settings, once per connection."""
    link_state = getattr(_link(), "_STATE", None)
    connected = link_state is not None and getattr(link_state, "client", None) is not None
    if not connected:
        state.asked = False
        return
    if state.asked:
        return
    state.asked = True
    if ask_wanted(state.environ, _command_line()):
        ask(force=False)


def _effective():
    """The running editor's console variables for BU's settings (key -> value). A variable this
    engine lacks reads "0" (seen in 5.8), not an error: at worst it is asked for when not needed."""
    import unreal

    values = {}
    for _ident, _words, lines in RENDER_SETTINGS:
        for _section, key, _value, _accepted in lines:
            if not key.startswith("r."):
                continue
            try:
                values[key] = str(unreal.SystemLibrary.get_console_variable_int_value(key))
            except Exception:  # noqa: BLE001
                values[key] = None
    return values


def wanted_here():
    """BU's settings this project lacks."""
    ini_text, _encoding = read_text_kept(os.path.join(config_dir(), ENGINE_INI))
    return settings_wanted(ini_text, _effective())


def _tell_blender(text):
    """A line for Blender's Unreal panel."""
    bu_link = _link()
    link_state = getattr(bu_link, "_STATE", None)
    if link_state is None or getattr(link_state, "client", None) is None:
        return
    try:
        bu_link._queue(link_state, {"type": "log", "text": text})
        bu_link._flush(link_state)
    except Exception:  # noqa: BLE001
        pass


def _message(text, kind="OK"):
    import unreal

    return unreal.EditorDialog.show_message("BU — Blender to Unreal", text,
                                            getattr(unreal.AppMsgType, kind))


def ask(force=True):
    """Ask about BU's render settings this project lacks; from Blender's first connection, or
    Tools > BU (`force`: also those answered before). Returns the settings written."""
    import unreal

    if os.environ.get(ENV_HOST_PORT):
        _message(HOSTED_LINE)
        return []
    path = choices_path()
    choices = read_choices(path)
    wanted = wanted_here()
    idents = wanted if force else settings_to_ask(wanted, choices)
    if not idents:
        if force:
            _message("This project already has every render setting BU uses.")
        return []
    state = _STATE
    if state is not None:
        state.busy = True
    try:
        _tell_blender("Unreal is asking about this project's render settings: answer it in "
                      "Unreal's window")
        answer = _message(question(idents), "YES_NO_CANCEL")
    finally:
        if state is not None:
            state.busy = False
    if answer == unreal.AppReturnType.CANCEL:
        _tell_blender("")
        return []
    choices["settings_answered"] = sorted(set(choices.get("settings_answered") or ()) | set(idents))
    if answer != unreal.AppReturnType.YES:
        choices["settings_answer"] = "no"
        _save(path, choices)
        _tell_blender("")
        _log("render settings left as they are; not asked again in this project")
        return []
    ini = os.path.join(config_dir(), ENGINE_INI)
    text, encoding = read_text_kept(ini)
    try:
        write_text_kept(ini, apply_settings(text, idents), encoding)
    except OSError as exc:
        _message("BU could not write {0} ({1}). If it is checked in to source control, check it "
                 "out, then Tools > BU > Apply BU's Render Settings.".format(ini, exc))
        return []
    choices["settings_answer"] = "yes"
    _save(path, choices)
    _log("added BU's render settings to {0}: {1}".format(ini, ", ".join(idents)))
    _tell_blender("Unreal is restarting for its new render settings")
    if not restart():
        _message("The settings are in Config/DefaultEngine.ini. Restart Unreal for them to "
                 "take effect.")
    return idents


def _save(path, choices):
    try:
        save_choices(path, choices)
    except OSError as exc:
        _warn("could not keep the answer in {0}: {1}".format(path, exc))


def restart():
    """Close this editor the way its close button does (asking about unsaved work), and start
    it again on the same project once it has gone. False when it cannot."""
    exe = _editor_exe()
    if not exe or sys.platform != "win32":
        return False
    command = restart_command(os.getpid(), exe, project_file())
    flags = (getattr(subprocess, "CREATE_NO_WINDOW", 0)
             | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
    breakaway = 0x01000000  # CREATE_BREAKAWAY_FROM_JOB: outlive the editor's job, if it has one
    for extra in (breakaway, 0):
        try:
            subprocess.Popen(command, creationflags=flags | extra, close_fds=True,
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
            break
        except OSError:
            continue
    else:
        return False
    from . import bu_host

    _unpublish()
    return bu_host._close_window()


def toggle_listen():
    """Tools > BU: turn listening at startup off or on for this project. Returns it."""
    if os.environ.get(ENV_HOST_PORT):
        _message(HOSTED_LINE)
        return True
    path = choices_path()
    choices = read_choices(path)
    on = choices.get("listen") is False
    choices["listen"] = on
    _save(path, choices)
    if on:
        port = listen_now()
        _message("The link now listens for Blender whenever this project opens{0}.".format(
            " (port {0})".format(port) if port else ""))
    else:
        _link().stop()
        _unpublish()
        _message("The link no longer listens by itself in this project. Tools > BU > Start "
                 "Real-Time Link still starts it.")
    return on
