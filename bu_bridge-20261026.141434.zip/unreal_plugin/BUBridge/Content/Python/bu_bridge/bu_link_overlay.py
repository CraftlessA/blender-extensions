# SPDX-License-Identifier: GPL-3.0-or-later
"""Overlay materials: a second material drawn over an object's own (Object properties >
Unreal > Overlay in Blender).

Unreal draws a mesh component's Overlay Material over every one of its sections. Its static
and instanced meshes do; its dynamic meshes do not (`FDynamicMeshSceneProxy` draws only the
section materials, and is final and private to the engine). BU shows a live mesh through a
dynamic mesh while it changes and a static stand-in once it settles (`bu_link_static`), so an
overlay set by hand showed on a settled character and went the moment it moved. So:

- The overlay is Blender's to say, per object, and kept here (`state.overlays`); every
  stand-in or rebuild gets it again.
- It is stored on the live dynamic component too (its `overlay_material`, which it keeps but
  does not draw), and a stand-in copies it from there (`bu_link_static.promote`).
- While the dynamic mesh shows, a **mirror** draws it: a second DynamicMeshComponent on the
  same actor, given the same geometry by the same native call (`follow`) and wearing only the
  overlay. It costs a second update of that one object's mesh each frame, nothing for objects
  without an overlay.

**Voxel Rim** is the project author's M_VoxelRim (a light-reactive, normal-free rim light for
voxel meshes: the silhouette found from the depth buffer gives a grazing normal, and Unreal's
own lighting does the rest), built here from `voxel_rim.hlsl` into BU's own content, Two
Sided, with per-object values on a dynamic instance.
"""

import hashlib
import os

RIM_PACKAGE = "/Game/BU/Materials"
RIM_SOURCE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "voxel_rim.hlsl")
MIRROR_TAG = "BUOverlay"
# Scene depth (any silhouette: against the floor too) or custom depth (only the object's own
# outline: it and its fellows are drawn into the custom depth pass).
SCENE_DEPTH, CUSTOM_DEPTH = 1, 13

# The material's own defaults (M_VoxelRim), but no flat Glow (the author's instance had it at
# 0: "it was adding a flat, light-independent stroke") and Gain 1, as that instance has it.
# Unreal clamps Base Color to 1 (measured: an orange tint at Gain 4 came out as (1, 1, 0.8),
# at 8 plain white), so a Gain past 1 only washes the tint out.
RIM_DEFAULTS = {"width": 3.0, "bias": 15.0, "feather": 150.0, "lean": 0.5, "gain": 1.0,
                "glow": 0.0, "specular": 0.0, "roughness": 1.0}
RIM_PARAMETERS = {"width": "Width", "bias": "Bias", "feather": "Feather", "lean": "Lean",
                  "gain": "Gain", "glow": "Glow", "specular": "Specular",
                  "roughness": "Roughness"}
RIM_RANGES = {"width": (0.0, 64.0), "bias": (0.0, 100000.0), "feather": (0.0, 100000.0),
              "lean": (-4.0, 4.0), "gain": (0.0, 1.0), "glow": (0.0, 10000.0),
              "specular": (0.0, 1.0), "roughness": (0.0, 1.0)}
KINDS = ("rim", "material", "unreal")
GRAPH = 1  # raised when `_build_rim` wires the material differently: a new master


def _number(value, fallback, low, high):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return fallback
    if value != value:  # NaN
        return fallback
    return min(high, max(low, value))


def plan(spec):
    """An overlay message's `overlay`, checked: None for no overlay. Pure."""
    if not isinstance(spec, dict) or spec.get("kind") not in KINDS:
        return None
    kind = spec["kind"]
    found = {"kind": kind, "distance": _number(spec.get("distance"), 0.0, 0.0, 1e9),
             "self": bool(spec.get("self"))}
    if kind == "rim":
        for key, fallback in RIM_DEFAULTS.items():
            found[key] = _number(spec.get(key), fallback, *RIM_RANGES[key])
        tint = spec.get("tint")
        if not isinstance(tint, (list, tuple)) or len(tint) < 3:
            tint = (1.0, 1.0, 1.0)
        found["tint"] = tuple(_number(c, 1.0, 0.0, 1e6) for c in tint[:3])
    elif kind == "material":
        found["material"] = str(spec.get("material") or "")
        if not found["material"]:
            return None
    else:
        found["path"] = str(spec.get("path") or "")
        if not found["path"].startswith("/"):
            return None
    return found


def rim_values(spec):
    """{Unreal parameter: value} for a rim overlay's instance, and its tint. Pure."""
    return ({RIM_PARAMETERS[key]: spec[key] for key in RIM_PARAMETERS},
            tuple(spec.get("tint") or (1.0, 1.0, 1.0)))


def rim_code():
    with open(RIM_SOURCE, "r", encoding="utf-8") as handle:
        return handle.read()


def rim_name(self_only, code=None):
    """The rim master's asset name: named after its shader's text, so a changed shader is a
    new material rather than a stale one kept from an earlier BU. Pure, given the code."""
    code = rim_code() if code is None else code
    digest = hashlib.sha1((str(GRAPH) + ":" + code).encode("utf-8")).hexdigest()[:8]
    return "M_BU_VoxelRim{0}_{1}".format("_Self" if self_only else "", digest)


_RIMS = {}


def ensure_rim(self_only=False):
    """BU's Voxel Rim master, built on first use (as the author's build_voxel_rim_material.py
    does, with Two Sided on). None if it cannot be made."""
    import unreal

    from . import bu_link_material

    name = rim_name(self_only)
    if name in _RIMS:
        return _RIMS[name]
    path = "{0}/{1}.{1}".format(RIM_PACKAGE, name)
    library = unreal.EditorAssetLibrary
    if library.does_asset_exist(path):
        found = library.load_asset(path)
        if found is not None:
            _RIMS[name] = found
            return found
    material = unreal.AssetToolsHelpers.get_asset_tools().create_asset(
        name, RIM_PACKAGE, unreal.Material, unreal.MaterialFactoryNew())
    if material is None:
        unreal.log_error("BU: could not create " + path)
        return None
    failed = _build_rim(unreal, material, self_only, bu_link_material._quiet)
    if failed:
        unreal.log_warning("BU: {0}: could not connect {1}".format(name, ", ".join(failed)))
    bu_link_material.compile_material(unreal, material)
    library.save_loaded_asset(material, only_if_is_dirty=False)
    unreal.log("BU: created {0}".format(name))
    _RIMS[name] = material
    return material


def _build_rim(unreal, material, self_only, quiet):
    edit = unreal.MaterialEditingLibrary
    failed = []

    for prop, value in (("blend_mode", unreal.BlendMode.BLEND_ADDITIVE),
                        ("shading_model", unreal.MaterialShadingModel.MSM_DEFAULT_LIT),
                        ("translucency_lighting_mode",
                         unreal.TranslucencyLightingMode.TLM_SURFACE_PER_PIXEL_LIGHTING),
                        ("tangent_space_normal", False),
                        ("two_sided", True)):
        try:
            quiet(material, prop, value, unreal)
        except Exception as exc:  # noqa: BLE001
            failed.append("{0} ({1})".format(prop, exc))

    def node(cls, x, y):
        return edit.create_material_expression(material, cls, x, y)

    def link(source, output, target, name):
        if not edit.connect_material_expressions(source, output, target, name):
            failed.append("{0}.{1}".format(name, output or "out"))

    def pin(source, output, prop):
        if not edit.connect_material_property(source, output, prop):
            failed.append(str(prop))

    def scalar(name, value, x, y):
        found = node(unreal.MaterialExpressionScalarParameter, x, y)
        quiet(found, "parameter_name", name, unreal)
        quiet(found, "default_value", float(value), unreal)
        return found

    def constant(value, x, y):
        found = node(unreal.MaterialExpressionConstant, x, y)
        quiet(found, "r", float(value), unreal)
        return found

    def mask(x, y, rgb=False, alpha=False):
        found = node(unreal.MaterialExpressionComponentMask, x, y)
        for channel in "rgb":
            quiet(found, channel, rgb, unreal)
        quiet(found, "a", alpha, unreal)
        return found

    screen = node(unreal.MaterialExpressionScreenPosition, -1400, -200)
    depth = node(unreal.MaterialExpressionPixelDepth, -1400, -80)
    params = [scalar(RIM_PARAMETERS[key], RIM_DEFAULTS[key], -1700, 40 + 100 * index)
              for index, key in enumerate(("width", "bias", "feather", "lean"))]
    packed = params[0]
    for index, param in enumerate(params[1:]):
        append = node(unreal.MaterialExpressionAppendVector, -1450 + 150 * index, 80 + 60 * index)
        link(packed, "", append, "A")
        link(param, "", append, "B")
        packed = append

    custom = node(unreal.MaterialExpressionCustom, -850, -100)
    quiet(custom, "code", rim_code(), unreal)
    quiet(custom, "output_type", unreal.CustomMaterialOutputType.CMOT_FLOAT4, unreal)
    quiet(custom, "description", "VoxelRim Silhouette Normal", unreal)
    inputs = []
    for name in ("ScreenUV", "PixDepth", "Params"):
        found = unreal.CustomInput()
        found.set_editor_property("input_name", name)
        inputs.append(found)
    quiet(custom, "inputs", inputs, unreal)
    define = unreal.CustomDefine()
    define.set_editor_property("define_name", "VOXELRIM_SCENETEX_ID")
    define.set_editor_property("define_value", str(CUSTOM_DEPTH if self_only else SCENE_DEPTH))
    quiet(custom, "additional_defines", [define], unreal)
    link(screen, "ViewportUV", custom, "ScreenUV")
    link(depth, "", custom, "PixDepth")
    link(packed, "", custom, "Params")

    normal = mask(-500, -160, rgb=True)
    link(custom, "", normal, "")
    pin(normal, "", unreal.MaterialProperty.MP_NORMAL)
    # Opacity is the silhouette's shape only: under Substrate it is coverage, clamped to 1, so
    # brightness is Gain on Base Color (the author's notes in build_voxel_rim_material.py).
    alpha = mask(-500, -40, alpha=True)
    link(custom, "", alpha, "")
    saturate = node(unreal.MaterialExpressionSaturate, -320, -40)
    link(alpha, "", saturate, "")
    pin(saturate, "", unreal.MaterialProperty.MP_OPACITY)

    tint = node(unreal.MaterialExpressionVectorParameter, -1100, 220)
    quiet(tint, "parameter_name", "RimTint", unreal)
    quiet(tint, "default_value", unreal.LinearColor(1.0, 1.0, 1.0, 1.0), unreal)
    tint_rgb = mask(-900, 220, rgb=True)
    link(tint, "", tint_rgb, "")
    lit = node(unreal.MaterialExpressionMultiply, -700, 240)
    link(tint_rgb, "", lit, "A")
    link(scalar("Gain", RIM_DEFAULTS["gain"], -900, 320), "", lit, "B")

    # A SceneTexture node must be in the graph for the Custom node's SceneTextureLookup to
    # compile; it is multiplied by 0 so it changes nothing.
    scene = node(unreal.MaterialExpressionSceneTexture, -900, 400)
    quiet(scene, "scene_texture_id",
          unreal.SceneTextureId.PPI_CUSTOM_DEPTH if self_only
          else unreal.SceneTextureId.PPI_SCENE_DEPTH, unreal)
    scene_r = mask(-700, 400)
    quiet(scene_r, "r", True, unreal)
    link(scene, "Color", scene_r, "")
    nothing = node(unreal.MaterialExpressionMultiply, -520, 420)
    link(scene_r, "", nothing, "A")
    link(constant(0.0, -700, 500), "", nothing, "B")
    base = node(unreal.MaterialExpressionAdd, -320, 260)
    link(lit, "", base, "A")
    link(nothing, "", base, "B")
    pin(base, "", unreal.MaterialProperty.MP_BASE_COLOR)

    glow = node(unreal.MaterialExpressionMultiply, -320, 140)
    tint_glow = mask(-500, 140, rgb=True)
    link(tint, "", tint_glow, "")
    link(tint_glow, "", glow, "A")
    link(scalar("Glow", RIM_DEFAULTS["glow"], -500, 200), "", glow, "B")
    pin(glow, "", unreal.MaterialProperty.MP_EMISSIVE_COLOR)

    pin(constant(0.0, -320, 380), "", unreal.MaterialProperty.MP_METALLIC)
    pin(scalar("Specular", RIM_DEFAULTS["specular"], -320, 460), "",
        unreal.MaterialProperty.MP_SPECULAR)
    pin(scalar("Roughness", RIM_DEFAULTS["roughness"], -320, 540), "",
        unreal.MaterialProperty.MP_ROUGHNESS)
    try:
        edit.layout_material_expressions(material)
    except Exception:  # noqa: BLE001
        pass
    return failed


# -- per object ----------------------------------------------------------------------------------

def _table(state, name):
    found = getattr(state, name, None)
    if found is None:
        found = {}
        setattr(state, name, found)
    return found


def set_spec(state, name, spec):
    """Blender said what an object's overlay is (an `overlay` message). True if it changed."""
    overlays = _table(state, "overlays")
    spec = plan(spec)
    if overlays.get(name) == spec:
        return False
    if spec is None:
        overlays.pop(name, None)
    else:
        overlays[name] = spec
    return True


def forget(state, name):
    _table(state, "overlays").pop(name, None)
    _table(state, "overlay_instances").pop(name, None)
    _table(state, "overlay_filled").pop(name, None)


def wanted_materials(state):
    """{object name: Blender material} for overlays that wear one of Blender's materials."""
    return {name: spec["material"] for name, spec in _table(state, "overlays").items()
            if spec["kind"] == "material"}


def material_for(state, name, find_material):
    """The material an object's overlay draws with, or None (no overlay, or not available)."""
    import unreal

    spec = _table(state, "overlays").get(name)
    if spec is None:
        return None
    if spec["kind"] == "material":
        return find_material(spec["material"])
    if spec["kind"] == "unreal":
        found = unreal.EditorAssetLibrary.load_asset(spec["path"])
        if found is None or not isinstance(found, unreal.MaterialInterface):
            unreal.log_warning("BU: overlay {0} is not a material in this project".format(
                spec["path"]))
            return None
        return found
    parent = ensure_rim(spec["self"])
    if parent is None:
        return None
    instances = _table(state, "overlay_instances")
    instance = instances.get(name)
    if instance is None or instance.get_editor_property("parent") != parent:
        world = unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
        instance = unreal.MaterialLibrary.create_dynamic_material_instance(world, parent)
        if instance is None:
            return None
        instances[name] = instance
    scalars, tint = rim_values(spec)
    for parameter, value in scalars.items():
        instance.set_scalar_parameter_value(parameter, float(value))
    instance.set_vector_parameter_value("RimTint", unreal.LinearColor(tint[0], tint[1], tint[2],
                                                                      1.0))
    return instance


def mirror_of(actor):
    """The overlay mirror on a live actor, or None."""
    import unreal

    try:
        found = actor.get_components_by_tag(unreal.DynamicMeshComponent, MIRROR_TAG)
    except Exception:  # noqa: BLE001
        return None
    return found[0] if found else None


def _add_mirror(actor):
    import unreal

    from . import bu_link_editor

    def work():
        subsystem = unreal.get_engine_subsystem(unreal.SubobjectDataSubsystem)
        handles = subsystem.k2_gather_subobject_data_for_instance(actor)
        if not handles:
            return None
        params = unreal.AddNewSubobjectParams(
            parent_handle=handles[0], new_class=unreal.DynamicMeshComponent,
            blueprint_context=None)
        handle, _why = subsystem.add_new_subobject(params)
        library = unreal.SubobjectDataBlueprintFunctionLibrary
        return library.get_object(library.get_data(handle))

    try:
        mirror = bu_link_editor.untracked(work)
    except Exception:  # noqa: BLE001
        mirror = None
    if mirror is None:
        return None
    mirror.set_editor_property("component_tags", [MIRROR_TAG])
    bu_link_editor.render_only(mirror)
    # Drawn over the mesh only: no shadow, no light of its own in Lumen or ray tracing.
    for prop, value in (("cast_shadow", False), ("affect_distance_field_lighting", False),
                        ("affect_dynamic_indirect_lighting", False),
                        ("visible_in_ray_tracing", False), ("render_custom_depth", False)):
        try:
            mirror.set_editor_property(prop, value)
        except Exception:  # noqa: BLE001
            pass
    return mirror


def _remove_mirror(actor):
    mirror = mirror_of(actor)
    if mirror is None:
        return
    try:
        mirror.destroy_component(actor)
    except Exception:  # noqa: BLE001
        try:
            mirror.set_visibility(False, False)
        except Exception:  # noqa: BLE001
            pass


def _set_overlay(component, material, distance):
    try:
        component.set_overlay_material(material)
    except Exception:  # noqa: BLE001 - an engine before 5.1
        return
    try:
        component.set_editor_property("overlay_material_max_draw_distance", float(distance))
    except Exception:  # noqa: BLE001
        pass


def _set_custom_depth(component, on):
    try:
        if bool(component.get_editor_property("render_custom_depth")) != bool(on):
            component.set_render_custom_depth(bool(on))
    except Exception:  # noqa: BLE001
        pass


def apply(state, name, actor, find_material, count=1):
    """Put an object's overlay (or none) on everything that draws it: its live mesh and
    stand-in (or its instances), and the mirror while its dynamic mesh shows."""
    from . import bu_link_instances, bu_link_static

    if actor is None:
        return
    spec = _table(state, "overlays").get(name)
    material = material_for(state, name, find_material) if spec is not None else None
    distance = spec["distance"] if spec is not None else 0.0
    own_outline = bool(spec is not None and spec["kind"] == "rim" and spec["self"])
    try:
        dynamic = actor.get_dynamic_mesh_component()
    except AttributeError:
        dynamic = None
    if dynamic is None:
        found = bu_link_instances.component(actor)
        if found is not None:
            _set_overlay(found, material, distance)
            _set_custom_depth(found, own_outline)
        return
    _set_overlay(dynamic, material, distance)  # kept, not drawn: the stand-in copies it
    _set_custom_depth(dynamic, own_outline)
    bu_link_static.copy_overlay(name, dynamic)
    mirror = mirror_of(actor)
    if material is None:
        if mirror is not None:
            _remove_mirror(actor)
            _table(state, "overlay_filled").pop(name, None)
        return
    if mirror is None:
        mirror = _add_mirror(actor)
        _table(state, "overlay_filled").pop(name, None)
    if mirror is None:
        return
    count = max(1, int(count or 1), int(dynamic.get_num_materials() or 0))
    mirror.configure_material_set([material] * count)
    from . import bu_link_editor

    show_mirror(actor, bool(dynamic.get_editor_property("visible"))
                and bu_link_editor.camera_flags(dynamic)[0])


def show_mirror(actor, visible):
    mirror = mirror_of(actor)
    if mirror is not None:
        try:
            if bool(mirror.is_visible()) != bool(visible):
                mirror.set_visibility(bool(visible), False)
        except Exception:  # noqa: BLE001
            pass


def hungry(state, name, actor):
    """True when an object's mirror has not been given its mesh yet: a mesh Unreal already
    shows must still be applied, to it."""
    return (actor is not None and name in _table(state, "overlays")
            and not _table(state, "overlay_filled").get(name) and mirror_of(actor) is not None)


def follow(state, name, actor, apply_shared, header, shared):
    """Give the mirror the mesh the live component was just given, by the same native call.
    Returns what that call said, or None with no mirror."""
    if name not in _table(state, "overlays") or actor is None:
        return None
    mirror = mirror_of(actor) or _add_mirror(actor)  # a new object's comes with its mesh
    if mirror is None:
        return None
    result = apply_shared(mirror, header, shared)
    _table(state, "overlay_filled")[name] = True
    return result
