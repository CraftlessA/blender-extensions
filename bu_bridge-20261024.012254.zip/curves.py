# SPDX-License-Identifier: GPL-3.0-or-later
"""Convert curve-like objects to real meshes for the duration of the export.

A Blender curve with `bevel_depth` is solid geometry -- it is how you build voxel hair, cables,
trim. Blender's USD exporter does not see it that way: it writes the control points as a
`BasisCurves` prim and **discards the bevel entirely**. Verified on a bezier curve with
`bevel_depth = 0.05`, which evaluates to a 104-vertex, 96-polygon mesh and exported as:

    /root/HairCurve/BézierCurve                type=BasisCurves
    /root/HairCurve/HairCurve_0/BézierCurve    type=BasisCurves

Two prims, no thickness, and Unreal has no useful import for either. Worse, nothing fails: the
export reports success and the completeness audit counts the object as exported, because a prim
genuinely was written. The loss is only visible by looking at the prim *type*.

So convert first. Each curve-like object gets a temporary mesh built from its evaluated form --
which is exactly what Blender renders -- and the original is hidden for the duration. The
temporary object takes the original's name so prim names, the manifest and `usd_index` all line up
as if the artist had converted by hand.

Restores everything in a `finally`, including the original names, so an interrupted export cannot
leave the scene altered. The same discipline as `empties.py` and `filters.py`.
"""

import contextlib

# Object types that carry geometry but are not meshes. Blender can evaluate all of them to a mesh.
CURVE_LIKE = ("CURVE", "SURFACE", "FONT", "META")

# Suffix parked on the original while the stand-in borrows its name. Chosen to be something no
# artist would type, so a leaked one is recognisable rather than mysterious.
_PARKED_SUFFIX = "__bu_original"


def find_curve_like(scene):
    """Curve-like objects that would otherwise export as BasisCurves."""
    return [obj for obj in scene.objects if obj.type in CURVE_LIKE]


def _evaluated_mesh(context, obj):
    """A real mesh datablock matching what Blender would render, or None."""
    import bpy

    depsgraph = context.evaluated_depsgraph_get()
    evaluated = obj.evaluated_get(depsgraph)
    try:
        mesh = bpy.data.meshes.new_from_object(
            evaluated, preserve_all_data_layers=True, depsgraph=depsgraph
        )
    except Exception:  # noqa: BLE001 - a curve with no geometry cannot be converted
        return None
    if mesh is None:
        return None
    if len(mesh.vertices) == 0:
        bpy.data.meshes.remove(mesh)
        return None
    return mesh


@contextlib.contextmanager
def converted(context, enabled=True):
    """Swap curve-like objects for temporary meshes, then put the scene back.

    Yields a list of (original_name, vertex_count) for what was converted.
    """
    import bpy

    if not enabled:
        yield []
        return

    scene = context.scene
    originals = find_curve_like(scene)
    if not originals:
        yield []
        return

    made = []          # (temp_object, temp_mesh)
    parked = []        # (original_object, real_name, was_hidden)
    converted_info = []

    try:
        for obj in originals:
            mesh = _evaluated_mesh(context, obj)
            if mesh is None:
                # Nothing to convert -- an empty curve. Leave it exactly as found; the audit
                # will report it as zero-geometry, which is the truthful reason.
                continue

            name = obj.name
            temp = bpy.data.objects.new(name + "_bu_tmp", mesh)
            temp.matrix_world = obj.matrix_world.copy()

            # Live in the same collections, so collection-based include/exclude and the
            # visibility rules behave identically for the stand-in.
            for collection in obj.users_collection:
                collection.objects.link(temp)

            parked.append((obj, name, obj.hide_render))
            obj.hide_render = True
            obj.name = name + _PARKED_SUFFIX
            temp.name = name

            made.append((temp, mesh))
            converted_info.append((name, len(mesh.vertices)))

        yield converted_info
    finally:
        for temp, mesh in made:
            try:
                bpy.data.objects.remove(temp, do_unlink=True)
            except Exception:  # noqa: BLE001
                pass
            try:
                bpy.data.meshes.remove(mesh)
            except Exception:  # noqa: BLE001
                pass
        for obj, name, was_hidden in parked:
            try:
                obj.name = name
                obj.hide_render = was_hidden
            except Exception:  # noqa: BLE001
                pass
