# SPDX-License-Identifier: GPL-3.0-or-later
"""Give time-sampled transforms a default value, so Unreal's collapse cannot lose them.

Blender bakes every transform as time samples when animation is exported, and authors **no
default value** for them. That is valid USD, but it breaks Unreal's prim collapsing: when the
importer merges an Xform chain into one actor it reads the *default* of each ancestor's
xformOps, gets nothing, and treats it as identity.

Observed cost of that: a character parented under an Xform carrying
`translate = (87.16, 55.01, 125.09)` — its placement in the scene — collapsed to the world
origin, 195 m from the camera that was supposed to be filming her, and simply vanished from the
shot. The USD was correct; the placement was only expressible at a time code.

The fix is to also author a default equal to the value at the export's start frame. Defaults are
only consulted when no time is given, so animated prims keep animating and nothing else changes.
"""

import os


def flatten(usd_path, start_frame=None):
    """Author defaults for time-sampled xformOps. Returns (prims_fixed, ops_fixed)."""
    try:
        from pxr import Usd, UsdGeom
    except ImportError:
        return 0, 0

    if not os.path.isfile(usd_path):
        return 0, 0

    stage = Usd.Stage.Open(usd_path)
    if stage is None:
        return 0, 0

    if start_frame is None:
        start_frame = stage.GetStartTimeCode()

    prims_fixed = 0
    ops_fixed = 0

    for prim in stage.Traverse():
        xformable = UsdGeom.Xformable(prim)
        if not xformable:
            continue

        touched = False
        for op in xformable.GetOrderedXformOps():
            attr = op.GetAttr()
            if attr is None:
                continue
            # Only ops that are purely time-sampled are at risk.
            samples = attr.GetTimeSamples()
            if not samples:
                continue
            if attr.HasAuthoredValue() and attr.Get() is not None:
                continue

            value = attr.Get(start_frame)
            if value is None:
                value = attr.Get(samples[0])
            if value is None:
                continue

            # Set the default (no time argument) alongside the existing samples.
            if attr.Set(value):
                ops_fixed += 1
                touched = True

        if touched:
            prims_fixed += 1

    if ops_fixed:
        stage.GetRootLayer().Save()

    return prims_fixed, ops_fixed
