# SPDX-License-Identifier: GPL-3.0-or-later
"""Puts Blender's marker-driven camera cuts onto Unreal's Level Sequence.

USD has no camera-cut concept, so the cut list rides in the sidecar manifest.

**The cut track must go on the sequence the USD importer already made, not a new one.**
`bImportLevelSequences` defaults to true, and the importer's `FUsdLevelSequenceHelper` builds
a main Level Sequence (plus one subsequence per USD layer) into a `LevelSequences` folder,
named after the sanitised USD basename -- `Set v2.usdc` becomes `LevelSequences/Set_v2`.
That sequence holds all the animation. Creating a separate `BU_Set_v2` for the cuts leaves
you with animation on one sequence and cuts on another, which is useless.

So by default we locate that sequence and add to it, reusing the camera bindings it already
created (they carry the transform animation), and only fall back to creating a standalone
sequence if nothing importable is found.

Other things that silently break camera cuts, all handled below:

- `UMovieSceneCameraCutSection::SetCameraBindingID` is plain C++, *not* a UFUNCTION
  (`MovieSceneCameraCutSection.h` L49), so from Python the binding must go through
  `set_editor_property("camera_binding_id", ...)`. We build the ID explicitly and read it
  back to confirm it stuck.
- Unreal asset names reject spaces, which aborted sequence creation outright for "Set v2".
- Filmback must be set explicitly: `FCameraFilmbackSettings` defaults to 24.89 x 18.67mm
  (Super 35, `CineCameraSettings.h` L58-59) while Blender's default sensor is 36mm wide.
"""

import os

import unreal

from . import bu_names

# Blender works in metres by default; Unreal works in centimetres.
BLENDER_TO_UNREAL_UNITS = 100.0

_EMPTY_GUID = "00000000-0000-0000-0000-000000000000"

# Where UUsdStageImporter publishes generated sequences (USDStageImporter.cpp L955).
IMPORTED_SEQUENCE_FOLDER = "LevelSequences"


def _editor_world():
    try:
        return unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem).get_editor_world()
    except Exception:  # noqa: BLE001
        return None


def _camera_actor_index():
    """Index only actors that actually have a camera component.

    Filtering by component avoids binding a mesh that happens to share a camera's name,
    which would produce a cut that resolves to a non-camera and renders nothing.
    """
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    index = {}
    seen_labels = {}
    for actor in subsystem.get_all_level_actors():
        if actor.get_component_by_class(unreal.CameraComponent) is None:
            continue
        label = actor.get_actor_label()
        seen_labels.setdefault(label, []).append(actor)
        for name in (label, actor.get_name()):
            if name:
                index.setdefault(name, actor)
                index.setdefault(name.lower(), actor)

    # Repeated imports leave several camera actors sharing a label. Picking by name then lands
    # on whichever came first, which may be a stale one that nothing animates.
    duplicates = {k: len(v) for k, v in seen_labels.items() if len(v) > 1}
    if duplicates:
        unreal.log_warning(
            "BU: duplicate camera actors in the level {0}. These are usually left over from an "
            "earlier import — delete the old ones, or BU may bind the wrong instance.".format(
                duplicates
            )
        )
    return index


def find_camera_actor(entry, index=None):
    """Find the imported camera actor for a manifest camera entry.

    Tries the USD prim name first -- recorded at export time by reading the stage back --
    because that is what Unreal actually named the actor. Blender rewrites `Camera.001` to
    `Camera_001` on the way into USD, so matching the Blender name alone never works.
    """
    index = _camera_actor_index() if index is None else index

    if isinstance(entry, str):
        entry = {"object_name": entry}

    # The exact name the export read back out of the stage wins outright. Only fall back to
    # guessing when the manifest predates that field — the guessed sets overlap between cameras
    # and silently hand one camera's actor to another.
    for key in ("usd_name", "unreal_name"):
        exact = entry.get(key) if isinstance(entry, dict) else None
        if exact:
            actor = index.get(exact) or index.get(exact.lower())
            if actor is not None:
                return actor

    candidates = bu_names.prim_name_candidates(entry)

    for candidate in candidates:
        actor = index.get(candidate) or index.get(candidate.lower())
        if actor is not None:
            return actor

    # Unreal may suffix names to disambiguate: "Camera_001" -> "Camera_001_2".
    for candidate in candidates:
        lowered = candidate.lower()
        for key, actor in index.items():
            if key.lower().startswith(lowered):
                return actor
    return None


def find_imported_sequence(package_path, usd_filename="", imported_paths=None):
    """Locate the Level Sequence the USD importer generated for this stage.

    The main sequence is named after the sanitised USD basename. Subsequences (one per USD
    layer) sit alongside it, so prefer an exact name match, then a sequence that owns
    subsequence sections (only the main one does), then a lone candidate.
    """
    candidates = []

    def consider(asset_path):
        asset = unreal.EditorAssetLibrary.load_asset(asset_path)
        if isinstance(asset, unreal.LevelSequence) and asset not in candidates:
            candidates.append(asset)

    for asset_path in imported_paths or []:
        try:
            consider(asset_path)
        except Exception:  # noqa: BLE001 - imported_object_paths can hold non-assets
            pass

    if not candidates:
        for asset_path in unreal.EditorAssetLibrary.list_assets(package_path, recursive=True):
            consider(asset_path)

    if not candidates:
        return None

    # Never adopt a sequence BU itself created on an earlier run -- that is the orphan we are
    # trying to stop producing, and picking it would recreate the exact split being fixed.
    importable = [s for s in candidates if not s.get_name().startswith("BU_")]
    if importable:
        candidates = importable

    if usd_filename:
        wanted = bu_names.sequence_name_candidates(usd_filename)
        for target in wanted:
            for sequence in candidates:
                if sequence.get_name() == target:
                    return sequence
        # Compare with the type prefix stripped from both sides, in case the layer display
        # name and the file name differ.
        bare_targets = {bu_names.strip_asset_prefix(t) for t in wanted}
        for sequence in candidates:
            if bu_names.strip_asset_prefix(sequence.get_name()) in bare_targets:
                return sequence

    # Only the main sequence contains subsequence sections.
    for sequence in candidates:
        try:
            if sequence.find_tracks_by_type(unreal.MovieSceneSubTrack):
                return sequence
        except Exception:  # noqa: BLE001
            pass

    # The importer prefixes level sequences with "LS_", so that alone identifies one of its
    # own even when the stage name does not match the file name.
    prefixed = [s for s in candidates if s.get_name().startswith(bu_names.LEVEL_SEQUENCE_PREFIX)]
    if len(prefixed) == 1:
        return prefixed[0]

    if len(candidates) == 1:
        return candidates[0]

    if candidates:
        unreal.log_warning(
            "BU: several Level Sequences found and none clearly the main one ({0}); using "
            "'{1}'.".format([s.get_name() for s in candidates], candidates[0].get_name())
        )
        return candidates[0]
    return None


def filmback_for(entry, render_aspect):
    """Translate a Blender camera's sensor into an Unreal filmback. Returns (width, height).

    Copying `sensor_width` x `sensor_height` straight across is wrong, and it is wrong in a way
    that is easy to miss: it gets the horizontal field of view right, so the shot looks plausible
    while being the wrong *shape*. Blender's stock 36x24 sensor is 3:2, but almost nobody renders
    3:2 -- at 1920x1080 the render is 16:9, and Unreal then frames more vertically than Blender did.

    What Blender actually does depends on `sensor_fit`:

    * `AUTO` (the default) ignores `sensor_height` entirely. `sensor_width` is fitted to whichever
      render dimension is larger, so a 16:9 render turns a 36mm sensor into an effective 36x20.25.
    * `HORIZONTAL` always fits `sensor_width` across the width.
    * `VERTICAL` fits `sensor_height` down the height, and the width follows from the aspect.

    Keeping the fitted dimension and deriving the other from the render aspect preserves Blender's
    framing exactly, which is the whole point of exporting the cameras.
    """
    width = float(entry.get("sensor_width", 36.0))
    height = float(entry.get("sensor_height", 24.0))
    fit = (entry.get("sensor_fit") or "AUTO").upper()
    aspect = float(render_aspect or 0.0)

    if aspect <= 0.0:
        # No resolution in the manifest (an older export): the sensor is all we have.
        return width, height

    if fit == "VERTICAL":
        return height * aspect, height
    if fit == "HORIZONTAL":
        return width, width / aspect
    # AUTO: sensor_width is fitted to the larger render dimension.
    if aspect >= 1.0:
        return width, width / aspect
    return width * aspect, width


def apply_camera_settings(actor, entry, render_aspect=None):
    """Push Blender camera intrinsics onto an imported Unreal camera."""
    component = actor.get_component_by_class(unreal.CineCameraComponent)
    if component is None:
        basic = actor.get_component_by_class(unreal.CameraComponent)
        if basic is None:
            return False
        try:
            import math

            basic.set_editor_property("field_of_view", math.degrees(entry.get("fov_radians", 0.69)))
            return True
        except Exception:  # noqa: BLE001
            return False

    sensor_width, sensor_height = filmback_for(entry, render_aspect)
    filmback = unreal.CameraFilmbackSettings()
    filmback.set_editor_property("sensor_width", sensor_width)
    filmback.set_editor_property("sensor_height", sensor_height)
    component.set_editor_property("filmback", filmback)
    if abs(sensor_height - float(entry.get("sensor_height", 24.0))) > 1e-4:
        unreal.log(
            "BU: {0} filmback {1:.2f}x{2:.2f} (aspect {3:.4f}) — derived from the render "
            "resolution, because Blender's {4} fit does not use the sensor height".format(
                actor.get_actor_label(), sensor_width, sensor_height,
                sensor_width / max(1e-9, sensor_height),
                (entry.get("sensor_fit") or "AUTO").upper(),
            )
        )

    focal = float(entry.get("lens_mm", 50.0))
    try:
        component.set_editor_property("current_focal_length", focal)
    except Exception:  # noqa: BLE001 - BlueprintSetter-backed on some versions
        component.set_current_focal_length(focal)

    dof = entry.get("dof", {})
    if dof.get("use"):
        focus = unreal.CameraFocusSettings()
        focus.set_editor_property("focus_method", unreal.CameraFocusMethod.MANUAL)
        focus.set_editor_property(
            "manual_focus_distance",
            float(dof.get("focus_distance", 10.0)) * BLENDER_TO_UNREAL_UNITS,
        )
        component.set_editor_property("focus_settings", focus)
        try:
            component.set_editor_property("current_aperture", float(dof.get("aperture_fstop", 2.8)))
        except Exception:  # noqa: BLE001
            pass

    return True


def _rate_fps(rate):
    """A FrameRate struct as a plain float, or 0.0 if it cannot be read."""
    try:
        numerator = float(rate.numerator)
        denominator = float(rate.denominator) or 1.0
        return numerator / denominator
    except (AttributeError, TypeError, ZeroDivisionError):
        return 0.0


def _display_rate_scale(sequence, manifest):
    """How many sequence frames one Blender frame is worth.

    1.0 whenever the two rates agree, which is every sequence BU creates itself. It only differs
    on a sequence Unreal's USD importer made, which carries Unreal's default rate rather than the
    scene's — and there, cut frames have to be converted by time or the shot is cut in the wrong
    places.
    """
    try:
        sequence_fps = _rate_fps(sequence.get_display_rate())
    except AttributeError:
        return 1.0
    scene_fps = float(getattr(manifest, "fps", 0.0) or 0.0)
    if sequence_fps <= 0.0 or scene_fps <= 0.0:
        return 1.0
    return sequence_fps / scene_fps


def _frame_rate(scene, fallback_fps):
    numerator = int(scene.get("fps_numerator", round(fallback_fps)) or round(fallback_fps))
    denominator = float(scene.get("fps_denominator", 1.0) or 1.0)
    # Blender stores fps_base as a float; 1.001 encodes the NTSC rates (23.976, 29.97).
    if abs(denominator - 1.001) < 1e-6:
        return unreal.FrameRate(numerator=numerator * 1000, denominator=1001)
    return unreal.FrameRate(numerator=numerator, denominator=max(1, int(round(denominator))))


def _binding_has_animation(binding):
    """True if this binding or any child possessable carries tracks.

    The camera's transform track does **not** live on the actor binding -- the importer puts
    it on a child *component* binding (bound to `Camera_0`, a SceneComponent), with focal
    length and friends on another child bound to the CameraComponent. So "is this the animated
    camera?" has to be asked of the subtree, not the binding itself.
    """
    try:
        if binding.get_tracks():
            return True
    except Exception:  # noqa: BLE001
        pass
    try:
        for child in binding.get_child_possessables():
            try:
                if child.get_tracks():
                    return True
            except Exception:  # noqa: BLE001
                continue
    except Exception:  # noqa: BLE001
        pass
    return False


def _has_transform_track(binding):
    try:
        return any(
            isinstance(track, unreal.MovieScene3DTransformTrack) for track in binding.get_tracks()
        )
    except Exception:  # noqa: BLE001
        return False


def _path_of(obj):
    try:
        return obj.get_path_name()
    except Exception:  # noqa: BLE001
        return None


def animated_camera_actor(sequence, entry, world):
    """The camera actor that actually moves in this sequence.

    Unreal's USD import puts the camera's transform track on a **SceneComponent** binding whose
    parent is the single `root` actor — not on the camera actor. The CineCameraActor is then
    *attached* to that component, so it inherits the movement.

    That matters when a level holds more than one import of the same scene: several actors share
    the label "Camera", but only the one attached to a component this sequence animates will
    move. Binding any other gives cuts that switch correctly and never move — the exact symptom
    this exists to prevent.
    """
    if world is None:
        return None

    # Exact prim name only — see `_find_existing_binding` for what the guessed candidates cost.
    # This path runs first, so a fuzzy match here shuffles the shot before the other lookup ever
    # gets a chance to be right.
    exact = {entry.get(key) for key in ("usd_name", "unreal_name") if entry.get(key)}
    names = exact or set(bu_names.prim_name_candidates(entry))

    animated_components = []
    try:
        for binding in sequence.get_bindings():
            try:
                if binding.get_name() not in names or not _has_transform_track(binding):
                    continue
                for obj in sequence.locate_bound_objects(binding, world):
                    if isinstance(obj, unreal.SceneComponent):
                        animated_components.append(_path_of(obj))
            except Exception:  # noqa: BLE001
                continue
    except Exception:  # noqa: BLE001
        return None

    if not animated_components:
        return None

    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    for actor in subsystem.get_all_level_actors():
        if actor.get_component_by_class(unreal.CameraComponent) is None:
            continue
        try:
            root = actor.get_editor_property("root_component")
            parent = root.get_attach_parent() if root else None
        except Exception:  # noqa: BLE001
            continue
        if parent is not None and _path_of(parent) in animated_components:
            return actor
    return None


def _find_existing_binding(sequence, entry, world):
    """Reuse Unreal's own *actor* binding for this camera, preferring an animated one.

    Getting this wrong is what produced "cuts switch correctly but the camera no longer
    moves": the previous version checked only whether a binding resolved to the actor object.
    The importer's animated binding resolves to a child component instead, so the check missed
    it and a fresh possessable was added — which resolves fine and carries no animation.

    A camera cut should reference the **actor** binding; the component binding beneath it
    supplies the movement. So search actor-level bindings by prim name and prefer whichever has
    animation in its subtree.
    """
    if world is None:
        return None

    try:
        bindings = list(sequence.get_bindings())
    except Exception:  # noqa: BLE001
        return None

    # The export already recorded the exact prim name this camera was written as (`usd_name`,
    # read back out of the USD itself), so prefer it and do not guess.
    #
    # The guessed candidate sets overlap, and on a real four-camera scene that silently shuffled
    # the shot: `Camera` offered {Camera, Camera_001} while `Camera.001` offered {Camera.001,
    # Camera_001, Camera_002}. Whichever camera BU processed first claimed the shared name, the
    # rest cascaded by one, and every camera that lost its binding got a fresh possessable with
    # no transform track -- so the cuts fired in the wrong order *and* the cameras stood still,
    # while the imported bindings that actually held the animation (954, 828 and 1683 keys) sat
    # unused beside them.
    exact = {entry.get(key) for key in ("usd_name", "unreal_name") if entry.get(key)}
    names = exact or set(bu_names.prim_name_candidates(entry))
    best, best_score = None, -1

    for binding in bindings:
        try:
            if binding.get_name() not in names:
                continue
        except Exception:  # noqa: BLE001
            continue

        try:
            resolved = list(sequence.locate_bound_objects(binding, world))
        except Exception:  # noqa: BLE001
            continue

        # Must be the actor-level binding: a cut bound to a bare component does not work.
        if not any(isinstance(obj, unreal.Actor) for obj in resolved):
            continue

        score = 2 if _binding_has_animation(binding) else 0
        if score > best_score:
            best, best_score = binding, score

    return best


def _binding_for_actor(sequence, actor, world):
    """An existing binding that resolves to exactly this actor, or None."""
    if world is None or actor is None:
        return None
    wanted = _path_of(actor)
    try:
        for binding in sequence.get_bindings():
            try:
                for obj in sequence.locate_bound_objects(binding, world):
                    if _path_of(obj) == wanted:
                        return binding
            except Exception:  # noqa: BLE001
                continue
    except Exception:  # noqa: BLE001
        return None
    return None


def _binding_actor(sequence, binding, world, fallback=None):
    """The actor a binding resolves to.

    Taking the actor *from the binding* matters when the level holds duplicate camera actors
    from repeated imports — several actors share a label, and picking by name can land on a
    stale one that nothing animates.
    """
    if world is None:
        return fallback
    try:
        for obj in sequence.locate_bound_objects(binding, world):
            if isinstance(obj, unreal.Actor):
                return obj
    except Exception:  # noqa: BLE001
        pass
    return fallback


def _stale_binding_names(sequence, actor, world):
    """Bindings that carry this actor's name but resolve to nothing.

    Their presence is the likely explanation for a cut that looks correctly authored yet
    reports a missing bound object.
    """
    if world is None:
        return []

    names = {actor.get_actor_label(), actor.get_name()}
    stale = []
    try:
        bindings = sequence.get_bindings()
    except Exception:  # noqa: BLE001
        return []

    for binding in bindings:
        try:
            name = binding.get_name()
        except Exception:  # noqa: BLE001
            continue
        if name not in names:
            continue
        try:
            if not sequence.locate_bound_objects(binding, world):
                stale.append(name)
        except Exception:  # noqa: BLE001
            stale.append(name)
    return stale


def _remove_existing_cut_tracks(sequence):
    """Drop any camera cut track already present, so re-running is idempotent."""
    removed = 0
    try:
        for track in sequence.find_tracks_by_type(unreal.MovieSceneCameraCutTrack):
            if sequence.remove_track(track):
                removed += 1
    except Exception as exc:  # noqa: BLE001
        unreal.log_warning("BU: could not clear existing cut tracks ({0})".format(exc))
    if removed:
        unreal.log("BU: removed {0} existing camera cut track(s) before rebuilding".format(removed))
    return removed


def _binding_guid(binding):
    try:
        return binding.get_id()
    except Exception:  # noqa: BLE001
        return binding.get_editor_property("binding_id")


def _guid_key(guid):
    """Canonical, comparable value for an FGuid.

    Three ways of comparing GUIDs do **not** work, all verified live against UE 5.8:

    - `str(guid)` gives `<Struct 'Guid' (0x0000024431460C60) {}>`. The object address is baked
      in and the braces are empty, so two structs holding the same GUID stringify differently.
    - `guid.a` raises `AttributeError: 'Guid' object has no attribute 'a'`.
    - **`guid_a == guid_b` returns False even for identical GUIDs** — struct equality is not
      value-based here. This one is nasty: it made BU's own diagnostic report "NO MATCH" for
      cuts that were in fact bound correctly.

    What does work: `guid.to_string()` -> "4CEA5A8044CAE2DFBC722DADBA3323AD", and
    `guid.get_editor_property('a'..'d')` as a fallback. Returns None if neither is readable,
    which callers treat as "cannot verify" rather than "failed".
    """
    if guid is None:
        return None
    try:
        text = guid.to_string()
        if text:
            return str(text)
    except Exception:  # noqa: BLE001
        pass
    try:
        return "-".join(str(int(guid.get_editor_property(c))) for c in ("a", "b", "c", "d"))
    except Exception:  # noqa: BLE001
        return None


# to_string() renders an unset GUID as 32 zeros; the component form gives four zeros.
_EMPTY_GUID_KEYS = ("0" * 32, "0-0-0-0")


def _is_empty_guid(key):
    return key in _EMPTY_GUID_KEYS


def _make_binding_id(sequence, binding):
    """Build a MovieSceneObjectBindingID for a binding in this same sequence.

    Use the engine's own constructor. `GetBindingID` is literally
    `FRelativeObjectBindingID(BindingID)`, which yields
    `{Guid, SequenceID = Root(0), ResolveParentIndex = 0}`.

    Hand-constructing is a trap: `FMovieSceneObjectBindingID()`'s default constructor sets
    `ResolveParentIndex = FixedRootSequenceParentIndex`, which is **-1**
    (`MovieSceneObjectBindingID.h` L401, L216) -- a legacy *fixed root* reference. Setting
    only the GUID leaves that -1 in place, and the cut then fails to resolve, which Sequencer
    reports as "Object Binding / Bound Object is missing!". `SequenceID` and
    `ResolveParentIndex` are plain `UPROPERTY()` without `EditAnywhere`, so they cannot
    reliably be corrected via `set_editor_property` either.
    """
    guid = _binding_guid(binding)

    try:
        binding_id = sequence.get_binding_id(binding)
        if binding_id is not None:
            return binding_id, guid
    except Exception as exc:  # noqa: BLE001
        unreal.log_warning("BU: get_binding_id failed ({0}); falling back".format(exc))

    # Last resort. Try to force relative resolution; log loudly if we cannot, because the
    # cut will show as "Bound Object is missing" if ResolveParentIndex stays at -1.
    binding_id = unreal.MovieSceneObjectBindingID()
    binding_id.set_editor_property("guid", guid)
    for prop, value in (("sequence_id", 0), ("resolve_parent_index", 0)):
        try:
            binding_id.set_editor_property(prop, value)
        except Exception:  # noqa: BLE001 - not EditAnywhere, so this may well refuse
            unreal.log_warning(
                "BU: could not set '{0}' on the binding ID; the cut may not resolve".format(prop)
            )
    return binding_id, guid


def _assign_camera(section, binding_id, expected_guid):
    """Set a cut section's camera and verify the binding actually resolves.

    Checking only for a non-empty GUID is not enough -- a *wrong* GUID, or a right GUID with
    the wrong `ResolveParentIndex`, is non-empty and still shows as
    "Object Binding / Bound Object is missing!" in Sequencer. So compare the GUID against the
    binding we meant, and check the resolution mode too.
    """
    assigned = False
    try:
        section.set_camera_binding_id(binding_id)
        assigned = True
    except Exception:  # noqa: BLE001 - not a UFUNCTION, so normally absent
        pass

    if not assigned:
        try:
            section.set_editor_property("camera_binding_id", binding_id)
            assigned = True
        except Exception as exc:  # noqa: BLE001
            unreal.log_error("BU: could not set camera_binding_id — {0}".format(exc))
            return False

    try:
        readback = section.get_editor_property("camera_binding_id")
        actual = _guid_key(readback.get_editor_property("guid"))
        expected = _guid_key(expected_guid)

        if actual is not None and _is_empty_guid(actual):
            unreal.log_error("BU: camera_binding_id read back empty; this cut will not switch")
            return False

        # None means the GUID components were unreadable -- do not fail on that.
        if actual is not None and expected is not None and actual != expected:
            unreal.log_error(
                "BU: camera_binding_id read back as {0} but expected {1}; the cut will not "
                "resolve".format(actual, expected)
            )
            return False

        # `sequence_id` and `resolve_parent_index` are plain UPROPERTY() with no EditAnywhere,
        # so they are NOT exposed to Python at all -- reading them raises
        # "Failed to find property 'resolve_parent_index'". Verified live. This check
        # therefore cannot run, and neither could any attempt to *set* them, which is exactly
        # why get_binding_id() (the engine's FRelativeObjectBindingID constructor) is the only
        # correct way to build one. Kept in case a future version exposes them.
        try:
            parent_index = readback.get_editor_property("resolve_parent_index")
            if parent_index == -1:
                unreal.log_error(
                    "BU: binding ID has resolve_parent_index -1 (fixed root); Sequencer will "
                    "report 'Bound Object is missing'. Expected 0 (relative)."
                )
                return False
        except Exception:  # noqa: BLE001 - expected: the property is not script-visible
            pass
    except Exception:  # noqa: BLE001 - if we cannot verify, trust the assignment
        pass

    return assigned


def _section_count(cut_track):
    try:
        return len(cut_track.get_sections())
    except Exception:  # noqa: BLE001
        return 0


def _verify_cuts(sequence, cut_track):
    """Confirm each cut's binding resolves to a real actor, and say so in the log.

    Sequencer shows one error for two different faults: a binding ID that does not match any
    binding in the MovieScene, and a binding whose bound object cannot be found in the level.
    Distinguishing them here means the log identifies which, instead of leaving it to guesswork.
    """
    world = _editor_world()
    try:
        bindings = {}
        for candidate in sequence.get_bindings():
            key = _guid_key(_binding_guid(candidate))
            if key is not None:
                bindings[key] = candidate
    except Exception:  # noqa: BLE001
        unreal.log_warning("BU: could not enumerate bindings to verify cuts")
        return 0, 0, _section_count(cut_track)

    if not bindings:
        # Without readable GUIDs there is nothing to match against; say so rather than
        # reporting every cut as broken *or* as fine.
        unreal.log_warning("BU: could not read binding GUIDs; skipping cut verification")
        return 0, 0, _section_count(cut_track)

    resolved, broken, unverified = 0, 0, 0
    try:
        sections = cut_track.get_sections()
    except Exception:  # noqa: BLE001
        return 0, 0, 0

    for section in sections:
        try:
            binding_id = section.get_editor_property("camera_binding_id")
            key = _guid_key(binding_id.get_editor_property("guid"))
        except Exception:  # noqa: BLE001
            broken += 1
            continue

        if key is None:
            unverified += 1
            continue

        binding = bindings.get(key)
        if binding is None:
            broken += 1
            unreal.log_error(
                "BU: cut references binding {0}, which is not in sequence '{1}'. Known "
                "bindings: {2}".format(key, sequence.get_name(), sorted(bindings))
            )
            continue

        if world is None:
            # Previously counted as resolved, which manufactured a false "0 broken" while
            # Sequencer showed missing bindings. Never claim success we did not establish.
            unverified += 1
            continue

        try:
            bound = sequence.locate_bound_objects(binding, world)
        except Exception:  # noqa: BLE001
            bound = []

        if bound:
            resolved += 1
        else:
            broken += 1
            try:
                label = binding.get_name()
            except Exception:  # noqa: BLE001
                label = str(key)
            unreal.log_error(
                "BU: cut binding '{0}' exists but resolves to no actor in the level. The "
                "actor it was bound to may have been renamed, deleted or reimported.".format(label)
            )

    if broken:
        unreal.log_error(
            "BU: {0}/{1} camera cuts do not resolve — Sequencer will show 'Bound Object is "
            "missing'.".format(broken, broken + resolved + unverified)
        )
    if unverified:
        unreal.log_warning(
            "BU: {0} camera cut(s) could NOT be verified (no editor world, or unreadable "
            "GUIDs). Trust Sequencer over this summary.".format(unverified)
        )
    if resolved and not broken and not unverified:
        unreal.log("BU: verified {0} camera cut(s) resolve to real actors".format(resolved))
    return resolved, broken, unverified


def _spawn_sequence_actor(sequence):
    """Drop a LevelSequenceActor into the level so the shot is playable immediately."""
    try:
        subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
        for actor in subsystem.get_all_level_actors():
            if isinstance(actor, unreal.LevelSequenceActor):
                # Already a player in the level; don't stack up duplicates.
                return actor

        actor = subsystem.spawn_actor_from_class(
            unreal.LevelSequenceActor, unreal.Vector(0, 0, 0), unreal.Rotator(0, 0, 0)
        )
        if actor is None:
            return None
        actor.set_actor_label("BU_SequencePlayer")
        try:
            actor.set_sequence(sequence)
        except Exception:  # noqa: BLE001
            actor.set_editor_property("level_sequence_asset", sequence)
        return actor
    except Exception as exc:  # noqa: BLE001
        unreal.log_warning("BU: could not spawn a LevelSequenceActor ({0})".format(exc))
        return None


def _create_standalone_sequence(manifest, package_path, sequence_name):
    """Fallback: build our own sequence when the importer produced none."""
    safe_name = bu_names.sanitize_asset_name(sequence_name, "BU_Shot")
    safe_package = bu_names.sanitize_package_path(package_path)
    if safe_name != sequence_name or safe_package != package_path:
        unreal.log(
            "BU: sanitised sequence target '{0}/{1}' -> '{2}/{3}'".format(
                package_path, sequence_name, safe_package, safe_name
            )
        )

    asset_path = "{0}/{1}".format(safe_package.rstrip("/"), safe_name)
    if unreal.EditorAssetLibrary.does_asset_exist(asset_path):
        unreal.EditorAssetLibrary.delete_asset(asset_path)

    sequence = unreal.AssetToolsHelpers.get_asset_tools().create_asset(
        asset_name=safe_name,
        package_path=safe_package,
        asset_class=unreal.LevelSequence,
        factory=unreal.LevelSequenceFactoryNew(),
    )
    if sequence is None:
        unreal.log_error("BU: could not create Level Sequence at " + asset_path)
        return None

    # Rate and range must be set before sections are added, so section frame numbers are
    # interpreted against the correct display rate.
    sequence.set_display_rate(_frame_rate(manifest.scene, manifest.fps))
    sequence.set_playback_start(0)
    sequence.set_playback_end(max(1, manifest.frame_end - manifest.frame_start + 1))
    return sequence


def _geometry_cache_components():
    """Every GeometryCache component in the level, with the actor that owns it."""
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    found = []
    for actor in subsystem.get_all_level_actors():
        try:
            components = actor.get_components_by_class(unreal.PrimitiveComponent)
        except Exception:  # noqa: BLE001
            continue  # WorldDataLayers and friends have no components at all.
        for component in components:
            if isinstance(component, unreal.GeometryCacheComponent):
                found.append((actor, component))
    return found


def _geometry_cache_asset(component):
    """The GeometryCache a component plays, or None."""
    for name in ("geometry_cache", "geometry_cache_asset"):
        try:
            asset = component.get_editor_property(name)
        except Exception:  # noqa: BLE001
            continue
        if asset is not None:
            return asset
    return None


def _set_section_cache(section, cache):
    """Point a geometry-cache section at its asset. Returns True on success."""
    for name in ("params", "geometry_cache_params"):
        try:
            params = section.get_editor_property(name)
        except Exception:  # noqa: BLE001
            continue
        if params is None:
            continue
        try:
            params.set_editor_property("geometry_cache_asset", cache)
            section.set_editor_property(name, params)
            return True
        except Exception:  # noqa: BLE001
            continue
    return False


def add_geometry_cache_tracks(sequence):
    """Give every GeometryCache component a track, so baked geometry actually animates.

    With skeletal export off -- which is a hard requirement here -- an armature-deformed
    character leaves Blender as per-frame `points` time samples. Unreal collapses that whole
    subtree into a **single GeometryCache component**, so the character stops being N static
    meshes and becomes one baked cache.

    The importer writes `3DTransform` tracks for the prims it kept as static meshes, but it does
    **not** create a `MovieSceneGeometryCacheTrack` for the caches it made. A GeometryCache
    component with nothing driving it holds its frame-0 state for the entire shot, so the
    character is either frozen or simply not where the shot expects her -- indistinguishable from
    "the exporter lost my character", which is exactly how it was reported.

    Cost of not doing this, measured: a 14-part character was absent from a 37-binding sequence
    that had transform tracks for every other animated object in the scene, including the pickaxe
    in her hand -- which is why the prop moved correctly while she did not appear at all.

    Returns (tracks_added, already_present, failed).
    """
    components = _geometry_cache_components()
    if not components:
        return 0, 0, 0

    try:
        start = sequence.get_playback_start()
        end = sequence.get_playback_end()
    except Exception:  # noqa: BLE001
        return 0, 0, 0

    added = existing = failed = 0

    for actor, component in components:
        cache = _geometry_cache_asset(component)
        label = "{0}/{1}".format(actor.get_actor_label(), component.get_name())
        if cache is None:
            unreal.log_warning(
                "BU: {0} is a geometry cache with no asset assigned; cannot animate "
                "it.".format(label)
            )
            failed += 1
            continue

        binding = sequence.add_possessable(component)
        if binding is None:
            unreal.log_warning("BU: could not bind {0} into the sequence".format(label))
            failed += 1
            continue

        if any(isinstance(t, unreal.MovieSceneGeometryCacheTrack) for t in binding.get_tracks()):
            existing += 1
            continue

        track = binding.add_track(unreal.MovieSceneGeometryCacheTrack)
        section = track.add_section()
        section.set_range(start, end)
        if not _set_section_cache(section, cache):
            unreal.log_warning(
                "BU: added a track for {0} but could not point its section at "
                "'{1}'".format(label, cache.get_name())
            )
            failed += 1
            continue

        added += 1
        unreal.log(
            "BU: geometry cache '{0}' now animates over frames {1}-{2} ({3})".format(
                cache.get_name(), start, end, label
            )
        )

    if added or failed:
        unreal.log(
            "BU: geometry cache tracks — {0} added, {1} already present, {2} "
            "failed".format(added, existing, failed)
        )
    return added, existing, failed


def verify_geometry_caches(package_path="/Game/BU"):
    """Report any GeometryCache in the level that no sequence track drives.

    The usual reason a rigged character does not appear. Returns the list of undriven component
    names, so an empty list means everything is animating.
    """
    components = _geometry_cache_components()
    if not components:
        unreal.log("BU: no baked geometry in this scene — nothing to check")
        return []

    driven = set()
    for path in unreal.EditorAssetLibrary.list_assets(package_path, recursive=True):
        asset = unreal.EditorAssetLibrary.load_asset(path)
        if not isinstance(asset, unreal.LevelSequence):
            continue
        for binding in asset.get_bindings():
            for track in binding.get_tracks():
                if isinstance(track, unreal.MovieSceneGeometryCacheTrack):
                    driven.add(str(binding.get_display_name()))

    undriven = []
    for actor, component in components:
        name = component.get_name()
        if not any(name == d or name.startswith(d) or d.startswith(name) for d in driven):
            undriven.append(name)

    if undriven:
        unreal.log_warning(
            "BU: {0} of {1} geometry cache(s) have no sequence track and will not animate: "
            "{2}. Re-import, or call bu_sequence.add_geometry_cache_tracks(sequence).".format(
                len(undriven), len(components), ", ".join(undriven)
            )
        )
    else:
        unreal.log(
            "BU: all {0} geometry cache(s) are driven by a sequence track".format(len(components))
        )
    return undriven


def build_sequence(
    manifest,
    package_path="/Game/BU",
    sequence_name="BU_Shot",
    spawn_actor=True,
    usd_filename="",
    imported_paths=None,
    attach_to_imported=True,
):
    """Add the manifest's camera cuts to the imported Level Sequence.

    Returns the sequence the cuts landed on, or None if there was nothing to do.
    """
    cameras = manifest.cameras
    if not cameras:
        unreal.log_warning("BU: manifest has no cameras; skipping sequence build")
        return None

    sequence = None
    attached = False
    if attach_to_imported:
        sequence = find_imported_sequence(package_path, usd_filename, imported_paths)
        if sequence is not None:
            attached = True
            unreal.log(
                "BU: adding camera cuts to the imported sequence '{0}' (where the animation "
                "already is)".format(sequence.get_name())
            )
        else:
            unreal.log_warning(
                "BU: no imported Level Sequence found under {0}; creating a standalone one. "
                "Animation and cuts will be on separate sequences.".format(package_path)
            )

    if sequence is None:
        sequence = _create_standalone_sequence(manifest, package_path, sequence_name)
        if sequence is None:
            return None

    # Align to whatever frame numbering the sequence already uses. The importer maps USD
    # timecodes straight onto frames, so a stage starting at timeCode 1 gives a playback
    # start of 1 -- blindly rebasing to 0 would offset every cut.
    try:
        playback_start = sequence.get_playback_start()
    except Exception:  # noqa: BLE001
        playback_start = 0
    offset = playback_start - manifest.frame_start

    # Blender's rendered aspect ratio, needed to give each camera the right filmback shape.
    scene = manifest.data.get("scene", {}) or {}
    render_aspect = scene.get("render_aspect")
    if not render_aspect:
        width = scene.get("resolution_x")
        height = scene.get("resolution_y")
        if width and height:
            render_aspect = (
                float(width) * float(scene.get("pixel_aspect_x", 1.0) or 1.0)
            ) / max(1e-9, float(height) * float(scene.get("pixel_aspect_y", 1.0) or 1.0))
    if not render_aspect:
        unreal.log_warning(
            "BU: this manifest has no render resolution, so camera filmbacks fall back to "
            "Blender's raw sensor size and the aspect ratio may be wrong. Re-export to fix."
        )

    index = _camera_actor_index()
    if not index:
        unreal.log_error(
            "BU: no camera actors found in the level. Import the USD with 'Import Actors' "
            "enabled before building the sequence."
        )
        return sequence

    world = _editor_world()
    if world is None:
        unreal.log_warning(
            "BU: could not get the editor world. Bindings cannot be verified, so BU will "
            "create fresh possessables rather than risk reusing dead ones."
        )

    bindings = {}
    configured = 0
    reused = 0
    created = 0
    for entry in cameras:
        name = entry["object_name"]

        # First choice: the camera actor attached to a component this sequence animates. In a
        # level holding two imports of the same scene, several actors share a label and only
        # this one moves.
        moving = animated_camera_actor(sequence, entry, world)
        binding = None
        if moving is not None:
            actor = moving
            binding = _binding_for_actor(sequence, actor, world)
            if binding is None:
                binding = sequence.add_possessable(actor)
                created += 1
            else:
                reused += 1
            unreal.log(
                "BU: '{0}' -> {1} (follows animated component)".format(name, actor.get_name())
            )

        # Otherwise fall back to the sequence's own animated binding.
        if binding is None:
            binding = _find_existing_binding(sequence, entry, world)
        if binding is not None and moving is None:
            reused += 1
            actor = _binding_actor(sequence, binding, world, find_camera_actor(entry, index))
            if not _binding_has_animation(binding):
                unreal.log_warning(
                    "BU: reusing binding for '{0}', but nothing animates it — the camera will "
                    "hold still. If it moves in Blender, the level probably contains a stale "
                    "copy of an earlier import; delete the old actors.".format(name)
                )
        elif binding is None:
            actor = find_camera_actor(entry, index)
            if actor is None:
                unreal.log_warning(
                    "BU: camera '{0}' not found in the level. Tried {1}; level has {2}.".format(
                        name,
                        bu_names.prim_name_candidates(entry),
                        sorted({a.get_actor_label() for a in index.values()}),
                    )
                )
                continue
            stale = _stale_binding_names(sequence, actor, world)
            if stale:
                unreal.log_warning(
                    "BU: sequence has binding(s) {0} matching '{1}' by name that resolve to "
                    "nothing; creating a fresh possessable instead of reusing a dead "
                    "one.".format(stale, name)
                )
            binding = sequence.add_possessable(actor)
            created += 1
            unreal.log(
                "BU: no existing binding for '{0}'; added a possessable. If this camera is "
                "animated in Blender, check that the sequence really lacks a binding for "
                "it.".format(name)
            )

        if binding is None or actor is None:
            unreal.log_warning("BU: could not possess camera '{0}'".format(name))
            continue

        if apply_camera_settings(actor, entry, render_aspect):
            configured += 1
        bindings[name] = binding

    if not bindings:
        unreal.log_error("BU: no camera actors matched the manifest; sequence has no bindings")
        return sequence

    _remove_existing_cut_tracks(sequence)

    cut_track = sequence.add_track(unreal.MovieSceneCameraCutTrack)
    if cut_track is None:
        unreal.log_error("BU: could not add a MovieSceneCameraCutTrack to the sequence")
        return sequence

    cuts = list(manifest.camera_cuts)
    if not cuts:
        # No bound markers still means one camera should be live for the whole range.
        fallback = manifest.scene.get("active_camera") or next(iter(bindings))
        cuts = [
            {
                "camera": fallback,
                "frame_start": manifest.frame_start,
                "frame_end": manifest.frame_end + 1,
            }
        ]
        unreal.log(
            "BU: no camera markers in the manifest; using '{0}' for the whole range".format(fallback)
        )

    # Cut frames are Blender frame numbers. When BU creates the sequence it sets the display rate
    # to match, so they transfer one for one — but when it attaches to a sequence Unreal's USD
    # importer already made, that sequence carries Unreal's own rate.
    #
    # Measured: a 30 fps Blender scene of 187 frames imported as a 24 fps sequence 148 frames
    # long. Written unconverted, the cuts landed at 0/96/145 out of 148, so every cut fired
    # roughly a quarter early and the last one ran 39 frames past the end of the sequence.
    scale = _display_rate_scale(sequence, manifest)
    if abs(scale - 1.0) > 1e-6:
        unreal.log_warning(
            "BU: this sequence runs at {0:.3f} fps but the Blender scene is {1:.3f} fps, so cut "
            "frames are being converted by time (x{2:.4f}). Unreal's USD importer sets the rate "
            "on sequences it creates; BU only sets it on ones it creates itself.".format(
                _rate_fps(sequence.get_display_rate()), manifest.fps, scale)
        )

    made, failed = 0, 0
    for cut in cuts:
        binding = bindings.get(cut["camera"])
        if binding is None:
            unreal.log_warning(
                "BU: cut at frame {0} names camera '{1}', which has no binding".format(
                    cut.get("frame_start"), cut.get("camera")
                )
            )
            failed += 1
            continue

        start = int(round((cut["frame_start"] + offset) * scale))
        end = int(round((cut["frame_end"] + offset) * scale))
        if end <= start:
            unreal.log_warning(
                "BU: skipping empty cut for '{0}' ({1} -> {2})".format(cut["camera"], start, end)
            )
            failed += 1
            continue

        section = cut_track.add_section()
        section.set_range(start, end)

        binding_id, guid = _make_binding_id(sequence, binding)
        if _assign_camera(section, binding_id, guid):
            made += 1
            unreal.log("BU: cut {0}-{1} -> {2} (guid {3})".format(start, end, cut["camera"], guid))
        else:
            failed += 1

    resolved, broken, unverified = _verify_cuts(sequence, cut_track)

    # Baked geometry needs a track of its own or it never moves -- see the docstring below.
    add_geometry_cache_tracks(sequence)

    unreal.EditorAssetLibrary.save_loaded_asset(sequence, only_if_is_dirty=False)

    if spawn_actor:
        _spawn_sequence_actor(sequence)

    if broken:
        status = "BROKEN BINDINGS"
    elif unverified:
        status = "UNVERIFIED"
    elif made and not failed:
        status = "OK"
    elif made:
        status = "PARTIAL"
    else:
        status = "FAILED"
    unreal.log(
        "BU: sequence '{0}' [{1}] — {2} on {3}, {4} cameras configured, {5} bindings reused, "
        "{6} created, {7} cuts made, {8} failed, {9} resolve, {10} broken, {11} unverified, "
        "frame offset {12}".format(
            sequence.get_name(),
            status,
            "attached to imported animation" if attached else "STANDALONE (animation is elsewhere)",
            package_path,
            configured,
            reused,
            created,
            made,
            failed,
            resolved,
            broken,
            unverified,
            offset,
        )
    )
    return sequence
