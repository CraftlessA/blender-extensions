# SPDX-License-Identifier: GPL-3.0-or-later
"""Maps Blender object names to the USD prim names Unreal will actually use.

Blender sanitises object names when writing prims -- `.`, spaces and `-` all become `_`:

    Camera.001      -> Xform "Camera_001"
    Cam With Space   -> Xform "Cam_With_Space"
    Cam-Dash         -> Xform "Cam_Dash"

Unreal then names the spawned actor after the prim, so an actor lookup by the *Blender* name
can never match. Guessing the sanitisation rule would be fragile, so instead we read the
exported stage and recover the mapping exactly: Blender helpfully writes the original name
onto each Xform as `userProperties:blender:object_name`.
"""

import os


def build(usd_path):
    """Return {blender_object_name: {"usd_name", "prim_path", "child_names"}}.

    Returns an empty dict if the stage cannot be read, so callers can degrade to
    name-based matching rather than failing the export.
    """
    try:
        from pxr import Usd
    except ImportError:
        return {}

    if not os.path.isfile(usd_path):
        return {}

    stage = Usd.Stage.Open(usd_path)
    if stage is None:
        return {}

    index = {}
    for prim in stage.Traverse():
        attr = prim.GetAttribute("userProperties:blender:object_name")
        if not attr:
            continue
        original = attr.Get()
        if not original:
            continue

        # Child prim names matter too: for a camera the data prim under the Xform may carry
        # a different name, and Unreal can name the actor after either depending on whether
        # parent xforms were merged.
        entry = {
            "usd_name": prim.GetName(),
            "prim_path": prim.GetPath().pathString,
            "child_names": [child.GetName() for child in prim.GetChildren()],
        }

        # For meshes the Xform name is the wrong key. Blender names the Mesh prim after the
        # *mesh datablock*, and Unreal names both the StaticMesh asset and the component after
        # that Mesh prim -- so object `Head` arrives as component `Cube_001` / `SM_Cube_001`.
        #
        # This is not merely cosmetic. Datablock numbering drifts out of step with object
        # numbering, and in a real scene object `Left Arm.002` held mesh `Left_Arm_003` while
        # `Left Arm.003` held `Left_Arm_002`. Sanitising the object name to guess the component
        # would have resolved each of those to the *other* one's geometry, silently.
        for child in prim.GetChildren():
            if child.GetTypeName() == "Mesh":
                entry["mesh_name"] = child.GetName()
                entry["mesh_prim_path"] = child.GetPath().pathString
                break

        index[original] = entry
    return index


def unreal_lookup_name(entry):
    """The name Unreal will give this object's component and StaticMesh asset.

    The Mesh prim name when there is one, else the Xform name (cameras, empties).
    """
    return entry.get("mesh_name") or entry.get("usd_name")


def build_data_index(usd_path):
    """Map Blender data-block names to prim names, for materials and mesh data.

    Blender tags data prims with `userProperties:blender:data_name` rather than
    `object_name`. Materials need this: `stone.002` becomes prim `stone_002`, which Unreal
    publishes as `MI_stone_002`, so the raw Blender name matches nothing.
    """
    try:
        from pxr import Usd
    except ImportError:
        return {}

    if not os.path.isfile(usd_path):
        return {}

    stage = Usd.Stage.Open(usd_path)
    if stage is None:
        return {}

    index = {}
    for prim in stage.Traverse():
        attr = prim.GetAttribute("userProperties:blender:data_name")
        if not attr:
            continue
        original = attr.Get()
        if not original or original in index:
            continue
        index[original] = {
            "usd_name": prim.GetName(),
            "prim_path": prim.GetPath().pathString,
        }
    return index


def annotate(manifest, usd_path):
    """Fill in usd_name / prim_path for cameras and objects, in place.

    Also records any entry we could not resolve, so the Unreal side can say something
    useful instead of silently finding no actor.
    """
    index = build(usd_path)
    if not index:
        manifest.setdefault("warnings", []).append(
            "Could not read back the exported USD to map prim names; Unreal will fall back "
            "to matching by Blender object name, which may miss renamed objects."
        )
        return manifest

    # Materials are keyed by data name, not object name.
    data_index = build_data_index(usd_path)
    for entry in manifest.get("materials", []):
        hit = data_index.get(entry.get("name", ""))
        if hit is not None:
            entry["usd_name"] = hit["usd_name"]
            entry["prim_path"] = hit["prim_path"]

    unresolved = []

    for group in ("cameras", "objects"):
        for entry in manifest.get(group, []):
            key = entry.get("object_name") or entry.get("name") or ""
            hit = index.get(key)
            if hit is None:
                # Not every object survives export (hidden, unsupported types).
                if group == "cameras":
                    unresolved.append(entry)
                continue
            entry["usd_name"] = hit["usd_name"]
            entry["prim_path"] = hit["prim_path"]
            # What Unreal will actually call the component -- see unreal_lookup_name().
            entry["unreal_name"] = unreal_lookup_name(hit)
            if hit.get("mesh_name"):
                entry["mesh_name"] = hit["mesh_name"]
                entry["mesh_prim_path"] = hit["mesh_prim_path"]
            if group == "cameras" and hit["child_names"]:
                entry["usd_child_names"] = hit["child_names"]

    for entry in unresolved:
        name = entry.get("object_name", "")
        # build_manifest already diagnosed the common causes; don't repeat them vaguely.
        if entry.get("export_blockers"):
            continue
        manifest.setdefault("warnings", []).append(
            "Camera '{0}' has no prim in the exported USD, and BU could not tell why. Check "
            "that it is not disabled in renders (camera icon), that its collection is not "
            "excluded in the Outliner, and that it is inside the exported "
            "collection.".format(name)
        )

    return manifest
