# SPDX-License-Identifier: GPL-3.0-or-later
"""Walks the Blender scene and builds the BU sidecar manifest.

Everything Unreal needs that USD cannot carry lives here. The big one is texture
filtering: `UsdUVTexture` has no filter attribute in the schema at all, and UE's USD
importer never sets `Texture->Filter`, so nearest-neighbour intent is lost end to end
unless we ship it ourselves. See NOTES.md.
"""

import os

import bpy

from . import visibility

MANIFEST_VERSION = 1

# How many real meshes one render-disabled collection has to swallow before BU calls it an
# error rather than a note. See the comment in `build_manifest` for where the number came from.
HIDDEN_GEOMETRY_ALARM = 12

# Blender 5.2: ShaderNodeTexImage.interpolation == ['Linear', 'Closest', 'Cubic', 'Smart']
# (mixed case, not upper-case identifiers -- verified against RNA)
#
# UE has no cubic/smart texture filter, so both fall back to Default, which defers to the
# texture group (normally trilinear + aniso). Only 'Closest' has an exact counterpart, and
# it is the one that actually matters for voxel/pixel art.
INTERPOLATION_TO_UE_FILTER = {
    "Closest": "Nearest",
    "Linear": "Default",
    "Cubic": "Default",
    "Smart": "Default",
}

# Blender 5.2: ShaderNodeTexImage.extension == ['REPEAT', 'EXTEND', 'CLIP', 'MIRROR']
#
# UE already derives address mode from USD wrapS/wrapT, so these are informational /
# a fallback for when the USD round-trip is bypassed. CLIP has no UE equivalent
# (transparent-outside); it collapses to Clamp, which we warn about.
EXTENSION_TO_UE_ADDRESS = {
    "REPEAT": "Wrap",
    "EXTEND": "Clamp",
    "CLIP": "Clamp",
    "MIRROR": "Mirror",
}

# Colorspace names that mean "this is data, not colour". The user's OCIO config is custom
# (D:\ocio\...), so match loosely rather than against a fixed stock list.
_DATA_COLORSPACE_HINTS = ("non-color", "non color", "raw", "data", "generic data")

_FORMAT_EXTENSIONS = {
    "PNG": ".png",
    "JPEG": ".jpg",
    "JPEG2000": ".jp2",
    "TARGA": ".tga",
    "TARGA_RAW": ".tga",
    "TIFF": ".tif",
    "OPEN_EXR": ".exr",
    "OPEN_EXR_MULTILAYER": ".exr",
    "BMP": ".bmp",
    "WEBP": ".webp",
    "HDR": ".hdr",
}


def _is_data_colorspace(name):
    low = (name or "").lower()
    return any(hint in low for hint in _DATA_COLORSPACE_HINTS)


def _image_extension(image):
    if image.filepath_raw:
        ext = os.path.splitext(bpy.path.basename(image.filepath_raw))[1]
        if ext:
            return ext
    return _FORMAT_EXTENSIONS.get(image.file_format, ".png")


def texture_match_keys(image):
    """Candidate filenames Unreal might see for this image.

    Blender may copy, rename or synthesise the file on export (packed and generated
    images have no path at all), and UE only reliably preserves the *resolved source
    filename* on the texture's AssetImportData. So we emit every plausible basename and
    let the Unreal side match on any of them.
    """
    keys = []

    def add(value):
        if not value:
            return
        base = bpy.path.basename(value)
        if base and base.lower() not in keys:
            keys.append(base.lower())

    add(image.filepath_raw)
    add(image.filepath)
    add(image.name)

    # Generated/packed images get written as "<name><ext>", and image.name often already
    # carries an extension, so cover the bare-stem case too.
    stem = os.path.splitext(image.name)[0]
    add(stem + _image_extension(image))
    return keys


# Principled BSDF input socket -> the parameter prefix Unreal's USD importer uses on its
# generated material instances. It names them "<Prefix>Texture" plus a "Use<Prefix>Texture"
# scalar switch (verified in USDShadeConversion.cpp L1215-1227). When a texture arrives
# "unlinked" in Unreal it is almost always because that switch is still 0.
BSDF_SOCKET_TO_UE_PARAM = {
    "Base Color": "BaseColor",
    "Metallic": "Metallic",
    "Roughness": "Roughness",
    "Normal": "Normal",
    "Emission Color": "EmissiveColor",
    "Alpha": "Opacity",
    "Specular IOR Level": "SpecularColor",
    "Specular Tint": "SpecularColor",
}

# Nodes we are willing to walk through while looking for the BSDF, because they pass the
# texture along rather than replacing it.
_PASSTHROUGH_NODES = {
    "ShaderNodeNormalMap",
    "ShaderNodeSeparateColor",
    "ShaderNodeSeparateRGB",
    "ShaderNodeMix",
    "ShaderNodeMixRGB",
    "ShaderNodeHueSaturation",
    "ShaderNodeInvert",
    "ShaderNodeGamma",
    "ShaderNodeBrightContrast",
    "ShaderNodeMath",
    "ShaderNodeMapRange",
    "ShaderNodeClamp",
    "ShaderNodeRGBCurve",
    "ShaderNodeValToRGB",
    "ShaderNodeGroup",
    "NodeReroute",
}


def trace_bsdf_channel(node, max_depth=8):
    """Follow a texture node's output forward to the shader input it ultimately feeds.

    Returns the Unreal parameter prefix ("BaseColor", "Normal", ...) or "" if the texture
    does not reach a Principled BSDF. Unreal needs this to know which material parameter
    to bind the texture to.
    """
    visited = set()
    # (node, depth) frontier over outgoing links.
    frontier = [(node, 0)]

    while frontier:
        current, depth = frontier.pop(0)
        if depth > max_depth or current.as_pointer() in visited:
            continue
        visited.add(current.as_pointer())

        for output in current.outputs:
            for link in output.links:
                target = link.to_node
                socket_name = link.to_socket.name

                if target.bl_idname == "ShaderNodeBsdfPrincipled":
                    param = BSDF_SOCKET_TO_UE_PARAM.get(socket_name)
                    if param:
                        return param
                    continue

                # Emission and similar terminal shaders still mean "colour".
                if target.bl_idname in ("ShaderNodeEmission",):
                    if socket_name == "Color":
                        return "EmissiveColor"
                    continue

                if target.bl_idname == "ShaderNodeOutputMaterial":
                    continue

                # A Bump node takes a *height* map, not a normal map. Unreal has no equivalent
                # input, and binding a greyscale height texture to NormalTexture would have it
                # read as a tangent-space vector -- which produces chaotic shading rather than
                # bumps. Report it as its own channel so the texture is named in the manifest
                # and the artist is told, instead of it vanishing without comment.
                if target.bl_idname == "ShaderNodeBump":
                    if socket_name == "Height":
                        return "Height"
                    # Bump's *Normal* input is a genuine normal map that carries on to the BSDF,
                    # so keep walking. Only the Height input is the untransportable one.
                    frontier.append((target, depth + 1))
                    continue

                if target.bl_idname in _PASSTHROUGH_NODES:
                    frontier.append((target, depth + 1))

    return ""


def _colorspace_of(image):
    try:
        return image.colorspace_settings.name
    except AttributeError:
        return ""


def needs_materialize(image):
    """True when this image has no usable file on disk.

    Packed and generated images live only inside the .blend. Blender's USD exporter still
    writes a reference for them -- `@./textures/Foo.png@` -- but never writes the file, so
    the stage arrives in Unreal with a dangling texture. We have to write the pixels out.
    """
    if image.source == "GENERATED" or image.packed_file:
        return True
    if not image.filepath_raw:
        return True
    return not os.path.isfile(bpy.path.abspath(image.filepath_raw))


def unresolvable_images(materials):
    """Images whose pixels exist nowhere: not packed, and no file at the path they point to.

    `needs_materialize` asks "must BU write this file out?" and answers yes for packed and
    generated images, which are perfectly healthy. This asks the opposite question — "can the
    pixels be found at all?" — and only a broken link answers no.

    Measured on `Ennard.blend`, where the base-colour image `Ennard (REMAKE)` points at a file
    that is not there. It reaches Unreal as a material with no base colour across 130 objects,
    and the only thing BU said about it was "Image ... does not have any image data", printed
    twice, naming neither the path nor the materials affected.
    """
    broken = {}
    for material in materials:
        for node in _iter_image_nodes(getattr(material, "node_tree", None)):
            image = node.image
            # A packed or generated image carries its own pixels; there is nothing to resolve.
            if image.packed_file or image.source == "GENERATED":
                continue
            if image.source not in ("FILE", "SEQUENCE", "TILED"):
                continue
            raw = image.filepath_raw or ""
            try:
                resolved = bpy.path.abspath(raw, library=image.library) if raw else ""
            except (RuntimeError, ValueError):
                resolved = raw
            if resolved and os.path.isfile(resolved):
                continue
            entry = broken.setdefault(image.name, {
                "image": image.name,
                "path": raw,
                "resolved": resolved,
                "materials": [],
            })
            if material.name not in entry["materials"]:
                entry["materials"].append(material.name)
    return [dict(e, materials=sorted(e["materials"])) for e in broken.values()]


def _iter_image_nodes(node_tree, _seen=None):
    """Yield every ShaderNodeTexImage in a tree, descending into node groups."""
    if node_tree is None:
        return
    if _seen is None:
        _seen = set()
    if node_tree.as_pointer() in _seen:
        return
    _seen.add(node_tree.as_pointer())

    for node in node_tree.nodes:
        if node.bl_idname == "ShaderNodeTexImage":
            if node.image is not None:
                yield node
        elif node.bl_idname == "ShaderNodeGroup":
            yield from _iter_image_nodes(node.node_tree, _seen)


def collect_textures(materials):
    """Build the texture table, keyed by exported filename.

    A single image can appear in several materials with *different* interpolation
    settings. Unreal texture settings are per-asset, not per-material, so that is a
    genuine conflict -- we keep the first setting seen, record the conflict, and let the
    exporter surface it as a warning.
    """
    textures = {}
    conflicts = []

    for material in materials:
        node_tree = getattr(material, "node_tree", None)
        for node in _iter_image_nodes(node_tree):
            image = node.image
            keys = texture_match_keys(image)
            if not keys:
                continue
            primary = keys[0]

            colorspace = ""
            try:
                colorspace = image.colorspace_settings.name
            except AttributeError:
                pass

            entry = textures.get(primary)
            if entry is None:
                entry = {
                    "key": primary,
                    "match_keys": keys,
                    "image_name": image.name,
                    "source_path": bpy.path.abspath(image.filepath_raw) if image.filepath_raw else "",
                    "is_packed": bool(image.packed_file),
                    "is_generated": image.source == "GENERATED",
                    "size": list(image.size),
                    "colorspace": colorspace,
                    "alpha_mode": image.alpha_mode,
                    "interpolation": node.interpolation,
                    "extension": node.extension,
                    "projection": node.projection,
                    "channel": trace_bsdf_channel(node),
                    # True when there is no usable file on disk, so the USD reference
                    # would dangle unless we write the pixels out ourselves.
                    "needs_materialize": needs_materialize(image),
                    "unreal": {
                        "filter": INTERPOLATION_TO_UE_FILTER.get(node.interpolation, "Default"),
                        "address_x": EXTENSION_TO_UE_ADDRESS.get(node.extension, "Wrap"),
                        "address_y": EXTENSION_TO_UE_ADDRESS.get(node.extension, "Wrap"),
                        "srgb": not _is_data_colorspace(colorspace),
                    },
                    "used_by": [],
                    "warnings": [],
                }
                if node.extension == "CLIP":
                    entry["warnings"].append(
                        "Blender 'Clip' extension has no Unreal equivalent; imported as Clamp."
                    )
                if entry["channel"] == "Height":
                    entry["warnings"].append(
                        "Feeds a Bump node, so this is a height map rather than a normal map. "
                        "Unreal has no height input, and binding it as a normal map would read "
                        "the greyscale as a tangent-space vector and shade chaotically, so it is "
                        "not transported. Bake it to a normal map in Blender (Bump > Normal Map) "
                        "if you need it in Unreal."
                    )
                textures[primary] = entry
            elif entry["interpolation"] != node.interpolation:
                conflicts.append(
                    "Image '{0}' is used with both '{1}' and '{2}' interpolation; "
                    "Unreal settings are per-texture so '{1}' wins.".format(
                        image.name, entry["interpolation"], node.interpolation
                    )
                )

            if material.name not in entry["used_by"]:
                entry["used_by"].append(material.name)

    return list(textures.values()), conflicts


def alpha_info(material):
    """How this material uses alpha, and what blend mode Unreal should end up with.

    Blender writes `inputs:opacity.connect` for an alpha-linked material but **never authors
    `inputs:opacityThreshold`**. That matters because Unreal's `IsMaterialTranslucent` returns
    true for *any* texture-driven opacity regardless of threshold, so it always picks a
    `UsdPreviewSurfaceTranslucent` parent. Alpha-blending a cutout texture gives no depth
    sorting, which is what mangles Minecraft skins.

    Blender does know the intent: `surface_render_method` is `DITHERED` (cutout-ish, the
    default) or `BLENDED` (true transparency), and `alpha_threshold` carries the clip value.
    """
    tree = getattr(material, "node_tree", None)
    linked = False
    # A *constant* Alpha never reaches USD at all. Measured across seven combinations of value,
    # connection and render method: Blender writes `inputs:opacity = 1.0` every time, so a
    # Principled sitting at Alpha 0 exports as fully opaque. Only a *connected* Alpha travels,
    # as `inputs:opacity.connect`. BU therefore has to carry the constant itself.
    constant = None
    if tree is not None:
        for node in tree.nodes:
            if node.bl_idname != "ShaderNodeBsdfPrincipled":
                continue
            socket = node.inputs.get("Alpha")
            if socket is None:
                continue
            if socket.is_linked:
                linked = True
                continue
            try:
                value = float(socket.default_value)
            except (TypeError, ValueError):
                continue
            # Most transparent wins: with several Principled nodes the visible one is whichever
            # actually reaches the output, and under-reporting transparency is the worse error.
            constant = value if constant is None else min(constant, value)

    # Blender 4.2 replaced blend_method's Opaque/Clip/Hashed/Blend with these two.
    method = getattr(material, "surface_render_method", "") or ""
    threshold = float(getattr(material, "alpha_threshold", 0.5) or 0.5)

    see_through = constant is not None and constant < 1.0
    if linked:
        blend = "Translucent" if method == "BLENDED" else "Masked"
    elif see_through:
        # A flat alpha is real transparency, not a cutout — there is no mask to clip against.
        blend = "Translucent"
    else:
        blend = "Opaque"

    return {
        # Kept meaning "texture-driven", which is what the masked-blending pass keys off.
        "uses_alpha": linked,
        "constant_alpha": round(constant, 4) if see_through else None,
        "render_method": method,
        "alpha_threshold": round(threshold, 4),
        "unreal_blend": blend,
    }


def collect_materials(materials):
    """Per-material texture assignments, including which channel each texture feeds.

    Unreal's USD importer builds a material instance whose texture parameters are named
    "<Channel>Texture" with a "Use<Channel>Texture" switch. Carrying the channel lets the
    Unreal side bind textures that arrived unlinked.
    """
    out = []
    for material in materials:
        node_tree = getattr(material, "node_tree", None)
        assignments = []
        seen = set()
        for node in _iter_image_nodes(node_tree):
            keys = texture_match_keys(node.image)
            if not keys or keys[0] in seen:
                continue
            seen.add(keys[0])
            assignments.append(
                {
                    "texture": keys[0],
                    "channel": trace_bsdf_channel(node),
                    "interpolation": node.interpolation,
                    "is_data": _is_data_colorspace(_colorspace_of(node.image)),
                }
            )

        # A texture whose path to the BSDF we could not follow -- through a node group, a
        # custom mix, a driver -- still needs a channel, or Unreal leaves it unbound. When a
        # material has exactly one image and it is colour data, Base Color is the only sensible
        # reading. Observed on a real scene: 'iron_pickaxe' traced to nothing and imported
        # white. Data textures (non-colour) are left alone, since guessing Base Color for a
        # normal map would be worse than leaving it.
        if len(assignments) == 1 and not assignments[0]["channel"]:
            if not assignments[0]["is_data"]:
                assignments[0]["channel"] = "BaseColor"
                assignments[0]["channel_guessed"] = True
        out.append(
            {
                "name": material.name,
                "textures": assignments,
                "backface_culling": bool(getattr(material, "use_backface_culling", False)),
                "alpha": alpha_info(material),
            }
        )
    return out


# Measured against Blender 5.2 rather than inferred: of the eighteen surface shader nodes
# tested, the USD exporter converts exactly two -- Principled BSDF and Diffuse BSDF -- and it
# looks for them only among the material's OWN top-level nodes. Everything else (Emission,
# Glass, Glossy, Toon, Sheen, Translucent, Transparent, Refraction, Subsurface, Hair, Specular,
# Holdout, Background, Mix Shader, Add Shader) yields a material with no surface source at all.
#
# Two consequences that bite real files:
#
#   * A top-level Principled is found even when nothing connects it to Material Output. So a
#     material whose actual surface is an Emission still exports, as long as a stray Principled
#     sits somewhere in the tree.
#   * A Principled wrapped in a node group is NOT found. The very common "shared shader group
#     plugged into Material Output" shape therefore exports as an empty material.
#
# An empty UsdShade.Material has no surface source, so Unreal's importer falls back to its
# DisplayColor material and the geometry arrives untextured -- with no error on either side.
# Measured on Creeking.blend, whose Emission-only eye material lost its texture exactly this way:
# three meshes imported bound to MI_DisplayColor with UseBaseColorTexture at 0.
USD_SURFACE_NODES = ("ShaderNodeBsdfPrincipled", "ShaderNodeBsdfDiffuse")


def _output_surface_node(material):
    """The node feeding the active Material Output's Surface socket, or None."""
    tree = getattr(material, "node_tree", None)
    if tree is None:
        return None
    output = None
    try:
        output = tree.get_output_node("ALL")
    except (AttributeError, TypeError):
        output = None
    if output is None:
        outputs = [n for n in tree.nodes if n.bl_idname == "ShaderNodeOutputMaterial"]
        active = [n for n in outputs if getattr(n, "is_active_output", False)]
        output = (active or outputs or [None])[0]
    if output is None:
        return None
    socket = output.inputs.get("Surface")
    if socket is None or not socket.is_linked:
        return None
    return socket.links[0].from_node


def _group_holds_surface_node(node_tree, _seen=None):
    """True if a Principled/Diffuse hides inside a node group, where the exporter cannot see it."""
    if node_tree is None:
        return False
    if _seen is None:
        _seen = set()
    if node_tree.as_pointer() in _seen:
        return False
    _seen.add(node_tree.as_pointer())
    for node in node_tree.nodes:
        if node.bl_idname in USD_SURFACE_NODES:
            return True
        if node.bl_idname == "ShaderNodeGroup" and _group_holds_surface_node(node.node_tree, _seen):
            return True
    return False


def surface_export_risk(context, materials, evaluation_mode="RENDER", selected_only=False):
    """Materials that will not survive USD export intact, and which objects wear them.

    Two buckets, because they need different responses from the artist:

    `empty`         Blender will write a material with no surface at all. The geometry arrives
                    in Unreal untextured. This is a break, not a nuance.
    `approximated`  A Principled/Diffuse is exported, but it is not what actually feeds Material
                    Output, so the exported look is a partial reading of the real shader.
    """
    wearers = {}
    for obj in context.scene.objects:
        if obj.type not in _MATERIAL_HOLDER_TYPES:
            continue
        if export_blockers(obj, context, evaluation_mode, selected_only):
            continue
        for slot in obj.material_slots:
            if slot.material is not None:
                wearers.setdefault(slot.material.name, []).append(obj.name)

    empty, approximated = [], []
    for material in materials:
        # A material with nodes switched off exports from its viewport colour and is fine --
        # measured, and worth stating because "no nodes" reads like the more broken case.
        if not getattr(material, "use_nodes", False):
            continue
        tree = getattr(material, "node_tree", None)
        if tree is None:
            continue

        exportable = [n for n in tree.nodes if n.bl_idname in USD_SURFACE_NODES]
        surface = _output_surface_node(material)
        entry = {
            "material": material.name,
            "objects": sorted(wearers.get(material.name, [])),
            "surface_node": surface.bl_idname if surface is not None else "",
            "surface_node_label": (surface.bl_label if surface is not None else "nothing"),
        }

        if not exportable:
            # Distinguish "there is no usable shader" from "there is one, but it is hidden in a
            # group" -- the fix is completely different, so the message has to be too.
            entry["principled_in_group"] = any(
                _group_holds_surface_node(n.node_tree)
                for n in tree.nodes if n.bl_idname == "ShaderNodeGroup"
            )
            entry["textures"] = sorted({
                node.image.name for node in _iter_image_nodes(tree) if node.image is not None
            })
            empty.append(entry)
        elif surface is not None and surface not in exportable:
            approximated.append(entry)

    return {"empty": empty, "approximated": approximated}


def buried_textures(context, materials, evaluation_mode="RENDER", selected_only=False):
    """Images that live only inside node groups, where the USD exporter cannot see them.

    Blender's USD exporter reads a Principled BSDF's **directly connected** inputs. An image
    sitting inside a node group reaches the Principled across the group boundary, which the
    exporter does not follow, so the material exports with flat values and the image is dropped.

    This is a third, separate silent failure, and the nastiest of the three because it passes both
    of the other checks. Measured on `Body` in the real scene, a Ucupaint material: it has a
    top-level Principled (so `surface_export_risk` does not call it empty) and that Principled
    feeds Material Output (so it is not called approximated), yet both of its 4096x4096 layer
    images are inside `Ucupaint Material.001` and neither reaches Unreal.

    Returns one entry per affected material, with `top_level` counting the images that *can*
    travel — zero means the surface arrives with no texture at all.
    """
    wearers = {}
    for obj in context.scene.objects:
        if obj.type not in _MATERIAL_HOLDER_TYPES:
            continue
        if export_blockers(obj, context, evaluation_mode, selected_only):
            continue
        for slot in obj.material_slots:
            if slot.material is not None:
                wearers.setdefault(slot.material.name, []).append(obj.name)

    found = []
    for material in materials:
        tree = getattr(material, "node_tree", None)
        if tree is None or not getattr(material, "use_nodes", False):
            continue

        reachable = {node.image.name for node in _iter_image_nodes(tree) if node.image is not None}
        if not reachable:
            continue
        top_level = {
            node.image.name for node in tree.nodes
            if node.bl_idname == "ShaderNodeTexImage" and node.image is not None
        }
        buried = reachable - top_level
        if not buried:
            continue

        found.append({
            "material": material.name,
            "buried": sorted(buried),
            "top_level": len(top_level),
            "groups": sorted({
                node.node_tree.name for node in tree.nodes
                if node.bl_idname == "ShaderNodeGroup" and node.node_tree is not None
            }),
            "objects": sorted(wearers.get(material.name, [])),
        })
    return found


# How many frames to sample when looking for topology that changes under animation. Five caught
# every case in the real scene; the cost is one full mesh evaluation per animated object per
# sample, so this is the knob to turn if the pre-flight ever feels slow.
TOPOLOGY_SAMPLES = 5

# Modifiers whose output vertex count depends on the *deformed* geometry, so it drifts as an
# armature moves the mesh. Named in the error because "your mesh has unstable topology" is not
# actionable but "your Bevel is under the Armature" is.
_TOPOLOGY_UNSTABLE_MODIFIERS = {
    "BEVEL", "DECIMATE", "REMESH", "SHRINKWRAP", "BOOLEAN", "NODES", "SKIN",
    "WELD", "MASK", "BUILD", "EXPLODE", "OCEAN",
}


def unstable_topology(context, evaluation_mode="RENDER", selected_only=False,
                      samples=TOPOLOGY_SAMPLES):
    """Animated meshes whose evaluated vertex count changes between frames.

    A Geometry Cache stores per-frame **point positions**, which only works if the point count
    holds still: frame N's points have to map onto frame N+1's. When the evaluated topology
    changes, Unreal has no consistent mapping and the mesh tears — continuously, on every frame it
    changes, which reads as a character constantly breaking apart.

    Measured on the real scene: `Sphere.013` (Jax's mouth, stack `ARMATURE, SUBSURF, BEVEL,
    SUBSURF`) ran 2074 -> 2086 -> 2088 -> 2086 vertices. Bevel evaluates on the deformed mesh, so
    segments come and go as the armature moves it. Three other meshes did the same via Decimate
    and Shrinkwrap. Nothing downstream can repair this — the varying count is already baked into
    what Blender hands the exporter — so it has to be caught before the export, not after.

    Only animated meshes are checked. Static geometry is written once and cannot tear.
    """
    scene = context.scene
    animated = {
        entry["object"] for entry in classify_animation(scene).get("geometry_cache", ())
    }
    if not animated or samples < 2:
        return []

    objects = []
    for obj in scene.objects:
        if obj.type != "MESH" or obj.name not in animated:
            continue
        if export_blockers(obj, context, evaluation_mode, selected_only):
            continue
        objects.append(obj)
    if not objects:
        return []

    start, end = scene.frame_start, scene.frame_end
    if end <= start:
        return []
    step = (end - start) / float(samples - 1)
    frames = sorted({int(round(start + i * step)) for i in range(samples)})

    original = scene.frame_current
    counts = {}
    try:
        for frame in frames:
            scene.frame_set(frame)
            depsgraph = context.evaluated_depsgraph_get()
            for obj in objects:
                try:
                    evaluated = obj.evaluated_get(depsgraph)
                    mesh = evaluated.to_mesh()
                    counts.setdefault(obj.name, []).append(len(mesh.vertices) if mesh else 0)
                    evaluated.to_mesh_clear()
                except (RuntimeError, AttributeError):
                    # An object that cannot be evaluated cannot be judged; leaving it out is
                    # better than reporting a change that is really an evaluation failure.
                    counts.pop(obj.name, None)
    finally:
        scene.frame_set(original)

    found = []
    for obj in objects:
        values = counts.get(obj.name)
        if not values or len(set(values)) < 2:
            continue
        blamed = [
            m.type for m in obj.modifiers
            if m.show_render and m.type in _TOPOLOGY_UNSTABLE_MODIFIERS
        ]
        found.append({
            "object": obj.name,
            "frames": frames,
            "vertex_counts": values,
            "spread": max(values) - min(values),
            "modifiers": [m.type for m in obj.modifiers if m.show_render],
            "likely_cause": blamed,
        })
    found.sort(key=lambda e: -e["spread"])
    return found


def collect_subdivision(scene):
    """Subdivision-surface modifiers in the scene, and the level Unreal would need.

    This matters because Blender's default USD export mode (`BEST_MATCH`) writes the *base cage*
    plus `subdivisionScheme = catmullClark`, and Unreal's importer only reads that scheme when
    its `SubdivisionLevel` option is above zero -- and it defaults to **0, "don't subdivide"**.
    So a subdivided model silently arrives blocky unless either Blender bakes it (TESSELLATE) or
    Unreal is told a level.
    """
    entries = []
    for obj in scene.objects:
        for modifier in getattr(obj, "modifiers", []):
            if modifier.type != "SUBSURF":
                continue
            entries.append(
                {
                    "object": obj.name,
                    "modifier": modifier.name,
                    "viewport_levels": modifier.levels,
                    "render_levels": modifier.render_levels,
                    "show_render": bool(modifier.show_render),
                }
            )
    # Unreal clamps SubdivisionLevel to 0..6.
    max_level = min(6, max((e["render_levels"] for e in entries), default=0))
    return {"modifiers": entries, "max_render_level": max_level}


def collect_objects(scene):
    """Object -> material slot names, so Unreal can reassign a material if one is missing."""
    out = []
    for obj in scene.objects:
        if obj.type not in ("MESH", "CURVE", "SURFACE", "META", "FONT"):
            continue
        slots = [slot.material.name if slot.material else "" for slot in obj.material_slots]
        entry = {"name": obj.name, "type": obj.type, "material_slots": slots}

        # A mirrored object -- any transform with a negative determinant -- reverses handedness.
        # Blender compensates when shading, so it looks correct there, and the USD is written
        # correctly too: the negative scale is on the Xform and the mesh's winding matches its
        # authored normals. Unreal's USD importer then bakes the mirror into the vertex positions
        # (the component arrives at scale 1,1,1) *without* reversing the winding or setting
        # bReverseCulling, so every triangle is back-facing and a two-sided material flips the
        # shading normal on all of them. The mesh renders inside-out.
        #
        # Measured on four objects in the artist's scene: correct in Blender, correct in the USD
        # (winding agreed with authored normals on 60 of 60 sampled faces), inverted in Unreal.
        # Flagged here so the Unreal side can set reverse_culling on exactly these components.
        if obj.matrix_world.determinant() < 0:
            entry["mirrored"] = True
        out.append(entry)
    return out


def _is_animated(id_block):
    anim = getattr(id_block, "animation_data", None)
    if anim is None:
        return False
    if anim.action is not None:
        return True
    return bool(anim.nla_tracks)


def _iter_layer_collections(root):
    """Every LayerCollection under `root`, root included.

    The view layer's collection tree carries the Outliner's exclude/hide state, which lives
    separately from the collection datablock's own flags.
    """
    yield root
    for child in root.children:
        yield from _iter_layer_collections(child)


def _collection_parents(collection):
    """Collections that hold `collection` as a direct child."""
    import bpy

    return [c for c in bpy.data.collections if collection in set(c.children)]


def _visibility_culprit(obj, evaluation_mode, ignore=(), _max_depth=32):
    """The nearest collection at or above `obj` that hides it, as (collection, flag_name).

    Walks upward because the flag that matters is rarely on the collection the object sits in.
    `ignore` names collections BU un-hid for the duration of the export, so a survey run after
    the scene is restored does not report objects that did in fact export.
    """
    flag = "hide_render" if evaluation_mode == "RENDER" else "hide_viewport"

    frontier = list(obj.users_collection)
    seen = set()
    for _ in range(_max_depth):
        if not frontier:
            return None
        for collection in frontier:
            if collection.name in ignore:
                continue
            if getattr(collection, flag, False):
                return collection, flag
        nxt = []
        for collection in frontier:
            if collection.name in seen:
                continue
            seen.add(collection.name)
            nxt.extend(_collection_parents(collection))
        frontier = nxt
    return None


def bone_widget_names():
    """Meshes currently assigned as a bone's custom shape."""
    names = set()
    for obj in bpy.data.objects:
        if obj.type != "ARMATURE":
            continue
        pose = getattr(obj, "pose", None)
        if pose is None:
            continue
        for bone in pose.bones:
            shape = getattr(bone, "custom_shape", None)
            if shape is not None:
                names.add(shape.name)
    return names


def _is_rig_furniture(obj, widgets):
    """True for meshes that exist to drive a rig, not to be seen.

    Rig widgets are *supposed* to be render-disabled — that is what makes them widgets — and a
    rigged scene is full of them. Left in, they bury the objects that matter: measured on a real
    five-character scene, 1879 meshes were render-blocked and only **177** of them were geometry
    anyone would miss.

    Three signals, measured against that scene:

    | Signal                     | Blocked meshes remaining |
    |----------------------------|--------------------------|
    | none                       | 1879                     |
    | assigned as a custom shape | 1119                     |
    | + `WGT-` name prefix       |  214                     |
    | + has no material slot     |  177                     |

    The custom-shape check alone is not enough because Rigify leaves **orphaned** widgets behind
    on regeneration — 727 of them in that file, no longer assigned to any bone but still named
    `WGT-`. The material-slot check costs almost nothing to be wrong about: only 2 of the 492
    meshes that actually exported had no material slot, and a mesh with no material arrives in
    Unreal as a bare DisplayColor component regardless.
    """
    return (
        obj.name in widgets
        or obj.name.startswith("WGT-")
        or not len(obj.material_slots)
    )


def hidden_geometry(context, evaluation_mode="RENDER", ignore_collections=()):
    """Survey the real geometry a render-disabled *collection* is keeping out of the export.

    Only collection-level blocks, and only meshes with vertices that are not rig widgets. An
    object's own camera icon is a decision about that one object; a collection's is a decision
    about everything beneath it, and that is the one that quietly costs an artist a whole
    character.

    Returns `{"exported": N, "hidden": N, "by_collection": [(name, [object, ...])]}`, worst
    collection first. `exported` is counted in the same pass so severity can be judged against
    the scene's own scale instead of a made-up threshold.
    """
    widgets = bone_widget_names()
    ignore = set(ignore_collections)
    grouped = {}
    exported = 0

    try:
        view_layer_objects = context.view_layer.objects
    except AttributeError:
        view_layer_objects = None

    own_flag = "hide_render" if evaluation_mode == "RENDER" else "hide_viewport"

    for obj in context.scene.objects:
        if obj.type != "MESH" or _is_rig_furniture(obj, widgets):
            continue
        data = getattr(obj, "data", None)
        if data is None or not len(data.vertices):
            continue

        culprit = _visibility_culprit(obj, evaluation_mode, ignore)
        if culprit is not None:
            grouped.setdefault(culprit[0].name, []).append(obj.name)
            continue

        in_view_layer = view_layer_objects is None or obj.name in view_layer_objects
        if in_view_layer and not getattr(obj, own_flag, False):
            exported += 1

    by_collection = sorted(grouped.items(), key=lambda kv: (-len(kv[1]), kv[0]))
    return {
        "exported": exported,
        "hidden": sum(len(v) for v in grouped.values()),
        "by_collection": by_collection,
    }


def materialless_geometry(context, evaluation_mode="RENDER", selected_only=False):
    """Meshes that will export with no material at all, and so arrive untextured.

    USD writes no `material:binding` for them, and Unreal's importer answers that by assigning
    its DisplayColor fallback — a flat, untextured surface. That is indistinguishable, on screen,
    from a texture pipeline that has failed, which is why it is worth naming explicitly rather
    than leaving the artist to wonder.

    Counted only over geometry that actually exports, so hidden rig widgets — which are
    material-less by nature and hidden by design — do not inflate it.
    """
    bare, exported = [], 0
    for obj in context.scene.objects:
        if obj.type != "MESH":
            continue
        data = getattr(obj, "data", None)
        if data is None or not len(data.vertices):
            continue
        if export_blockers(obj, context, evaluation_mode, selected_only):
            continue
        exported += 1
        if not any(slot.material is not None for slot in obj.material_slots):
            bare.append(obj.name)
    return {"exported": exported, "bare": sorted(bare)}


def camera_export_blockers(obj, context, evaluation_mode="RENDER", selected_only=False):
    """Why this object will not appear in the exported USD, in the user's terms.

    Verified by testing each case against Blender 5.2's exporter. With the Render evaluation
    mode BU uses:

    | State                                   | Exported? |
    |-----------------------------------------|-----------|
    | hidden in viewport (eye icon)           | yes       |
    | `hide_viewport` (monitor icon)           | yes       |
    | `hide_render` (camera icon)              | **no**    |
    | excluded collection (Outliner checkbox)  | **no**    |
    | unselected + Selected Objects Only       | **no**    |

    Viewport evaluation mode inverts the middle two: `hide_viewport` drops it and
    `hide_render` does not.
    """
    reasons = []

    try:
        in_view_layer = obj.name in context.view_layer.objects
    except (AttributeError, KeyError):
        in_view_layer = True

    if not in_view_layer:
        reasons.append(
            "it is excluded from the view layer — tick its collection's checkbox in the Outliner"
        )

    if evaluation_mode == "RENDER" and obj.hide_render:
        reasons.append(
            "it is disabled in renders (camera icon in the Outliner) and BU evaluates in "
            "Render mode"
        )
    if evaluation_mode == "VIEWPORT" and obj.hide_viewport:
        reasons.append(
            "it is disabled in the viewport (monitor icon in the Outliner) and BU is set to "
            "evaluate in Viewport mode"
        )

    # Collection flags matter as much as object flags, and they propagate *down*: a render-
    # disabled collection hides everything beneath it however clean the child's own flags are.
    # Reporting the leaf collection is useless here -- the user needs the ancestor actually
    # holding the switch. Blender's own scene had `Iris` fully visible under a `Face stuff`
    # collection with hide_render set, which quietly cost the character its pupils.
    culprit = _visibility_culprit(obj, evaluation_mode)
    if culprit is not None:
        collection, flag = culprit
        if collection in set(obj.users_collection):
            where = "its collection '{0}'".format(collection.name)
        else:
            where = "the parent collection '{0}' above it".format(collection.name)
        reasons.append(
            "{0} is {1}, which applies to everything inside it".format(
                where,
                "disabled in renders (camera icon)" if flag == "hide_render"
                else "hidden in the viewport (monitor icon)",
            )
        )

    if selected_only and in_view_layer:
        try:
            if not obj.select_get():
                reasons.append("it is not selected and 'Selected Objects Only' is enabled")
        except RuntimeError:
            pass

    return reasons


# The blocker rules are not camera-specific -- they govern any object's export.
export_blockers = camera_export_blockers

_MATERIAL_HOLDER_TYPES = ("MESH", "CURVE", "SURFACE", "META", "FONT")


def materials_in_use(context, evaluation_mode="RENDER", selected_only=False):
    """Materials reachable from objects that will actually export.

    Using every material with `users > 0` produced hundreds of spurious
    "No imported material found for 'stone.002'" warnings, because duplicated materials on
    non-exporting objects have no Unreal counterpart by design.
    """
    found = []
    for obj in context.scene.objects:
        if obj.type not in _MATERIAL_HOLDER_TYPES:
            continue
        if export_blockers(obj, context, evaluation_mode, selected_only):
            continue
        # Zero-vertex objects are excluded from the export, so their materials never reach
        # Unreal. Listing them anyway produced dozens of bogus "No imported material found"
        # warnings for materials that were never meant to exist.
        if obj.type == "MESH" and len(obj.data.vertices) == 0:
            continue
        for slot in obj.material_slots:
            if slot.material is not None and slot.material not in found:
                found.append(slot.material)
    return found


def collect_cameras(context, evaluation_mode="RENDER", selected_only=False,
                    freed=()):
    """Capture camera intrinsics.

    Filmback must travel explicitly: Blender's default sensor is 36mm wide and Unreal's
    CineCamera filmback defaults to 24.89x18.67mm. If those disagree, focal length no longer
    implies the same FOV, and the shot silently reframes in Unreal.
    """
    scene = context.scene
    cameras = []
    for obj in scene.objects:
        if obj.type != "CAMERA":
            continue
        blockers = camera_export_blockers(obj, context, evaluation_mode, selected_only)
        # The manifest is built after the export, by which point BU has already put the scene
        # back -- so a camera it deliberately un-blocked for the export still *looks* blocked
        # here. Reporting that would be a lie in both directions: the camera is in the file, and
        # the cut built from it works.
        if blockers and obj.name in freed:
            blockers = []
        cam = obj.data
        dof = cam.dof
        cameras.append(
            {
                "object_name": obj.name,
                "data_name": cam.name,
                "type": cam.type,
                "lens_mm": round(cam.lens, 6),
                "lens_unit": cam.lens_unit,
                "fov_radians": round(cam.angle, 6),
                "sensor_width": round(cam.sensor_width, 6),
                "sensor_height": round(cam.sensor_height, 6),
                "sensor_fit": cam.sensor_fit,
                "shift_x": round(cam.shift_x, 6),
                "shift_y": round(cam.shift_y, 6),
                "clip_start": round(cam.clip_start, 6),
                "clip_end": round(cam.clip_end, 6),
                "ortho_scale": round(cam.ortho_scale, 6),
                "dof": {
                    "use": bool(dof.use_dof),
                    "focus_object": dof.focus_object.name if dof.focus_object else "",
                    "focus_distance": round(dof.focus_distance, 6),
                    "aperture_fstop": round(dof.aperture_fstop, 6),
                    "aperture_blades": dof.aperture_blades,
                },
                "animated": _is_animated(obj) or _is_animated(cam),
                "is_scene_camera": scene.camera is not None and obj.name == scene.camera.name,
                "export_blockers": blockers,
            }
        )
    return cameras


def collect_camera_cuts(scene):
    """Turn Blender's camera-bound timeline markers into an Unreal cut list.

    A marker with a camera bound switches the active camera at that frame; it stays
    active until the next such marker. USD has no camera-cut concept, which is exactly
    why this has to ride in the sidecar.
    """
    markers = sorted(
        (m for m in scene.timeline_markers if m.camera is not None),
        key=lambda m: m.frame,
    )
    if not markers:
        return []

    cuts = []
    for index, marker in enumerate(markers):
        start = marker.frame
        if index + 1 < len(markers):
            end = markers[index + 1].frame
        else:
            end = scene.frame_end + 1

        # A marker before frame_start still defines the camera that is live at frame_start.
        if end <= scene.frame_start:
            continue
        start = max(start, scene.frame_start)
        if end <= start:
            continue

        cuts.append(
            {
                "marker": marker.name,
                "camera": marker.camera.name,
                "frame_start": start,
                "frame_end": end,  # exclusive
            }
        )
    return cuts


_TIME_DEPENDENT_MODIFIERS = {
    "CLOTH", "SOFT_BODY", "FLUID", "OCEAN", "WAVE", "EXPLODE",
    "PARTICLE_INSTANCE", "PARTICLE_SYSTEM", "DYNAMIC_PAINT", "MESH_SEQUENCE_CACHE",
}


def classify_animation(scene, export_skeletal=False):
    """Bucket objects by how their animation will land in Unreal.

    Skeletal and blendshape meshes come through USD as UsdSkel -> Skeletal Mesh.
    Procedurally deforming meshes come through as time-sampled points -> Geometry Cache,
    which is far heavier, so it is worth telling the artist which is which.
    """
    skeletal, geo_cache, transform_only = [], [], []

    for obj in scene.objects:
        if obj.type == "ARMATURE":
            continue

        if obj.type == "MESH":
            has_armature = any(m.type == "ARMATURE" and m.object for m in obj.modifiers)
            shape_keys = obj.data.shape_keys
            has_animated_keys = shape_keys is not None and _is_animated(shape_keys)

            if has_armature or has_animated_keys:
                skeletal.append(
                    {
                        "object": obj.name,
                        "reason": "armature" if has_armature else "shape keys",
                    }
                )
                continue

            time_dependent = [m.type for m in obj.modifiers if m.type in _TIME_DEPENDENT_MODIFIERS]
            if time_dependent or _is_animated(obj.data):
                geo_cache.append({"object": obj.name, "modifiers": time_dependent})
                continue

        if _is_animated(obj):
            transform_only.append({"object": obj.name})

    if not export_skeletal:
        # With skeletal export off there is no UsdSkel, so armature- and shape-key-driven
        # meshes arrive as time-sampled points, i.e. a Geometry Cache. Reporting them as
        # "skeletal" would describe an asset type that will not exist.
        geo_cache = geo_cache + [
            {"object": e["object"], "modifiers": [], "reason": e.get("reason", "")}
            for e in skeletal
        ]
        skeletal = []

    return {
        "skeletal": skeletal,
        "geometry_cache": geo_cache,
        "transform_only": transform_only,
    }


def build_manifest(
    context,
    usd_filename,
    materials=None,
    evaluation_mode="RENDER",
    selected_only=False,
    subdivision_mode="TESSELLATE",
    export_skeletal=False,
    freed=(),
    revealed=(),
    export_animation=True,
):
    """Assemble the full sidecar manifest for the current scene."""
    scene = context.scene

    if materials is None:
        materials = materials_in_use(context, evaluation_mode, selected_only)

    textures, conflicts = collect_textures(materials)
    cameras = collect_cameras(context, evaluation_mode, selected_only, freed)
    cuts = collect_camera_cuts(scene)

    fps = scene.render.fps / scene.render.fps_base if scene.render.fps_base else scene.render.fps

    warnings = list(conflicts)
    # Errors are the subset the artist must act on: the export completed, but
    # something it produced cannot work in Unreal.
    errors = []
    for texture in textures:
        warnings.extend(texture["warnings"])

    # Say which scene was exported, whenever the file holds more than one.
    #
    # BU exports the *active* scene, which is correct but invisible. In a file with three scenes
    # this cost an entire session: the artist deleted an object and fixed normals in one scene while
    # the export ran on another, so their fixes never appeared in Unreal and the export looked
    # stale. It is not detectable downstream -- the USD is a perfectly correct export of the wrong
    # scene -- and the giveaway was that *modifier* edits came through (that object lived in the
    # exported scene) while deletions did not (they only unlinked it from the other one).
    #
    # Object names are listed because two scenes holding entirely different objects is a very
    # different situation from two scenes sharing them, and the artist can tell instantly which.
    others = [s for s in bpy.data.scenes if s != scene]
    if others:
        exported_names = {o.name for o in scene.objects}
        summary = []
        for other in others:
            names = {o.name for o in other.objects}
            shared = len(names & exported_names)
            summary.append("'{0}' ({1} object(s), {2} shared with this one)".format(
                other.name, len(names), shared))
        warnings.append(
            "Exported scene '{0}'. This file has {1} scenes and the others were NOT exported: "
            "{2}. BU always exports the scene that is active in Blender — if your recent work is "
            "in one of the others, switch to it with the scene selector in the top bar and export "
            "again. Deleting an object only unlinks it from the scene you are in, so a scene you "
            "are not looking at can keep exporting geometry you thought you removed.".format(
                scene.name, len(bpy.data.scenes), ", ".join(summary)
            )
        )

    # Say exactly why a camera will be missing, rather than leaving it to be discovered as
    # an unresolved name on the Unreal side.
    for camera in cameras:
        for reason in camera["export_blockers"]:
            warnings.append(
                "Camera '{0}' will NOT be exported because {1}.".format(
                    camera["object_name"], reason
                )
            )

    # A render-disabled collection is the single most expensive silent failure in this pipeline.
    # Measured on the scene that prompted this: `Models` had its camera icon off, which cost
    # every character in the shot -- 153 mesh objects -- while the export reported success and
    # the camera cuts all worked, so nothing pointed at the cause. Cameras already escalate to
    # an error for the same reason; geometry had no equivalent.
    hidden = hidden_geometry(context, evaluation_mode, revealed)
    for name, objects in hidden["by_collection"][:6]:
        warnings.append(
            "Collection '{0}' is disabled in renders, so {1} mesh object(s) will NOT be "
            "exported: {2}{3}.".format(
                name, len(objects), ", ".join(sorted(objects)[:8]),
                " (+{0} more)".format(len(objects) - 8) if len(objects) > 8 else "",
            )
        )
    # Warn about any amount; error only when it is the shape of an accidental toggle rather
    # than housekeeping. Two triggers, both taken from measurement rather than invented:
    #
    #   * a single collection swallowing >= HIDDEN_GEOMETRY_ALARM meshes. In the scene this was
    #     written against, the deliberate hides ('hidden stuff', 'BOOLEAN [GANGLE]', 'HIDE
    #     THIS') held 1-9 meshes each, while the two accidents held 13 and 148.
    #   * more hidden than exported, which catches a small scene losing most of itself and
    #     needs no threshold at all.
    #
    # Counting alone would not do: losing all five characters cost 161 meshes against 492
    # exported, so a purely proportional rule would have stayed silent on the very case that
    # prompted this.
    worst_count = len(hidden["by_collection"][0][1]) if hidden["by_collection"] else 0
    if hidden["hidden"] and (
        worst_count >= HIDDEN_GEOMETRY_ALARM or hidden["hidden"] >= hidden["exported"]
    ):
        worst = ", ".join(
            "'{0}' ({1})".format(n, len(o)) for n, o in hidden["by_collection"][:3]
        )
        errors.append(
            "{0} mesh object(s) are excluded from this export by a collection's camera icon, "
            "against {1} exported. Worst: {2}. Tick the camera icon in the Outliner, or add the "
            "collection to BU's Include list — an Include entry overrides it.".format(
                hidden["hidden"], hidden["exported"], worst
            )
        )

    # An export that writes nothing at all still reports success, which is the most complete
    # silent failure available. Measured on IACB.blend: 3.3 MB of orphaned datablocks, one empty
    # collection, zero objects. The round trip produced a valid USD with zero mesh prims, no
    # error anywhere, and the only clue was a passing remark about prim names not mapping.
    #
    # Counted from `collect_objects`, which spans MESH/CURVE/SURFACE/META/FONT regardless of
    # visibility, so a scene whose geometry is merely hidden falls to the render-disabled rules
    # below rather than being reported as empty.
    geometry_objects = collect_objects(scene)
    if not geometry_objects and not cameras:
        errors.append(
            "This scene has no objects to export — no meshes, curves, text or cameras in "
            "'{0}'. The USD was written but is empty, so importing it into Unreal will "
            "produce nothing. Check you are on the intended scene: this file has {1}.".format(
                scene.name,
                ", ".join("'{0}'".format(s.name) for s in bpy.data.scenes) or "no scenes",
            )
        )

    # A broken texture link is not BU's doing, but BU is the last place it can be caught before
    # it becomes "why is my character grey in Unreal".
    broken_images = unresolvable_images(materials)
    for entry in broken_images[:6]:
        errors.append(
            "Texture '{0}' cannot be found, so the {1} material(s) using it export with no "
            "image and arrive untextured in Unreal: {2}. Blender is looking for '{3}'{4}. "
            "Relink it (Image editor > Open) or pack it (File > External Data > Pack "
            "Resources).".format(
                entry["image"], len(entry["materials"]), ", ".join(entry["materials"][:6]),
                entry["path"] or "(no path set)",
                ", which resolves to '{0}'".format(entry["resolved"])
                if entry["resolved"] and entry["resolved"] != entry["path"] else "",
            )
        )
    if len(broken_images) > 6:
        errors.append(
            "{0} further texture(s) also cannot be found.".format(len(broken_images) - 6))

    # Topology that changes under animation. Only meaningful when animation is exported, and only
    # for meshes that become Geometry Caches — a static mesh is written once and cannot tear.
    unstable = unstable_topology(context, evaluation_mode, selected_only) if export_animation else []
    for entry in unstable[:5]:
        cause = (
            " Its {0} modifier(s) evaluate on the deformed mesh, so the count drifts as the "
            "armature moves it — apply them, or move them above the Armature in the stack.".format(
                " and ".join(entry["likely_cause"]))
            if entry["likely_cause"] else
            " Modifier stack: {0}.".format(", ".join(entry["modifiers"]) or "none")
        )
        errors.append(
            "'{0}' changes vertex count between frames ({1} across frames {2}), so its Geometry "
            "Cache has no consistent point mapping and the mesh will tear in Unreal on every "
            "frame it changes.{3}".format(
                entry["object"],
                " -> ".join(str(v) for v in entry["vertex_counts"]),
                ", ".join(str(f) for f in entry["frames"]),
                cause,
            )
        )
    if len(unstable) > 5:
        errors.append(
            "{0} further animated mesh(es) also change vertex count between frames: {1}.".format(
                len(unstable) - 5, ", ".join(e["object"] for e in unstable[5:11])))

    # Textures hidden inside node groups. Split by severity on whether *anything* survives:
    # losing every texture a material has arrives as a flat surface and is a break; losing some of
    # them is a real but partial loss, and a scene full of group-based utility masks would drown in
    # errors if both were treated the same.
    buried = buried_textures(context, materials, evaluation_mode, selected_only)
    total_loss = [e for e in buried if not e["top_level"]]
    partial_loss = [e for e in buried if e["top_level"]]

    for entry in total_loss[:6]:
        errors.append(
            "Material '{0}' keeps all {1} of its textures inside node group(s) ({2}), and "
            "Blender's USD exporter only reads a Principled BSDF's directly connected inputs — "
            "so none of them travel and the {3} object(s) using it arrive flat: {4}. Lost: {5}. "
            "Bake the group down to a single image and wire that straight into Base Color.".format(
                entry["material"], len(entry["buried"]),
                ", ".join(entry["groups"][:2]) or "a group",
                len(entry["objects"]), ", ".join(entry["objects"][:4]) or "(none)",
                ", ".join(entry["buried"][:3]),
            )
        )
    if len(total_loss) > 6:
        errors.append(
            "{0} further material(s) also keep every texture inside a node group.".format(
                len(total_loss) - 6))

    if partial_loss:
        warnings.append(
            "{0} material(s) keep some textures inside node groups, which the USD exporter does "
            "not follow, so those images will not reach Unreal: {1}.".format(
                len(partial_loss),
                ", ".join(
                    "'{0}' ({1})".format(e["material"], ", ".join(e["buried"][:2]))
                    for e in partial_loss[:5]
                ),
            )
        )

    # A material Blender writes empty is the same class of failure as a render-disabled
    # collection: the export reports success, Unreal reports success, and the artist is left
    # looking at untextured geometry with nothing anywhere naming a cause.
    surfaces = surface_export_risk(context, materials, evaluation_mode, selected_only)
    for entry in surfaces["empty"][:8]:
        if entry["principled_in_group"]:
            cause = (
                "its Principled BSDF is inside a node group, and Blender's USD exporter only "
                "looks at a material's own top-level nodes. Move a Principled BSDF up to the "
                "material itself"
            )
        else:
            cause = (
                "it is built on {0}, which Blender's USD exporter does not convert (only "
                "Principled BSDF and Diffuse BSDF are). Add a Principled BSDF to the material"
            ).format(entry["surface_node_label"])
        errors.append(
            "Material '{0}' will export with no surface at all, so the {1} object(s) using it "
            "arrive in Unreal untextured: {2}. This is because {3}.{4}".format(
                entry["material"], len(entry["objects"]),
                ", ".join(entry["objects"][:6]) or "(none)", cause,
                " Textures that will be lost with it: {0}.".format(
                    ", ".join(entry["textures"][:4])) if entry["textures"] else "",
            )
        )
    if len(surfaces["empty"]) > 8:
        errors.append(
            "{0} further material(s) will also export with no surface.".format(
                len(surfaces["empty"]) - 8)
        )

    # Not a break, but the reason an export can look "close but wrong" in Unreal.
    if surfaces["approximated"]:
        warnings.append(
            "{0} material(s) export from a Principled/Diffuse node that is not what feeds "
            "Material Output, so Unreal gets an approximation of the shader rather than the "
            "look you see in Blender: {1}.".format(
                len(surfaces["approximated"]),
                ", ".join(
                    "'{0}' (output driven by {1})".format(e["material"], e["surface_node_label"])
                    for e in surfaces["approximated"][:5]
                ),
            )
        )

    # Not a fault — a mesh with no material is a legitimate thing to author — but it is the
    # other half of "why is my import grey", and only BU is positioned to say which half.
    # Measured on Spoopy.blend: 148 of 236 exported meshes carry no material slot at all, so
    # most of the character arrives on Unreal's DisplayColor fallback no matter how well the
    # textured materials transfer.
    bare_geometry = materialless_geometry(context, evaluation_mode, selected_only)
    if bare_geometry["bare"]:
        warnings.append(
            "{0} of {1} exported mesh object(s) have no material, so Unreal will assign its "
            "DisplayColor fallback and they arrive flat and untextured: {2}{3}.".format(
                len(bare_geometry["bare"]), bare_geometry["exported"],
                ", ".join(bare_geometry["bare"][:8]),
                " (+{0} more)".format(len(bare_geometry["bare"]) - 8)
                if len(bare_geometry["bare"]) > 8 else "",
            )
        )

    height_maps = [t["image_name"] for t in textures if t.get("channel") == "Height"]
    if height_maps:
        warnings.append(
            "{0} height map(s) feed a Bump node and are not transported to Unreal: {1}. "
            "Unreal has no height input; bake them to normal maps in Blender if you need "
            "them.".format(len(height_maps), ", ".join(height_maps[:6]))
        )

    if cuts:
        known = {c["object_name"] for c in cameras}
        # A camera in the manifest is not necessarily a camera in the *file*: one with export
        # blockers is listed so BU can explain itself, but no prim was written for it.
        exported = {c["object_name"] for c in cameras if not c.get("export_blockers")}
        for cut in cuts:
            if cut["camera"] not in known:
                warnings.append(
                    "Marker '{0}' binds camera '{1}', which is not in the exported scene.".format(
                        cut["marker"], cut["camera"]
                    )
                )
            elif cut["camera"] not in exported:
                reason = next(
                    (c["export_blockers"][0] for c in cameras
                     if c["object_name"] == cut["camera"] and c.get("export_blockers")),
                    "it was not exported",
                )
                warnings.append(
                    "Cut '{0}' uses camera '{1}', which will NOT be exported because {2}. This "
                    "cut cannot be built in Unreal.".format(cut["marker"], cut["camera"], reason)
                )

        # Every cut pointing at an unexported camera is not a warning, it is a broken shot: the
        # sequence arrives with no usable cuts at all. Measured on a real export -- three markers
        # bound to three cameras that all sat in one render-disabled collection, so the import
        # reported PARTIAL and two of three cuts failed, while the export itself looked fine.
        usable = [c for c in cuts if c["camera"] in exported]
        if not usable:
            errors.append(
                "None of the {0} camera cut(s) can be built: every camera they bind is excluded "
                "from the export. Tick the camera icon on the collection holding {1} in the "
                "Outliner.".format(
                    len(cuts),
                    ", ".join(sorted({c["camera"] for c in cuts}))
                )
            )
        elif len(usable) < len(cuts):
            errors.append(
                "Only {0} of {1} camera cut(s) can be built; the rest bind cameras that are "
                "excluded from the export.".format(len(usable), len(cuts))
            )
    elif len(cameras) > 1:
        warnings.append(
            "{0} cameras found but no camera-bound timeline markers; Unreal will get a "
            "single-camera cut track. Bind markers to cameras (Ctrl+Shift+C) to author cuts.".format(
                len(cameras)
            )
        )

    return {
        "bu_manifest_version": MANIFEST_VERSION,
        "generator": "BU — Blender to Unreal Bridge",
        "blender_version": bpy.app.version_string,
        "source_blend": bpy.data.filepath,
        "usd_file": usd_filename,
        "scene": {
            "name": scene.name,
            "fps": round(fps, 6),
            "fps_numerator": scene.render.fps,
            "fps_denominator": round(scene.render.fps_base, 6),
            "frame_start": scene.frame_start,
            "frame_end": scene.frame_end,
            "unit_scale": round(scene.unit_settings.scale_length, 6),
            "active_camera": scene.camera.name if scene.camera else "",
            # How many objects have their visibility driven or keyframed. BU has to mute those
            # channels to filter at all (visibility.py), and a non-zero count here is the first
            # thing to check if an export ever contains something it was told to leave out.
            "driven_visibility_objects": len(visibility.driven(scene.objects)),
            # Needed to translate a camera's aspect ratio. With `sensor_fit = AUTO` -- Blender's
            # default -- the sensor's *height* is never used: Blender fits the sensor to the
            # render's larger dimension, so the rendered aspect comes from the resolution alone.
            # Copying sensor_width x sensor_height into Unreal's filmback therefore gives the
            # wrong shape (the stock 36x24 becomes 3:2 where the render is 16:9).
            "resolution_x": scene.render.resolution_x,
            "resolution_y": scene.render.resolution_y,
            "resolution_percentage": scene.render.resolution_percentage,
            "pixel_aspect_x": round(scene.render.pixel_aspect_x, 6),
            "pixel_aspect_y": round(scene.render.pixel_aspect_y, 6),
            "render_aspect": round(
                (scene.render.resolution_x * scene.render.pixel_aspect_x)
                / max(1e-9, scene.render.resolution_y * scene.render.pixel_aspect_y),
                6,
            ),
        },
        "textures": textures,
        "materials": collect_materials(materials),
        "material_export_risk": surfaces,
        "materialless_geometry": bare_geometry,
        "unresolvable_images": broken_images,
        "buried_textures": buried,
        "unstable_topology": unstable,
        "objects": geometry_objects,
        "subdivision": dict(collect_subdivision(scene), export_mode=subdivision_mode),
        "cameras": cameras,
        "camera_cuts": cuts,
        "animation": dict(
            classify_animation(scene, export_skeletal),
            skeletal_exported=bool(export_skeletal),
        ),
        "hidden_geometry": {
            "exported_meshes": hidden["exported"],
            "hidden_meshes": hidden["hidden"],
            "by_collection": [
                {"collection": name, "objects": sorted(objects)}
                for name, objects in hidden["by_collection"]
            ],
        },
        "warnings": warnings,
        "errors": errors,
    }
