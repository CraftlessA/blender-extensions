# SPDX-License-Identifier: GPL-3.0-or-later
"""Creating and removing the link's actors without touching the editor's undo history.

`EditorActorSubsystem.spawn_actor_from_class` and `destroy_actor` both record an undo step.
Measured in a throwaway editor: one Ctrl+Z after the link removed an actor brought it back, and
one Ctrl+Z after it spawned one removed it — after which the link spawned another, and a redo
restored the first. The artist saw that as objects duplicating, and it happened whenever they
undid something of their own in Unreal, because the link's steps sat on top of theirs.

So the link's own changes are made inside a transaction that is then cancelled.
`UTransBuffer::Cancel` drops the recorded step without reverting anything, and puts back the
redo history the new transaction had cleared. If the user already has a transaction open — a
slider being dragged in a details panel holds one across frames — cancelling would throw their
edit away and working inside it would fold the link's changes into it, so the work waits.

Spawning or removing an actor also marks the level as changed, transient or not (measured: a
blank level with nothing unsaved had unsaved changes after one transient spawn). The link's
actors are never saved, so a level that had nothing unsaved before is marked that way again
after (`keeping_saved`); otherwise closing BU's editor, with its window, would ask to save every
time. Without the compiled module there is nothing to clear the flag with, and Unreal asks.
"""

DESCRIPTION = "BU real-time link"


def _level_flags():
    """(is dirty, set clean) for the editor's current level, or None without the module."""
    import unreal

    library = getattr(unreal, "BULinkLibrary", None)
    is_dirty = getattr(library, "is_current_level_dirty", None)
    set_clean = getattr(library, "set_current_level_clean", None)
    if is_dirty is None or set_clean is None:
        return None
    return is_dirty, set_clean


def keeping_saved(work):
    """Run `work()`; a level with no unsaved changes before has none after. Returns its result."""
    flags = _level_flags()
    if flags is None:
        return work()
    is_dirty, set_clean = flags
    try:
        was_dirty = bool(is_dirty(None))
    except Exception:  # noqa: BLE001
        return work()
    try:
        return work()
    finally:
        if not was_dirty:
            try:
                set_clean(None)
            except Exception:  # noqa: BLE001
                pass


def transaction_open():
    """True while the user has an undoable edit in progress."""
    import unreal

    try:
        index = unreal.SystemLibrary.begin_transaction("BU", unreal.Text(DESCRIPTION), None)
    except Exception:  # noqa: BLE001 - no transaction system: nothing to protect
        return False
    if index > 0:
        unreal.SystemLibrary.end_transaction()  # only unwinds our nesting level
        return True
    if index == 0:
        unreal.SystemLibrary.cancel_transaction(index)
    return False


def untracked(work):
    """Run `work()` and leave no undo step behind. Returns its result.

    Called only when `transaction_open()` was False this tick. If a transaction has opened
    since, the work is done anyway rather than lost, inside the user's transaction.
    """
    import unreal

    try:
        index = unreal.SystemLibrary.begin_transaction("BU", unreal.Text(DESCRIPTION), None)
    except Exception:  # noqa: BLE001
        return work()
    if index != 0:
        if index > 0:
            unreal.SystemLibrary.end_transaction()
        return work()
    try:
        return work()
    finally:
        unreal.SystemLibrary.cancel_transaction(index)


def native(name):
    """The native module's function `name`, or None with an older module (or none)."""
    import unreal

    return getattr(getattr(unreal, "BULinkLibrary", None), name, None)


def spawn(actor_class, location=None, rotation=None):
    """A transient actor in the editor world, with no undo step."""
    import unreal

    location = location if location is not None else unreal.Vector(0.0, 0.0, 0.0)
    rotation = rotation if rotation is not None else unreal.Rotator(0.0, 0.0, 0.0)
    native = getattr(getattr(unreal, "BULinkLibrary", None), "spawn_transient_actor", None)
    if native is not None:
        # Straight through the world: 0.08 ms an actor, against 7.3 ms through the editor's
        # actor factories. Outside `untracked` too: inside a transaction, even one cancelled
        # straight after, Unreal records the new actor for undo first (2 ms). With none open
        # (the link spawns only then) nothing is recorded.
        try:
            actor = keeping_saved(lambda: native(None, actor_class, location, rotation))
        except Exception:  # noqa: BLE001 - an older module: the subsystem below
            actor = None
        if actor is not None:
            return actor
    subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    return keeping_saved(lambda: untracked(
        lambda: subsystem.spawn_actor_from_class(actor_class, location, rotation, True)))


def render_only(component):
    """Leave a live actor's component nothing to do but be drawn.

    Spawned, a primitive collides, generates overlap events and affects navigation, so every
    move updates a physics body, tests for overlaps and dirties the navigation octree. A
    character of a couple of hundred pieces moves most of them every frame, and only the
    picture of it is wanted.
    """
    import unreal

    for call in (lambda: component.set_collision_enabled(unreal.CollisionEnabled.NO_COLLISION),
                 lambda: component.set_generate_overlap_events(False),
                 lambda: component.set_can_ever_affect_navigation(False)):
        try:
            call()
        except Exception:  # noqa: BLE001 - an engine without one of these still draws
            pass


DEFAULT_CHANNELS = (True, False, False)


def lighting_channels(header):
    """A mesh message's Unreal lighting channels (Blender's light linking, worked out by BU's
    Blender), or Unreal's default: channel 0 only. Pure."""
    found = header.get("channels")
    if not isinstance(found, (list, tuple)) or len(found) != 3:
        return DEFAULT_CHANNELS
    return tuple(bool(c) for c in found)


def _set_flag(component, setter, value):
    """`component.<setter>(value)` unless the flag is already so (each set dirties its render
    state). The flag is the setter's name without "set_"."""
    try:
        if bool(component.get_editor_property(setter[4:])) != value:
            getattr(component, setter)(value)
    except Exception:  # noqa: BLE001 - an engine without one of these still draws
        pass


def show_to_camera(component, camera=True, shadow=True, channels=DEFAULT_CHANNELS):
    """Blender's Ray Visibility Camera and Shadow boxes, and its light linking as Unreal's
    lighting channels, on one primitive.

    Unseen by the camera (a glowing card lighting a set from out of shot) is hidden in game,
    which is what BU's captures draw by, and kept for the rest (`hidden_extras`): it still casts
    its shadow and Lumen still bounces its light, as in Blender. Hidden outright, the cards'
    glow would go with them. Not by leaving it out of the main pass, as BU did: Unreal leaves
    those out of ray tracing as well (`GetRayTracingPrimitiveFlags`), so ray-traced shadows,
    reflections and hardware Lumen went straight through them. seq100's projector shone
    through a shade only its light sees, 3.5 times too bright.
    """
    for setter, value in (("set_render_in_main_pass", True),
                          ("set_render_in_depth_pass", True),
                          ("set_cast_shadow", bool(shadow)),
                          ("set_hidden_in_game", not camera)):
        _set_flag(component, setter, value)
    hidden_extras(component)
    try:
        if _channels_of(component) != tuple(channels):
            component.set_lighting_channels(*[bool(c) for c in channels])
    except Exception:  # noqa: BLE001
        pass


def _channels_of(component):
    try:
        found = component.get_editor_property("lighting_channels")
        return tuple(bool(found.get_editor_property("channel" + str(i))) for i in range(3))
    except Exception:  # noqa: BLE001
        return DEFAULT_CHANNELS


def hidden_extras(component):
    """A primitive the camera does not see (`show_to_camera`) casts its shadow and lights by
    bounce while it is drawn at all; switched off (a stand-in's dynamic mesh, an instanced
    prototype: `set_drawn`) it does neither, or it would cast and glow twice, or from where
    no copy of it is."""
    try:
        on = (bool(component.get_editor_property("hidden_in_game"))
              and bool(component.get_editor_property("visible")))
    except Exception:  # noqa: BLE001
        on = False
    for setter in ("set_cast_hidden_shadow", "set_affect_indirect_lighting_while_hidden"):
        _set_flag(component, setter, on)


def set_drawn(component, drawn):
    """Switch a primitive on or off, its camera-hidden shadow and bounce with it."""
    try:
        component.set_visibility(bool(drawn), False)
    except Exception:  # noqa: BLE001 - the actor may already be gone
        return
    hidden_extras(component)


def camera_flags(component):
    """(camera, shadow, channels) as `show_to_camera` last set them on a primitive (or an
    earlier BU, which left camera-hidden ones out of the main pass)."""
    try:
        camera = (bool(component.get_editor_property("render_in_main_pass"))
                  and not bool(component.get_editor_property("hidden_in_game")))
        shadow = bool(component.get_editor_property("cast_shadow"))
    except Exception:  # noqa: BLE001
        camera, shadow = True, True
    return camera, shadow, _channels_of(component)


def alive(actor):
    if actor is None:
        return False
    try:
        actor.get_actor_label()
        return True
    except Exception:  # noqa: BLE001 - a destroyed actor's wrapper raises on any access
        return False


def destroy(actor):
    """Remove an actor, with no undo step. False if it was already gone."""
    if not alive(actor):
        return False

    def work():
        # `AActor.destroy_actor`, not the subsystem's: the subsystem opens its own "Delete
        # Actors" transaction, which is exactly the step that brought deleted actors back.
        actor.destroy_actor()
        return True

    try:
        if not transaction_open():
            # With no transaction open nothing is recorded, and none is needed: inside even a
            # cancelled one Unreal records the actor for undo first, 2.1 ms against 0.02.
            return bool(keeping_saved(work))
        return bool(keeping_saved(lambda: untracked(work)))
    except Exception:  # noqa: BLE001
        return False
