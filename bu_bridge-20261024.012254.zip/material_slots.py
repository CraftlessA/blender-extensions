# SPDX-License-Identifier: GPL-3.0-or-later
"""Correct a Blender USD-exporter quirk: multi-slot meshes using only one slot bind wrong.

Measured directly against Blender's own exporter, with no BU code involved: a mesh with material
slots `['Skin', 'EyeWhites']` where every face uses index 1 (`EyeWhites`) exports bound to
**`Skin`** — slot 0's material — regardless of which slot the faces actually reference. A mesh
that genuinely uses two slots exports its `GeomSubset`s correctly on its own; the exporter only
gets it wrong when there is nothing to subset because a single slot covers every face, and that
slot isn't index 0.

The fix does not touch face `material_index` or delete anything: it swaps slot 0's *material
assignment* to the material actually in use, for the duration of the export, then restores the
original assignment exactly. Faces keep referencing whatever index they always did; only which
material sits in slot 0 changes, which is what Blender's exporter reads.
"""

import contextlib


def _face_material_indices(mesh):
    used = set()
    for polygon in mesh.polygons:
        used.add(polygon.material_index)
    return used


def mismatched(scene):
    """Mesh objects where exactly one material slot is used, and it is not slot 0.

    Only these are wrong: a mesh using no slots but its own (nothing to export), a mesh using
    slot 0 (already correct), and a mesh using several slots (the exporter handles it with
    subsets, verified separately) are all left alone.
    """
    found = []
    for obj in scene.objects:
        if obj.type != "MESH" or obj.hide_render:
            continue
        slots = obj.material_slots
        if len(slots) < 2:
            continue
        used = _face_material_indices(obj.data)
        if len(used) != 1:
            continue
        (index,) = used
        if index == 0:
            continue
        if slots[index].material is None:
            continue
        found.append((obj, index))
    return found


@contextlib.contextmanager
def corrected(scene, enabled=True):
    """Point slot 0 at the material actually in use, for every affected mesh; restore after.

    Yields the list of (object name, correct material name) touched, so the manifest can say
    what BU worked around rather than leaving it invisible.
    """
    if not enabled:
        yield []
        return

    targets = mismatched(scene)
    original = [(obj, obj.material_slots[0].material) for obj, _ in targets]
    touched = []
    try:
        for obj, index in targets:
            correct = obj.material_slots[index].material
            obj.material_slots[0].material = correct
            touched.append((obj.name, correct.name))
        yield touched
    finally:
        for obj, material in original:
            try:
                obj.material_slots[0].material = material
            except ReferenceError:
                pass
