# SPDX-License-Identifier: GPL-3.0-or-later
"""Include / exclude lists, so one .blend can feed several shots.

A scene usually holds more than the shot needs: a second character, set dressing for another
sequence, blockout geometry. `Selected Objects Only` handles that once, but it is not a saved
decision -- change the selection and the next export is different. These lists live on the scene,
save with the .blend, and describe the intent: *this shot is these collections*.

Semantics, chosen to match how artists actually think about it:

* An empty include list means "everything", not "nothing". Otherwise adding your first exclude
  entry would silently empty the export.
* A non-empty include list is a whitelist: only what it names is eligible.
* Exclude always wins, applied after include, so you can include a big collection and carve one
  child out of it without restructuring the outliner.
* Collections resolve **recursively** through child collections, because that is what the
  Outliner's nesting looks like it should mean.

The mechanism is the one already proven for zero-vertex meshes: Blender's USD exporter has no
include/exclude switch, but `hide_render` reliably drops an object under RENDER evaluation. So
BU sets it for the duration of the export and restores it afterwards, leaving the scene exactly
as found even if the export raises.

**An include entry also forces visibility** — see `revealed()`. Naming something in the include
list is as explicit an instruction as binding a camera to a marker, and BU already honours that
one (`cut_cameras`). Without this the feature reads as broken: include a render-disabled
collection and you get an empty export with no indication that the list was the wrong lever.
"""

import contextlib

_EXPORTABLE = ("MESH", "CURVE", "SURFACE", "META", "FONT", "CAMERA", "EMPTY", "ARMATURE")


def _collection_objects(collection, seen=None):
    """Every object in a collection, following child collections."""
    if seen is None:
        seen = set()
    if collection is None or collection.name in seen:
        return set()
    seen.add(collection.name)

    names = {obj.name for obj in collection.objects}
    for child in collection.children:
        names |= _collection_objects(child, seen)
    return names


def _resolve(scene, entries):
    """Turn a list of names into the set of object names they cover.

    A name may be a collection or an object; collections are looked up first because that is the
    more useful reading when both exist, and the ambiguity is rare enough not to warrant a type
    selector in the UI.
    """
    import bpy

    names = set()
    for raw in entries:
        entry = (raw or "").strip()
        if not entry:
            continue
        collection = bpy.data.collections.get(entry)
        if collection is not None:
            names |= _collection_objects(collection)
            continue
        if entry in scene.objects:
            names.add(entry)
    return names


def unknown_entries(scene, entries):
    """Entries that name neither a collection nor an object in this scene.

    Worth surfacing rather than ignoring: a typo in an include list silently exports nothing,
    which is a confusing way to find out you misspelled a collection.
    """
    import bpy

    missing = []
    for raw in entries:
        entry = (raw or "").strip()
        if not entry:
            continue
        if bpy.data.collections.get(entry) is None and entry not in scene.objects:
            missing.append(entry)
    return missing


def filtered_out(scene, include=(), exclude=()):
    """Object names the lists keep out of the export."""
    include = [e for e in include if (e or "").strip()]
    exclude = [e for e in exclude if (e or "").strip()]
    if not include and not exclude:
        return set()

    candidates = {obj.name for obj in scene.objects if obj.type in _EXPORTABLE}

    # Empty include list means "everything is eligible".
    allowed = _resolve(scene, include) & candidates if include else set(candidates)
    allowed -= _resolve(scene, exclude)
    return candidates - allowed


def _parents(collection):
    """Collections holding `collection` as a direct child."""
    import bpy

    return [c for c in bpy.data.collections if collection in set(c.children)]


def named_targets(scene, include=()):
    """The collections and objects an include list names *explicitly*.

    Deliberately not the same as `_resolve`, which expands a collection to its contents. The
    distinction is what keeps `revealed()` from overreaching: naming `Models` means "export
    Models", not "and undo every deliberate hide inside it".
    """
    import bpy

    collections, objects = [], []
    for raw in include:
        entry = (raw or "").strip()
        if not entry:
            continue
        collection = bpy.data.collections.get(entry)
        if collection is not None:
            collections.append(collection)
            continue
        obj = scene.objects.get(entry)
        if obj is not None:
            objects.append(obj)
    return collections, objects


def visibility_blockers(scene, include=(), evaluation_mode="RENDER"):
    """What stands between the include list and an actual export.

    Returns `(collections, objects)`: collections at or above anything the list names whose
    render flag is set, and named objects carrying the flag themselves.

    Only walks **upward**. A hide *inside* a named collection is a separate decision by the
    artist — scenes here routinely have a `hidden stuff` child holding retired geometry — and
    clearing that would replace one silent surprise with another.
    """
    flag = "hide_render" if evaluation_mode == "RENDER" else "hide_viewport"
    collections, objects = named_targets(scene, include)

    frontier = list(collections)
    for obj in objects:
        frontier.extend(obj.users_collection)

    found, seen = [], set()
    while frontier:
        nxt = []
        for collection in frontier:
            if collection.name in seen:
                continue
            seen.add(collection.name)
            if getattr(collection, flag, False):
                found.append(collection)
            nxt.extend(_parents(collection))
        frontier = nxt

    hidden_objects = [o for o in objects if getattr(o, flag, False)]
    return found, hidden_objects


def _layer_collections(root):
    yield root
    for child in root.children:
        yield from _layer_collections(child)


@contextlib.contextmanager
def revealed(scene, include=(), exclude=(), evaluation_mode="RENDER", enabled=True,
             view_layer=None):
    """Make everything a non-empty include list names actually exportable.

    Clears the render flag on the collections above it and un-excludes them from the view layer,
    then restores every flag exactly.

    This cannot leak other objects into the export even though it un-hides whole collections,
    because `applied()` has already set `hide_render` on **every** object the lists filter out —
    individually, one object at a time. Un-hiding their collection does not un-hide them. That is
    why this is a separate context manager nested inside `applied()` rather than part of it.

    Yields a list of `(name, what_was_cleared)` so the manifest can say what BU overrode.
    """
    include = [e for e in include if (e or "").strip()]
    if not enabled or not include:
        yield []
        return

    flag = "hide_render" if evaluation_mode == "RENDER" else "hide_viewport"
    collections, objects = visibility_blockers(scene, include, evaluation_mode)

    # Exclude still wins. Without this, naming an object in both lists would have `applied()`
    # hide it and then this un-hide it again -- exactly the object the artist asked to drop.
    dropped = filtered_out(scene, include, exclude)
    objects = [o for o in objects if o.name not in dropped]

    # View-layer exclusion is a third, independent control: an excluded collection's objects are
    # absent from the export whatever their flags say. Snapshot the *whole* tree, because setting
    # `exclude` on a LayerCollection propagates to its descendants -- restoring only the ones we
    # touched would silently flatten the rest.
    layer_collections = []
    excluded_before = []
    if view_layer is not None:
        layer_collections = list(_layer_collections(view_layer.layer_collection))
        excluded_before = [lc.exclude for lc in layer_collections]

    wanted = {c.name for c in collections}
    for lc in layer_collections:
        if lc.exclude and lc.collection is not None and lc.collection.name in wanted:
            lc.exclude = False

    from . import visibility

    freed = []
    with visibility.frozen(objects):
        try:
            for collection in collections:
                setattr(collection, flag, False)
                freed.append((collection.name, "collection " + flag))
            for obj in objects:
                setattr(obj, flag, False)
                freed.append((obj.name, "object " + flag))
            yield freed
        finally:
            for collection in collections:
                try:
                    setattr(collection, flag, True)
                except Exception:  # noqa: BLE001 - restore must not mask the export result
                    pass
            for obj in objects:
                try:
                    setattr(obj, flag, True)
                except Exception:  # noqa: BLE001
                    pass
        # Top-down, so a parent's propagation is corrected by the children that follow it.
        for lc, was_excluded in zip(layer_collections, excluded_before):
            try:
                if lc.exclude != was_excluded:
                    lc.exclude = was_excluded
            except Exception:  # noqa: BLE001
                pass


@contextlib.contextmanager
def applied(scene, include=(), exclude=(), enabled=True):
    """Hide everything the lists filter out, then put it back.

    Yields the sorted list of object names that were excluded. Restores `hide_render` exactly as
    found on every object it touched, even if the export raises -- an interrupted export must not
    leave the artist's scene altered.
    """
    if not enabled:
        yield []
        return

    names = filtered_out(scene, include, exclude)
    if not names:
        yield []
        return

    from . import visibility

    objects = [o for o in (scene.objects.get(n) for n in names) if o is not None]

    previous = {}
    # Freeze first. A rig that drives `hide_render` puts its own value back on the next
    # depsgraph evaluation, so without this the writes below read back correctly and are then
    # silently undone before the exporter looks. See visibility.py.
    with visibility.frozen(objects):
        try:
            for obj in objects:
                previous[obj.name] = obj.hide_render
                obj.hide_render = True
            yield sorted(previous)
        finally:
            for name, was_hidden in previous.items():
                obj = scene.objects.get(name)
                if obj is not None:
                    obj.hide_render = was_hidden
