# SPDX-License-Identifier: GPL-3.0-or-later
"""Talks to a running Unreal Editor from Blender, so a test round trip is one click.

Unreal ships a Python remote-execution protocol: the editor announces itself over UDP
multicast (239.0.0.1:6766 by default) and accepts Python over a TCP command connection. The
reference client is `remote_execution.py`, shipped inside the engine at
`Engine/Plugins/Experimental/PythonScriptPlugin/Content/Python/`.

We **import that file from the user's own engine install** rather than vendoring a copy —
it is Epic-licensed, and BU is GPL, so redistributing it here would be a licensing problem.
Importing the user's existing copy at runtime avoids that entirely.

Requires "Enable Remote Execution?" in Project Settings -> Plugins -> Python. It is **off by
default**, and nothing here can turn it on remotely (that would need the very channel it
gates), so the operator reports it precisely when no editor answers.
"""

import glob
import importlib.util
import os
import sys

MODULE_NAME = "bu_ue_remote_execution"
RELATIVE_CLIENT_PATH = os.path.join(
    "Engine", "Plugins", "Experimental", "PythonScriptPlugin", "Content", "Python",
    "remote_execution.py",
)

# Where Epic installs engines on Windows, newest last so the newest wins.
_ENGINE_GLOBS = (
    r"C:\Program Files\Epic Games\UE_*",
    r"D:\Program Files\Epic Games\UE_*",
    r"C:\Epic Games\UE_*",
)


def candidate_client_paths(engine_dir=""):
    """Every plausible location of the engine's remote_execution.py, best first."""
    paths = []

    def add(path):
        if path and path not in paths and os.path.isfile(path):
            paths.append(path)

    if engine_dir:
        engine_dir = bpy_abspath(engine_dir)
        # Accept either the engine root or a path already pointing at the file.
        if engine_dir.lower().endswith(".py"):
            add(engine_dir)
        else:
            add(os.path.join(engine_dir, RELATIVE_CLIENT_PATH))
            # Also tolerate being given the "Engine" folder itself.
            add(os.path.join(os.path.dirname(engine_dir), RELATIVE_CLIENT_PATH))

    for pattern in _ENGINE_GLOBS:
        for root in sorted(glob.glob(pattern)):
            add(os.path.join(root, RELATIVE_CLIENT_PATH))

    return paths


def bpy_abspath(path):
    try:
        import bpy

        return bpy.path.abspath(path)
    except Exception:  # noqa: BLE001 - usable outside Blender for testing
        return path


# What we actually use from the engine's client. Checked after import so a wrong or truncated
# file fails here with a clear message, rather than as an AttributeError mid-export.
_REQUIRED_ATTRS = ("RemoteExecutionConfig", "RemoteExecution", "MODE_EXEC_FILE")


def load_client(engine_dir=""):
    """Import the engine's remote_execution module. Returns (module, path) or (None, error)."""
    cached = sys.modules.get(MODULE_NAME)
    if cached is not None and all(hasattr(cached, a) for a in _REQUIRED_ATTRS):
        return cached, getattr(cached, "__file__", "")
    sys.modules.pop(MODULE_NAME, None)

    candidates = candidate_client_paths(engine_dir)
    if not candidates:
        return None, (
            "Could not find Unreal's remote_execution.py. Set the Unreal install directory in "
            "the BU add-on preferences (the folder containing Engine/)."
        )

    errors = []
    for path in candidates:
        try:
            spec = importlib.util.spec_from_file_location(MODULE_NAME, path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[MODULE_NAME] = module
            spec.loader.exec_module(module)
        except Exception as exc:  # noqa: BLE001
            sys.modules.pop(MODULE_NAME, None)
            errors.append("{0}: {1}".format(path, exc))
            continue

        missing = [a for a in _REQUIRED_ATTRS if not hasattr(module, a)]
        if missing:
            sys.modules.pop(MODULE_NAME, None)
            errors.append("{0}: not Unreal's client (missing {1})".format(path, ", ".join(missing)))
            continue

        return module, path

    return None, "Could not load a usable remote_execution.py. Tried:\n  " + "\n  ".join(errors)


class Session(object):
    """A short-lived remote-execution session, safe to use as a context manager."""

    def __init__(self, engine_dir="", multicast_group="", bind_address=""):
        self.engine_dir = engine_dir
        self.multicast_group = multicast_group
        self.bind_address = bind_address
        self.client = None
        self.remote = None
        self.error = ""

    def __enter__(self):
        module, info = load_client(self.engine_dir)
        if module is None:
            self.error = info
            return self

        self.client = module
        config = module.RemoteExecutionConfig()

        if self.multicast_group:
            host, _, port = self.multicast_group.rpartition(":")
            if host and port.isdigit():
                config.multicast_group_endpoint = (host, int(port))
        if self.bind_address:
            config.multicast_bind_address = self.bind_address

        self.remote = module.RemoteExecution(config)
        try:
            self.remote.start()
        except Exception as exc:  # noqa: BLE001
            self.error = "Could not start a remote-execution session: {0}".format(exc)
            self.remote = None
        return self

    def __exit__(self, *_exc):
        if self.remote is not None:
            try:
                if self.remote.has_command_connection():
                    self.remote.close_command_connection()
            except Exception:  # noqa: BLE001
                pass
            try:
                self.remote.stop()
            except Exception:  # noqa: BLE001
                pass
        return False

    # -- discovery -----------------------------------------------------------

    def nodes(self, timeout=3.0, settle=1.0):
        """Every editor that answers within `timeout`, accumulated rather than raced.

        Editors announce on independent heartbeats, so the first reply is not the only reply.
        Stopping at it — even after a short extra wait — reports whichever editor happened to be
        quickest, and that is how a command aimed at a test project ends up in a production one.
        Measured with two editors open: a 5-second window that stopped early saw only one of them,
        and widening the window did not help while the loop still broke on the first result.

        So: keep listening for the whole `settle` period after the first answer, and return the
        union. `timeout` bounds how long to wait for *any* editor; `settle` bounds how long to
        keep collecting once one has spoken.
        """
        if self.remote is None:
            return []

        import time

        by_id = {}
        deadline = time.time() + max(0.2, timeout)
        settle_until = None
        while time.time() < deadline:
            for node in self.remote.remote_nodes:
                node_id = node.get("node_id")
                if node_id and node_id not in by_id:
                    by_id[node_id] = node
            if by_id:
                if settle_until is None:
                    settle_until = time.time() + max(0.0, settle)
                elif time.time() >= settle_until:
                    break
            time.sleep(0.1)
        return sorted(by_id.values(), key=lambda n: str(n.get("project_name") or ""))

    def run(self, script, node_id=None, timeout=3.0):
        """Execute a Python script in the editor. Returns (ok, output_lines, message)."""
        if self.remote is None:
            return False, [], self.error or "No remote-execution session"

        found = self.nodes(timeout)
        if not found:
            return False, [], (
                "No running Unreal Editor answered. Check that the project is open and that "
                "Project Settings > Plugins > Python > 'Enable Remote Execution?' is ticked "
                "(it is off by default, and needs an editor restart)."
            )

        if node_id:
            # Match on project name too: node ids are regenerated every time an editor restarts,
            # so a saved selection would otherwise go stale the moment the artist reopens Unreal.
            match = [n for n in found if n.get("node_id") == node_id]
            if not match:
                match = [n for n in found if n.get("project_name") == node_id]
            if not match:
                return False, [], (
                    "'{0}' is not running. Editors answering now: {1}".format(
                        node_id, ", ".join(str(n.get("project_name")) for n in found) or "none")
                )
            target = match[0]
        elif len(found) > 1:
            # Never guess between projects. Picking the first responder is how an export lands in
            # the wrong project, and the wrong project may be one the artist cannot afford to have
            # touched.
            return False, [], (
                "{0} Unreal editors are running ({1}). Pick one in BU's sidebar — BU will not "
                "guess.".format(
                    len(found), ", ".join(str(n.get("project_name")) for n in found))
            )
        else:
            target = found[0]

        try:
            self.remote.open_command_connection(target["node_id"])
        except Exception as exc:  # noqa: BLE001
            return False, [], "Could not open a command connection: {0}".format(exc)

        try:
            result = self.remote.run_command(
                script, unattended=True, exec_mode=self.client.MODE_EXEC_FILE
            )
        except Exception as exc:  # noqa: BLE001
            return False, [], "Remote command failed: {0}".format(exc)
        finally:
            try:
                self.remote.close_command_connection()
            except Exception:  # noqa: BLE001
                pass

        lines = []
        for item in result.get("output") or []:
            text = item.get("output", "") if isinstance(item, dict) else str(item)
            for line in str(text).splitlines():
                if line.strip():
                    lines.append(line.rstrip())

        ok = bool(result.get("success"))
        # The engine reports a script's return value here, and an exec-file script returns nothing,
        # so this arrives as the *string* "None" rather than as None. That is truthy, so it won
        # every `message or fallback` downstream and surfaced to the artist as the whole error:
        # "Unreal import failed: None". Anything that carries no information becomes "".
        raw = result.get("result")
        message = "" if raw is None else str(raw).strip()
        if message in ("None", "null", "NULL"):
            message = ""
        return ok, lines, message


# Editors found by the last scan. Cached deliberately: an EnumProperty's items callback runs on
# every UI redraw, and doing UDP discovery there would stall Blender's interface several times a
# second. The artist refreshes explicitly instead, which is also honest — the list is a snapshot,
# not a live feed, and an editor closed since the scan is a case the code has to handle anyway.
_FOUND = []


def scan(engine_dir="", multicast_group="", bind_address="", timeout=4.0):
    """Refresh the cached editor list. Returns (nodes, error_message)."""
    global _FOUND
    with Session(engine_dir, multicast_group, bind_address) as session:
        if session.remote is None:
            _FOUND = []
            return [], session.error or "No remote-execution session"
        found = session.nodes(timeout)
    _FOUND = [
        {
            "node_id": n.get("node_id", ""),
            "project_name": str(n.get("project_name") or "(unnamed)"),
            "user": str(n.get("user") or ""),
            "machine": str(n.get("machine") or ""),
        }
        for n in found
    ]
    return _FOUND, ""


def found():
    return list(_FOUND)


# "No project chosen" needs to be a real enum entry, not an empty string. An EnumProperty cannot
# hold a value that is not among its items: assigning "" once the list is populated is rejected and
# Blender falls back to the *first* item — silently re-selecting a project and undoing the whole
# point of asking. Measured: with two editors up, clearing the choice left it reading 'BU'.
UNSET = "BU_NO_TARGET"


def target_items(self=None, context=None):
    """EnumProperty items for the project picker. Always non-empty so the UI cannot break."""
    if not _FOUND:
        return [(UNSET, "No editors found — press Scan", "")]

    items = [
        (
            # Keyed by project name, not node id: ids change on every editor restart, and a
            # selection that silently stops matching is worse than one that stays put.
            node["project_name"],
            node["project_name"],
            "Running as {0}@{1}".format(node["user"], node["machine"]),
        )
        for node in _FOUND
    ]
    if len(items) > 1:
        # Only offered when there is genuine ambiguity: with one editor there is nothing to pick
        # between, and making the artist choose anyway would be ceremony for its own sake.
        items.insert(0, (UNSET, "— pick a project —", "BU will not guess between projects"))
    return items


def chosen_target(scene):
    """The selected project name, or "" when nothing is genuinely chosen."""
    value = getattr(scene, "bu_unreal_target", "") or ""
    return "" if value == UNSET else value


def describe_node(node):
    """One-line description of a discovered editor, for the UI."""
    project = node.get("project_name") or "?"
    machine = node.get("machine") or "?"
    user = node.get("user") or "?"
    return "{0} ({1}@{2})".format(project, user, machine)


def build_import_script(usd_path, content_path, pixel_art_preset=False, reload_first=True):
    """The Python BU sends to the editor.

    Prints sentinels so the Blender side can tell a real failure from noisy output, and always
    reloads first by default -- Unreal caches modules for the editor's lifetime, so without a
    reload an edited BU would appear to do nothing.
    """
    usd = usd_path.replace("\\", "/")
    reload_line = "    bu_bridge.reload()\n" if reload_first else ""
    # An unsaved level (/Temp/Untitled_N) is imported into, as artists expect, and said plainly:
    # its placed actors live only in that level until it is saved. Unreal itself asks to save it
    # when the editor closes. `import_scene` still refuses one by default for scripted imports,
    # where nobody would be asked: that is how a whole scene was once lost.
    return (
        "import traceback\n"
        "try:\n"
        "    import bu_bridge\n"
        + reload_line
        + "    from bu_bridge import bu_import as _bu_import\n"
        "    _level = _bu_import.current_level_path()\n"
        "    _unsaved = _bu_import.level_is_unsaved(_level)\n"
        "    bu_bridge.import_scene(\n"
        '        r"{usd}",\n'
        '        "{dest}",\n'
        "        pixel_art_preset={pixel},\n"
        "        allow_unsaved_level=True,\n"
        "    )\n"
        "    if _unsaved:\n"
        '        print("BU_LIVE_UNSAVED Imported into Unreal\'s unsaved level (" + _level + "). '
        "Save it there (File > Save Current Level As) to keep what was placed in it; the "
        'imported assets are saved either way.")\n'
        '    print("BU_LIVE_OK")\n'
        "except Exception as exc:\n"
        "    traceback.print_exc()\n"
        '    print("BU_LIVE_FAIL", exc)\n'
    ).format(usd=usd, dest=content_path, pixel=bool(pixel_art_preset))


def build_link_script(port, reload_first=True):
    """The Python that starts the real-time link's listener inside the editor.

    Same sentinel convention as `build_import_script`. Reloading first is safe while a link is
    already running: the listener's state lives in module globals, which a reload leaves alone.
    """
    reload_line = "    bu_bridge.reload()\n" if reload_first else ""
    return (
        "import traceback\n"
        "try:\n"
        "    import bu_bridge\n"
        + reload_line
        + "    from bu_bridge import bu_link as _bu_link\n"
        "    _bu_link.start(port={port})\n"
        '    print("BU_LINK_OK")\n'
        "except Exception as exc:\n"
        "    traceback.print_exc()\n"
        '    print("BU_LINK_FAIL", exc)\n'
    ).format(port=int(port))
