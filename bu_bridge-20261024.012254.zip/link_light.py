# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender's lights, described for the real-time link.

Sent in Blender's own terms: watts, radians, metres. Unreal's `bu_link_light` converts them, in
one tested place. What is here is reading the light and the one geometric fact the two programs
disagree on: a Blender light shines down its local -Z, an Unreal light along its local +X. So the
matrix sent for a light is its world matrix turned a quarter turn about local Y, and without
scale (Unreal light actors do not scale; an area light's scale is folded into its size instead).
"""

import numpy as np

try:
    from . import link_mesh
except ImportError:  # loaded by path in the plain-CPython tests
    import link_mesh

PRECISION = 4
# A quarter turn about local Y: +X (Unreal's forward) onto -Z (where a Blender light points).
TO_FORWARD = np.array([[0.0, 0.0, 1.0, 0.0],
                       [0.0, 1.0, 0.0, 0.0],
                       [-1.0, 0.0, 0.0, 0.0],
                       [0.0, 0.0, 0.0, 1.0]])


def _round(value):
    return round(float(value), PRECISION)


def scale_of(matrix):
    """The length of each basis axis of a 4x4 matrix. Pure."""
    m = np.array([list(row) for row in matrix], dtype=np.float64).reshape(4, 4)
    return [float(np.linalg.norm(m[:3, axis])) for axis in range(3)]


def light_matrix(matrix):
    """A Blender light's world matrix -> 16 floats for Unreal's light actor. Pure."""
    m = np.array([list(row) for row in matrix], dtype=np.float64).reshape(4, 4)
    for axis in range(3):
        length = np.linalg.norm(m[:3, axis])
        if length > 1e-12:
            m[:3, axis] /= length
    return link_mesh.matrix_to_unreal(m @ TO_FORWARD)


def describe(obj):
    """A light object -> the dict sent to Unreal (without name and matrix)."""
    light = obj.data
    kind = str(light.type)
    spec = {
        "light": kind,
        "color": [_round(c) for c in tuple(light.color)[:3]],
        "energy": _round(light.energy),
        "shadow": bool(getattr(light, "use_shadow", True)),
    }
    if getattr(light, "use_temperature", False):
        spec["temperature"] = _round(light.temperature)
    if getattr(light, "use_custom_distance", False):
        spec["distance"] = _round(light.cutoff_distance)
    if kind == "SUN":
        spec["angle"] = _round(light.angle)
    elif kind == "AREA":
        sx, sy, _sz = scale_of(obj.matrix_world)
        wide = light.shape in ("RECTANGLE", "ELLIPSE")
        spec["shape"] = str(light.shape)
        spec["size_x"] = _round(light.size * sx)
        spec["size_y"] = _round((light.size_y if wide else light.size) * sy)
        spec["spread"] = _round(getattr(light, "spread", 3.14159265))
    else:
        spec["radius"] = _round(light.shadow_soft_size)
        if kind == "SPOT":
            spec["spot_size"] = _round(light.spot_size)
            spec["spot_blend"] = _round(light.spot_blend)
    visibility = ray_visibility(obj)
    if visibility:
        spec["visibility"] = visibility
    if getattr(light, "bu_unreal", None) is not None:
        # What only Unreal has: units, scales, channels, IES… (BU's Unreal Light panel).
        from . import link_lighting

        spec["unreal"] = link_lighting.describe_light(light)
    return spec


# Blender's ways of keeping a light out of one kind of ray: the object's Ray Visibility box
# (Cycles) and the light's Influence factor (EEVEE). Unreal's `bu_link_light` turns each into its
# nearest setting: diffuse and specular scale, volumetric scattering.
# Not Transmission: in Blender that is light passing through glass and skin, which Unreal has no
# per-light scale for. Sent as Unreal's "Affect Translucent Lighting" it stopped every light
# lighting Blended surfaces at all; Toy Freddy's lights all had it at 0, and his eye whites
# went dark.
RAY_VISIBILITY = (("diffuse", "visible_diffuse", "diffuse_factor"),
                  ("glossy", "visible_glossy", "specular_factor"),
                  ("volume", "visible_volume_scatter", "volume_factor"))


def ray_visibility(obj):
    """{kind: how much of the light those rays see} for what is not fully seen, or {}."""
    light = obj.data
    found = {}
    for key, visible, factor in RAY_VISIBILITY:
        value = _round(getattr(light, factor, 1.0)) if getattr(obj, visible, True) else 0.0
        if value != 1.0:
            found[key] = max(0.0, value)
    return found
