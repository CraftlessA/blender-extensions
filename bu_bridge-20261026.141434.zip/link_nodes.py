# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender's shader nodes, translated for Unreal's material graph.

The nodes behind a Principled BSDF input become a small portable graph that Unreal rebuilds as
material expressions (`bu_link_graph`). The graph keeps **wiring** and **values** apart:

* `graph` is the topology: which operations, connected how, with any setting that Unreal bakes
  into the material itself (a blend type, a noise's number of levels). It is hashed into
  `graph_key`, and Unreal compiles one material per key — so rewiring costs a shader compile,
  a few seconds.
* `graph_values` holds every typed-in number and colour as a named parameter (`p0`, `p1`, ...),
  set on a material instance — so dragging a slider is instant, as it is for any other material.
* `graph_textures` holds the images (`t0`, ...), as the texture fields `link_material` makes, so
  repainting one re-imports it without touching the graph. A Color Ramp becomes a small gradient
  image here (`ramp_file`), sampled by its factor: exact, and one texture lookup in Unreal.

A node with no translation makes its whole channel fall back to what the link did before (the
typed-in value, or a plain image map), and the panel lists which node it was. Some translations
are approximations, and say so: Unreal's noise is not Blender's noise, so a Noise Texture has
the right scale and character but not the same pattern. For an exact match, a material can be
baked instead (`link_bake`).

**Layered shaders.** A surface built from several Principled BSDFs — Mix Shaders, often inside
node groups, as decal and grime layers are — is translated per channel: each BSDF's input,
blended by its Mix Shader's factor. Unreal's material has one set of inputs, so mixing the
inputs is what mixing the shaders becomes; for two physically based layers that is very close.

IR, as sent: `{"nodes": [{"op", "in": {name: ref}, "opt": {...}}...], "out": {channel: ref}}`
where a ref is `{"n": index, "o": output, "t": type}` or `{"p": name, "t": type}`, and a type is
"f" (a float), "c" (a colour) or "v" (a vector). Unreal broadcasts a float wherever three values
are wanted; a colour or vector used as a float is converted here, explicitly, the way Blender
converts it (a colour's luminance, a vector's average).
"""

import hashlib
import json
import os

try:
    from . import link_material
except ImportError:  # loaded by path in the plain-CPython tests
    import link_material

# Which Principled inputs are translated, and as which Unreal channel and type. The normal is a
# vector in tangent space, as Unreal's Normal input takes it.
CHANNELS = (("Base Color", "BaseColor", "c"), ("Metallic", "Metallic", "f"),
            ("Roughness", "Roughness", "f"), ("Alpha", "Opacity", "f"),
            ("Emission Color", "EmissiveColor", "c"), ("Specular IOR Level", "Specular", "f"),
            ("Normal", "Normal", "v"),
            # A coat's amount and roughness from a map (Ennard's mask: a ramp of its ORM's
            # roughness). Read as 0.03 they made the coat a mirror.
            ("Coat Weight", "ClearCoat", "f"), ("Coat Roughness", "ClearCoatRoughness", "f"),
            # Sheen, Unreal's Fuzz on a Substrate Slab (`bu_link_material._slab`).
            ("Sheen Weight", "SheenWeight", "f"), ("Sheen Roughness", "SheenRoughness", "f"),
            ("Sheen Tint", "SheenTint", "c"))
FLAT_NORMAL = (0.0, 0.0, 1.0)
BLACK = (0.0, 0.0, 0.0, 1.0)
# What a shader other than a Principled BSDF means for each Principled input, when it is mixed
# with others: the name of its own input that stands for it, a fixed value, or None for none
# (that side of a mix takes the other's, as for a Transparent BSDF).
_GLASS = {"Base Color": "Color", "Metallic": 0.0, "Roughness": "Roughness", "Alpha": 1.0,
          "Emission Color": BLACK, "Emission Strength": 0.0, "Specular IOR Level": 0.5,
          "Normal": "Normal"}
_DIFFUSE = dict(_GLASS, **{"Roughness": 1.0, "Specular IOR Level": 0.0})
LEAF_INPUTS = {
    "BSDF_GLASS": _GLASS,
    "BSDF_REFRACTION": _GLASS,
    "BSDF_DIFFUSE": _DIFFUSE,
    "BSDF_TRANSLUCENT": _DIFFUSE,
    "BSDF_GLOSSY": dict(_GLASS, **{"Metallic": 1.0}),
    "BSDF_ANISOTROPIC": dict(_GLASS, **{"Metallic": 1.0}),
    "BSDF_METALLIC": dict(_GLASS, **{"Base Color": "Base Color", "Metallic": 1.0}),
    # Hair shaders on a mesh (Ennard's hat, asked for by a tester): a rough, non-metallic
    # surface of the hair's colour, reflecting by its IOR (1.55: Specular IOR Level about 0.6).
    # No normal input of their own. The Principled Hair's Melanin and Absorption modes have no
    # Color: `leaf_input` works one out.
    "BSDF_HAIR_PRINCIPLED": {"Base Color": "Color", "Metallic": 0.0, "Roughness": "Roughness",
                             "Alpha": 1.0, "Emission Color": BLACK, "Emission Strength": 0.0,
                             "Specular IOR Level": 0.6, "Normal": None},
    "BSDF_HAIR": {"Base Color": "Color", "Metallic": 0.0, "Roughness": "RoughnessU",
                  "Alpha": 1.0, "Emission Color": BLACK, "Emission Strength": 0.0,
                  "Specular IOR Level": 0.5, "Normal": None},
    # Light alone: no surface of its own, so the other side's, but opaque.
    "EMISSION": {"Base Color": None, "Metallic": None, "Roughness": None, "Alpha": 1.0,
                 "Emission Color": "Color", "Emission Strength": "Strength",
                 "Specular IOR Level": None, "Normal": None},
}
# The glow a layer gives: its Emission Color times its Emission Strength, mixed as one.
GLOW = "Emission Color x Strength"
# The Bump node's Filter Width default: the height's slope is taken over this fraction of a pixel.
BUMP_FILTER_WIDTH = 0.1
# UV maps Unreal gets per mesh (`bu_link.MAX_UV_CHANNELS`): a UV Map node naming a later one
# reads the first instead.
UV_CHANNELS = 4
DEPTH_LIMIT = 64
RAMP_WIDTH = 256
MIX_BLENDS = ("MIX", "MULTIPLY", "ADD", "SUBTRACT", "SCREEN", "DIFFERENCE", "DARKEN", "LIGHTEN",
              "OVERLAY", "DIVIDE", "LINEAR_LIGHT", "HUE", "SATURATION", "VALUE", "COLOR", "BURN",
              "DODGE", "SOFT_LIGHT")
MATH_OPS = ("ADD", "SUBTRACT", "MULTIPLY", "DIVIDE", "POWER", "MINIMUM", "MAXIMUM", "ABSOLUTE",
            "SQRT", "FLOOR", "CEIL", "FRACT", "MODULO", "SINE", "COSINE", "LESS_THAN",
            "GREATER_THAN", "MULTIPLY_ADD", "ROUND", "SIGN", "INVERSE_SQRT", "EXPONENT",
            "TANGENT", "ARCSINE", "ARCCOSINE", "ARCTANGENT", "ARCTAN2", "PINGPONG", "WRAP",
            "SNAP", "TRUNC", "COMPARE", "SMOOTH_MIN", "SMOOTH_MAX", "LOGARITHM", "RADIANS",
            "DEGREES", "SINH", "COSH", "TANH")
# Math operations of one input, and of three (the third is Value_002).
MATH_UNARY = ("ABSOLUTE", "SQRT", "FLOOR", "CEIL", "FRACT", "SINE", "COSINE", "ROUND", "SIGN",
              "INVERSE_SQRT", "EXPONENT", "TANGENT", "ARCSINE", "ARCCOSINE", "ARCTANGENT", "TRUNC",
              "RADIANS", "DEGREES", "SINH", "COSH", "TANH")
MATH_TERNARY = ("MULTIPLY_ADD", "WRAP", "COMPARE", "SMOOTH_MIN", "SMOOTH_MAX")
VECTOR_OPS = ("ADD", "SUBTRACT", "MULTIPLY", "DIVIDE", "SCALE", "LENGTH", "DOT_PRODUCT",
              "NORMALIZE", "ABSOLUTE", "MINIMUM", "MAXIMUM", "FLOOR", "FRACTION", "CEIL",
              "CROSS_PRODUCT", "DISTANCE", "MODULO", "SNAP", "SINE", "COSINE", "MULTIPLY_ADD")
# The Geometry node's outputs Unreal has: (op output, socket kind).
GEOMETRY_OUTPUTS = {"Position": ("position", "v"), "Normal": ("normal", "v"),
                    "True Normal": ("normal", "v"), "Incoming": ("incoming", "v"),
                    "Backfacing": ("backfacing", "f")}
GRADIENTS = ("LINEAR", "QUADRATIC", "EASING", "DIAGONAL", "SPHERICAL", "QUADRATIC_SPHERE",
             "RADIAL")
SOCKET_TYPES = {"VALUE": "f", "INT": "f", "BOOLEAN": "f", "RGBA": "c", "VECTOR": "v"}


# The Light Path node as a ray from the camera sees it: what Unreal draws is what the camera
# sees, so a shadow-ray or bounce trick (a lens see-through for shadows only) takes its camera
# side. Ray Length has no single value.
LIGHT_PATH_CAMERA = {"Is Camera Ray": 1.0, "Is Shadow Ray": 0.0, "Is Diffuse Ray": 0.0,
                     "Is Glossy Ray": 0.0, "Is Singular Ray": 0.0, "Is Reflection Ray": 0.0,
                     "Is Transmission Ray": 0.0, "Is Volume Scatter Ray": 0.0, "Ray Depth": 0.0,
                     "Diffuse Depth": 0.0, "Glossy Depth": 0.0, "Transparent Depth": 0.0,
                     "Transmission Depth": 0.0, "Portal Depth": 0.0}


class Unsupported(Exception):
    """A node, or a setting of one, this translation does not cover."""


def _round(value):
    return round(float(value), 5)


def param_value(value, kind):
    """A typed-in value as `graph_values` holds it. Pure."""
    if kind == "f":
        return _round(value)
    return [_round(v) for v in tuple(value)[:3]]


def socket_source(socket):
    """(tree, path) naming where a socket's typed-in value lives, or None. The tree is "" for
    the material's own node tree, else the node group's name; the path is the socket's within
    it (`nodes["Mix"].inputs[0]`), as a driver on it names it without `.default_value`."""
    try:
        tree = socket.id_data
        path = socket.path_from_id()
    except (AttributeError, ReferenceError, ValueError, TypeError):
        return None
    if not path:
        return None
    return ("" if getattr(tree, "is_embedded_data", False) else str(tree.name), str(path))


class Builder(object):
    """Translates the sockets of one material into one shared graph."""

    def __init__(self, material_name=""):
        self.material_name = material_name
        self.nodes = []
        self.values = {}
        # Parameter name -> `socket_source` of the typed-in value it was read from, so a driven
        # value can go to Unreal on its own (`link.Sync._send_values`).
        self.sources = {}
        self.textures = {}
        self.approximate = set()
        self.clear_gloss = False  # see `clear_gloss`
        self.added_glow = False  # see `added_glow`
        self._memo = {}
        self._groups = {}
        self._material = None

    # -- refs and parameters ---------------------------------------------------------------

    def _add(self, op, inputs, opt=None):
        self.nodes.append({"op": op, "in": inputs, "opt": opt or {}})
        return len(self.nodes) - 1

    def ref(self, op, inputs, out, kind, opt=None):
        return {"n": self._add(op, inputs, opt), "o": out, "t": kind}

    def param(self, value, kind, source=None):
        name = "p{0}".format(len(self.values))
        self.values[name] = param_value(value, kind)
        if source is not None:
            found = socket_source(source)
            if found is not None:
                self.sources[name] = found
        return {"p": name, "t": kind}

    def convert(self, ref, want, source_kind=None):
        """`ref` as type `want`, the way Blender converts between socket types."""
        have = ref["t"]
        if want == "f" and have in ("c", "v"):
            op = "luminance" if have == "c" else "average"
            return self.ref(op, {"a": ref}, "", "f")
        return dict(ref, t=want if have != "f" else "f")

    # -- sockets ---------------------------------------------------------------------------

    def socket(self, socket, want, context=(), depth=0):
        """A ref for what feeds `socket` (or its typed-in value), as type `want`."""
        if depth > DEPTH_LIMIT:
            raise Unsupported("a node chain deeper than {0}".format(DEPTH_LIMIT))
        if socket.is_linked:
            link = socket.links[0]
            if not link.is_valid or getattr(link, "is_muted", False):
                return self.default(socket, want)
            found = self.output(link.from_node, link.from_socket, context, depth + 1)
            return self.convert(found, want)
        return self.default(socket, want)

    def default(self, socket, want):
        kind = SOCKET_TYPES.get(socket.type)
        if kind is None:
            raise Unsupported("a {0} input".format(socket.type.lower()))
        if not hasattr(socket, "default_value"):
            # Unlinked inputs with no value: Blender's texture coordinates by default.
            return self.convert(self.ref("generated", {}, "", "v"), want)
        value = socket.default_value
        if kind == "f":
            return self.convert(self.param(float(value), "f", socket), want)
        return self.convert(self.param(tuple(value)[:3], kind, socket), want)

    def input(self, node, identifier, want, context, depth):
        for socket in node.inputs:
            if socket.identifier == identifier:
                return self.socket(socket, want, context, depth)
        raise Unsupported("{0} has no input {1}".format(node.name, identifier))

    # -- nodes -----------------------------------------------------------------------------

    def output(self, node, socket, context=(), depth=0):
        key = (node.as_pointer(), socket.identifier, context)
        if key in self._memo:
            return self._memo[key]
        found = self._translate(node, socket, context, depth)
        self._memo[key] = found
        return found

    def _translate(self, node, socket, context, depth):
        kind = node.type
        out = socket.identifier
        if getattr(node, "mute", False):
            for link in node.internal_links:
                if link.to_socket.identifier == out:
                    return self.socket(link.from_socket, SOCKET_TYPES.get(socket.type, "c"),
                                       context, depth)
            return self.default(socket, SOCKET_TYPES.get(socket.type, "c"))
        handler = getattr(self, "_node_" + kind.lower(), None)
        if handler is None:
            raise Unsupported("{0} ({1})".format(node.name, node.bl_label))
        return handler(node, out, context, depth)

    def _i(self, node, identifier, want, context, depth):
        return self.input(node, identifier, want, context, depth)

    def _node_reroute(self, node, out, context, depth):
        return self.socket(node.inputs[0], "c", context, depth)

    def _node_light_path(self, node, out, context, depth):
        name = next((s.name for s in node.outputs if s.identifier == out), out)
        if name not in LIGHT_PATH_CAMERA:
            raise Unsupported("{0}: {1}".format(node.name, name))
        self.approximate.add("Light Path as the camera's rays see it")
        return self.param(LIGHT_PATH_CAMERA[name], "f")

    def _node_input_scene_time(self, node, out, context, depth):
        # The current frame's time: a frame change tags the material (Blender's depsgraph
        # knows it reads the time), and the link describes it again with the new value. NCC's
        # stars read it as a 4D noise's W, to twinkle; untranslated, the whole sky was lost.
        import bpy

        scene = bpy.context.scene
        frame = float(scene.frame_current) + float(getattr(scene, "frame_subframe", 0.0))
        if out == "Frame":
            return self.param(frame, "f")
        fps = float(scene.render.fps) / float(scene.render.fps_base or 1.0)
        return self.param(frame / fps if fps > 0.0 else 0.0, "f")

    def _node_value(self, node, out, context, depth):
        return self.param(node.outputs[0].default_value, "f", node.outputs[0])

    def _node_rgb(self, node, out, context, depth):
        return self.param(tuple(node.outputs[0].default_value)[:3], "c", node.outputs[0])

    def _node_vertex_color(self, node, out, context, depth):
        # The mesh's render Color Attribute, which the link sends with the mesh (`link_mesh`).
        # Unreal has one set of vertex colours, so a node naming another attribute reads that one.
        if out == "Alpha":
            return self.ref("vertex_color", {}, "a", "f")
        return self.ref("vertex_color", {}, "rgb", "c")

    def _node_attribute(self, node, out, context, depth):
        # A geometry attribute by name: a UV map, the Color Attribute, or else a vector that
        # stands for a UV map on a mesh with none (geometry nodes' cables; `link_mesh.attribute_uv`).
        if getattr(node, "attribute_type", "GEOMETRY") != "GEOMETRY":
            raise Unsupported("{0}: {1} attribute".format(node.name, node.attribute_type.lower()))
        name = getattr(node, "attribute_name", "")
        kind = attribute_kind(self._material, name)
        if kind == "color":
            if out == "Alpha":
                return self.ref("vertex_color", {}, "a", "f")
            found = self.ref("vertex_color", {}, "rgb", "c")
            return self.ref("average", {"a": found}, "", "f") if out == "Fac" else found
        if out == "Alpha":
            return self.param(1.0, "f")
        if kind == "missing":
            # On no mesh wearing it, and those meshes have UV maps: Blender reads 0 (Sister
            # Location's wall cables: a ramp at 0 is black; read as the UV map, it was green).
            if out == "Fac":
                return self.param(0.0, "f")
            return self.param((0.0, 0.0, 0.0), "c" if out == "Color" else "v")
        if kind is None:
            self.approximate.add("Attribute {0!r} read as the mesh's UV map".format(name))
            index = 0
        else:
            index = kind
        uv = self.ref("uv", {}, "", "v", {"index": index})
        return self.ref("average", {"a": uv}, "", "f") if out == "Fac" else uv

    def _node_tex_image(self, node, out, context, depth):
        index = self._image(node, context, depth)
        if out == "Alpha":
            return {"n": index, "o": "a", "t": "f"}
        return {"n": index, "o": "rgb", "t": "c"}

    def _image(self, node, context, depth, normal=False):
        """The `image` op sampling this node's image (as a tangent-space normal if `normal`)."""
        found = link_material.texture(node) if getattr(node, "image", None) else None
        if found is None:
            raise Unsupported("{0}: an image with no file".format(node.name))
        if getattr(node, "projection", "FLAT") != "FLAT":
            raise Unsupported("{0}: {1} projection".format(node.name, node.projection))
        if normal:
            found["linear"] = True
            found["normal"] = True
        name = "t{0}".format(len(self.textures))
        self.textures[name] = found
        vector = node.inputs["Vector"]
        uv = self.socket(vector, "v", context, depth) if vector.is_linked else None
        opt = {"tex": name, "linear": bool(found.get("linear"))}
        if normal:
            opt["normal"] = True
        extension = getattr(node, "extension", "REPEAT")
        if extension in ("EXTEND", "CLIP", "MIRROR"):
            # Outside 0-1: the edge pixels, nothing (transparent black), or the image mirrored.
            opt["extension"] = extension
        return self._add("image", {"uv": uv} if uv else {}, opt)

    def _node_normal_map(self, node, out, context, depth):
        """A tangent-space Normal Map fed by an image, as the tangent-space normal it makes."""
        if getattr(node, "space", "TANGENT") != "TANGENT":
            raise Unsupported("{0}: {1} space".format(node.name, node.space.lower()))
        colour = node.inputs["Color"]
        if not colour.is_linked:
            return self.param(FLAT_NORMAL, "v")
        source = _upstream(colour)
        signs = None
        if source is not None and source.type == "COMBINE_COLOR":
            # A map made for DirectX, its green turned over for Blender (Separate Color, Invert,
            # Combine Color): the same image, that axis of its normal turned over.
            source, signs = _flipped_channels(source)
        if source is None or source.type != "TEX_IMAGE":
            # Built from other nodes (Ennard's wires overlay a scratch map on the wire's normal
            # map): that colour read as a normal, as Blender does, with its green turned over
            # for Unreal as an imported normal map's is. Its images are sampled as plain data.
            built = self._i(node, "Color", "c", context, depth)
            stretched = self.ref("vmath", {"a": built, "b": self.param((2.0, -2.0, 2.0), "v")},
                                 "", "v", {"op": "MULTIPLY"})
            image = self.ref("vmath", {"a": stretched, "b": self.param((1.0, -1.0, 1.0), "v")},
                             "", "v", {"op": "SUBTRACT"})
            return self.ref("mix", {"fac": self._i(node, "Strength", "f", context, depth),
                                    "a": self.param(FLAT_NORMAL, "v"), "b": image},
                            "", "v", {"blend": "MIX", "clamp": False})
        image = {"n": self._image(source, context, depth + 1, normal=True), "o": "rgb", "t": "v"}
        if signs is not None and signs != (1.0, 1.0, 1.0):
            image = self.ref("vmath", {"a": image, "b": self.param(signs, "v")}, "", "v",
                             {"op": "MULTIPLY"})
        # Strength 1 is the map; 0 is flat; Blender goes past 1 the same way.
        return self.ref("mix", {"fac": self._i(node, "Strength", "f", context, depth),
                                "a": self.param(FLAT_NORMAL, "v"), "b": image},
                        "", "v", {"blend": "MIX", "clamp": False})

    def _node_bump(self, node, out, context, depth):
        """A Bump node: the height's screen-space slope tilts the normal under it.

        Unreal rebuilds Blender's own formula from the height's derivatives (`bu_link_graph`
        `_op_bump`). A Bump with no height is the normal under it.
        """
        under = self.normal(node.inputs["Normal"], context, depth + 1)
        height = node.inputs["Height"]
        if not height.is_linked:
            return under
        width = node.inputs.get("Filter Width")
        heights = self._i(node, "Height", "f", context, depth)
        self._mark_heights(heights)
        return self.ref("bump", {"strength": self._i(node, "Strength", "f", context, depth),
                                 "distance": self._i(node, "Distance", "f", context, depth),
                                 "filter_width": (self.socket(width, "f", context, depth)
                                                  if width is not None
                                                  else self.param(BUMP_FILTER_WIDTH, "f")),
                                 "height": heights,
                                 "normal": under},
                        "", "v", {"invert": bool(getattr(node, "invert", False))})

    def _mark_heights(self, ref):
        """Mark the images a Bump's height reads as heights: Unreal keeps them sharper than a
        colour image (BC1 blurs a height into 4x4 blocks, and the bump shows each step)."""
        seen = set()
        todo = [ref]
        while todo:
            item = todo.pop()
            if not isinstance(item, dict) or "n" not in item or item["n"] in seen:
                continue
            seen.add(item["n"])
            node = self.nodes[item["n"]]
            if node.get("op") == "image":
                found = self.textures.get((node.get("opt") or {}).get("tex"))
                if found is not None and not found.get("normal"):
                    found["height"] = True
            todo.extend((node.get("in") or {}).values())

    def normal(self, socket, context=(), depth=0):
        """The tangent-space normal behind a Normal input: flat when nothing feeds it."""
        if socket is None or not socket.is_linked:
            return self.param(FLAT_NORMAL, "v")
        link = socket.links[0]
        if not link.is_valid or getattr(link, "is_muted", False):
            return self.param(FLAT_NORMAL, "v")
        node = link.from_node
        if node.type in ("MIX", "MIX_RGB"):
            return self._normal_mix(node, context, depth)
        if node.type not in ("NORMAL_MAP", "BUMP", "REROUTE", "GROUP", "GROUP_INPUT"):
            raise Unsupported("{0} ({1}) feeding a normal".format(node.name, node.bl_label))
        if node.type == "REROUTE":
            return self.normal(node.inputs[0], context, depth + 1)
        if node.type == "GROUP":
            inner, inner_context = self._enter_group(node, link.from_socket.identifier, context)
            return self.normal(inner, inner_context, depth + 1)
        if node.type == "GROUP_INPUT":
            outer, outer_context = self._leave_group(link.from_socket.identifier, context)
            return self.normal(outer, outer_context, depth + 1)
        return self.output(node, link.from_socket, context, depth + 1)

    def _normal_mix(self, node, context, depth):
        """A Mix of normals: Blender mixes them as world-space vectors, Unreal's normal is in
        tangent space. Where only one side is a normal BU follows (a Normal Map or Bump; the
        other a Geometry normal jittered by a texture, as Lefty's pupil darkens its normal map
        with), that side."""
        sides = [socket for socket in node.inputs if socket.enabled and socket.is_linked
                 and socket.name in ("A", "B", "Color1", "Color2")]
        found = []
        for socket in sides:
            try:
                found.append(self.normal(socket, context, depth + 1))
            except Unsupported:
                continue
        if len(found) != 1:
            raise Unsupported("{0} ({1}) feeding a normal".format(node.name, node.bl_label))
        self.approximate.add("a Mix of normals (its normal map side only)")
        return found[0]

    def _node_mix(self, node, out, context, depth):
        data = node.data_type
        if data not in ("RGBA", "FLOAT", "VECTOR"):
            raise Unsupported("{0}: mixing {1}".format(node.name, data.lower()))
        suffix, kind = {"RGBA": ("Color", "c"), "FLOAT": ("Float", "f"),
                        "VECTOR": ("Vector", "v")}[data]
        blend = node.blend_type if data == "RGBA" else "MIX"
        if blend not in MIX_BLENDS:
            raise Unsupported("{0}: the {1} blend".format(node.name, blend.title().replace("_", " ")))
        if data == "VECTOR" and getattr(node, "factor_mode", "UNIFORM") != "UNIFORM":
            raise Unsupported("{0}: a non-uniform factor".format(node.name))
        inputs = {"fac": self._i(node, "Factor_Float", "f", context, depth),
                  "a": self._i(node, "A_" + suffix, kind, context, depth),
                  "b": self._i(node, "B_" + suffix, kind, context, depth)}
        clamp = bool(getattr(node, "clamp_result", False)) and data == "RGBA"
        options = {"blend": blend, "clamp": clamp}
        # On by default: a factor past 0..1 (a Voronoi distance, a scaled noise) would push the
        # colour beyond both ends, where Blender stops at one of them.
        if getattr(node, "clamp_factor", True):
            options["clamp_factor"] = True
        return self.ref("mix", inputs, "", kind, options)

    def _node_mix_rgb(self, node, out, context, depth):
        if node.blend_type not in MIX_BLENDS:
            raise Unsupported("{0}: the {1} blend".format(node.name, node.blend_type.title()))
        inputs = {"fac": self._i(node, "Fac", "f", context, depth),
                  "a": self._i(node, "Color1", "c", context, depth),
                  "b": self._i(node, "Color2", "c", context, depth)}
        # The old MixRGB always clamps its factor.
        return self.ref("mix", inputs, "", "c",
                        {"blend": node.blend_type, "clamp": bool(node.use_clamp),
                         "clamp_factor": True})

    def _node_math(self, node, out, context, depth):
        op = node.operation
        if op not in MATH_OPS:
            raise Unsupported("{0}: {1}".format(node.name, op.title().replace("_", " ")))
        inputs = {"a": self._i(node, "Value", "f", context, depth)}
        if op not in MATH_UNARY:
            inputs["b"] = self._i(node, "Value_001", "f", context, depth)
        if op in MATH_TERNARY:
            inputs["c"] = self._i(node, "Value_002", "f", context, depth)
        return self.ref("math", inputs, "", "f", {"op": op, "clamp": bool(node.use_clamp)})

    def _node_vect_math(self, node, out, context, depth):
        op = node.operation
        if op not in VECTOR_OPS:
            raise Unsupported("{0}: vector {1}".format(node.name, op.title().replace("_", " ")))
        inputs = {"a": self._i(node, "Vector", "v", context, depth)}
        if op in ("ADD", "SUBTRACT", "MULTIPLY", "DIVIDE", "DOT_PRODUCT", "MINIMUM", "MAXIMUM",
                  "CROSS_PRODUCT", "DISTANCE", "MODULO", "SNAP", "MULTIPLY_ADD"):
            inputs["b"] = self._i(node, "Vector_001", "v", context, depth)
        if op == "MULTIPLY_ADD":
            inputs["c"] = self._i(node, "Vector_002", "v", context, depth)
        if op == "SCALE":
            inputs["b"] = self._i(node, "Scale", "f", context, depth)
        kind = "f" if op in ("LENGTH", "DOT_PRODUCT", "DISTANCE") else "v"
        if kind == "f" and out == "Vector":
            raise Unsupported("{0}: its vector output".format(node.name))
        return self.ref("vmath", inputs, "", kind, {"op": op})

    def _node_rgbtobw(self, node, out, context, depth):
        # The colour's luminance, as Blender's own colour-to-number conversion takes it.
        return self.ref("luminance", {"a": self._i(node, "Color", "c", context, depth)}, "", "f")

    def _node_new_geometry(self, node, out, context, depth):
        """The Geometry node, in Blender's axes and metres: Position, Normal, Incoming (towards
        the camera) and Backfacing. True Normal is taken as the smooth normal."""
        found = GEOMETRY_OUTPUTS.get(out)
        if found is None:
            raise Unsupported("{0}: {1}".format(node.name, out))
        if out == "True Normal":
            self.approximate.add("Geometry's True Normal (as the smooth normal)")
        return self.ref("geometry", {}, "", found[1], {"out": found[0]})

    def _node_invert(self, node, out, context, depth):
        return self.ref("invert", {"fac": self._i(node, "Fac", "f", context, depth),
                                   "a": self._i(node, "Color", "c", context, depth)}, "", "c")

    def _node_ambient_occlusion(self, node, out, context, depth):
        """Unoccluded: its Color passed through, AO 1. Unreal shades its own ambient occlusion
        (Ennard's wires scale their colour's Value by it)."""
        self.approximate.add("Ambient Occlusion as unoccluded (Unreal shades its own)")
        if out == "AO":
            return self.param(1.0, "f")
        return self._i(node, "Color", "c", context, depth)

    def _node_curve_rgb(self, node, out, context, depth):
        """RGB Curves: each channel through its curve after the combined one, as a lookup
        texture (one row; red, green and blue each read their own channel), mixed in by the
        factor."""
        mapping = node.mapping
        if (tuple(mapping.black_level)[:3] != (0.0, 0.0, 0.0)
                or tuple(mapping.white_level)[:3] != (1.0, 1.0, 1.0)
                or not mapping.use_clip or (mapping.clip_min_x, mapping.clip_max_x) != (0.0, 1.0)):
            self.approximate.add("RGB Curves over 0-1 only")
        path, stamp = curves_file(node, self.material_name)
        name = "t{0}".format(len(self.textures))
        self.textures[name] = {"path": path, "stamp": stamp, "nearest": False}
        colour = self._i(node, "Color", "c", context, depth)
        channels = {}
        for channel in ("r", "g", "b"):
            x = self.ref("channel", {"a": colour}, "", "f", {"channel": channel})
            looked = self._add("ramp", {"fac": x}, {"tex": name})
            channels[channel] = self.ref("channel", {"a": {"n": looked, "o": "rgb", "t": "c"}},
                                         "", "f", {"channel": channel})
        curved = self.ref("combine", channels, "", "c")
        return self.ref("mix", {"fac": self._i(node, "Fac", "f", context, depth),
                                "a": colour, "b": curved}, "", "c",
                        {"blend": "MIX", "clamp": False})

    def _node_valtorgb(self, node, out, context, depth):
        path, stamp = ramp_file(node, self.material_name)
        name = "t{0}".format(len(self.textures))
        self.textures[name] = {"path": path, "stamp": stamp,
                               "nearest": node.color_ramp.interpolation == "CONSTANT"}
        index = self._add("ramp", {"fac": self._i(node, "Fac", "f", context, depth)},
                          {"tex": name})
        if out == "Alpha":
            return {"n": index, "o": "a", "t": "f"}
        return {"n": index, "o": "rgb", "t": "c"}

    MAP_RANGE_MODES = ("LINEAR", "STEPPED", "SMOOTHSTEP", "SMOOTHERSTEP")

    def _node_map_range(self, node, out, context, depth):
        # Every interpolation, on a number or a vector (each component alike). Smoother Step
        # was missing: a tester's eyes (a procedural iris and sclera) lost their whole Base
        # Color graph to it and came out black.
        mode = node.interpolation_type
        if node.data_type not in ("FLOAT", "FLOAT_VECTOR") or mode not in self.MAP_RANGE_MODES:
            raise Unsupported("{0}: {1} {2}".format(node.name, node.data_type.lower(),
                                                    mode.lower()))
        vector = node.data_type == "FLOAT_VECTOR"
        kind = "v" if vector else "f"
        names = (("x", "Vector" if vector else "Value"), ("from_min", "From Min"),
                 ("from_max", "From Max"), ("to_min", "To Min"), ("to_max", "To Max"))
        if mode == "STEPPED":
            names += (("steps", "Steps"),)
        # A vector's own sockets: "Vector", then "From_Min_FLOAT3" and so on.
        inputs = {name: self._i(node, ident if not vector or name == "x"
                                else ident.replace(" ", "_") + "_FLOAT3", kind, context, depth)
                  for name, ident in names}
        # "smooth" as older Unreal plugins read it; "mode" for the rest.
        return self.ref("map_range", inputs, "", kind,
                        {"clamp": bool(node.clamp) and mode in ("LINEAR", "STEPPED"),
                         "smooth": mode == "SMOOTHSTEP", "mode": mode.lower()})

    def _node_clamp(self, node, out, context, depth):
        inputs = {"x": self._i(node, "Value", "f", context, depth),
                  "min": self._i(node, "Min", "f", context, depth),
                  "max": self._i(node, "Max", "f", context, depth)}
        return self.ref("clamp", inputs, "", "f", {"range": node.clamp_type == "RANGE"})

    def _node_separate_color(self, node, out, context, depth):
        if getattr(node, "mode", "RGB") != "RGB":
            raise Unsupported("{0}: {1} mode".format(node.name, node.mode))
        source = self._i(node, "Color", "c", context, depth)
        channel = {"Red": "r", "Green": "g", "Blue": "b"}[out]
        return self.ref("channel", {"a": source}, "", "f", {"channel": channel})

    def _node_seprgb(self, node, out, context, depth):
        source = self._i(node, "Image", "c", context, depth)
        channel = {"R": "r", "G": "g", "B": "b"}[out]
        return self.ref("channel", {"a": source}, "", "f", {"channel": channel})

    def _node_combine_color(self, node, out, context, depth):
        if getattr(node, "mode", "RGB") != "RGB":
            raise Unsupported("{0}: {1} mode".format(node.name, node.mode))
        inputs = {k: self._i(node, ident, "f", context, depth)
                  for k, ident in (("r", "Red"), ("g", "Green"), ("b", "Blue"))}
        return self.ref("combine", inputs, "", "c")

    def _node_combrgb(self, node, out, context, depth):
        inputs = {k: self._i(node, ident, "f", context, depth)
                  for k, ident in (("r", "R"), ("g", "G"), ("b", "B"))}
        return self.ref("combine", inputs, "", "c")

    def _node_sepxyz(self, node, out, context, depth):
        source = self._i(node, "Vector", "v", context, depth)
        channel = {"X": "r", "Y": "g", "Z": "b"}[out]
        return self.ref("channel", {"a": source}, "", "f", {"channel": channel})

    def _node_combxyz(self, node, out, context, depth):
        inputs = {k: self._i(node, ident, "f", context, depth)
                  for k, ident in (("r", "X"), ("g", "Y"), ("b", "Z"))}
        return self.ref("combine", inputs, "", "v")

    def _node_object_info(self, node, out, context, depth):
        # Random only: Unreal's own random per instance, so instanced copies (Sister Location's
        # pipe sections) still vary; a lone object reads 0, where Blender hashes its name.
        if out != "Random":
            raise Unsupported("{0}: {1}".format(node.name, out))
        self.approximate.add("Object Info's Random is Unreal's per-instance random")
        return self.ref("instance_random", {}, "", "f")

    def _node_gamma(self, node, out, context, depth):
        return self.ref("gamma", {"a": self._i(node, "Color", "c", context, depth),
                                  "gamma": self._i(node, "Gamma", "f", context, depth)}, "", "c")

    def _node_brightcontrast(self, node, out, context, depth):
        return self.ref("bright_contrast", {
            "a": self._i(node, "Color", "c", context, depth),
            "bright": self._i(node, "Bright", "f", context, depth),
            "contrast": self._i(node, "Contrast", "f", context, depth)}, "", "c")

    def _node_hue_sat(self, node, out, context, depth):
        return self.ref("hue_sat", {
            "hue": self._i(node, "Hue", "f", context, depth),
            "sat": self._i(node, "Saturation", "f", context, depth),
            "val": self._i(node, "Value", "f", context, depth),
            "fac": self._i(node, "Fac", "f", context, depth),
            "a": self._i(node, "Color", "c", context, depth)}, "", "c")

    def _node_tex_coord(self, node, out, context, depth):
        if out == "UV":
            return self.ref("uv", {}, "", "v", {"index": 0})
        if out == "Object" and getattr(node, "object", None) is None:
            return self.ref("object", {}, "", "v")
        if out == "Generated":
            return self.ref("generated", {}, "", "v")
        if out == "Normal":
            # The object-space normal (Ennard's eye whites shade by it).
            return self.ref("object_normal", {}, "", "v")
        if out == "Object":
            # In another object's space (a decal's empty, an eye's control): that object's
            # inverse matrix where it was when the material was sent.
            inverse = node.object.matrix_world.inverted()
            rows = {axis: self.param(tuple(inverse[row][:3]), "v")
                    for row, axis in enumerate(("x", "y", "z"))}
            rows["t"] = self.param(tuple(inverse[row][3] for row in range(3)), "v")
            self.approximate.add("Object coordinates of {0!r} (where it was when sent)".format(
                node.object.name))
            return self.ref("object_of", rows, "", "v")
        if out == "Camera":
            # The point in the camera's space: X right, Y up, -Z ahead, in metres (the sclera of
            # Tiny Eye's eyes shades by it).
            return self.ref("camera_coords", {}, "", "v")
        if out == "Window":
            return self.ref("window", {}, "", "v")
        if out == "Reflection":
            return self.ref("reflection", {}, "", "v")
        raise Unsupported("{0}: {1} coordinates".format(node.name, out))

    def _facing_input(self, node):
        """Fresnel and Layer Weight read the surface's own normal; a wired one is a world-space
        normal Unreal's tangent-space graph does not have."""
        normal = node.inputs.get("Normal")
        if normal is not None and normal.is_linked:
            raise Unsupported("{0}: a wired Normal".format(node.name))

    def _node_fresnel(self, node, out, context, depth):
        """How much a dielectric of this IOR reflects at this viewing angle (Ennard's mask and
        suit tint their edges by it)."""
        self._facing_input(node)
        return self.ref("fresnel", {"ior": self._i(node, "IOR", "f", context, depth)}, "", "f")

    def _node_layer_weight(self, node, out, context, depth):
        self._facing_input(node)
        return self.ref("layer_weight", {"blend": self._i(node, "Blend", "f", context, depth)},
                        "fresnel" if out == "Fresnel" else "facing", "f")

    def _node_uvmap(self, node, out, context, depth):
        index = uv_index(self._material, getattr(node, "uv_map", ""))
        if index >= UV_CHANNELS:
            self.approximate.add("UV map {0!r} (only the first {1} reach Unreal)".format(
                node.uv_map, UV_CHANNELS))
            index = 0
        return self.ref("uv", {}, "", "v", {"index": index})

    def _node_mapping(self, node, out, context, depth):
        vector_type = node.vector_type
        if vector_type not in ("POINT", "TEXTURE", "VECTOR"):
            raise Unsupported("{0}: {1} mapping".format(node.name, vector_type.lower()))
        inputs = {"a": self._i(node, "Vector", "v", context, depth),
                  "rotation": self._i(node, "Rotation", "v", context, depth),
                  "scale": self._i(node, "Scale", "v", context, depth)}
        if vector_type != "VECTOR":
            inputs["location"] = self._i(node, "Location", "v", context, depth)
        opt = {"type": vector_type}
        rotation = node.inputs.get("Rotation")
        if rotation is not None and (rotation.is_linked or any(
                abs(float(v)) > 1e-7 for v in tuple(rotation.default_value)[:2])):
            # Turned about X or Y as well (Sister Location's ground fog: a gradient stood up
            # its height by -90 degrees about Y). About Z alone the material stays smaller, and
            # keeps the wiring it was compiled with.
            opt["euler"] = True
        return self.ref("mapping", inputs, "", "v", opt)

    def _coordinates(self, node, context, depth):
        vector = node.inputs["Vector"]
        if vector.is_linked:
            return self.socket(vector, "v", context, depth)
        return self.ref("generated", {}, "", "v")

    def _node_tex_noise(self, node, out, context, depth):
        dimensions = getattr(node, "noise_dimensions", "3D")
        if hasattr(node, "noise_type"):
            # Blender's own noise, in Unreal as Cycles has it (`bu_link_graph.NOISE_HLSL`):
            # the same pattern, every dimension and type, Distortion and a driven Detail.
            dims = int(dimensions[0])
            colour = out == "Color"
            opt = {"dims": dims, "type": str(node.noise_type),
                   "normalize": bool(getattr(node, "normalize", True)), "color": colour}
            inputs = {"scale": self._i(node, "Scale", "f", context, depth)}
            if dims > 1:
                inputs["a"] = self._coordinates(node, context, depth)
            if dims in (1, 4):
                inputs["w"] = self._i(node, "W", "f", context, depth)
            names = [("Detail", "detail"), ("Roughness", "roughness"),
                     ("Lacunarity", "lacunarity"), ("Distortion", "distortion")]
            if opt["type"] != "FBM":
                names += [("Offset", "offset"), ("Gain", "gain")]
            for name, key in names:
                if node.inputs.get(name) is not None:
                    inputs[key] = self._i(node, name, "f", context, depth)
            index = self._add("noise", inputs, opt)
            return {"n": index, "o": "color" if colour else "fac", "t": "c" if colour else "f"}
        if dimensions == "1D":
            raise Unsupported("{0}: 1D noise".format(node.name))
        detail = node.inputs["Detail"]
        if detail.is_linked:
            raise Unsupported("{0}: a driven Detail".format(node.name))
        lacunarity = node.inputs.get("Lacunarity")
        opt = {"levels": max(1, min(10, int(round(detail.default_value)) + 1)),
               "lacunarity": _round(lacunarity.default_value) if lacunarity is not None else 2.0}
        coordinates = self._coordinates(node, context, depth)
        if dimensions == "2D":
            # Blender's 2D noise reads X and Y only, so it does not change along Z: the same
            # noise on flattened coordinates, which streaks down vertical faces as Blender's does.
            coordinates = self.ref("vmath", {"a": coordinates,
                                             "b": self.param((1.0, 1.0, 0.0), "v")},
                                   "", "v", {"op": "MULTIPLY"})
        elif dimensions == "4D":
            # As 3D noise, W or no W, driven or not. Refusing a driven W (NCC's sky: W from
            # Scene Time, to make its stars twinkle) cost the whole chain it sat in: the sky's
            # Transparent mix went, and the cylinder became a solid purple wall that flooded
            # the scene with light it does not have in Blender. Here only the twinkle is lost.
            self.approximate.add("4D Noise Texture (as 3D: W is not used, so a W that changes "
                                 "over time does not animate it)")
        inputs = {"a": coordinates,
                  "scale": self._i(node, "Scale", "f", context, depth)}
        self.approximate.add("Noise Texture (Unreal's noise has the same scale, not the same pattern)")
        index = self._add("noise", inputs, opt)
        return {"n": index, "o": "color" if out == "Color" else "fac",
                "t": "c" if out == "Color" else "f"}

    def _node_tex_wave(self, node, out, context, depth):
        # Cycles' `svm_wave`, rebuilt from math nodes, its Distortion from Cycles' own noise.
        bands = node.wave_type == "BANDS"
        opt = {"type": node.wave_type,
               "direction": node.bands_direction if bands else node.rings_direction,
               "profile": node.wave_profile}
        inputs = {"a": self._coordinates(node, context, depth),
                  "scale": self._i(node, "Scale", "f", context, depth),
                  "phase": self._i(node, "Phase Offset", "f", context, depth)}
        distortion = node.inputs["Distortion"]
        if distortion.is_linked or distortion.default_value != 0.0:
            # Cycles' own noise in Unreal (`bu_link_graph.NOISE_HLSL`), as the Noise
            # Texture's: Detail, Detail Scale and Detail Roughness.
            inputs["distortion"] = self._i(node, "Distortion", "f", context, depth)
            inputs["detail"] = self._i(node, "Detail", "f", context, depth)
            inputs["detail_scale"] = self._i(node, "Detail Scale", "f", context, depth)
            inputs["roughness"] = self._i(node, "Detail Roughness", "f", context, depth)
        index = self._add("wave", inputs, opt)
        if out == "Color":
            return {"n": index, "o": "color", "t": "c"}
        return {"n": index, "o": "fac", "t": "f"}

    def _node_tex_checker(self, node, out, context, depth):
        inputs = {"a": self._coordinates(node, context, depth),
                  "c1": self._i(node, "Color1", "c", context, depth),
                  "c2": self._i(node, "Color2", "c", context, depth),
                  "scale": self._i(node, "Scale", "f", context, depth)}
        index = self._add("checker", inputs)
        return {"n": index, "o": "fac" if out == "Fac" else "color",
                "t": "f" if out == "Fac" else "c"}

    def _node_tex_gradient(self, node, out, context, depth):
        if node.gradient_type not in GRADIENTS:
            raise Unsupported("{0}: {1}".format(node.name, node.gradient_type))
        index = self._add("gradient", {"a": self._coordinates(node, context, depth)},
                          {"type": node.gradient_type})
        return {"n": index, "o": "", "t": "f"}

    VORONOI_FEATURES = ("F1", "F2", "SMOOTH_F1", "DISTANCE_TO_EDGE")
    VORONOI_METRICS = ("EUCLIDEAN", "MANHATTAN", "CHEBYCHEV", "MINKOWSKI")

    def _node_tex_voronoi(self, node, out, context, depth):
        # Blender's own Voronoi, rebuilt in Unreal from Cycles' code (its hash and cell search),
        # so the cells land where Blender's do.
        if node.voronoi_dimensions != "3D":
            raise Unsupported("{0}: {1} Voronoi (3D is translated)".format(
                node.name, node.voronoi_dimensions))
        if node.feature not in self.VORONOI_FEATURES:
            raise Unsupported("{0}: Voronoi {1}".format(node.name, node.feature.title()))
        if out not in ("Distance", "Color", "Position") or (
                node.feature == "DISTANCE_TO_EDGE" and out != "Distance"):
            raise Unsupported("{0}: its {1} output".format(node.name, out))
        inputs = {"a": self._coordinates(node, context, depth)}
        for key, identifier in (("scale", "Scale"), ("detail", "Detail"),
                                ("roughness", "Roughness"), ("lacunarity", "Lacunarity"),
                                ("smoothness", "Smoothness"), ("exponent", "Exponent"),
                                ("randomness", "Randomness")):
            inputs[key] = self._i(node, identifier, "f", context, depth)
        opt = {"feature": node.feature, "metric": node.distance,
               "normalize": bool(getattr(node, "normalize", False)),
               "rgb": "position" if out == "Position" else "color"}
        index = self._add("voronoi", inputs, opt)
        if out == "Distance":
            return {"n": index, "o": "", "t": "f"}
        return {"n": index, "o": "rgb", "t": "v" if out == "Position" else "c"}

    def _node_vector_rotate(self, node, out, context, depth):
        kind = node.rotation_type
        inputs = {"a": self._i(node, "Vector", "v", context, depth),
                  "center": self._i(node, "Center", "v", context, depth)}
        if kind == "EULER_XYZ":
            inputs["rotation"] = self._i(node, "Rotation", "v", context, depth)
        else:
            inputs["angle"] = self._i(node, "Angle", "f", context, depth)
            if kind == "AXIS_ANGLE":
                inputs["axis"] = self._i(node, "Axis", "v", context, depth)
        return self.ref("vector_rotate", inputs, "", "v",
                        {"type": kind, "invert": bool(getattr(node, "invert", False))})

    def _enter_group(self, node, out, context):
        """(the group's inner socket for output `out`, its context)."""
        tree = node.node_tree
        if tree is None:
            raise Unsupported("{0}: an empty group".format(node.name))
        output = next((n for n in tree.nodes if n.type == "GROUP_OUTPUT" and n.is_active_output),
                      None) or next((n for n in tree.nodes if n.type == "GROUP_OUTPUT"), None)
        if output is None:
            raise Unsupported("{0}: a group with no output".format(node.name))
        socket = next((s for s in output.inputs if s.identifier == out), None)
        if socket is None:
            raise Unsupported("{0}: output {1}".format(node.name, out))
        inner = context + (node.as_pointer(),)
        self._groups[inner] = (node, context)
        return socket, inner

    def _leave_group(self, out, context):
        """(the group node's own input for its Group Input's `out`, the outer context)."""
        if not context or context not in self._groups:
            raise Unsupported("a Group Input outside its group")
        outer, outer_context = self._groups[context]
        socket = next((s for s in outer.inputs if s.identifier == out), None)
        if socket is None:
            raise Unsupported("{0}: input {1}".format(outer.name, out))
        return socket, outer_context

    def _node_group(self, node, out, context, depth):
        socket, inner = self._enter_group(node, out, context)
        return self.socket(socket, SOCKET_TYPES.get(socket.type, "c"), inner, depth)

    def _node_group_input(self, node, out, context, depth):
        socket, outer_context = self._leave_group(out, context)
        return self.socket(socket, SOCKET_TYPES.get(socket.type, "c"), outer_context, depth)

    # -- layered shaders -------------------------------------------------------------------

    def shader(self, socket, context=(), depth=0):
        """The shader behind a shader socket, as a tree of layers.

        A layer is `("bsdf", principled node, context)` or `("mix", mix shader node, context,
        layer A, layer B)`. Reroutes, node groups and muted nodes are walked through.
        """
        if depth > DEPTH_LIMIT:
            raise Unsupported("a shader chain deeper than {0}".format(DEPTH_LIMIT))
        if socket is None or not socket.is_linked:
            raise Unsupported("an empty shader input")
        link = socket.links[0]
        if not link.is_valid or getattr(link, "is_muted", False):
            raise Unsupported("a muted shader link")
        node = link.from_node
        out = link.from_socket.identifier
        if getattr(node, "mute", False):
            for inner in node.internal_links:
                if inner.to_socket.identifier == out:
                    return self.shader(inner.from_socket, context, depth + 1)
            raise Unsupported("{0}: muted".format(node.name))
        if node.type == "BSDF_PRINCIPLED" or node.type in LEAF_INPUTS:
            return ("bsdf", node, context)
        if node.type == "BSDF_TRANSPARENT":
            # See-through where it is mixed in: no alpha there, every other input the other
            # side's (an eye's cornea over its iris, a decal's surround, eyelash cards).
            return ("clear", node, context)
        if node.type == "ADD_SHADER":
            # Light added on top (a second gloss, a glint): Unreal has one surface, so the
            # first shader is kept and the added one is dropped.
            self.approximate.add("Add Shader (its first shader only)")
            # Toy Freddy's eye adds its Principled over a mix of itself and a Transparent BSDF:
            # where the Transparent is, its cornea, the added Principled is glass, so it stays
            # see-through but still reflects (`clear_gloss`).
            drawn = []
            clear = False
            for index in (0, 1):
                try:
                    found = self.shader(node.inputs[index], context, depth + 1)
                except Unsupported:
                    continue
                if found[0] != "clear":
                    drawn.append(found)
                else:
                    clear = True
            if clear and drawn:
                # A Transparent BSDF plus something: that something over what is behind, not
                # in place of it (a star field's Transparent + Emission; `added_glow`).
                self.added_glow = True
            if not drawn:
                raise Unsupported("{0}: an Add Shader of nothing Unreal draws".format(node.name))
            if _clear(drawn[0]) and any(not _clear(other) for other in drawn[1:]):
                self.clear_gloss = True
            return drawn[0]
        if node.type == "REROUTE":
            return self.shader(node.inputs[0], context, depth + 1)
        if node.type == "MIX_SHADER":
            ray = _light_path_flag(node.inputs[0])
            if ray is not None:
                # Chosen by the kind of ray: the camera's side alone (the other is often a
                # Transparent BSDF for shadow rays, which would make the whole surface clear).
                self.approximate.add("Light Path as the camera's rays see it")
                return self.shader(node.inputs[2 if ray else 1], context, depth + 1)
            empty = [index for index in (1, 2) if not _shader_wired(node.inputs[index])]
            if empty == [1] and _ambient_occlusion(node.inputs[0]):
                # Darkened in its creases: the shader times Blender's Ambient Occlusion, mixed
                # with nothing (Lefty's suit and eyes). Unreal shades its own ambient
                # occlusion, so the shader alone.
                self.approximate.add("Mix Shader by Ambient Occlusion (Unreal shades its own)")
                return self.shader(node.inputs[2], context, depth + 1)
            if len(empty) == 2:
                raise Unsupported("{0}: a Mix Shader of nothing".format(node.name))
            # An empty side is black: no colour, no gloss, no glow.
            sides = [("dark", node, context) if index in empty
                     else self.shader(node.inputs[index], context, depth + 1)
                     for index in (1, 2)]
            return ("mix", node, context, sides[0], sides[1])
        if node.type == "GROUP":
            inner, inner_context = self._enter_group(node, out, context)
            return self.shader(inner, inner_context, depth + 1)
        if node.type == "GROUP_INPUT":
            outer, outer_context = self._leave_group(out, context)
            if not _shader_wired(outer):
                # The group's own shader input, with nothing plugged in: black, as an empty
                # Mix Shader side is (Sister Location's hose: its bands mix to unwired inputs).
                return ("dark", node, outer_context)
            return self.shader(outer, outer_context, depth + 1)
        raise Unsupported("{0} ({1}) in a layered shader".format(node.name, node.bl_label))

    def see_through(self, shader, layers, opacity=None):
        """Opacity that lets a driven transmission through: alpha x (1 - transmission). Unreal's
        masked surface then shows what is behind where the surface is clear, as a cornea shows
        the iris; solid glass it is not (no refraction, no reflection where it is cut out:
        Unreal's thin glass, tried instead, drew Tiny Eye's whites black)."""
        if layers is not None:
            amount = self.channel(layers, "Transmission Weight", "f")
            if opacity is None:
                opacity = self.channel(layers, "Alpha", "f")
        else:
            amount = self.socket(shader.inputs["Transmission Weight"], "f")
            if opacity is None:
                opacity = self.socket(shader.inputs["Alpha"], "f")
        if amount is None or opacity is None:
            raise Unsupported("a Transmission Weight from nodes in a mix of other shaders")
        solid = self.ref("math", {"a": self.param(1.0, "f"), "b": amount}, "", "f",
                         {"op": "SUBTRACT", "clamp": True})
        self.approximate.add("Transmission from nodes, as a cutout where the surface is clear")
        return self.ref("math", {"a": opacity, "b": solid}, "", "f",
                        {"op": "MULTIPLY", "clamp": False})

    def channel(self, layer, socket_name, kind):
        """One Principled input through a layer tree: each BSDF's, mixed by the Mix Shaders."""
        if layer[0] == "clear":
            # Nothing of its own but its transparency.
            return self.param(0.0, "f") if socket_name == "Alpha" else None
        if layer[0] == "dark":
            # An empty shader input: black, reflecting nothing; the rest the other side's.
            if socket_name in ("Base Color", GLOW):
                return self.param(BLACK, "c")
            if socket_name in ("Specular IOR Level", "Metallic"):
                return self.param(0.0, "f")
            return None
        if layer[0] == "bsdf":
            _, node, context = layer
            if socket_name == GLOW:
                colour = self.channel(layer, "Emission Color", "c")
                strength = self.channel(layer, "Emission Strength", "f")
                if colour is None or strength is None:
                    return None
                return self.ref("vmath", {"a": colour, "b": strength}, "", "c", {"op": "SCALE"})
            stands = leaf_input(node, socket_name)
            if stands is None:
                return None
            if not isinstance(stands, str):
                return self.param(stands, kind)
            socket = node.inputs.get(stands)
            if kind == "v":
                return self.normal(socket, context)
            if socket is None:
                raise Unsupported("{0} has no {1}".format(node.name, stands))
            return self.socket(socket, kind, context)
        _, node, context, first, second = layer
        key = ("mix shader", node.as_pointer(), context)
        if key not in self._memo:
            # Blender clamps a Mix Shader's factor. Built once, shared by every channel.
            self._memo[key] = self.ref(
                "clamp", {"x": self.socket(node.inputs[0], "f", context),
                          "min": self.param(0.0, "f"), "max": self.param(1.0, "f")},
                "", "f", {"range": False})
        fac = self._memo[key]
        a = self.channel(first, socket_name, kind)
        b = self.channel(second, socket_name, kind)
        if a is None or b is None:
            return b if a is None else a  # a Transparent BSDF's side takes the other's
        return self.ref("mix", {"fac": fac, "a": a, "b": b},
                        "", kind, {"blend": "MIX", "clamp": False})

    # -- the result ------------------------------------------------------------------------

    def topology(self, outputs):
        return {"nodes": self.nodes, "out": outputs}


def graph_key(topology):
    """A short hash of the wiring alone. Pure."""
    text = json.dumps(topology, sort_keys=True, separators=(",", ":"))
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:12]


def _plain_image(node):
    """True for an image node sampled at the mesh's own UVs, as a plain texture map is."""
    return (node.type == "TEX_IMAGE" and getattr(node, "image", None) is not None
            and not node.inputs["Vector"].is_linked
            # Extend, Clip and Mirror change what lies outside 0-1; only the graph shows that
            # (a sign's logo set to Clip was tiled across the whole wall).
            and getattr(node, "extension", "REPEAT") == "REPEAT")


def _simple(socket, colour, name=""):
    """True when `socket` is fed in a way the plain material path already shows exactly."""
    if not socket.is_linked:
        return True
    if name == "Normal":
        return link_material._normal_map(socket) is not None and _plain_normal(socket)
    if name in ("Specular IOR Level", "Specular"):
        return False  # the plain path has a value for it, not a map
    if colour:
        link = socket.links[0]
        node = link.from_node
        while node.type == "REROUTE" and node.inputs[0].is_linked:
            node = node.inputs[0].links[0].from_node
        return _plain_image(node)
    node = link_material._map_source(socket)[0]
    return node is not None and _plain_image(node)


def _plain(shader, socket, kind, name):
    """`_simple`, for the base shader of layers: other shaders than a Principled BSDF are sent
    with no maps but a colour image (and an Emission's glow image), so only those are plain."""
    if shader.type == "BSDF_PRINCIPLED" or name == "Base Color" or (
            shader.type == "EMISSION" and name == "Emission Color"):
        return _simple(socket, kind == "c", name)
    return not socket.is_linked


def _plain_normal(socket):
    """True when the normal map `link_material._normal_map` found is sampled plainly."""
    node = socket.links[0].from_node
    while node.type == "BUMP":
        height = node.inputs.get("Height")
        if height is not None and height.is_linked:
            return False  # a real bump: only the graph carries the height
        inner = node.inputs.get("Normal")
        if inner is None or not inner.is_linked:
            return False
        node = inner.links[0].from_node
    colour = node.inputs.get("Color")
    return bool(colour is not None and colour.is_linked
                and _plain_image(colour.links[0].from_node))


def uv_index(material, name):
    """Which of the UV maps Unreal gets (`link_mesh.uv_order`) a UV Map node's name is.

    Read from the first mesh using the material that has a map of that name; 0 (the render
    map) for no name, or when no mesh has one.
    """
    if not name or material is None:
        return 0
    try:
        import bpy
        try:
            from . import link_mesh
        except ImportError:  # loaded by path in the plain-CPython tests
            import link_mesh
    except ImportError:
        return 0
    for mesh in bpy.data.meshes:
        if material.name not in {m.name for m in mesh.materials if m is not None}:
            continue
        names = [layer.name for layer in mesh.uv_layers]
        if name not in names:
            continue
        render = next((l for l in mesh.uv_layers if l.active_render), None) or mesh.uv_layers.active
        return link_mesh.uv_order(names, render.name if render is not None else "").index(name)
    return 0


def attribute_kind(material, name):
    """What an Attribute node's name is on the meshes using `material`: "color" for a Color
    Attribute, a UV map's index (`uv_index`), None for one geometry nodes made (no mesh wearing
    the material, or one with no UV map, which then sends it as its UV map:
    `link_mesh.attribute_uv`), or "missing" when every mesh wearing it has UV maps and none
    has the attribute."""
    if not name or material is None:
        return None
    try:
        import bpy
    except ImportError:
        return None
    wearers = [mesh for mesh in bpy.data.meshes
               if material.name in {m.name for m in mesh.materials if m is not None}]
    for mesh in wearers:
        if name in {layer.name for layer in mesh.uv_layers}:
            return uv_index(material, name)
        colors = getattr(mesh, "color_attributes", None)
        if colors is not None and name in {a.name for a in colors}:
            return "color"
    for mesh in wearers:
        if not len(mesh.uv_layers) or name in {a.name for a in mesh.attributes}:
            return None
    return "missing" if wearers else None


def leaf_input(node, socket_name):
    """What stands for a Principled input in a layer's shader (`LEAF_INPUTS`): an input's name,
    a value, or None."""
    inputs = LEAF_INPUTS.get(node.type)
    if inputs is None:
        return socket_name
    if (socket_name == "Base Color" and node.type == "BSDF_HAIR_PRINCIPLED"
            and getattr(node, "parametrization", "COLOR") != "COLOR"):
        return hair_colour(node)
    return inputs.get(socket_name)


# Cycles' melanin absorption per unit (principled_hair: eumelanin, pheomelanin).
EUMELANIN = (0.506, 0.841, 1.653)
PHEOMELANIN = (0.343, 0.733, 1.924)


def hair_colour(node):
    """The colour a Principled Hair BSDF in Melanin or Absorption mode looks: its absorption
    through about one hair's width, as Cycles works it out from the typed-in values."""
    import math

    def value(name, fallback):
        found = node.inputs.get(name)
        return float(found.default_value) if found is not None else fallback

    if getattr(node, "parametrization", "") == "ABSORPTION":
        found = node.inputs.get("Absorption Coefficient")
        sigma = tuple(found.default_value)[:3] if found is not None else (0.245, 0.52, 1.365)
    else:
        melanin = min(max(value("Melanin", 0.8), 0.0), 0.9999)
        redness = min(max(value("Melanin Redness", 1.0), 0.0), 1.0)
        amount = -math.log(1.0 - melanin)
        sigma = tuple(amount * ((1.0 - redness) * e + redness * p)
                      for e, p in zip(EUMELANIN, PHEOMELANIN))
        tint = node.inputs.get("Tint")
        if tint is not None:
            # Dye: the tint's own absorption added (Cycles' sigma from a colour, roughness 0).
            sigma = tuple(s + (math.log(max(t, 1e-4)) / -5.969) ** 2
                          for s, t in zip(sigma, tuple(tint.default_value)[:3]))
    return tuple(math.exp(-2.0 * s) for s in sigma) + (1.0,)


def leaf_socket(node, socket_name):
    """The layer shader's own input standing for a Principled one, or None."""
    stands = leaf_input(node, socket_name)
    return node.inputs.get(stands) if isinstance(stands, str) else None


def surface_layers(material):
    """The layer tree (`Builder.shader`) of a surface that mixes shaders, or None.

    A lone Principled BSDF inside a node group (a studio's "base character" shader) is one
    layer: its inputs come from outside the group, which the plain path cannot follow.

    None for a Principled BSDF or other single shader wired straight to the output (the plain
    path describes it) and for anything the layering does not cover (a Toon BSDF in the mix...).
    """
    socket = link_material._surface_socket(material)
    if socket is None or not socket.is_linked:
        return None
    if socket.links[0].from_node.type == "BSDF_PRINCIPLED":
        return None
    try:
        layer = Builder(getattr(material, "name", "")).shader(socket)
    except Unsupported:
        return None
    if not _leaves(layer):
        return None  # Transparent BSDFs alone
    # Anything but a shader wired straight to the output: a mix, a node group, an Add Shader,
    # a reroute.
    root = socket.links[0].from_node
    return layer if layer[0] == "mix" or layer[2] or layer[1] != root else None


def clear_gloss(material):
    """True when a surface is added over the see-through part of a mix with a Transparent BSDF:
    clear there, but still reflecting (an eye's cornea)."""
    socket = link_material._surface_socket(material)
    if socket is None or not socket.is_linked:
        return False
    builder = Builder(getattr(material, "name", ""))
    try:
        builder.shader(socket)
    except Unsupported:
        return False
    return builder.clear_gloss


def added_glow(material):
    """True when a surface is see-through with light added over it and nothing else: only
    Transparent BSDFs and Emissions, joined by an Add Shader (a star field, a glow card).
    Blender adds that light to what is behind; drawn as one surface it hid it (an opaque
    emission), so Unreal adds it too (`bu_link_material.ADDITIVE`)."""
    socket = link_material._surface_socket(material)
    if socket is None or not socket.is_linked:
        return False
    builder = Builder(getattr(material, "name", ""))
    try:
        layer = builder.shader(socket)
    except Unsupported:
        return False
    leaves = _leaves(layer)
    return builder.added_glow and bool(leaves) and all(
        leaf[1].type == "EMISSION" for leaf in leaves)


def base_layer(layer):
    """The shader under all the others: the first of every Mix Shader (the second where the
    first is a Transparent BSDF), and a surface rather than an Emission where there is one (a
    beacon's glass, its glow mixed in)."""
    leaves = [leaf[1] for leaf in _leaves(layer)]
    return next((node for node in leaves if node.type != "EMISSION"), leaves[0])


def _upstream(socket):
    """The node feeding a socket, past reroutes; None when nothing does."""
    for _ in range(DEPTH_LIMIT):
        if not socket.is_linked or not socket.links[0].is_valid:
            return None
        node = socket.links[0].from_node
        if node.type != "REROUTE":
            return node
        socket = node.inputs[0]
    return None


def _flipped_channels(combine):
    """(the image, each axis's sign) for a Combine Color putting an image's own channels back,
    some through a full Invert; (None, None) for anything else."""
    if getattr(combine, "mode", "RGB") != "RGB":
        return None, None
    image, signs = None, []
    for name in ("Red", "Green", "Blue"):
        socket = combine.inputs[name]
        sign = 1.0
        node = _upstream(socket)
        if node is not None and node.type == "INVERT":
            factor = node.inputs[0]
            if factor.is_linked or float(factor.default_value) not in (0.0, 1.0):
                return None, None
            sign = -1.0 if float(factor.default_value) == 1.0 else 1.0
            socket = node.inputs[1]
            node = _upstream(socket)
        if (node is None or node.type != "SEPARATE_COLOR"
                or getattr(node, "mode", "RGB") != "RGB"):
            return None, None
        if socket.links[0].from_socket.name != name and not _via_reroutes(socket, name):
            return None, None
        found = _upstream(node.inputs["Color"])
        if found is None or found.type != "TEX_IMAGE" or image not in (None, found):
            return None, None
        image = found
        signs.append(sign)
    return image, tuple(signs)


def _via_reroutes(socket, name):
    """True when the output reached through reroutes from a socket is called `name`."""
    for _ in range(DEPTH_LIMIT):
        if not socket.is_linked:
            return False
        link = socket.links[0]
        if link.from_node.type != "REROUTE":
            return link.from_socket.name == name
        socket = link.from_node.inputs[0]
    return False


def _light_path_flag(socket):
    """A Light Path ray flag's value for camera rays (1.0 or 0.0) when it feeds a socket straight
    (through reroutes); None otherwise."""
    node = _upstream(socket)
    if node is None or node.type != "LIGHT_PATH":
        return None
    link = socket.links[0]
    while link.from_node.type == "REROUTE":
        link = link.from_node.inputs[0].links[0]
    name = link.from_socket.name
    return LIGHT_PATH_CAMERA.get(name) if name.startswith("Is ") else None


def _shader_wired(socket):
    """True when a shader input has a working link into it."""
    return bool(socket.is_linked and socket.links[0].is_valid
                and not getattr(socket.links[0], "is_muted", False))


def _ambient_occlusion(socket):
    """True when a factor comes from an Ambient Occlusion node (through reroutes)."""
    for _ in range(DEPTH_LIMIT):
        if not _shader_wired(socket):
            return False
        node = socket.links[0].from_node
        if node.type != "REROUTE":
            return node.type == "AMBIENT_OCCLUSION"
        socket = node.inputs[0]
    return False


def _weights(layer, share=1.0):
    """[(leaf layer, its share of the surface)], or None when a Mix Shader's factor is wired."""
    if layer[0] != "mix":
        return [(layer, share)]
    factor = layer[1].inputs[0]
    if factor.is_linked:
        return None
    fac = min(1.0, max(0.0, float(factor.default_value)))
    first = _weights(layer[3], share * (1.0 - fac))
    second = _weights(layer[4], share * fac)
    return None if first is None or second is None else first + second


def see_through_glass(layer):
    """The Glass layer of a surface mixed by fixed amounts that light mostly goes through, Glass
    among it; None otherwise. Glass and Transparent BSDFs let it all through, a Principled BSDF
    its unwired Alpha's complement; anything else none."""
    weights = _weights(layer)
    if not weights:
        return None
    through, glass = 0.0, None
    for leaf, share in weights:
        if leaf[0] == "clear":
            through += share
        elif leaf[0] == "bsdf" and leaf[1].type in ("BSDF_GLASS", "BSDF_REFRACTION"):
            through += share
            if glass is None and share > 0.0:
                glass = leaf
        elif leaf[0] == "bsdf" and leaf[1].type == "BSDF_PRINCIPLED":
            alpha = leaf[1].inputs.get("Alpha")
            if alpha is not None and not alpha.is_linked:
                through += share * (1.0 - min(1.0, max(0.0, float(alpha.default_value))))
    return glass if glass is not None and through > 0.5 else None


def _leaves(layer):
    """The Principled BSDFs of a layer tree, first to last (Transparent BSDFs are not)."""
    if layer[0] == "bsdf":
        return [layer]
    if layer[0] in ("clear", "dark"):
        return []
    return _leaves(layer[3]) + _leaves(layer[4])



def _clear(layer):
    if layer[0] == "mix":
        return _clear(layer[3]) or _clear(layer[4])
    return layer[0] == "clear"


def _dark(layer):
    if layer[0] == "mix":
        return _dark(layer[3]) or _dark(layer[4])
    return layer[0] == "dark"


def _uniform(layer, socket_name):
    """True when every BSDF in the layers has this input unlinked and set alike (never for
    Alpha past a Transparent BSDF, nor for what an empty shader side blackens)."""
    if socket_name == "Alpha" and _clear(layer):
        return False
    if socket_name in ("Base Color", GLOW, "Specular IOR Level", "Metallic") and _dark(layer):
        return False
    values = set()
    for _, node, _context in _leaves(layer):
        stands = leaf_input(node, socket_name)
        if stands is None:
            continue  # the other side's
        if not isinstance(stands, str):
            value = stands
        else:
            socket = node.inputs.get(stands)
            if socket is None or socket.is_linked:
                return False
            value = socket.default_value if hasattr(socket, "default_value") else None
        try:
            values.add(tuple(_round(v) for v in value))
        except TypeError:
            values.add(_round(value) if value is not None else None)
    return len(values) <= 1


def translate(material, shader, skip=(), layers=None):
    """Add `graph`, `graph_key`, `graph_values`, `graph_textures` for a Principled shader.

    With `layers` (`surface_layers`), every input that differs between the layers is
    translated through their Mix Shaders, `shader` being the base one.

    Returns (fields, {Principled input: why not translated}). Fields is empty when no linked
    input needs a translation, or none could be translated.
    """
    builder = Builder(getattr(material, "name", ""))
    builder._material = material
    if layers is not None:
        # Walked again with this builder, which then knows the node groups it passed through.
        wanted = layers
        layers = builder.shader(link_material._surface_socket(material))
        if wanted[0] == "bsdf" and layers[0] == "mix":
            # One layer of the mix alone (`see_through_glass`).
            layers = next((leaf for leaf in _leaves(layers)
                           if leaf[1].as_pointer() == wanted[1].as_pointer()), wanted)
    outputs = {}
    failed = {}
    channels = CHANNELS
    strength_name = "Emission Strength"
    if shader.type == "EMISSION" and layers is None:
        # A bare Emission shader: its Color is the glow, its Strength the strength.
        channels = (("Color", "EmissiveColor", "c"),)
        strength_name = "Strength"
    # An Emission Strength fed by anything (a node group's input, a Math node, a map, layers
    # that differ) goes through the graph, multiplied into the colour: the plain path can only
    # send a typed-in number, and read a wired one as 0, so the surface did not glow.
    if layers is not None:
        strength_socket = leaf_socket(shader, strength_name)
        strength_driven = not _uniform(layers, strength_name) or (
            strength_socket is not None and strength_socket.is_linked)
    else:
        strength_socket = shader.inputs.get(strength_name)
        strength_driven = strength_socket is not None and strength_socket.is_linked
    scaled = False
    for socket_name, channel, kind in channels:
        if channel in skip:
            continue
        if layers is not None:
            # The base shader's own input for it, if it has one (an Emission has no colour).
            socket = leaf_socket(shader, socket_name)
            if channel == "EmissiveColor" and strength_driven:
                pass
            elif _uniform(layers, socket_name) and (
                    socket is None or _plain(shader, socket, kind, socket_name)):
                continue
        else:
            socket = shader.inputs.get(socket_name)
            if socket is None:
                continue
            if not (channel == "EmissiveColor" and strength_driven) and _simple(
                    socket, kind == "c", socket_name):
                continue
        mark = (len(builder.nodes), dict(builder.values), dict(builder.textures),
                dict(builder._memo), set(builder.approximate), dict(builder.sources))
        try:
            if layers is not None and channel == "EmissiveColor" and strength_driven:
                # Each layer's glow at its own strength, then mixed: a beacon's Emission at 400
                # faded into its Glass at 0 glows 400 times its fade, not that squared.
                found = builder.channel(layers, GLOW, kind)
                scaled = found is not None
            elif layers is not None:
                found = builder.channel(layers, socket_name, kind)
            elif kind == "v":
                found = builder.normal(socket)
            else:
                found = builder.socket(socket, kind)
            if found is None:
                raise Unsupported("no layer has a {0}".format(socket_name))
            if layers is None and channel == "EmissiveColor" and strength_driven:
                found = builder.ref("vmath", {"a": found,
                                              "b": builder.socket(strength_socket, "f")},
                                    "", "c", {"op": "SCALE"})
                scaled = True
            outputs[channel] = found
        except Unsupported as exc:
            # Undo what this channel added, so a half-translated chain is not sent.
            builder.nodes = builder.nodes[:mark[0]]
            (builder.values, builder.textures, builder._memo, builder.approximate,
             builder.sources) = mark[1:]
            failed[socket_name] = str(exc)
            if channel == "EmissiveColor":
                scaled = False
    see_through = False
    if "Opacity" not in skip and driven_transmission(shader, layers):
        mark = (len(builder.nodes), dict(builder.values), dict(builder.textures),
                dict(builder._memo), set(builder.approximate), dict(builder.sources))
        try:
            outputs["Opacity"] = builder.see_through(shader, layers, outputs.get("Opacity"))
            see_through = True
        except Unsupported as exc:
            builder.nodes = builder.nodes[:mark[0]]
            (builder.values, builder.textures, builder._memo, builder.approximate,
             builder.sources) = mark[1:]
            failed["Transmission Weight"] = str(exc)
    if not outputs:
        return {}, failed
    topology = builder.topology(outputs)
    fields = {"graph": topology, "graph_key": graph_key(topology),
              "graph_values": builder.values, "graph_textures": builder.textures}
    if builder.approximate:
        fields["graph_approximate"] = sorted(builder.approximate)
    if scaled and "EmissiveColor" in outputs:
        fields["graph_emission_scaled"] = True  # read by `link_material`, not sent
    if builder.sources:
        fields["graph_sources"] = dict(builder.sources)  # kept by `link_material`, not sent
    if see_through:
        fields["graph_see_through"] = True  # read by `link_material`, not sent
    return fields, failed


def driven_transmission(shader, layers=None):
    """True when a Principled BSDF's Transmission Weight comes from nodes: clear in places,
    solid in others (Tiny Eye's sclera: a clear cornea over the iris, white around it)."""
    leaves = _leaves(layers) if layers is not None else [("bsdf", shader, ())]
    for _, node, _context in leaves:
        if node.type != "BSDF_PRINCIPLED":
            continue
        socket = node.inputs.get("Transmission Weight")
        if socket is not None and socket.is_linked:
            return True
    return False


# A volume shader's inputs, as the fog box's channels (`translate_volume`): Unreal's fog master
# works Cycles' extinction and albedo out of them (`bu_link_fog`).
VOLUME_CHANNELS = (("Color", "Color", "c"), ("Density", "Density", "f"),
                   ("Absorption Color", "AbsorptionColor", "c"))


def translate_volume(material, node):
    """Add `graph`, `graph_key`, `graph_values`, `graph_textures` for a volume shader (Principled
    Volume or Volume Scatter) whose inputs are wired: a height gradient for ground fog, noise
    for patches. Channels as `VOLUME_CHANNELS`, and "Emission" (colour times strength).

    Returns (fields, {input: why not translated}); fields is empty when nothing wired could be
    translated, and the plain values stand.
    """
    builder = Builder(getattr(material, "name", ""))
    builder._material = material
    outputs = {}
    failed = {}
    jobs = [(name, channel, kind) for name, channel, kind in VOLUME_CHANNELS
            if node.inputs.get(name) is not None and node.inputs[name].is_linked]
    colour = node.inputs.get("Emission Color")
    strength = node.inputs.get("Emission Strength")
    glow = any(s is not None and s.is_linked for s in (colour, strength))
    if glow:
        jobs.append(("Emission Color", "Emission", "c"))
    for name, channel, kind in jobs:
        mark = (len(builder.nodes), dict(builder.values), dict(builder.textures),
                dict(builder._memo), set(builder.approximate), dict(builder.sources))
        try:
            if channel == "Emission":
                found = builder.ref("vmath", {"a": builder.socket(colour, "c"),
                                              "b": builder.socket(strength, "f")},
                                    "", "c", {"op": "SCALE"})
            else:
                found = builder.socket(node.inputs[name], kind)
            outputs[channel] = found
        except Unsupported as exc:
            builder.nodes = builder.nodes[:mark[0]]
            (builder.values, builder.textures, builder._memo, builder.approximate,
             builder.sources) = mark[1:]
            failed[name] = str(exc)
    if not outputs:
        return {}, failed
    topology = builder.topology(outputs)
    fields = {"graph": topology, "graph_key": graph_key(topology),
              "graph_values": builder.values, "graph_textures": builder.textures}
    if builder.approximate:
        fields["graph_approximate"] = sorted(builder.approximate)
    return fields, failed


# (path, stamp) of each lookup file by what it was made from: a driven material is described
# again every frame, and sampling a ramp 256 times from Python and reading its file back to
# compare was half of that.
_LUTS = {}


def _known_lut(key):
    found = _LUTS.get(key)
    if found is not None and os.path.isfile(found[0]):
        return found
    return None


def ramp_key(node, material_name=""):
    """Everything a Color Ramp's lookup file is made from. Pure, given the node."""
    ramp = node.color_ramp
    return ("ramp", material_name, node.name, ramp.interpolation, ramp.color_mode,
            ramp.hue_interpolation,
            tuple((round(e.position, 6), tuple(round(c, 6) for c in e.color)) for e in ramp.elements))


def ramp_file(node, material_name=""):
    """(path, stamp) of a 256x1 PNG of a Color Ramp, as Blender evaluates it."""
    import numpy as np

    key = ramp_key(node, material_name)
    found = _known_lut(key)
    if found is not None:
        return found
    ramp = node.color_ramp
    samples = np.array([tuple(ramp.evaluate(i / (RAMP_WIDTH - 1.0))) for i in range(RAMP_WIDTH)],
                       dtype=np.float32).reshape(1, RAMP_WIDTH, 4)
    _LUTS[key] = _lut_file(samples, node, material_name, "ramp")
    return _LUTS[key]


def curves_key(node, material_name=""):
    """Everything an RGB Curves node's lookup file is made from. Pure, given the node."""
    mapping = node.mapping
    return ("curves", material_name, node.name, mapping.extend,
            tuple(round(c, 6) for c in mapping.black_level),
            tuple(round(c, 6) for c in mapping.white_level),
            tuple(tuple((round(p.location[0], 6), round(p.location[1], 6), p.handle_type)
                        for p in curve.points) for curve in mapping.curves))


def curves_file(node, material_name=""):
    """(path, stamp) of a 256x1 PNG of an RGB Curves node: for each input value, each channel's
    curve applied to the combined curve's output (Cycles' order)."""
    import numpy as np

    key = curves_key(node, material_name)
    found = _known_lut(key)
    if found is not None:
        return found
    mapping = node.mapping
    mapping.initialize()
    curves = mapping.curves
    rows = []
    for i in range(RAMP_WIDTH):
        x = mapping.evaluate(curves[3], i / (RAMP_WIDTH - 1.0))
        rows.append([mapping.evaluate(curves[c], x) for c in range(3)] + [1.0])
    samples = np.array(rows, dtype=np.float32).reshape(1, RAMP_WIDTH, 4)
    _LUTS[key] = _lut_file(samples, node, material_name, "curves")
    return _LUTS[key]


def _lut_file(samples, node, material_name, prefix):
    """Write a 1 x 256 lookup row of linear RGBA samples as an sRGB PNG; (path, stamp)."""
    import numpy as np

    rgb = np.clip(samples[..., :3], 0.0, 1.0)
    # A ramp's colours are scene linear; the PNG holds sRGB, which Unreal decodes on import.
    samples[..., :3] = np.where(rgb <= 0.0031308, rgb * 12.92,
                                1.055 * np.power(rgb, 1.0 / 2.4) - 0.055)
    data = link_material.png_bytes((np.clip(samples, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8))
    stamp = hashlib.sha1(data).hexdigest()[:16]
    stem = hashlib.sha1("{0}/{1}".format(material_name, node.name).encode("utf-8")).hexdigest()[:10]
    path = os.path.join(link_material.packed_folder(), "{0}_{1}.png".format(prefix, stem))
    try:
        with open(path, "rb") as handle:
            unchanged = handle.read() == data
    except OSError:
        unchanged = False
    if not unchanged:
        with open(path, "wb") as handle:
            handle.write(data)
    return path, stamp
