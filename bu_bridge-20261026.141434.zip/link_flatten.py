# SPDX-License-Identifier: GPL-3.0-or-later
"""Node chains worked out on their own image, for an Unreal that cannot build materials.

BU's packaged renderer has no editor, so no shader compiler: a material reaches it as its master's
plain values and maps, and a node graph (`link_nodes`) as nothing. On the FNAF map that is 141
of the materials in use, many of them an image through a Color Ramp into Roughness.

When a shader input is one image texture passed through nodes that work pixel by pixel (Color
Ramp, RGB Curves, Math, Mix, Invert, Gamma, Bright/Contrast, RGB to BW, Separate and Combine
Color, Clamp, Map Range, Value and RGB), the result depends on that image's pixels alone. It is
worked out here, on the image itself, written as a PNG and sent as an ordinary map in the graph's
place. Exact but for filtering: the chain runs on texels, where Blender runs it on filtered
samples. No Cycles bake (`link_bake`) and no UVs are needed.

Anything else (a second image, a procedural texture, a Mapping node, a node group) leaves that
input to the graph. Used only when Unreal's hello says `graphs: 0`; the editor builds graphs.

`constant` works out an input that needs no image at all: a Blackbody with a typed-in
temperature (the office bulb's material) is one colour, which went to the packaged renderer as
black because a node fed it, while Cycles lit the room with it. That is used whatever Unreal can
build (`link_material`).

What was worked out is remembered on disk too (`flat_index.json` beside the PNGs): on the FNAF
map it is about 10 s of a first load, and the same scene opened again would do it all again.
"""

import hashlib
import json
import math
import os

try:
    from . import link_material, link_nodes
except ImportError:  # loaded by path in the tests
    import link_material
    import link_nodes

# A larger image is worked out on every second (or third...) texel: a 4K map would be a quarter
# of a gigabyte of floats, and the result is a stand-in for a graph the renderer cannot build.
MAX_SIDE = 2048
# Samples of a Color Ramp or RGB Curves, read between linearly.
LUT_SIZE = 1024
# Blender's default scene-linear luminance (Rec. 709), which it uses to turn a colour into a value.
LUMINANCE = (0.2126729, 0.7151522, 0.0721750)

# shader node type -> ((input, Unreal channel), ...)
INPUTS = {
    "BSDF_PRINCIPLED": (("Base Color", "BaseColor"), ("Metallic", "Metallic"),
                        ("Roughness", "Roughness"), ("Emission Color", "EmissiveColor")),
    "EMISSION": (("Color", "EmissiveColor"),),
}
# The strength that goes with an emission colour, per shader.
STRENGTH = {"BSDF_PRINCIPLED": "Emission Strength", "EMISSION": "Strength"}

# key -> texture field: a driven material is described every frame.
_CACHE = {}
# signature -> worked-out constant (or None), for `constant`.
_CONSTANTS = {}
# Blackbody: (temperatures, colours), read once from Blender. Cycles' node and a light's
# `temperature_color` are the same function (checked to four places from 1500 K to 10000 K).
BLACKBODY_RANGE = (800.0, 12000.0)
BLACKBODY_SAMPLES = 512
_BLACKBODY = []


class Unsupported(Exception):
    """A node this module cannot work out per pixel."""


# The same, kept on disk across sessions: key -> field (or None). Tied to this file's own source,
# so results worked out by other code are never used.
INDEX_NAME = "flat_index.json"
_INDEX = {"loaded": False, "entries": {}, "version": None}


def _version():
    if _INDEX["version"] is None:
        try:
            with open(__file__, "rb") as handle:
                _INDEX["version"] = hashlib.sha1(handle.read()).hexdigest()[:16]
        except OSError:
            _INDEX["version"] = ""
    return _INDEX["version"]


def forget():
    """Drop what this session remembers (the disk index is read again when next needed)."""
    _CACHE.clear()
    _CONSTANTS.clear()
    _INDEX["loaded"] = False
    _INDEX["entries"] = {}


def _index_path():
    return os.path.join(link_material.packed_folder(), INDEX_NAME)


def _index():
    if not _INDEX["loaded"]:
        _INDEX["loaded"] = True
        try:
            with open(_index_path(), encoding="utf-8") as handle:
                data = json.load(handle)
            if isinstance(data, dict) and _version() and data.get("version") == _version():
                _INDEX["entries"] = dict(data.get("entries") or {})
        except (OSError, ValueError):
            _INDEX["entries"] = {}
    return _INDEX["entries"]


def _remembered(key):
    """(True, field or None) when the disk index has this key and its file still holds what was
    written (another scene can reuse the same file name); (False, None) otherwise."""
    entries = _index()
    if key not in entries:
        return False, None
    field = entries[key]
    if field is None:
        return True, None
    try:
        with open(field["path"], "rb") as handle:
            stamp = hashlib.sha1(handle.read()).hexdigest()[:16]
    except (OSError, KeyError, TypeError):
        return False, None
    return (True, field) if stamp == field.get("stamp") else (False, None)


def _remember(name, key, field):
    """Note a result on disk, dropping older ones for the same input. Best effort."""
    entries = _index()
    for stale in [k for k in entries if k.startswith(name + "|")]:
        del entries[stale]
    entries[key] = field
    path = _index_path()
    try:
        with open(path + ".tmp", "w", encoding="utf-8") as handle:
            json.dump({"version": _version(), "entries": entries}, handle)
        os.replace(path + ".tmp", path)
    except OSError:
        pass


def blackbody_table():
    """(temperatures, (n, 3) colours) on a log scale over BLACKBODY_RANGE, from Blender."""
    if _BLACKBODY:
        return _BLACKBODY[0]
    import bpy

    np = _np()
    low, high = BLACKBODY_RANGE
    temperatures = np.geomspace(low, high, BLACKBODY_SAMPLES).astype(np.float32)
    light = bpy.data.lights.new("BU blackbody table", "POINT")
    try:
        light.use_temperature = True
        colours = []
        for value in temperatures:
            light.temperature = float(value)
            colours.append(tuple(light.temperature_color)[:3])
    finally:
        bpy.data.lights.remove(light)
    _BLACKBODY.append((temperatures, np.asarray(colours, dtype=np.float32)))
    return _BLACKBODY[0]


def blackbody(temperature):
    """Blender's Blackbody colour for a temperature (a number or an array), scene linear."""
    np = _np()
    temperatures, colours = blackbody_table()
    where = np.log(np.clip(np.asarray(temperature, dtype=np.float32), *BLACKBODY_RANGE))
    grid = np.log(temperatures)
    return np.stack([np.interp(where, grid, colours[:, c]) for c in range(3)], axis=-1).astype(np.float32)


def _np():
    import numpy as np

    return np


def _input(node, *names):
    """An enabled input by name or identifier."""
    for socket in node.inputs:
        if getattr(socket, "enabled", True) and (socket.identifier in names or socket.name in names):
            return socket
    raise Unsupported("{0} has no input {1}".format(node.name, names[0]))


def _plain(value):
    try:
        return tuple(round(float(v), 6) for v in value)
    except TypeError:
        return round(float(value), 6)


def _srgb_to_linear(values):
    np = _np()
    return np.where(values <= 0.04045, values / 12.92, np.power((values + 0.055) / 1.055, 2.4))


def _linear_to_srgb(values):
    np = _np()
    values = np.clip(values, 0.0, 1.0)
    return np.where(values <= 0.0031308, values * 12.92, 1.055 * np.power(values, 1.0 / 2.4) - 0.055)


def _hsv_blend(blend, a, b):
    """Blender's Hue, Saturation, Value and Color blends at a factor of 1, as Unreal builds them
    (`bu_link_graph._hsv_blend`): hsv_to_rgb(h, s, v) is v - chroma + chroma * pure, where pure
    is the hue at full saturation and value, (c - min) / (max - min)."""
    np = _np()
    a = np.asarray(a, dtype=np.float32)
    b = np.asarray(b, dtype=np.float32)

    def parts(c):
        value, lowest = c.max(axis=-1, keepdims=True), c.min(axis=-1, keepdims=True)
        chroma = value - lowest
        return value, chroma, (c - lowest) / np.maximum(chroma, 1e-6)
    a_value, a_chroma, a_pure = parts(a)
    b_value, b_chroma, b_pure = parts(b)

    def saturation(value, chroma):
        return chroma / np.maximum(value, 1e-20)
    if blend == "HUE":
        mixed, keep = a_value - a_chroma + a_chroma * b_pure, b_chroma <= 0.0
    elif blend == "SATURATION":
        chroma = a_value * saturation(b_value, b_chroma)
        mixed, keep = a_value - chroma + chroma * a_pure, a_chroma <= 0.0
    elif blend == "VALUE":
        chroma = b_value * saturation(a_value, a_chroma)
        mixed, keep = b_value - chroma + chroma * a_pure, np.zeros_like(a_chroma, dtype=bool)
    else:
        chroma = a_value * saturation(b_value, b_chroma)
        mixed, keep = a_value - chroma + chroma * b_pure, b_chroma <= 0.0
    return np.where(keep, a, mixed)


def _one_side(fac, blend):
    """"A" or "B" when a Mix with this factor reads only that side, else None. At a factor of 0
    every blend gives A; at 1 Mix gives B. So the side mixed away (a World's Sky Texture, at a
    factor of 1) need not be worked out, nor be something this cannot work out."""
    if getattr(fac, "ndim", 0) != 0:
        return None
    if float(fac) == 0.0:
        return "A"
    if float(fac) == 1.0 and blend == "MIX":
        return "B"
    return None


class Value(object):
    """A value in the chain: `kind` "f" (shape () or (h, w)) or "c" (shape (3,) or (h, w, 3))."""

    __slots__ = ("kind", "data")

    def __init__(self, kind, data):
        self.kind = kind
        self.data = data

    def as_kind(self, kind):
        np = _np()
        if kind == self.kind:
            return self.data
        if kind == "f":
            return self.data @ np.asarray(LUMINANCE, dtype=np.float32)
        return np.repeat(np.asarray(self.data, dtype=np.float32)[..., None], 3, axis=-1)


class Chain(object):
    """One input's nodes, worked out on the one image they read."""

    def __init__(self, max_side=MAX_SIDE):
        self.max_side = max_side
        self.image = None
        self.pixels = None  # (h, w, 4) scene linear, bottom row first, as Blender stores it
        self._memo = {}

    # -- sockets ---------------------------------------------------------------------------

    def socket(self, socket, kind):
        np = _np()
        if not socket.is_linked:
            value = socket.default_value
            if socket.type in ("RGBA", "VECTOR"):
                found = Value("c", np.asarray(tuple(value)[:3], dtype=np.float32))
            else:
                found = Value("f", np.float32(value))
            return found.as_kind(kind)
        link = socket.links[0]
        if getattr(link, "is_muted", False) or not getattr(link, "is_valid", True):
            raise Unsupported("a muted or invalid link")
        return self.output(link.from_node, link.from_socket).as_kind(kind)

    def output(self, node, socket):
        key = (node.name, socket.identifier)
        if key not in self._memo:
            if getattr(node, "mute", False):
                raise Unsupported(node.name + " is muted")
            handler = getattr(self, "_node_" + node.type.lower(), None)
            if handler is None:
                raise Unsupported("{0} ({1})".format(node.name, node.type))
            self._memo[key] = handler(node, socket)
        return self._memo[key]

    # -- the image -------------------------------------------------------------------------

    def _node_tex_image(self, node, socket):
        np = _np()
        image = getattr(node, "image", None)
        if not link_nodes._plain_image(node) or image is None:
            raise Unsupported(node.name + " is not sampled at the mesh's own UVs")
        if getattr(node, "projection", "FLAT") != "FLAT" or image.source not in ("FILE", "GENERATED"):
            raise Unsupported(node.name + " is not a flat single image")
        if self.image is not None and self.image != image:
            raise Unsupported("a second image")
        if self.pixels is None:
            self.image = image
            self.pixels = self._read(image)
        if socket.identifier == "Alpha":
            return Value("f", self.pixels[..., 3])
        return Value("c", self.pixels[..., :3])

    def _read(self, image):
        np = _np()
        width, height = (int(v) for v in image.size)
        channels = int(image.channels)
        if width <= 0 or height <= 0 or channels not in (1, 3, 4):
            raise Unsupported(image.name + " has no pixels")
        flat = np.empty(width * height * channels, dtype=np.float32)
        image.pixels.foreach_get(flat)
        flat = flat.reshape(height, width, channels)
        step = max(1, int(math.ceil(max(width, height) / float(self.max_side))))
        flat = flat[::step, ::step]
        pixels = np.ones(flat.shape[:2] + (4,), dtype=np.float32)
        if channels == 1:
            pixels[..., :3] = flat[..., :1]
        else:
            pixels[..., :channels] = flat
        settings = image.colorspace_settings
        if not image.is_float and not settings.is_data:
            # A byte image's pixels are its stored values: decoded here as Blender's shader does.
            name = str(settings.name)
            if name in ("sRGB",):
                pixels[..., :3] = _srgb_to_linear(pixels[..., :3])
            elif not name.lower().startswith("linear"):
                raise Unsupported("{0} is in {1}".format(image.name, name))
        return pixels

    # -- per-pixel nodes -------------------------------------------------------------------

    def _node_reroute(self, node, socket):
        return Value("c" if node.inputs[0].type == "RGBA" else "f",
                     self.socket(node.inputs[0], "c" if node.inputs[0].type == "RGBA" else "f"))

    def _node_value(self, node, socket):
        np = _np()
        return Value("f", np.float32(node.outputs[0].default_value))

    def _node_rgb(self, node, socket):
        np = _np()
        return Value("c", np.asarray(tuple(node.outputs[0].default_value)[:3], dtype=np.float32))

    def _ramp_lut(self, ramp):
        np = _np()
        return np.array([tuple(ramp.evaluate(i / (LUT_SIZE - 1.0))) for i in range(LUT_SIZE)],
                        dtype=np.float32)

    def _node_valtorgb(self, node, socket):
        np = _np()
        fac = np.clip(self.socket(_input(node, "Fac"), "f"), 0.0, 1.0)
        lut = self._ramp_lut(node.color_ramp)
        where = fac * (LUT_SIZE - 1.0)
        if node.color_ramp.interpolation == "CONSTANT":
            # Steps: the sample at or below, not a blend across the edge.
            index = np.clip(np.floor(where + 1e-6).astype(np.int32), 0, LUT_SIZE - 1)
            picked = lut[index]
        else:
            grid = np.arange(LUT_SIZE, dtype=np.float32)
            picked = np.stack([np.interp(where, grid, lut[:, c]) for c in range(4)], axis=-1)
        if socket.identifier == "Alpha":
            return Value("f", picked[..., 3])
        return Value("c", picked[..., :3])

    def _node_curve_rgb(self, node, socket):
        np = _np()
        fac = self.socket(_input(node, "Fac"), "f")
        colour = self.socket(_input(node, "Color"), "c")
        mapping = node.mapping
        mapping.initialize()
        curves = mapping.curves
        grid = np.linspace(0.0, 1.0, LUT_SIZE, dtype=np.float32)
        combined = [mapping.evaluate(curves[3], float(x)) for x in grid]
        luts = [np.array([mapping.evaluate(curves[c], x) for x in combined], dtype=np.float32)
                for c in range(3)]
        result = np.stack([np.interp(np.clip(colour[..., c], 0.0, 1.0), grid, luts[c])
                           for c in range(3)], axis=-1)
        fac = np.asarray(fac, dtype=np.float32)[..., None] if np.ndim(fac) else fac
        return Value("c", colour + fac * (result - colour))

    def _node_math(self, node, socket):
        np = _np()
        op = node.operation
        inputs = [s for s in node.inputs if getattr(s, "enabled", True)]
        a = self.socket(inputs[0], "f")
        b = self.socket(inputs[1], "f") if len(inputs) > 1 else None
        c = self.socket(inputs[2], "f") if len(inputs) > 2 else None
        with np.errstate(all="ignore"):
            if op == "ADD":
                out = a + b
            elif op == "SUBTRACT":
                out = a - b
            elif op == "MULTIPLY":
                out = a * b
            elif op == "DIVIDE":
                out = np.where(b != 0.0, a / np.where(b != 0.0, b, 1.0), 0.0)
            elif op == "MULTIPLY_ADD":
                out = a * b + c
            elif op == "POWER":
                out = np.where(a >= 0.0, np.power(np.maximum(a, 0.0), b), 0.0)
            elif op == "MINIMUM":
                out = np.minimum(a, b)
            elif op == "MAXIMUM":
                out = np.maximum(a, b)
            elif op == "ABSOLUTE":
                out = np.abs(a)
            elif op == "SQRT":
                out = np.sqrt(np.maximum(a, 0.0))
            elif op == "LESS_THAN":
                out = (a < b).astype(np.float32)
            elif op == "GREATER_THAN":
                out = (a > b).astype(np.float32)
            elif op == "ROUND":
                out = np.floor(a + 0.5)
            elif op == "FLOOR":
                out = np.floor(a)
            elif op == "CEIL":
                out = np.ceil(a)
            elif op == "FRACT":
                out = a - np.floor(a)
            elif op == "SNAP":
                out = np.where(b != 0.0, np.floor(a / np.where(b != 0.0, b, 1.0)) * b, 0.0)
            elif op == "SIGN":
                out = np.sign(a)
            else:
                raise Unsupported("Math " + op)
        out = np.nan_to_num(np.asarray(out, dtype=np.float32))
        if node.use_clamp:
            out = np.clip(out, 0.0, 1.0)
        return Value("f", out)

    def _blend(self, blend, fac, a, b):
        np = _np()
        if np.ndim(fac) == 2:
            fac = fac[..., None]
        with np.errstate(all="ignore"):
            if blend == "MIX":
                return a + fac * (b - a)
            if blend == "ADD":
                return a + fac * b
            if blend == "MULTIPLY":
                return a * (1.0 - fac + fac * b)
            if blend == "SUBTRACT":
                return a - fac * b
            if blend == "SCREEN":
                return 1.0 - (1.0 - fac + fac * (1.0 - b)) * (1.0 - a)
            if blend == "DIFFERENCE":
                return a + fac * (np.abs(a - b) - a)
            if blend == "DARKEN":
                return a + fac * (np.minimum(a, b) - a)
            if blend == "LIGHTEN":
                return a + fac * (np.maximum(a, b) - a)
            if blend == "DIVIDE":
                return np.where(b != 0.0, a + fac * (a / np.where(b != 0.0, b, 1.0) - a), a)
            if blend == "OVERLAY":
                low = a * (1.0 - fac + 2.0 * fac * b)
                high = 1.0 - (1.0 - fac + 2.0 * fac * (1.0 - b)) * (1.0 - a)
                return np.where(a < 0.5, low, high)
            if blend in ("HUE", "SATURATION", "VALUE", "COLOR"):
                return a + fac * (_hsv_blend(blend, a, b) - a)
        raise Unsupported("Mix " + blend)

    def _node_mix(self, node, socket):
        np = _np()
        kind = node.data_type
        if kind not in ("FLOAT", "RGBA") or getattr(node, "factor_mode", "UNIFORM") != "UNIFORM":
            raise Unsupported("Mix of " + kind)
        fac = self.socket(_input(node, "Factor_Float"), "f")
        if getattr(node, "clamp_factor", True):
            fac = np.clip(fac, 0.0, 1.0)
        if kind == "FLOAT":
            side = _one_side(fac, "MIX")
            if side is not None:
                return Value("f", self.socket(_input(node, side + "_Float"), "f"))
            a = self.socket(_input(node, "A_Float"), "f")
            b = self.socket(_input(node, "B_Float"), "f")
            return Value("f", a + fac * (b - a))
        side = _one_side(fac, node.blend_type)
        if side is not None:
            out = self.socket(_input(node, side + "_Color"), "c")
        else:
            a = self.socket(_input(node, "A_Color"), "c")
            b = self.socket(_input(node, "B_Color"), "c")
            out = self._blend(node.blend_type, fac, a, b)
        if getattr(node, "clamp_result", False):
            out = np.clip(out, 0.0, 1.0)
        return Value("c", out)

    def _node_mix_rgb(self, node, socket):
        np = _np()
        fac = np.clip(self.socket(_input(node, "Fac"), "f"), 0.0, 1.0)
        side = _one_side(fac, node.blend_type)
        if side is not None:
            out = self.socket(_input(node, "Color1" if side == "A" else "Color2"), "c")
        else:
            a = self.socket(_input(node, "Color1"), "c")
            b = self.socket(_input(node, "Color2"), "c")
            out = self._blend(node.blend_type, fac, a, b)
        if getattr(node, "use_clamp", False):
            out = np.clip(out, 0.0, 1.0)
        return Value("c", out)

    def _node_invert(self, node, socket):
        np = _np()
        fac = self.socket(_input(node, "Fac"), "f")
        colour = self.socket(_input(node, "Color"), "c")
        fac = fac[..., None] if np.ndim(fac) == 2 else fac
        return Value("c", colour + fac * ((1.0 - colour) - colour))

    def _node_gamma(self, node, socket):
        np = _np()
        colour = self.socket(_input(node, "Color"), "c")
        gamma = self.socket(_input(node, "Gamma"), "f")
        gamma = gamma[..., None] if np.ndim(gamma) == 2 else gamma
        return Value("c", np.where(colour > 0.0, np.power(np.maximum(colour, 0.0), gamma), colour))

    def _node_brightcontrast(self, node, socket):
        np = _np()
        colour = self.socket(_input(node, "Color"), "c")
        bright = self.socket(_input(node, "Bright"), "f")
        contrast = self.socket(_input(node, "Contrast"), "f")
        bright = bright[..., None] if np.ndim(bright) == 2 else bright
        contrast = contrast[..., None] if np.ndim(contrast) == 2 else contrast
        return Value("c", np.maximum((1.0 + contrast) * colour + bright - contrast * 0.5, 0.0))

    def _node_blackbody(self, node, socket):
        try:
            return Value("c", blackbody(self.socket(_input(node, "Temperature"), "f")))
        except (RuntimeError, AttributeError) as exc:  # no light could be made just now
            raise Unsupported(str(exc))

    def _node_rgbtobw(self, node, socket):
        return Value("f", self.socket(_input(node, "Color"), "f"))

    def _node_separate_color(self, node, socket):
        if getattr(node, "mode", "RGB") != "RGB":
            raise Unsupported("Separate Color in " + node.mode)
        colour = self.socket(_input(node, "Color"), "c")
        index = {"Red": 0, "Green": 1, "Blue": 2}[socket.name]
        return Value("f", colour[..., index])

    def _node_seprgb(self, node, socket):
        colour = self.socket(_input(node, "Image"), "c")
        index = {"R": 0, "G": 1, "B": 2}[socket.name]
        return Value("f", colour[..., index])

    def _combine(self, values):
        np = _np()
        shape = np.broadcast_shapes(*(np.shape(v) for v in values))
        return Value("c", np.stack([np.broadcast_to(v, shape) for v in values], axis=-1).astype(np.float32))

    def _node_combine_color(self, node, socket):
        if getattr(node, "mode", "RGB") != "RGB":
            raise Unsupported("Combine Color in " + node.mode)
        return self._combine([self.socket(_input(node, name), "f") for name in ("Red", "Green", "Blue")])

    def _node_combrgb(self, node, socket):
        return self._combine([self.socket(_input(node, name), "f") for name in ("R", "G", "B")])

    def _node_clamp(self, node, socket):
        np = _np()
        value = self.socket(_input(node, "Value"), "f")
        low = self.socket(_input(node, "Min"), "f")
        high = self.socket(_input(node, "Max"), "f")
        if getattr(node, "clamp_type", "MINMAX") == "RANGE":
            low, high = np.minimum(low, high), np.maximum(low, high)
        return Value("f", np.minimum(np.maximum(value, low), high))

    def _node_map_range(self, node, socket):
        np = _np()
        if node.data_type != "FLOAT" or node.interpolation_type != "LINEAR":
            raise Unsupported("Map Range " + node.interpolation_type)
        floats = [s for s in node.inputs if getattr(s, "enabled", True) and s.type == "VALUE"]
        by_name = {s.name: s for s in floats}
        value = self.socket(by_name["Value"], "f")
        from_min = self.socket(by_name["From Min"], "f")
        from_max = self.socket(by_name["From Max"], "f")
        to_min = self.socket(by_name["To Min"], "f")
        to_max = self.socket(by_name["To Max"], "f")
        span = from_max - from_min
        with np.errstate(all="ignore"):
            factor = np.where(span != 0.0, (value - from_min) / np.where(span != 0.0, span, 1.0), 0.0)
        out = to_min + factor * (to_max - to_min)
        if node.clamp:
            out = np.clip(out, np.minimum(to_min, to_max), np.maximum(to_min, to_max))
        return Value("f", out.astype(np.float32))


def _write(pixels, name, colour):
    """A PNG of (h, w, 3) linear colour or (h, w) data, bottom row first; (path, stamp)."""
    np = _np()
    rgba = np.ones(pixels.shape[:2] + (4,), dtype=np.float32)
    if colour:
        rgba[..., :3] = _linear_to_srgb(pixels)
    else:
        rgba[..., :3] = np.clip(pixels, 0.0, 1.0)[..., None]
    data = link_material.png_bytes((rgba[::-1] * 255.0 + 0.5).astype(np.uint8))
    stamp = hashlib.sha1(data).hexdigest()[:16]
    path = os.path.join(link_material.packed_folder(), "flat_{0}.png".format(
        hashlib.sha1(name.encode("utf-8")).hexdigest()[:12]))
    try:
        with open(path, "rb") as handle:
            unchanged = handle.read() == data
    except OSError:
        unchanged = False
    if not unchanged:
        with open(path, "wb") as handle:
            handle.write(data)
    return path, stamp


# Node settings that change what a node computes.
_SETTINGS = ("operation", "blend_type", "data_type", "use_clamp", "clamp_factor", "clamp_result",
             "factor_mode", "interpolation_type", "clamp", "clamp_type", "mode", "mute", "projection",
             "interpolation", "extension")


def signature(sockets):
    """A key for everything behind these sockets, read without touching any pixels: a driven
    material is described every frame, and only a real change should work it out again."""
    parts = []
    pending = [socket for socket in sockets if socket is not None]
    seen = set()
    while pending:
        socket = pending.pop()
        if not socket.is_linked:
            if hasattr(socket, "default_value"):
                parts.append(repr(_plain(socket.default_value)))
            continue
        for link in socket.links:
            node = link.from_node
            parts.append("{0}>{1}".format(node.name, link.from_socket.identifier))
            if node.name in seen:
                continue
            seen.add(node.name)
            parts.append(node.type)
            for attribute in _SETTINGS:
                value = getattr(node, attribute, None)
                if value is not None:
                    parts.append("{0}={1}".format(attribute, value))
            if node.type == "VALTORGB":
                parts.append(repr(link_nodes.ramp_key(node)))
            elif node.type == "CURVE_RGB":
                parts.append(repr(link_nodes.curves_key(node)))
            elif node.type == "TEX_IMAGE":
                image = getattr(node, "image", None)
                found = link_material.texture(node) or {}
                parts.append("{0}:{1}:{2}".format(getattr(image, "name", ""), found.get("stamp", ""),
                                                  link_material._EPOCH[0]))
            elif node.type in ("VALUE", "RGB"):
                parts.append(repr(_plain(node.outputs[0].default_value)))
            pending.extend(node.inputs)
    return hashlib.sha1("|".join(parts).encode("utf-8")).hexdigest()


def constant(socket):
    """What a linked input works out to when nothing behind it reads an image or coordinates:
    a float, or an RGB tuple. None when it cannot be worked out here."""
    if socket is None or not socket.is_linked:
        return None
    key = signature([socket])
    if key in _CONSTANTS:
        return _CONSTANTS[key]
    np = _np()
    chain = Chain()
    colour = socket.type in ("RGBA", "VECTOR")
    found = None
    try:
        value = np.asarray(chain.socket(socket, "c" if colour else "f"), dtype=np.float32)
        if chain.pixels is None and value.ndim == (1 if colour else 0):
            found = tuple(float(v) for v in value[:3]) if colour else float(value)
    except Unsupported:
        found = None
    except Exception:  # noqa: BLE001 - a node set up in a way not foreseen
        found = None
    _CONSTANTS[key] = found
    return found


def work_out(shader, input_name, strength_name=None, max_side=MAX_SIDE):
    """(pixels, strength) for one input worked out on its image, or None.

    `pixels` are (h, w, 3) scene-linear colour or (h, w) data, bottom row first. `strength` is
    the typed-in strength; one driven by nodes too is multiplied into the pixels (and is then 1).
    """
    np = _np()
    socket = shader.inputs.get(input_name)
    if socket is None or not socket.is_linked:
        return None
    chain = Chain(max_side)
    colour = socket.type == "RGBA"
    try:
        values = chain.socket(socket, "c" if colour else "f")
        strength = 1.0
        found = shader.inputs.get(strength_name) if strength_name else None
        if found is not None and found.is_linked:
            amount = np.asarray(chain.socket(found, "f"), dtype=np.float32)
            values = values * (amount[..., None] if amount.ndim == 2 else amount)
        elif found is not None:
            strength = float(found.default_value)
    except Unsupported:
        return None
    except Exception:  # noqa: BLE001 - a node set up in a way not foreseen: left to the graph
        return None
    if chain.pixels is None or np.ndim(values) < (3 if colour else 2):
        return None  # no image in the chain: the graph's own job
    return np.asarray(values, dtype=np.float32), strength


def _field(material, shader, input_name, channel, strength_name):
    """The texture field for one input, from the cache when nothing behind it changed."""
    emission = channel == "EmissiveColor"
    # By the material's own key: a linked material can share its name with a local one.
    name = "{0}/{1}".format(link_material.material_key(material), input_name)
    sockets = [shader.inputs.get(input_name)]
    if strength_name:
        sockets.append(shader.inputs.get(strength_name))
    key = name + "|" + signature(sockets)
    if key in _CACHE:
        field = _CACHE[key]
        if field is None or os.path.isfile(field["path"]):
            return field
    known, field = _remembered(key)
    if known:
        _CACHE[key] = field
        return field
    found = work_out(shader, input_name, strength_name)
    if found is None:
        _CACHE[key] = None  # not worked out: not tried again until something changes
        _remember(name, key, None)
        return None
    pixels, strength = found
    colour = pixels.ndim == 3
    if emission:
        # A PNG holds 0-1: anything brighter goes into the strength.
        peak = float(pixels.max()) if pixels.size else 0.0
        if peak > 1.0:
            pixels = pixels / peak
            strength *= peak
    path, stamp = _write(pixels, name, colour)
    # The file is the same for every version of this input (so Unreal re-imports into the same
    # texture); entries for older versions would now name the wrong picture.
    for stale in [k for k in _CACHE if k.startswith(name + "|")]:
        del _CACHE[stale]
    field = {"path": path, "stamp": stamp, "nearest": False}
    if colour:
        field["colorspace"] = "sRGB"
    else:
        field["linear"] = True
        field["channel"] = "r"
    if emission:
        field["strength"] = link_material._round(strength)
    _CACHE[key] = field
    _remember(name, key, field)
    return field


def apply(spec, material, shader):
    """Replace the graph's channels with maps worked out on their image. Returns those done."""
    graph = spec.get("graph")
    channels = graph.get("out") if isinstance(graph, dict) else None
    inputs = INPUTS.get(getattr(shader, "type", ""))
    if not channels or not inputs:
        return []
    done = []
    for input_name, channel in inputs:
        if channel not in channels:
            continue
        strength_name = STRENGTH.get(shader.type) if channel == "EmissiveColor" else None
        field = _field(material, shader, input_name, channel, strength_name)
        if field is None:
            continue
        field = dict(field)
        if channel == "BaseColor":
            spec["texture"] = field
            spec["textured"] = True
        elif channel == "EmissiveColor":
            spec.setdefault("maps", {})["emission"] = field
        else:
            spec.setdefault("maps", {})[channel.lower()] = field
        del channels[channel]
        done.append(channel)
    if done:
        spec["graph_flattened"] = sorted(done)
        if not channels:
            # Nothing left for a graph to do.
            for key in ("graph", "graph_key", "graph_values", "graph_textures", "graph_approximate",
                        "emission_strength"):
                spec.pop(key, None)
    return done
