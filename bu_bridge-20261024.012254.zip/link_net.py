# SPDX-License-Identifier: GPL-3.0-or-later
"""The Blender end of the real-time link's socket. Standard library only — no `bpy`.

Two threads own the socket so Blender's main thread never blocks on the network: one drains a
send queue, one reads replies. Neither touches `bpy`; the main thread hands them finished bytes
and collects decoded messages with `poll()`.

**The send queue coalesces by key.** A mesh being sculpted changes faster than it can be sent,
and a queue that kept every version would fall further behind with each stroke until Unreal was
showing the past. So a message queued under a key that is already waiting *replaces* it: only
the newest state of each object is ever in flight, and a slow link drops frames instead of
accumulating lag.
"""

import collections
import socket
import threading

try:
    from . import link_wire
except ImportError:  # loaded by path in the plain-CPython tests
    import link_wire


class Client(object):
    def __init__(self, host="127.0.0.1", port=link_wire.DEFAULT_PORT):
        self.host = host
        self.port = port
        self.error = ""
        self._socket = None
        self._alive = False
        self._lock = threading.Condition()
        self._outgoing = collections.OrderedDict()
        self._outgoing_bytes = 0  # what `_outgoing` holds, kept as it changes
        self._incoming = collections.deque()
        self._threads = []
        self.bytes_sent = 0
        self.messages_sent = 0
        self.messages_replaced = 0

    # -- lifecycle -------------------------------------------------------------

    def connect(self, timeout=1.0):
        """Open the connection. Returns True, or False with `self.error` set."""
        try:
            sock = socket.create_connection((self.host, self.port), timeout=timeout)
        except OSError as exc:
            self.error = "Could not connect to {0}:{1} — {2}".format(self.host, self.port, exc)
            return False
        sock.settimeout(None)
        try:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass

        self._socket = sock
        self._alive = True
        self.error = ""
        self._threads = [
            threading.Thread(target=self._write_loop, name="bu-link-send", daemon=True),
            threading.Thread(target=self._read_loop, name="bu-link-recv", daemon=True),
        ]
        for thread in self._threads:
            thread.start()
        return True

    @property
    def alive(self):
        return self._alive

    def close(self):
        with self._lock:
            self._alive = False
            self._outgoing.clear()
            self._outgoing_bytes = 0
            self._lock.notify_all()
        sock, self._socket = self._socket, None
        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass

    def _fail(self, message):
        with self._lock:
            if self._alive:
                self.error = message
            self._alive = False
            self._lock.notify_all()

    # -- sending ---------------------------------------------------------------

    def send(self, key, header, blob=b""):
        """Queue a message. One already waiting under the same `key` is replaced."""
        data = link_wire.pack(header, blob)
        with self._lock:
            if not self._alive:
                return False
            older = self._outgoing.get(key)
            if older is not None:
                # Replace in place: the object keeps its turn in the queue, so one that changes
                # every tick cannot be starved by being sent to the back each time.
                self.messages_replaced += 1
                self._outgoing_bytes -= len(older)
            self._outgoing[key] = data
            self._outgoing_bytes += len(data)
            self._lock.notify()
        return True

    def drop(self, key):
        """Forget a queued message that no longer applies. True if one was waiting."""
        with self._lock:
            older = self._outgoing.pop(key, None)
            if older is None:
                return False
            self._outgoing_bytes -= len(older)
            return True

    def pending_bytes(self):
        with self._lock:
            return self._outgoing_bytes

    def pending_keys(self):
        with self._lock:
            return list(self._outgoing)

    def _write_loop(self):
        while True:
            with self._lock:
                while self._alive and not self._outgoing:
                    self._lock.wait()
                if not self._alive:
                    return
                _key, data = self._outgoing.popitem(last=False)
                self._outgoing_bytes -= len(data)
            sock = self._socket
            if sock is None:
                return
            try:
                sock.sendall(data)
            except OSError as exc:
                self._fail("Connection to Unreal lost while sending: {0}".format(exc))
                return
            self.bytes_sent += len(data)
            self.messages_sent += 1

    # -- receiving -------------------------------------------------------------

    def poll(self):
        """Every message received since the last call, as `(header, blob)` pairs."""
        messages = []
        while True:
            try:
                messages.append(self._incoming.popleft())
            except IndexError:
                return messages

    def _read_loop(self):
        decoder = link_wire.Decoder()
        while self._alive:
            sock = self._socket
            if sock is None:
                return
            try:
                data = sock.recv(1 << 16)
            except OSError as exc:
                self._fail("Connection to Unreal lost: {0}".format(exc))
                return
            if not data:
                self._fail("Unreal closed the link.")
                return
            try:
                for message in decoder.feed(data):
                    self._incoming.append(message)
            except link_wire.WireError as exc:
                self._fail("Unreal sent something unreadable: {0}".format(exc))
                return
