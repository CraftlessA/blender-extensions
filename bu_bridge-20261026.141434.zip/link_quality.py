# SPDX-License-Identifier: GPL-3.0-or-later
"""Quality presets, Unreal's scalability groups and the user's own console variables, for the
Render properties (`link_lighting`). Pure: no bpy, so the rules can be tested on their own.

A preset is a set of values for settings that also have their own controls. The preset a scene
is at is worked out from those values (`matching`), never stored: change one of them and the
preset reads Custom, so where a value came from is always visible.
"""

import re

PRECISION = 4

# Render > Viewport Quality: the live view. Balanced is BU's defaults, so a scene made before
# presets reads Balanced and nothing about it changes.
VIEWPORT_PRESETS = (
    ("FAST", "Fast", "Fewer pixels, Lumen's cache for what rays hit, and High shadows, global "
                     "illumination and reflections: for heavy scenes and slower cards"),
    ("BALANCED", "Balanced", "BU's defaults: TSR at 67%, hit lighting, the project's quality"),
    ("BEST", "Best", "Every pixel rendered, and twice the rays for bounce light and "
                     "reflections: the cleanest live picture, for a fast card"),
)
# The `sg_*` properties a preset sets; any other stays as the user left it.
_FAST_GROUPS = ("sg_shadow", "sg_global_illumination", "sg_reflection")
VIEWPORT_VALUES = {
    "FAST": {"tsr_percentage": 50.0, "dlss_mode": "PERFORMANCE",
             "ray_lighting": "SURFACE_CACHE", "final_gather_quality": 1.0,
             "reflection_quality": 1.0, "sg_shadow": "2", "sg_global_illumination": "2",
             "sg_reflection": "2"},
    "BALANCED": {"tsr_percentage": 67.0, "dlss_mode": "DLAA", "ray_lighting": "HIT_LIGHTING",
                 "final_gather_quality": 1.0, "reflection_quality": 1.0,
                 "sg_shadow": "PROJECT", "sg_global_illumination": "PROJECT",
                 "sg_reflection": "PROJECT"},
    "BEST": {"tsr_percentage": 100.0, "dlss_mode": "DLAA", "ray_lighting": "HIT_LIGHTING",
             "final_gather_quality": 2.0, "reflection_quality": 2.0, "sg_shadow": "PROJECT",
             "sg_global_illumination": "PROJECT", "sg_reflection": "PROJECT"},
}
# F12 Render > Quality. Final is BU's defaults.
STILL_PRESETS = (
    ("DRAFT", "Draft", "A quick look: 4 warm-up frames, one picture, the live view's quality"),
    ("FINAL", "Final", "BU's defaults: 12 warm-up frames, 12 anti-aliasing samples, Cinematic "
                       "quality, Cinematic fog"),
    ("BEST", "Best", "32 warm-up frames and 32 samples, Cinematic quality, and fog twice as "
                     "deep: the cleanest, about three times as long as Final"),
)
STILL_VALUES = {
    "DRAFT": {"still_warmup": 4, "still_aa_samples": 1, "still_cinematic": False,
              "still_volume_steps": 128, "still_volume_resolution": "8"},
    "FINAL": {"still_warmup": 12, "still_aa_samples": 12, "still_cinematic": True,
              "still_volume_steps": 128, "still_volume_resolution": "4"},
    "BEST": {"still_warmup": 32, "still_aa_samples": 32, "still_cinematic": True,
             "still_volume_steps": 256, "still_volume_resolution": "4"},
}
CUSTOM = ("CUSTOM", "Custom", "Set by hand below: no preset matches")

# Unreal's scalability groups (Settings > Engine Scalability in its editor), for the live view.
# (property, console variable, label). F12's Cinematic Quality sets them all to Cinematic while
# it renders, then they come back.
SCALABILITY_GROUPS = (
    ("sg_view_distance", "sg.ViewDistanceQuality", "View Distance"),
    ("sg_anti_aliasing", "sg.AntiAliasingQuality", "Anti-Aliasing"),
    ("sg_shadow", "sg.ShadowQuality", "Shadows"),
    ("sg_global_illumination", "sg.GlobalIlluminationQuality", "Global Illumination"),
    ("sg_reflection", "sg.ReflectionQuality", "Reflections"),
    ("sg_post_process", "sg.PostProcessQuality", "Post Processing"),
    ("sg_texture", "sg.TextureQuality", "Textures"),
    ("sg_effects", "sg.EffectsQuality", "Effects"),
    ("sg_foliage", "sg.FoliageQuality", "Foliage"),
    ("sg_shading", "sg.ShadingQuality", "Shading"),
    ("sg_landscape", "sg.LandscapeQuality", "Landscape"),
)
SCALABILITY_LEVELS = (
    ("PROJECT", "Project", "What BU's Unreal has (Epic unless its settings say otherwise)"),
    ("0", "Low", ""), ("1", "Medium", ""), ("2", "High", ""), ("3", "Epic", ""),
    ("4", "Cinematic", "The highest: slower, more graphics memory"),
)
MEGALIGHTS_CHOICES = (
    ("PROJECT", "Project Default", "Whatever the Unreal project uses (off in BU's)"),
    ("ON", "On", "Unreal's MegaLights: many lights, each with ray-traced soft shadows, for a "
                 "steady cost. Lights are sampled, so their shadows can be a little noisy. "
                 "Needs a ray-tracing GPU"),
    ("OFF", "Off", "Every light lit and shadowed one by one, as without MegaLights"),
)
LIGHT_MEGALIGHTS_SHADOWS = (
    ("DEFAULT", "Default", "MegaLights' own choice (ray traced)"),
    ("RAY_TRACING", "Ray Traced", "Correct soft shadows from the light's size at a fixed cost"),
    ("VIRTUAL_SHADOW_MAP", "Virtual Shadow Map",
     "Shadows drawn from Nanite's full detail; costs more per light"),
)
CVAR_WHEN = (
    ("ALWAYS", "Always", "While Unreal renders the viewport and F12"),
    ("F12", "F12 Only", "Only while F12 renders; the viewport keeps Unreal's own value"),
)

# A console variable as Unreal names them (r.Lumen.Foo, sg.ShadowQuality, a.URO.Enable): at
# least one dot, so commands such as `quit` or `exit` cannot be typed in as one. Values are a
# single word: a number or a name, nothing that could start a second command.
_CVAR_NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$")
_CVAR_VALUE = re.compile(r"^[-+A-Za-z0-9_.]+$")


def valid_cvar(name, value):
    """Whether a console variable and value may be sent to Unreal. Pure."""
    name = str(name or "").strip()
    value = str(value or "").strip()
    return bool(_CVAR_NAME.match(name) and _CVAR_VALUE.match(value)) and len(name) < 128 \
        and len(value) < 64


def cvar_problem(name, value):
    """Why a console variable row is not sent, or "" when it is. Pure."""
    name = str(name or "").strip()
    value = str(value or "").strip()
    if not name:
        return "Type a console variable, such as r.Lumen.Reflections.MaxRoughnessToTrace"
    if not _CVAR_NAME.match(name):
        return "Not a console variable name (they look like r.Something.Name)"
    if not value:
        return "Give it a value"
    if not _CVAR_VALUE.match(value):
        return "A value is one number or word, without spaces"
    return ""


def describe_cvars(rows):
    """[[name, value, when]] for the enabled, valid rows: the `render` message's `cvars`.
    `rows`: (name, value, when, enabled) each; `when` ALWAYS or F12. Later rows win over
    earlier ones with the same name and moment. Pure."""
    found = {}
    for name, value, when, enabled in rows:
        if not enabled or not valid_cvar(name, value):
            continue
        when = "F12" if when == "F12" else "ALWAYS"
        found[(str(name).strip(), when)] = str(value).strip()
    return [[name, value, when] for (name, when), value in found.items()]


def describe_scalability(values):
    """{console variable: level} for the groups not left to the project. `values`: {property:
    "PROJECT" or "0".."4"}. Pure."""
    found = {}
    for prop, cvar, _label in SCALABILITY_GROUPS:
        level = str(values.get(prop, "PROJECT"))
        if level in ("0", "1", "2", "3", "4"):
            found[cvar] = int(level)
    return found


def _same(a, b):
    if isinstance(a, float) or isinstance(b, float):
        try:
            return abs(float(a) - float(b)) < 1e-4
        except (TypeError, ValueError):
            return False
    return a == b


def matching(values, table):
    """The preset in `table` whose every value `values` has, or "CUSTOM". `values`: {property:
    value}. Pure."""
    for key, wanted in table.items():
        if all(_same(values.get(prop), value) for prop, value in wanted.items()):
            return key
    return "CUSTOM"
