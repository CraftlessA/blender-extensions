# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender's instances in Unreal: one Instanced Static Mesh component per instancer and mesh.

Blender sends each distinct instanced mesh once as a hidden "prototype" (an ordinary mesh
message marked `proto`), then each instancer's copies as a list of matrices (`instances`). The
prototype is turned into a static mesh here, and every list of copies drawn with one
InstancedStaticMeshComponent: 18,599 pipe sections are one draw, not 18,599 actors.

Python cannot call `AActor::AddComponentByClass`; the editor's subobject subsystem, which is
what the Details panel's "+ Add" uses, adds the component instead.
"""

import array

from . import bu_link_editor, bu_link_material, bu_link_static

FLOATS_PER_MATRIX = 16


def matrices(blob, count):
    """The float32 matrices in an `instances` message, as lists of 16. Pure."""
    values = array.array("f")
    values.frombytes(bytes(blob)[:count * FLOATS_PER_MATRIX * 4])
    return [values[i:i + FLOATS_PER_MATRIX]
            for i in range(0, len(values) - FLOATS_PER_MATRIX + 1, FLOATS_PER_MATRIX)]


def transforms(blob, count):
    import unreal

    found = []
    for m in matrices(blob, count):
        planes = [unreal.Plane(*m[i:i + 4]) for i in range(0, 16, 4)]
        found.append(unreal.Matrix(*planes).transform())
    return found


def component(actor):
    """The actor's InstancedStaticMeshComponent, or None."""
    import unreal

    try:
        return actor.get_component_by_class(unreal.InstancedStaticMeshComponent)
    except Exception:  # noqa: BLE001 - a destroyed actor
        return None


def add_component(actor):
    """Give a plain actor an InstancedStaticMeshComponent, with no undo step. None on failure."""
    import unreal

    def work():
        subsystem = unreal.get_engine_subsystem(unreal.SubobjectDataSubsystem)
        handles = subsystem.k2_gather_subobject_data_for_instance(actor)
        if not handles:
            return None
        params = unreal.AddNewSubobjectParams(
            parent_handle=handles[0], new_class=unreal.InstancedStaticMeshComponent,
            blueprint_context=None)
        handle, _why = subsystem.add_new_subobject(params)
        library = unreal.SubobjectDataBlueprintFunctionLibrary
        return library.get_object(library.get_data(handle))

    try:
        found = bu_link_editor.untracked(work)
    except Exception:  # noqa: BLE001
        found = None
    if found is None:
        found = component(actor)
    if found is not None:
        bu_link_editor.render_only(found)
    return found


def build_proto(dynamic, digest):
    """A static mesh from a prototype's DynamicMeshComponent, or None (no triangles)."""
    source = dynamic.get_dynamic_mesh()
    if int(source.get_triangle_count()) == 0:
        return None
    count = max(1, int(dynamic.get_num_materials()))
    mesh = bu_link_static.cached_mesh(digest) if digest else None
    if mesh is not None:
        return mesh
    # The mesh's own slots get the saved master, never the link's live instances (a saved asset
    # cannot refer to them); the component overrides every slot.
    master = bu_link_material.ensure("plain")
    slots = [master] * count if master is not None else [None] * count
    if digest:
        return bu_link_static.build_cached(digest, source, slots)
    return bu_link_static.build(source, slots)


def dress(found, mesh, materials, xforms):
    """Show `xforms` copies of `mesh` wearing `materials`, slot by slot."""
    if found.get_editor_property("static_mesh") != mesh:
        found.set_static_mesh(mesh)
    wear(found, materials)
    found.clear_instances()
    if xforms:
        found.add_instances(xforms, False, True)


def wear(found, materials):
    for index, material in enumerate(materials):
        if material is not None and found.get_material(index) != material:
            found.set_material(index, material)
