# SPDX-License-Identifier: GPL-3.0-or-later
"""Make sure a camera bound to a timeline marker actually exports.

Binding a camera to a marker (Ctrl+Shift+C) is the artist saying "this camera is a shot". But
render visibility is a separate control, and it is very easy to have a whole `Camera` collection
switched off in renders -- cameras are not usually thought of as renderable, so the camera icon
gets toggled without a second thought.

When that happens the cameras are simply absent from the USD, and every cut bound to them fails on
the Unreal side. Measured on a real 182 MB export: three markers bound `Camera`, `Camera.001` and
`Camera.002`, all three sat in one render-disabled collection, and the sequence arrived with one
usable cut out of three -- while the export itself reported success.

Two intents conflict there, and the marker is the more specific one: a collection toggle is a
blunt "not in renders", a marker binding names one camera for one shot. So BU relinks a bound
camera into the scene root for the duration of the export and clears its own `hide_render`,
then puts it back exactly as it was.

Relinking rather than un-hiding the collection is deliberate. Clearing `hide_render` on the
collection would drag every *other* object inside it into the export too, which is precisely the
kind of surprise this module exists to prevent.
"""

import contextlib


def bound_cameras(scene):
    """Camera objects that timeline markers bind, in marker order."""
    seen = {}
    for marker in sorted(scene.timeline_markers, key=lambda m: m.frame):
        camera = marker.camera
        if camera is not None and camera.name not in seen:
            seen[camera.name] = camera
    return list(seen.values())


def blocked_bound_cameras(context, evaluation_mode="RENDER", selected_only=False):
    """Bound cameras that would not survive the export, with the reason."""
    from . import capture

    blocked = []
    for camera in bound_cameras(context.scene):
        reasons = capture.camera_export_blockers(
            camera, context, evaluation_mode, selected_only
        )
        if reasons:
            blocked.append((camera, reasons[0]))
    return blocked


@contextlib.contextmanager
def unblocked(context, enabled=True, evaluation_mode="RENDER", selected_only=False):
    """Force marker-bound cameras to be exportable, then restore the scene exactly.

    Yields a list of (camera_name, reason_it_was_blocked).
    """
    if not enabled:
        yield []
        return

    scene = context.scene
    blocked = blocked_bound_cameras(context, evaluation_mode, selected_only)
    if not blocked:
        yield []
        return

    from . import visibility

    restore = []
    freed = []
    # Camera visibility can be driven too (a rig switching between shot cameras), and a driver
    # puts its own value back over ours before the exporter reads it. See visibility.py.
    with visibility.frozen([c for c, _ in blocked]):
        yield from _free(scene, blocked, restore, freed)


def _free(scene, blocked, restore, freed):
    """The relink-and-restore itself. Split out so `unblocked` can wrap it in a freeze."""
    try:
        for camera, reason in blocked:
            collections = list(camera.users_collection)
            restore.append((camera, collections, camera.hide_render, camera.hide_viewport))

            for collection in collections:
                collection.objects.unlink(camera)
            scene.collection.objects.link(camera)
            camera.hide_render = False
            camera.hide_viewport = False
            freed.append((camera.name, reason))

        yield freed
    finally:
        for camera, collections, was_hidden, was_hidden_viewport in restore:
            try:
                for collection in list(camera.users_collection):
                    collection.objects.unlink(camera)
                for collection in collections:
                    collection.objects.link(camera)
                camera.hide_render = was_hidden
                camera.hide_viewport = was_hidden_viewport
            except Exception:  # noqa: BLE001 - never let restore failure mask the export result
                pass
