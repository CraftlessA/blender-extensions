# SPDX-License-Identifier: GPL-3.0-or-later
"""USDHook that writes texture filtering into the USD file itself.

The sidecar manifest is the channel Unreal actually reads, because UE hands an imported
texture the *material's* prim path rather than the shader prim's, so a texture asset
cannot be traced back to its own UsdUVTexture. But writing the data into the USD too
means the stage is self-describing: it survives being handed to someone else, shows up in
UE's USD Stage editor, and is readable via UE's metadata collection if we ever want it.

`bpy.types.USDHook` methods are duck-typed -- they are looked up by name at call time and
are not RNA-declared, so nothing here can be introspected or type-checked. Spelling
matters. Verified firing on Blender 5.2.0 LTS.
"""

import os

import bpy

from . import capture

# Hooks are global: once registered they fire for *every* USD export, including ones the
# user runs by hand from File > Export. Gate on this so BU only touches its own exports.
_active = False


def set_active(state):
    global _active
    _active = bool(state)


def _shader_id(prim):
    attr = prim.GetAttribute("info:id")
    return attr.Get() if attr else None


def _file_basename(prim):
    attr = prim.GetAttribute("inputs:file")
    if not attr:
        return None
    value = attr.Get()
    if value is None:
        return None
    # Sdf.AssetPath -> prefer the authored path; resolvedPath is empty for relative refs.
    path = getattr(value, "path", None) or str(value)
    return os.path.basename(path).lower() if path else None


class BU_USDHook(bpy.types.USDHook):
    bl_idname = "bu_bridge_usd_hook"
    bl_label = "BU — embed Unreal texture settings"
    bl_description = "Writes texture filtering and wrap intent into exported USD shader prims"

    @staticmethod
    def on_material_export(export_context, bl_material, usd_material):
        if not _active:
            return False

        try:
            from pxr import Sdf
        except ImportError:
            return False

        # Map every image node in the material by the filenames it might export as.
        by_key = {}
        for node in capture._iter_image_nodes(getattr(bl_material, "node_tree", None)):
            for key in capture.texture_match_keys(node.image):
                by_key.setdefault(key, node)

        if not by_key:
            return False

        texture_prims = [
            child
            for child in usd_material.GetPrim().GetChildren()
            if child.GetTypeName() == "Shader" and _shader_id(child) == "UsdUVTexture"
        ]

        for prim in texture_prims:
            node = by_key.get(_file_basename(prim))

            # Single texture in both the material and the USD material -> unambiguous even
            # if Blender renamed the file on the way out.
            if node is None and len(texture_prims) == 1 and len(set(by_key.values())) == 1:
                node = next(iter(by_key.values()))
            if node is None:
                continue

            interpolation = node.interpolation
            ue_filter = capture.INTERPOLATION_TO_UE_FILTER.get(interpolation, "Default")

            prim.SetCustomDataByKey("blender:interpolation", interpolation)
            prim.SetCustomDataByKey("blender:extension", node.extension)
            prim.SetCustomDataByKey("unreal:textureFilter", ue_filter)

            # Also author real attributes, so the intent is visible in usdview and in
            # UE's USD Stage editor rather than buried in prim metadata.
            attr = prim.CreateAttribute(
                "userProperties:blender:interpolation", Sdf.ValueTypeNames.String, custom=True
            )
            attr.Set(interpolation)
            attr = prim.CreateAttribute(
                "userProperties:unreal:textureFilter", Sdf.ValueTypeNames.String, custom=True
            )
            attr.Set(ue_filter)

        return True


def register():
    bpy.utils.register_class(BU_USDHook)


def unregister():
    set_active(False)
    bpy.utils.unregister_class(BU_USDHook)
