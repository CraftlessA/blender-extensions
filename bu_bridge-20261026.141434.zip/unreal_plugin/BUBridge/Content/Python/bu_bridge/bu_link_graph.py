# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender node graphs, rebuilt as Unreal material expressions (see Blender's `link_nodes`).

One material is compiled per (surface, wiring): `M_BU_Graph_<Surface>_<key>_v<N>`, saved under
`/Game/BU/Materials/Graphs`. It is one of `bu_link_material`'s masters with some channels fed by
the translated graph instead of a value or a texture. Every number and colour in the graph is a
parameter (`p0`, `p1`, ...) and every image a texture parameter (`t0`, ...), set on a dynamic
instance — so a value edited in Blender is instant, and only rewiring compiles.

Expressions are connected by *position*: each one's input names are read from Unreal
(`get_material_expression_input_names`) rather than guessed, which is how the masters' only
failed connections so far were caught.

Conventions, matching the link's:
* Blender's UV is (u, 1 - v) of Unreal's — the mesh's UVs are flipped on the way over — so a UV
  coordinate entering the graph is flipped to Blender's, and flipped back where an image samples.
* An image the graph uses as a normal (`"normal"` in its options) is sampled as one, from a
  texture imported as a normal map (green flipped), so its output is a tangent-space normal.
* `uv` carries an `index`: which of the mesh's UV maps, the render one being 0.
* Blender's Object coordinates are metres with Y the other way: Unreal's local position times
  (0.01, -0.01, 0.01). Generated coordinates are that, normalised to the object's local bounds.
"""

import math

from . import bu_link_cache, bu_link_material

PACKAGE = bu_link_material.PACKAGE + "/Graphs"
LUMINANCE = bu_link_material.LUMINANCE
TWO_PI = 2.0 * math.pi
# Mix blends worked out through HSV (`_hsv_blend`).
HSV_BLENDS = ("HUE", "SATURATION", "VALUE", "COLOR")


# Bumped when the same graph builds differently, so materials compiled before are not reused.
# 3: Generated coordinates on a flat object (a plane) were NaN.
# 4: Hue/Saturation/Value's saturation is clamped as Blender's is (an over-saturated iris and suit).
# 5: Blender's own noise (Noise Texture, Wave distortion), more ops, Map Range's smooth modes.
EMITTER_VERSION = 5
# Shader Model 5 has 16 sampler slots, and the master's own maps take some. A graph sampling
# more images than this shares Unreal's wrap sampler between them instead: no limit, but the
# filtering is the project's texture group setting rather than each texture's own.
OWN_SAMPLERS = 8


# Surfaces whose graph materials build differently since, as `bu_link_material.SURFACE_VERSIONS`.
SURFACE_EMITTER_VERSIONS = {"subsurface": 8}


def material_name(surface, key):
    return "M_BU_Graph_{0}_{1}_v{2}{3}".format(
        surface.capitalize(), key, SURFACE_EMITTER_VERSIONS.get(surface, EMITTER_VERSION),
        bu_link_material.slab_suffix(surface))


def material_path(surface, key):
    name = material_name(surface, key)
    return "{0}/{1}.{1}".format(PACKAGE, name)


def parameter_kinds(graph):
    """{parameter name: "f" or "c"/"v"} for every parameter a graph uses. Pure."""
    found = {}

    def visit(ref):
        if isinstance(ref, dict) and "p" in ref:
            found[ref["p"]] = ref.get("t", "f")

    for node in (graph or {}).get("nodes") or ():
        for ref in (node.get("in") or {}).values():
            visit(ref)
    for ref in ((graph or {}).get("out") or {}).values():
        visit(ref)
    return found


def texture_names(graph):
    """The texture parameters a graph samples. Pure."""
    return sorted({node["opt"]["tex"] for node in (graph or {}).get("nodes") or ()
                   if node.get("op") in ("image", "ramp") and "tex" in (node.get("opt") or {})})


def normal_textures(graph):
    """The texture parameters a graph samples as normal maps. Pure."""
    return {node["opt"]["tex"] for node in (graph or {}).get("nodes") or ()
            if node.get("op") == "image" and (node.get("opt") or {}).get("normal")
            and "tex" in node["opt"]}


AXES = {"x": (1.0, 0.0, 0.0), "y": (0.0, 1.0, 0.0), "z": (0.0, 0.0, 1.0)}
VORONOI_FEATURES = {"F1": 0, "F2": 1, "SMOOTH_F1": 2, "DISTANCE_TO_EDGE": 3}
VORONOI_METRICS = {"EUCLIDEAN": 0, "MANHATTAN": 1, "CHEBYCHEV": 2, "MINKOWSKI": 3}

# Blender's 3D Voronoi, line for line from Cycles (`kernel/svm/voronoi.h`, `util/hash.h`): the
# same PCG hash of each integer cell, the same search and the same octaves, so a cell lands
# where Blender's does. BU_FEATURE, BU_METRIC, BU_NORMALIZE and BU_RGB are filled in per node (`voronoi_hlsl`).
# Returns (colour or position, distance). Unreal puts a Custom node's code inside a function;
# the struct is the usual way to give it functions of its own.
VORONOI_HLSL = """
struct BUVoronoi
{
    float Randomness; float Smoothness; float Exponent; float3 Position;
    int3 Pcg(int3 v)
    {
        v = v * 1664525 + 1013904223;
        v.x += v.y * v.z; v.y += v.z * v.x; v.z += v.x * v.y;
        v = v ^ (v >> 16);
        v.x += v.y * v.z; v.y += v.z * v.x; v.z += v.x * v.y;
        return v & 0x7FFFFFFF;
    }
    float3 Hash(int3 k) { return float3(Pcg(k)) * (1.0 / 2147483648.0); }
    float Dist(float3 a, float3 b)
    {
        float3 d = abs(a - b);
        if (BU_METRIC == 0) return length(a - b);
        if (BU_METRIC == 1) return d.x + d.y + d.z;
        if (BU_METRIC == 2) return max(d.x, max(d.y, d.z));
        return pow(dot(pow(d, Exponent), 1.0), 1.0 / Exponent);
    }
    float Bound(float3 a, float3 b)
    {
        float3 d = abs(a - b);
        if (BU_METRIC == 0) return dot(a - b, a - b);
        if (BU_METRIC == 1) return d.x + d.y + d.z;
        if (BU_METRIC == 2) return max(d.x, max(d.y, d.z));
        return dot(pow(d, Exponent), 1.0);
    }
    float4 Octave(float3 coord)  /* (colour, edgeDist); position in Position */
    {
        float3 cellF = floor(coord);
        float3 local = coord - cellF;
        int3 cell = int3(cellF);
        if (BU_FEATURE == 2 && Smoothness != 0.0)
        {
            float sd = 0.0; float3 sc = 0.0; float3 sp = 0.0; float h = -1.0;
            [loop] for (int k = -2; k <= 2; k++) [loop] for (int j = -2; j <= 2; j++)
            [loop] for (int i = -2; i <= 2; i++)
            {
                int3 o = int3(i, j, k);
                float3 p = float3(o) + Hash(cell + o) * Randomness;
                float d = Dist(p, local);
                h = h == -1.0 ? 1.0 : smoothstep(0.0, 1.0, 0.5 + 0.5 * (sd - d) / Smoothness);
                float c = Smoothness * h * (1.0 - h);
                sd = lerp(sd, d, h) - c;
                c /= 1.0 + 3.0 * Smoothness;
                sc = lerp(sc, Hash(cell + o), h) - c;
                sp = lerp(sp, p, h) - c;
            }
            Position = cellF + sp;
            return float4(sc, sd);
        }
        float d1 = 3.4e38; float d2 = 3.4e38;
        int3 o1 = 0; int3 o2 = 0; float3 p1 = 0.0; float3 p2 = 0.0;
        [loop] for (int k = -1; k <= 1; k++) [loop] for (int j = -1; j <= 1; j++)
        [loop] for (int i = -1; i <= 1; i++)
        {
            int3 o = int3(i, j, k);
            float3 p = float3(o) + Hash(cell + o) * Randomness;
            if (BU_FEATURE == 1)
            {
                float d = Dist(p, local);
                if (d < d1) { d2 = d1; d1 = d; o2 = o1; o1 = o; p2 = p1; p1 = p; }
                else if (d < d2) { d2 = d; o2 = o; p2 = p; }
            }
            else
            {
                float d = Bound(p, local);
                if (d < d1) { o1 = o; d1 = d; p1 = p; }
            }
        }
        if (BU_FEATURE == 1)
        {
            Position = p2 + cellF;
            return float4(Hash(cell + o2), d2);
        }
        Position = p1 + cellF;
        return float4(Hash(cell + o1), Dist(p1, local));
    }
    float Edge(float3 coord)
    {
        float3 cellF = floor(coord);
        float3 local = coord - cellF;
        int3 cell = int3(cellF);
        float3 closest = 0.0; float least = 3.4e38;
        [loop] for (int k = -1; k <= 1; k++) [loop] for (int j = -1; j <= 1; j++)
        [loop] for (int i = -1; i <= 1; i++)
        {
            int3 o = int3(i, j, k);
            float3 v = float3(o) + Hash(cell + o) * Randomness - local;
            float d = dot(v, v);
            if (d < least) { least = d; closest = v; }
        }
        least = 3.4e38;
        [loop] for (int k2 = -1; k2 <= 1; k2++) [loop] for (int j2 = -1; j2 <= 1; j2++)
        [loop] for (int i2 = -1; i2 <= 1; i2++)
        {
            int3 o = int3(i2, j2, k2);
            float3 v = float3(o) + Hash(cell + o) * Randomness - local;
            float3 across = v - closest;
            if (dot(across, across) > 0.0001)
                least = min(least, dot((closest + v) / 2.0, normalize(across)));
        }
        return least;
    }
};
BUVoronoi V;
V.Randomness = clamp(Randomness, 0.0, 1.0);
V.Smoothness = clamp(Smoothness / 2.0, 0.0, 0.5);
V.Exponent = Minkowski;
V.Position = 0.0;
float detail = clamp(Detail, 0.0, 15.0);
float rough = clamp(Roughness, 0.0, 1.0);
float3 coord = Coord * Scale;
bool zero = detail == 0.0 || rough == 0.0;
float amplitude = 1.0; float scale = 1.0;
if (BU_FEATURE == 3)
{
    float maxd = 0.5 + 0.5 * V.Randomness;
    float maxa = maxd;
    float edgeDist = 8.0;
    [loop] for (int n = 0; n <= 15; ++n)
    {
        if (n > ceil(detail)) break;
        float od = V.Edge(coord * scale);
        if (zero) { edgeDist = od; break; }
        if (n <= detail)
        {
            maxa = lerp(maxa, maxd / scale, amplitude);
            edgeDist = lerp(edgeDist, min(edgeDist, od / scale), amplitude);
            scale *= Lacunarity; amplitude *= rough;
        }
        else
        {
            float rest = detail - floor(detail);
            if (rest != 0.0)
            {
                float la = lerp(maxa, maxd / scale, amplitude);
                maxa = lerp(maxa, la, rest);
                float ld = lerp(edgeDist, min(edgeDist, od / scale), amplitude);
                edgeDist = lerp(edgeDist, min(edgeDist, ld), rest);
            }
        }
    }
    if (BU_NORMALIZE) edgeDist /= maxa;
    return float4(0.0, 0.0, 0.0, edgeDist);
}
float halfway = 0.5 + 0.5 * V.Randomness;
float maxd = V.Dist(float3(0.0, 0.0, 0.0), float3(halfway, halfway, halfway)) * (BU_FEATURE == 1 ? 2.0 : 1.0);
float maxa = 0.0;
float dist = 0.0; float3 colour = 0.0; float3 position = 0.0;
[loop] for (int n = 0; n <= 15; ++n)
{
    if (n > ceil(detail)) break;
    float4 o = V.Octave(coord * scale);
    float3 op = V.Position;
    if (zero) { maxa = 1.0; dist = o.w; colour = o.rgb; position = op; break; }
    if (n <= detail)
    {
        maxa += amplitude;
        dist += o.w * amplitude;
        colour += o.rgb * amplitude;
        position = lerp(position, op / scale, amplitude);
        scale *= Lacunarity; amplitude *= rough;
    }
    else
    {
        float rest = detail - floor(detail);
        if (rest != 0.0)
        {
            maxa = lerp(maxa, maxa + amplitude, rest);
            dist = lerp(dist, dist + o.w * amplitude, rest);
            colour = lerp(colour, colour + o.rgb * amplitude, rest);
            position = lerp(position, lerp(position, op / scale, amplitude), rest);
        }
    }
}
if (BU_NORMALIZE) { dist /= maxa * maxd; colour /= maxa; }
position = Scale != 0.0 ? position / Scale : 0.0;
return float4(BU_RGB == 1 ? position : colour, dist);
"""


def voronoi_hlsl(feature, metric, normalize, rgb):
    """The Custom node code for one Voronoi node's settings. Pure."""
    code = VORONOI_HLSL
    for name, value in (("BU_FEATURE", VORONOI_FEATURES.get(feature, 0)),
                        ("BU_METRIC", VORONOI_METRICS.get(metric, 0)),
                        ("BU_NORMALIZE", "true" if normalize else "false"),
                        ("BU_RGB", 1 if rgb == "position" else 0)):
        code = code.replace(name, str(value))
    return code


# Blender's Noise Texture, line for line from Cycles (`kernel/svm/noise.h`, `fractal_noise.h`,
# `noisetex.h`, `util/hash.h`): the same Jenkins hash of each lattice corner, the same gradients,
# octaves and noise types, so the pattern lands where Blender's does. Unreal's own noise had the
# same scale and nothing else (sq041's stars: wavy grid lines where Blender has straight ones).
# BU_DIMS (1-4), BU_TYPE (`NOISE_TYPES`), BU_NORMALIZE, BU_COLOR and the BU_OFF* offsets are
# filled in per node (`noise_hlsl`). Returns (colour, value); the colour only when BU_COLOR is 1.
NOISE_HLSL = """
struct BUNoise
{
    uint Rot(uint x, uint k) { return (x << k) | (x >> (32u - k)); }
    uint Final(uint a, uint b, uint c)
    {
        c ^= b; c -= Rot(b, 14u); a ^= c; a -= Rot(c, 11u); b ^= a; b -= Rot(a, 25u);
        c ^= b; c -= Rot(b, 16u); a ^= c; a -= Rot(c, 4u); b ^= a; b -= Rot(a, 14u);
        c ^= b; c -= Rot(b, 24u);
        return c;
    }
    uint Hash1(int x)
    {
        uint a = 0xdeadbeefu + 17u; uint b = a; uint c = a;
        a += asuint(x);
        return Final(a, b, c);
    }
    uint Hash2(int x, int y)
    {
        uint a = 0xdeadbeefu + 21u; uint b = a; uint c = a;
        b += asuint(y); a += asuint(x);
        return Final(a, b, c);
    }
    uint Hash3(int x, int y, int z)
    {
        uint a = 0xdeadbeefu + 25u; uint b = a; uint c = a;
        c += asuint(z); b += asuint(y); a += asuint(x);
        return Final(a, b, c);
    }
    uint Hash4(int x, int y, int z, int w)
    {
        uint a = 0xdeadbeefu + 29u; uint b = a; uint c = a;
        a += asuint(x); b += asuint(y); c += asuint(z);
        a -= c; a ^= Rot(c, 4u); c += b; b -= a; b ^= Rot(a, 6u); a += c;
        c -= b; c ^= Rot(b, 8u); b += a; a -= c; a ^= Rot(c, 16u); c += b;
        b -= a; b ^= Rot(a, 19u); a += c; c -= b; c ^= Rot(b, 4u); b += a;
        a += asuint(w);
        return Final(a, b, c);
    }
    float Fade(float t) { return t * t * t * (t * (t * 6.0 - 15.0) + 10.0); }
    float Neg(float v, uint c) { return c != 0u ? -v : v; }
    float G1(uint h, float x) { h &= 15u; return Neg(1.0 + float(h & 7u), h & 8u) * x; }
    float G2(uint h, float x, float y)
    {
        h &= 7u;
        return Neg(h < 4u ? x : y, h & 1u) + Neg(2.0 * (h < 4u ? y : x), h & 2u);
    }
    float G3(uint h, float x, float y, float z)
    {
        h &= 15u;
        float vt = (h == 12u || h == 14u) ? x : z;
        return Neg(h < 8u ? x : y, h & 1u) + Neg(h < 4u ? y : vt, h & 2u);
    }
    float G4(uint h, float x, float y, float z, float w)
    {
        h &= 31u;
        return Neg(h < 24u ? x : y, h & 1u) + Neg(h < 16u ? y : z, h & 2u)
             + Neg(h < 8u ? z : w, h & 4u);
    }
    float Tri(float v0, float v1, float v2, float v3, float v4, float v5, float v6, float v7,
              float x, float y, float z)
    {
        float x1 = 1.0 - x; float y1 = 1.0 - y; float z1 = 1.0 - z;
        return z1 * (y1 * (v0 * x1 + v1 * x) + y * (v2 * x1 + v3 * x))
             + z * (y1 * (v4 * x1 + v5 * x) + y * (v6 * x1 + v7 * x));
    }
    float Perlin(float4 p)
    {
        float4 f = floor(p);
        int X = int(f.x); int Y = int(f.y); int Z = int(f.z); int W = int(f.w);
        float4 r = p - f;
        float fx = r.x; float fy = r.y; float fz = r.z; float fw = r.w;
        if (BU_DIMS == 1)
            return lerp(G1(Hash1(X), fx), G1(Hash1(X + 1), fx - 1.0), Fade(fx));
        if (BU_DIMS == 2)
        {
            float u = Fade(fx); float v = Fade(fy); float x1 = 1.0 - u;
            return (1.0 - v) * (G2(Hash2(X, Y), fx, fy) * x1
                                + G2(Hash2(X + 1, Y), fx - 1.0, fy) * u)
                 + v * (G2(Hash2(X, Y + 1), fx, fy - 1.0) * x1
                        + G2(Hash2(X + 1, Y + 1), fx - 1.0, fy - 1.0) * u);
        }
        if (BU_DIMS == 3)
            return Tri(G3(Hash3(X, Y, Z), fx, fy, fz),
                       G3(Hash3(X + 1, Y, Z), fx - 1.0, fy, fz),
                       G3(Hash3(X, Y + 1, Z), fx, fy - 1.0, fz),
                       G3(Hash3(X + 1, Y + 1, Z), fx - 1.0, fy - 1.0, fz),
                       G3(Hash3(X, Y, Z + 1), fx, fy, fz - 1.0),
                       G3(Hash3(X + 1, Y, Z + 1), fx - 1.0, fy, fz - 1.0),
                       G3(Hash3(X, Y + 1, Z + 1), fx, fy - 1.0, fz - 1.0),
                       G3(Hash3(X + 1, Y + 1, Z + 1), fx - 1.0, fy - 1.0, fz - 1.0),
                       Fade(fx), Fade(fy), Fade(fz));
        float a = Tri(G4(Hash4(X, Y, Z, W), fx, fy, fz, fw),
                      G4(Hash4(X + 1, Y, Z, W), fx - 1.0, fy, fz, fw),
                      G4(Hash4(X, Y + 1, Z, W), fx, fy - 1.0, fz, fw),
                      G4(Hash4(X + 1, Y + 1, Z, W), fx - 1.0, fy - 1.0, fz, fw),
                      G4(Hash4(X, Y, Z + 1, W), fx, fy, fz - 1.0, fw),
                      G4(Hash4(X + 1, Y, Z + 1, W), fx - 1.0, fy, fz - 1.0, fw),
                      G4(Hash4(X, Y + 1, Z + 1, W), fx, fy - 1.0, fz - 1.0, fw),
                      G4(Hash4(X + 1, Y + 1, Z + 1, W), fx - 1.0, fy - 1.0, fz - 1.0, fw),
                      Fade(fx), Fade(fy), Fade(fz));
        float b = Tri(G4(Hash4(X, Y, Z, W + 1), fx, fy, fz, fw - 1.0),
                      G4(Hash4(X + 1, Y, Z, W + 1), fx - 1.0, fy, fz, fw - 1.0),
                      G4(Hash4(X, Y + 1, Z, W + 1), fx, fy - 1.0, fz, fw - 1.0),
                      G4(Hash4(X + 1, Y + 1, Z, W + 1), fx - 1.0, fy - 1.0, fz, fw - 1.0),
                      G4(Hash4(X, Y, Z + 1, W + 1), fx, fy, fz - 1.0, fw - 1.0),
                      G4(Hash4(X + 1, Y, Z + 1, W + 1), fx - 1.0, fy, fz - 1.0, fw - 1.0),
                      G4(Hash4(X, Y + 1, Z + 1, W + 1), fx, fy - 1.0, fz - 1.0, fw - 1.0),
                      G4(Hash4(X + 1, Y + 1, Z + 1, W + 1), fx - 1.0, fy - 1.0, fz - 1.0,
                         fw - 1.0),
                      Fade(fx), Fade(fy), Fade(fz));
        return lerp(a, b, Fade(fw));
    }
    float S(float4 p)  /* snoise_Nd: signed, scaled per dimension */
    {
        float4 big = step(1000000.0, abs(p));  /* no vector ?: in HLSL 2021 */
        p = fmod(p, 100000.0) + 0.5 * big;
        float scale = BU_DIMS == 1 ? 0.25 : (BU_DIMS == 2 ? 0.6616
                                             : (BU_DIMS == 3 ? 0.982 : 0.8344));
        return scale * Perlin(p);
    }
    float Select(float4 p, float detail, float roughness, float lacunarity, float offset,
                 float gain)
    {
        int octaves = int(detail);
        float rmd = detail - floor(detail);
        if (BU_TYPE == 0)  /* fBM */
        {
            float fscale = 1.0; float amp = 1.0; float maxamp = 0.0; float sum = 0.0;
            [loop] for (int i = 0; i <= octaves; i++)
            {
                sum += S(fscale * p) * amp; maxamp += amp; amp *= roughness;
                fscale *= lacunarity;
            }
            if (rmd != 0.0)
            {
                float sum2 = sum + S(fscale * p) * amp;
                return BU_NORMALIZE ? lerp(0.5 * sum / maxamp + 0.5,
                                           0.5 * sum2 / (maxamp + amp) + 0.5, rmd)
                                    : lerp(sum, sum2, rmd);
            }
            return BU_NORMALIZE ? 0.5 * sum / maxamp + 0.5 : sum;
        }
        if (BU_TYPE == 1)  /* Multifractal */
        {
            float value = 1.0; float pwr = 1.0;
            [loop] for (int i = 0; i <= octaves; i++)
            {
                value *= pwr * S(p) + 1.0; pwr *= roughness; p *= lacunarity;
            }
            if (rmd != 0.0) value *= rmd * pwr * S(p) + 1.0;
            return value;
        }
        if (BU_TYPE == 2)  /* Hybrid Multifractal */
        {
            float pwr = 1.0; float value = 0.0; float weight = 1.0;
            [loop] for (int i = 0; weight > 0.001 && i <= octaves; i++)
            {
                weight = min(weight, 1.0);
                float signal = (S(p) + offset) * pwr;
                pwr *= roughness; value += weight * signal; weight *= gain * signal;
                p *= lacunarity;
            }
            if (rmd != 0.0 && weight > 0.001)
            {
                weight = min(weight, 1.0);
                value += rmd * weight * (S(p) + offset) * pwr;
            }
            return value;
        }
        if (BU_TYPE == 3)  /* Ridged Multifractal */
        {
            float pwr = roughness;
            float signal = offset - abs(S(p));
            signal *= signal;
            float value = signal;
            [loop] for (int i = 1; i <= octaves; i++)
            {
                p *= lacunarity;
                float weight = saturate(signal * gain);
                signal = offset - abs(S(p));
                signal *= signal;
                signal *= weight;
                value += signal * pwr; pwr *= roughness;
            }
            return value;
        }
        /* Hetero Terrain */
        float pwr = roughness;
        float value = offset + S(p);
        p *= lacunarity;
        [loop] for (int i = 1; i <= octaves; i++)
        {
            value += (S(p) + offset) * pwr * value; pwr *= roughness; p *= lacunarity;
        }
        if (rmd != 0.0) value += rmd * (S(p) + offset) * pwr * value;
        return value;
    }
};
BUNoise N;
float4 p = BU_DIMS == 1 ? float4(W, 0.0, 0.0, 0.0) : float4(Coord, W);
p *= Scale;
if (BU_DIMS == 2) p.zw = 0.0;
if (BU_DIMS == 3) p.w = 0.0;
float detail = clamp(Detail, 0.0, 15.0);
float roughness = max(Roughness, 0.0);
if (Distortion != 0.0)
    p += float4(N.S(p + BU_OFF0), BU_DIMS > 1 ? N.S(p + BU_OFF1) : 0.0,
                BU_DIMS > 2 ? N.S(p + BU_OFF2) : 0.0, BU_DIMS > 3 ? N.S(p + BU_OFF3) : 0.0)
         * Distortion;
float value = N.Select(p, detail, roughness, Lacunarity, Offset, Gain);
float3 colour = value;
if (BU_COLOR == 1)
    colour = float3(value, N.Select(p + BU_OFF4, detail, roughness, Lacunarity, Offset, Gain),
                    N.Select(p + BU_OFF5, detail, roughness, Lacunarity, Offset, Gain));
return float4(colour, value);
"""
NOISE_TYPES = {"FBM": 0, "MULTIFRACTAL": 1, "HYBRID_MULTIFRACTAL": 2, "RIDGED_MULTIFRACTAL": 3,
               "HETERO_TERRAIN": 4}
NOISE_INPUTS = (("Coord", "a", None), ("W", "w", 0.0), ("Scale", "scale", 5.0),
                ("Detail", "detail", 2.0), ("Roughness", "roughness", 0.5),
                ("Lacunarity", "lacunarity", 2.0), ("Offset", "offset", 0.0),
                ("Gain", "gain", 1.0), ("Distortion", "distortion", 0.0))


def _rot(x, k):
    return ((x << k) | (x >> (32 - k))) & 0xFFFFFFFF


def jenkins(*keys):
    """Cycles' `hash_uint` .. `hash_uint4` (Bob Jenkins' lookup3) of 1 to 4 32-bit words. Pure."""
    m = 0xFFFFFFFF
    a = b = c = (0xDEADBEEF + (len(keys) << 2) + 13) & m
    if len(keys) == 4:
        a, b, c = (a + keys[0]) & m, (b + keys[1]) & m, (c + keys[2]) & m
        a = (a - c) & m; a ^= _rot(c, 4); c = (c + b) & m
        b = (b - a) & m; b ^= _rot(a, 6); a = (a + c) & m
        c = (c - b) & m; c ^= _rot(b, 8); b = (b + a) & m
        a = (a - c) & m; a ^= _rot(c, 16); c = (c + b) & m
        b = (b - a) & m; b ^= _rot(a, 19); a = (a + c) & m
        c = (c - b) & m; c ^= _rot(b, 4); b = (b + a) & m
        a = (a + keys[3]) & m
    else:
        if len(keys) > 2:
            c = (c + keys[2]) & m
        if len(keys) > 1:
            b = (b + keys[1]) & m
        a = (a + keys[0]) & m
    c ^= b; c = (c - _rot(b, 14)) & m
    a ^= c; a = (a - _rot(c, 11)) & m
    b ^= a; b = (b - _rot(a, 25)) & m
    c ^= b; c = (c - _rot(b, 16)) & m
    a ^= c; a = (a - _rot(c, 4)) & m
    b ^= a; b = (b - _rot(a, 14)) & m
    c ^= b; c = (c - _rot(b, 24)) & m
    return c


def _float_bits(value):
    import struct
    return struct.unpack("<I", struct.pack("<f", float(value)))[0]


def noise_offset(dims, seed):
    """Cycles' `random_float<dims>_offset(seed)`: where each extra noise is read from, as a
    4-vector (unused components 0). Pure."""
    if dims == 1:
        return (100.0 + jenkins(_float_bits(seed)) / float(0xFFFFFFFF) * 100.0, 0.0, 0.0, 0.0)
    found = [100.0 + jenkins(_float_bits(seed), _float_bits(k)) / float(0xFFFFFFFF) * 100.0
             for k in range(dims)]
    return tuple(found + [0.0] * (4 - dims))


def noise_hlsl(dims, kind="FBM", normalize=True, colour=False):
    """The Custom node code for one Noise Texture's settings. Pure.

    The seeds are Cycles': the distortion reads seeds 0 .. dims - 1 (one per axis), the colour's
    other two channels the next two."""
    dims = max(1, min(4, int(dims)))
    code = NOISE_HLSL
    for index in range(6):
        seed = index if index < 4 else dims + index - 4
        code = code.replace("BU_OFF{0}".format(index), "float4({0})".format(
            ", ".join(repr(float(v)) for v in noise_offset(dims, seed))))
    for name, value in (("BU_DIMS", dims), ("BU_TYPE", NOISE_TYPES.get(kind, 0)),
                        ("BU_NORMALIZE", "true" if normalize else "false"),
                        ("BU_COLOR", 1 if colour else 0)):
        code = code.replace(name, str(value))
    return code


class Unbuildable(Exception):
    pass


class Emitter(object):
    """Builds a graph's expressions into one material, on demand per channel."""

    def __init__(self, unreal, material, graph):
        self.unreal = unreal
        self.library = unreal.MaterialEditingLibrary
        self.material = material
        self.graph = graph
        self.nodes = graph.get("nodes") or []
        self._built = {}
        self._params = {}
        # While a Bump takes its height's slope: ("x" or "y", filter width), and the nodes built
        # for each offset (`_offset`).
        self._variant = None
        self._variants = {}
        self._spec = None
        self.failed = []
        self._y = -2400
        self.shared_samplers = len(texture_names(graph)) > OWN_SAMPLERS

    # -- plumbing --------------------------------------------------------------------------

    def _new(self, cls_name, **props):
        cls = getattr(self.unreal, cls_name, None)
        if cls is None:
            raise Unbuildable("this Unreal has no " + cls_name)
        self._y += 90
        found = self.library.create_material_expression(self.material, cls, -2600, self._y)
        for key, value in props.items():
            bu_link_material._quiet(found, key, value, self.unreal)
        return found

    def expr(self, cls_name, args=(), named=None, **props):
        """A new expression with `args` connected to its inputs in order (None skips one)."""
        found = self._new(cls_name, **props)
        names = list(self.library.get_material_expression_input_names(found) or [])
        for index, source in enumerate(args):
            if source is None:
                continue
            if index >= len(names):
                raise Unbuildable("{0} has no input {1}".format(cls_name, index))
            self._connect(source, found, names[index])
        for name, source in (named or {}).items():
            self._connect(source, found, name)
        return (found, "")

    def _connect(self, source, target, name):
        expression, output = source
        if not self.library.connect_material_expressions(expression, output, target, name):
            self.failed.append("{0}.{1}".format(type(target).__name__, name or "input"))

    def const(self, *values):
        if len(values) == 1:
            return self.expr("MaterialExpressionConstant", r=float(values[0]))
        padded = tuple(values) + (0.0,) * (4 - len(values))
        found = self._new("MaterialExpressionConstant3Vector",
                          constant=self.unreal.LinearColor(*padded[:3], 1.0))
        return (found, "")

    def mask(self, source, channel):
        flags = {c: c == channel for c in ("r", "g", "b", "a")}
        return self.expr("MaterialExpressionComponentMask", [source], **flags)

    def add(self, a, b):
        return self.expr("MaterialExpressionAdd", [a, b])

    def sub(self, a, b):
        return self.expr("MaterialExpressionSubtract", [a, b])

    def mul(self, a, b):
        return self.expr("MaterialExpressionMultiply", [a, b])

    def div(self, a, b):
        return self.expr("MaterialExpressionDivide", [a, b])

    def lerp(self, a, b, alpha):
        return self.expr("MaterialExpressionLinearInterpolate", [a, b, alpha])

    def one_minus(self, a):
        return self.expr("MaterialExpressionOneMinus", [a])

    def saturate(self, a):
        return self.expr("MaterialExpressionSaturate", [a])

    def append(self, a, b):
        return self.expr("MaterialExpressionAppendVector", [a, b])

    # -- refs ------------------------------------------------------------------------------

    def ref(self, ref):
        if "p" in ref:
            return self.param(ref["p"], ref.get("t", "f"))
        outputs = self.node(int(ref["n"]))
        key = ref.get("o", "")
        if key not in outputs:
            raise Unbuildable("node {0} has no output {1!r}".format(ref["n"], key))
        return outputs[key]

    def param(self, name, kind):
        if name not in self._params:
            if kind == "f":
                found = self._new("MaterialExpressionScalarParameter", parameter_name=name)
                self._params[name] = (found, "")
            else:
                found = self._new("MaterialExpressionVectorParameter", parameter_name=name)
                self._params[name] = (found, "RGB")
        return self._params[name]

    def channel(self, name):
        """(expression, output) for a channel the graph drives, or None."""
        ref = (self.graph.get("out") or {}).get(name)
        return self.ref(ref) if ref else None

    def node(self, index):
        # Per offset and filter width: two Bumps of different widths share no offset nodes.
        built = self._built if self._variant is None else self._variants.setdefault(
            (self._variant[0], id(self._variant[1][0])), {})
        if index not in built:
            spec = self.nodes[index]
            handler = getattr(self, "_op_" + spec.get("op", ""), None)
            if handler is None:
                raise Unbuildable("no translation for op {0!r}".format(spec.get("op")))
            inputs = {k: self.ref(v) for k, v in (spec.get("in") or {}).items()}
            self._spec = spec
            found = handler(inputs, spec.get("opt") or {})
            built[index] = found if isinstance(found, dict) else {"": found}
        return built[index]

    def _offset(self, coordinate):
        """A coordinate as it is, or, while a Bump evaluates its height a little to one side,
        moved by its screen-space derivative times the filter width, as Blender does."""
        if self._variant is None:
            return coordinate
        axis, width = self._variant
        slope = self.expr("MaterialExpressionDDX" if axis == "x" else "MaterialExpressionDDY",
                          [coordinate])
        return self.add(coordinate, self.mul(slope, width))

    # -- coordinates -----------------------------------------------------------------------

    def _uv_blender(self, index=0):
        uv = self._offset(self.expr("MaterialExpressionTextureCoordinate",
                                    coordinate_index=int(index)))
        return self.append(self.append(self.mask(uv, "r"), self.one_minus(self.mask(uv, "g"))),
                           self.const(0.0))

    def _local_position(self):
        return self._offset((self.expr("MaterialExpressionLocalPosition")[0], "XYZ"))

    def _object(self):
        return self.mul(self._local_position(), self.const(0.01, -0.01, 0.01))

    # -- ops -------------------------------------------------------------------------------

    def _op_luminance(self, i, opt):
        return self.expr("MaterialExpressionDotProduct", [i["a"], self.const(*LUMINANCE)])

    def _op_average(self, i, opt):
        return self.expr("MaterialExpressionDotProduct", [i["a"], self.const(1 / 3.0, 1 / 3.0, 1 / 3.0)])

    def _sampler(self, name, linear, uvs=None, normal=False, lut=False):
        found = self._new("MaterialExpressionTextureSampleParameter2D", parameter_name=name)
        if normal:
            default = self.unreal.load_asset(bu_link_material.DEFAULT_NORMAL)
        elif linear:
            default = bu_link_material.linear_default()
        else:
            default = self.unreal.load_asset(bu_link_material.DEFAULT_TEXTURE)
        if default is not None:
            bu_link_material._quiet(found, "texture", default, self.unreal)
        if self.shared_samplers and not lut:  # a ramp keeps its own clamped sampler
            bu_link_material._quiet(
                found, "sampler_source",
                self.unreal.SamplerSourceMode.SSM_WRAP_WORLD_GROUP_SETTINGS, self.unreal)
        kinds = self.unreal.MaterialSamplerType
        bu_link_material._quiet(found, "sampler_type", kinds.SAMPLERTYPE_NORMAL if normal
                                else kinds.SAMPLERTYPE_LINEAR_COLOR if linear
                                else kinds.SAMPLERTYPE_COLOR, self.unreal)
        if uvs is not None:
            self._connect(uvs, found, "UVs")
        return found

    def _op_image(self, i, opt):
        uvs = None
        if "uv" in i:
            # Blender's (u, v) back to Unreal's (u, 1 - v).
            uvs = self.append(self.mask(i["uv"], "r"), self.one_minus(self.mask(i["uv"], "g")))
        elif self._variant is not None:
            uvs = self._offset(self.expr("MaterialExpressionTextureCoordinate",
                                         coordinate_index=0))
        extension = opt.get("extension")
        if extension and uvs is None:
            uvs = self.expr("MaterialExpressionTextureCoordinate", coordinate_index=0)
        inside = None
        # Blender's image extension, outside 0-1 (symmetric, so Unreal's flipped V is fine).
        if extension == "EXTEND":
            uvs = self.saturate(uvs)
        elif extension == "MIRROR":
            # A triangle wave of period 2: 0..1 forward, then 1..0 back.
            wave = self.mul(self.expr("MaterialExpressionFrac", [self.mul(uvs, self.const(0.5))]),
                            self.const(2.0))
            uvs = self.one_minus(self.expr("MaterialExpressionAbs",
                                           [self.sub(wave, self.const(1.0))]))
        elif extension == "CLIP":
            # 1 inside the image, 0 outside: max |uv - 0.5| over the two axes, against 0.5.
            off = self.expr("MaterialExpressionAbs", [self.sub(uvs, self.const(0.5))])
            far = self.expr("MaterialExpressionMax", [self.mask(off, "r"), self.mask(off, "g")])
            inside = self.one_minus(self.saturate(self.expr(
                "MaterialExpressionCeil", [self.sub(far, self.const(0.5))])))
        found = self._sampler(opt["tex"], opt.get("linear"), uvs, bool(opt.get("normal")))
        if inside is not None:
            # Blender's Clip is transparent black outside the image.
            return {"rgb": self.mul((found, "RGB"), inside), "a": self.mul((found, "A"), inside)}
        return {"rgb": (found, "RGB"), "a": (found, "A")}

    def _op_ramp(self, i, opt):
        uvs = self.append(self.saturate(i["fac"]), self.const(0.5))
        found = self._sampler(opt["tex"], False, uvs, lut=True)
        return {"rgb": (found, "RGB"), "a": (found, "A")}

    def _op_uv(self, i, opt):
        return self._uv_blender(opt.get("index", 0))

    def _op_vertex_color(self, i, opt):
        # The mesh holds Blender's sRGB bytes, as Unreal's own meshes do (`bu_link` sends them);
        # Blender's node gives linear colour, so they are decoded here. Alpha is not colour.
        found = self.expr("MaterialExpressionVertexColor")[0]
        return {"rgb": self.srgb_to_linear((found, "")), "a": (found, "A")}

    def srgb_to_linear(self, colour):
        """sRGB-encoded colour -> linear, the exact curve (not a 2.2 power)."""
        colour = self.mask3(colour)
        low = self.div(colour, self.const(12.92))
        high = self.expr("MaterialExpressionPower", [
            self.div(self.add(colour, self.const(0.055)), self.const(1.055)), self.const(2.4)])
        # 1 where colour is above the knee (0.04045), per channel (vertex colours stay 0-1).
        above = self.saturate(self.expr("MaterialExpressionCeil",
                                         [self.sub(colour, self.const(0.04045))]))
        return self.lerp(low, high, above)

    def mask3(self, source):
        return self.expr("MaterialExpressionComponentMask", [source], r=True, g=True, b=True,
                         a=False)

    def _op_object(self, i, opt):
        return self._object()

    BLENDER_AXES = (0.01, -0.01, 0.01)  # Unreal's centimetres and -Y as Blender's metres and Y

    def _world_blender(self):
        """The pixel's world position in Blender's axes and metres."""
        world = self._offset((self.expr("MaterialExpressionWorldPosition")[0], ""))
        return self.mul(world, self.const(*self.BLENDER_AXES))

    def _op_object_of(self, i, opt):
        """Texture Coordinate's Object, of a named object: Blender's world position through
        that object's inverse matrix (its rows and translation)."""
        position = self._world_blender()
        dot = "MaterialExpressionDotProduct"
        x, y, z = (self.expr(dot, [position, i[axis]]) for axis in ("x", "y", "z"))
        return self.add(self.append(self.append(x, y), z), i["t"])

    def _op_camera_coords(self, i, opt):
        """Texture Coordinate's Camera: the point in the camera's space, Blender's way (X right,
        Y up, -Z ahead; Unreal's camera space looks along +Z), in metres."""
        unreal = self.unreal
        world = self._offset((self.expr("MaterialExpressionWorldPosition")[0], ""))
        space = unreal.MaterialPositionTransformSource
        seen = self.expr("MaterialExpressionTransformPosition", [world],
                         transform_source_type=space.TRANSFORMPOSSOURCE_WORLD,
                         transform_type=space.TRANSFORMPOSSOURCE_CAMERA)
        return self.mul(seen, self.const(0.01, 0.01, -0.01))

    def _op_window(self, i, opt):
        """Texture Coordinate's Window: where on the picture, 0-1 from its bottom left."""
        screen = (self.expr("MaterialExpressionScreenPosition")[0], "ViewportUV")
        return self.append(self.append(self.mask(screen, "r"), self.one_minus(self.mask(screen, "g"))),
                           self.const(0.0))

    def _op_reflection(self, i, opt):
        """Texture Coordinate's Reflection: the view reflected about the normal, in Blender's
        world axes."""
        return self.mul(self.expr("MaterialExpressionReflectionVectorWS"),
                        self.const(1.0, -1.0, 1.0))

    def _op_geometry(self, i, opt):
        """The Geometry node: Position, Normal, Incoming and Backfacing, Blender's way."""
        out = opt.get("out")
        flip = self.const(1.0, -1.0, 1.0)
        if out == "position":
            return self._world_blender()
        if out == "normal":
            return self.mul(self.expr("MaterialExpressionVertexNormalWS"), flip)
        if out == "incoming":
            return self.mul(self.expr("MaterialExpressionCameraVectorWS"), flip)
        if out == "backfacing":
            # Unreal's sign is 1 on a front face and -1 on a back face.
            return self.mul(self.one_minus(self.expr("MaterialExpressionTwoSidedSign")),
                            self.const(0.5))
        raise Unbuildable("geometry " + str(out))

    def _facing(self):
        """|cos| of the angle between the surface's smooth normal and the way to the camera."""
        normal = self.expr("MaterialExpressionVertexNormalWS")
        towards = self.expr("MaterialExpressionCameraVectorWS")
        return self.expr("MaterialExpressionAbs",
                         [self.expr("MaterialExpressionDotProduct", [normal, towards])])

    def _fresnel(self, cos, eta):
        """Blender's `fresnel_dielectric_cos` (no total internal reflection: eta >= 1 here)."""
        g = self.expr("MaterialExpressionSquareRoot", [self.expr("MaterialExpressionMax", [
            self.add(self.sub(self.mul(eta, eta), self.const(1.0)), self.mul(cos, cos)),
            self.const(1e-6)])])
        a = self.div(self.sub(g, cos), self.add(g, cos))
        b = self.div(self.sub(self.mul(cos, self.add(g, cos)), self.const(1.0)),
                     self.add(self.mul(cos, self.sub(g, cos)), self.const(1.0)))
        return self.mul(self.mul(self.mul(a, a), self.const(0.5)),
                        self.add(self.const(1.0), self.mul(b, b)))

    def _op_fresnel(self, i, opt):
        eta = self.expr("MaterialExpressionMax", [i["ior"], self.const(1.00001)])
        return self._fresnel(self._facing(), eta)

    def _op_layer_weight(self, i, opt):
        # Blender: Fresnel at eta = 1 / (1 - blend); Facing = 1 - |cos|^p, p = 2 * blend below a
        # half and 0.5 / (1 - blend) above it.
        blend = self.expr("MaterialExpressionClamp",
                          [i["blend"], self.const(0.0), self.const(0.99999)])
        cos = self._facing()
        eta = self.div(self.const(1.0), self.expr("MaterialExpressionMax", [
            self.one_minus(blend), self.const(1e-5)]))
        low = self.mul(blend, self.const(2.0))
        high = self.div(self.const(0.5), self.one_minus(blend))
        above = self.expr("MaterialExpressionCeil", [self.saturate(self.sub(blend, self.const(0.5)))])
        power = self.lerp(low, high, above)
        facing = self.one_minus(self.expr("MaterialExpressionPower", [cos, power]))
        return {"fresnel": self._fresnel(cos, eta), "facing": facing}

    def _op_instance_random(self, i, opt):
        return self.expr("MaterialExpressionPerInstanceRandom")

    def _op_object_normal(self, i, opt):
        """Texture Coordinate's Normal: the smooth normal in the object's own axes (Blender's
        Y is Unreal's -Y)."""
        local = self._transform(self.expr("MaterialExpressionVertexNormalWS"), "world", "local")
        return self.mul(self.expr("MaterialExpressionNormalize", [local]),
                        self.const(1.0, -1.0, 1.0))

    def _op_generated(self, i, opt):
        bounds = self.expr("MaterialExpressionObjectLocalBounds")
        found_min = (bounds[0], "Min")
        found_max = (bounds[0], "Max")
        full = (bounds[0], "Extents")  # the whole size; "Half Extents" is half of it
        local = self.mul(self._local_position(), self.const(1.0, -1.0, 1.0))
        # Blender's Y is Unreal's -Y, so its smallest Y is Unreal's largest.
        corner = self.add(self.mul(found_min, self.const(1.0, 0.0, 1.0)),
                          self.mul(found_max, self.const(0.0, -1.0, 0.0)))
        # A side with no size (a plane's thickness) is 2 wide around its centre in Blender's
        # texture space, so it reads 0.5; dividing by its zero size made the whole graph NaN.
        flat = self.one_minus(self.expr("MaterialExpressionCeil",
                                        [self.saturate(self.mul(full, self.const(1e5)))]))
        corner = self.sub(corner, flat)
        full = self.add(full, self.mul(flat, self.const(2.0)))
        return self.div(self.sub(local, corner), full)

    def _op_mix(self, i, opt):
        a, b, fac = i["a"], i["b"], i["fac"]
        if opt.get("clamp_factor"):
            fac = self.saturate(fac)
        blend = opt.get("blend", "MIX")
        if blend == "MIX":
            result = self.lerp(a, b, fac)
        elif blend == "LIGHTEN":
            result = self.expr("MaterialExpressionMax", [a, self.mul(b, fac)])
        elif blend in HSV_BLENDS:
            result = self.lerp(a, self._hsv_blend(blend, a, b), fac)
        else:
            if blend == "MULTIPLY":
                mixed = self.mul(a, b)
            elif blend == "ADD":
                mixed = self.add(a, b)
            elif blend == "SUBTRACT":
                mixed = self.sub(a, b)
            elif blend == "SCREEN":
                mixed = self.one_minus(self.mul(self.one_minus(a), self.one_minus(b)))
            elif blend == "DIFFERENCE":
                mixed = self.expr("MaterialExpressionAbs", [self.sub(a, b)])
            elif blend == "DARKEN":
                mixed = self.expr("MaterialExpressionMin", [a, b])
            elif blend == "DIVIDE":
                mixed = self.div(a, self.expr("MaterialExpressionMax", [b, self.const(1e-5)]))
            elif blend == "LINEAR_LIGHT":
                # Blender: a + fac * (2b - 1).
                mixed = self.sub(self.add(a, self.mul(b, self.const(2.0))), self.const(1.0))
            elif blend in ("BURN", "DODGE", "SOFT_LIGHT"):
                mixed = None  # the factor is part of these (below)
            elif blend == "OVERLAY":
                low = self.mul(self.mul(a, b), self.const(2.0))
                high = self.one_minus(self.mul(self.mul(self.one_minus(a), self.one_minus(b)),
                                               self.const(2.0)))
                upper = self.expr("MaterialExpressionCeil", [self.saturate(self.sub(a, self.const(0.5)))])
                mixed = self.lerp(low, high, upper)
            else:
                raise Unbuildable("blend " + blend)
            result = self.lerp(a, mixed, fac) if mixed is not None else self._factor_blend(
                blend, a, b, fac)
        return self.saturate(result) if opt.get("clamp") else result

    def _factor_blend(self, blend, a, b, fac):
        """Blender's Burn, Dodge and Soft Light (`ramp_blend`), whose factor is inside them."""
        tiny = self.const(1e-6)
        if blend == "BURN":
            # 1 - (1 - a) / (1 - fac + fac b), 0 where that divisor is not positive.
            divisor = self.add(self.one_minus(fac), self.mul(fac, b))
            return self.saturate(self.one_minus(self.div(
                self.one_minus(a), self.expr("MaterialExpressionMax", [divisor, tiny]))))
        if blend == "DODGE":
            # a / (1 - fac b), 1 where that divisor is not positive (and a is not 0).
            divisor = self.one_minus(self.mul(fac, b))
            return self.saturate(self.div(a, self.expr("MaterialExpressionMax", [divisor, tiny])))
        # SOFT_LIGHT: a + fac ((1 - a) b a + a screen(a, b) - a)
        screen = self.one_minus(self.mul(self.one_minus(b), self.one_minus(a)))
        soft = self.add(self.mul(self.mul(self.one_minus(a), b), a), self.mul(a, screen))
        return self.lerp(a, soft, fac)

    def _hsv(self, colour):
        """(value, chroma, pure) of a colour: its brightest channel, brightest less dimmest, and
        its hue at full saturation and value, (c - min) / (max - min). With them Blender's
        hsv_to_rgb(h, s, v) is v * (1 - s + s * pure), and s * v the chroma."""
        r, g, b = self.mask(colour, "r"), self.mask(colour, "g"), self.mask(colour, "b")
        value = self.expr("MaterialExpressionMax", [self.expr("MaterialExpressionMax", [r, g]), b])
        lowest = self.expr("MaterialExpressionMin", [self.expr("MaterialExpressionMin", [r, g]), b])
        chroma = self.sub(value, lowest)
        pure = self.div(self.sub(colour, lowest),
                        self.expr("MaterialExpressionMax", [chroma, self.const(1e-6)]))
        return value, chroma, pure

    def _hsv_blend(self, blend, a, b):
        """Blender's Hue, Saturation, Value and Color blends (`ramp_blend`): `a` with the hue, the
        saturation, the value, or the hue and saturation of `b`; `a` itself where Blender leaves
        it (the colour that gives its hue is grey)."""
        a_value, a_chroma, a_pure = self._hsv(a)
        b_value, b_chroma, b_pure = self._hsv(b)

        def coloured(chroma):  # 1 where a colour has a hue, 0 for a grey
            return self.expr("MaterialExpressionCeil", [self.saturate(self.mul(chroma, self.const(1e6)))])

        def rgb(value, chroma, pure):  # v * (1 - s + s * pure) = v - chroma + chroma * pure
            return self.add(self.sub(value, chroma), self.mul(chroma, pure))

        def saturation(value, chroma):
            return self.div(chroma, self.expr("MaterialExpressionMax", [value, self.const(1e-20)]))
        if blend == "HUE":
            return self.lerp(a, rgb(a_value, a_chroma, b_pure), coloured(b_chroma))
        if blend == "SATURATION":
            chroma = self.mul(a_value, saturation(b_value, b_chroma))
            return self.lerp(a, rgb(a_value, chroma, a_pure), coloured(a_chroma))
        if blend == "VALUE":
            chroma = self.mul(b_value, saturation(a_value, a_chroma))
            return rgb(b_value, chroma, a_pure)
        chroma = self.mul(a_value, saturation(b_value, b_chroma))  # COLOR
        return self.lerp(a, rgb(a_value, chroma, b_pure), coloured(b_chroma))

    def _op_math(self, i, opt):
        op = opt.get("op")
        a, b = i.get("a"), i.get("b")
        binary = {"ADD": "MaterialExpressionAdd", "SUBTRACT": "MaterialExpressionSubtract",
                  "MULTIPLY": "MaterialExpressionMultiply", "MINIMUM": "MaterialExpressionMin",
                  "MAXIMUM": "MaterialExpressionMax", "MODULO": "MaterialExpressionFmod"}
        unary = {"ABSOLUTE": "MaterialExpressionAbs", "SQRT": "MaterialExpressionSquareRoot",
                 "FLOOR": "MaterialExpressionFloor", "CEIL": "MaterialExpressionCeil",
                 "FRACT": "MaterialExpressionFrac", "ROUND": "MaterialExpressionRound",
                 "SIGN": "MaterialExpressionSign", "EXPONENT": "MaterialExpressionExponential",
                 "ARCSINE": "MaterialExpressionArcsine", "ARCCOSINE": "MaterialExpressionArccosine",
                 "ARCTANGENT": "MaterialExpressionArctangent"}
        if op in binary:
            result = self.expr(binary[op], [a, b])
        elif op in unary:
            result = self.expr(unary[op], [a])
        elif op == "DIVIDE":
            result = self.div(a, b)
        elif op == "POWER":
            result = self.expr("MaterialExpressionPower", [a, b])
        elif op in ("SINE", "COSINE"):
            result = self.expr("MaterialExpressionSine" if op == "SINE" else "MaterialExpressionCosine",
                               [a], period=TWO_PI)
        elif op == "TANGENT":
            result = self.expr("MaterialExpressionTangent", [a], period=TWO_PI)
        elif op == "ARCTAN2":
            # Blender's arctan2(a, b) is atan2(y=a, x=b), as Unreal's inputs run.
            result = self.expr("MaterialExpressionArctangent2", [a, b])
        elif op == "PINGPONG":
            # Blender: |fract((a - s) / 2s) * 2s - s|, 0 when s is 0 (a negative s folds
            # as its size).
            span = self.mul(b, self.const(2.0))
            safe = self.expr("MaterialExpressionMax",
                             [self.expr("MaterialExpressionAbs", [span]), self.const(1e-8)])
            wave = self.expr("MaterialExpressionAbs", [self.sub(self.mul(
                self.expr("MaterialExpressionFrac", [self.div(self.sub(a, b), safe)]), safe),
                self.expr("MaterialExpressionAbs", [b]))])
            result = self.expr("MaterialExpressionIf", [self.expr("MaterialExpressionAbs", [b]),
                                                        self.const(1e-8), wave,
                                                        self.const(0.0), self.const(0.0)])
        elif op == "INVERSE_SQRT":
            result = self.div(self.const(1.0), self.expr("MaterialExpressionSquareRoot", [a]))
        elif op in ("TRUNC", "RADIANS", "DEGREES", "SINH", "COSH", "TANH", "WRAP", "SNAP",
                    "COMPARE", "SMOOTH_MIN", "SMOOTH_MAX", "LOGARITHM"):
            result = self._math_more(op, a, b, i.get("c"))
        elif op == "MULTIPLY_ADD":
            result = self.add(self.mul(a, b), i["c"])
        elif op in ("LESS_THAN", "GREATER_THAN"):
            one, zero = self.const(1.0), self.const(0.0)
            if op == "LESS_THAN":
                result = self.expr("MaterialExpressionIf", [a, b, zero, zero, one])
            else:
                result = self.expr("MaterialExpressionIf", [a, b, one, zero, zero])
        else:
            raise Unbuildable("math " + str(op))
        return self.saturate(result) if opt.get("clamp") else result

    def _math_more(self, op, a, b, c):
        """The rest of Blender's Math node, as Cycles' svm_math defines each."""
        e = "MaterialExpressionExponential"
        if op == "TRUNC":
            return self.expr("MaterialExpressionTruncate", [a])
        if op == "RADIANS":
            return self.mul(a, self.const(math.pi / 180.0))
        if op == "DEGREES":
            return self.mul(a, self.const(180.0 / math.pi))
        if op in ("SINH", "COSH", "TANH"):
            up = self.expr(e, [a])
            down = self.expr(e, [self.mul(a, self.const(-1.0))])
            if op == "SINH":
                return self.mul(self.sub(up, down), self.const(0.5))
            if op == "COSH":
                return self.mul(self.add(up, down), self.const(0.5))
            return self.div(self.sub(up, down), self.add(up, down))
        if op == "WRAP":
            # a - (max - min) floor((a - min) / (max - min)); min when the range is empty.
            span = self.sub(b, c)
            wrapped = self.sub(a, self.mul(span, self.expr("MaterialExpressionFloor", [
                self.div(self.sub(a, c), span)])))
            return self.expr("MaterialExpressionIf", [
                self.expr("MaterialExpressionAbs", [span]), self.const(1e-8), wrapped, c, c])
        if op == "SNAP":
            return self.mul(self.expr("MaterialExpressionFloor", [self.div(a, b)]), b)
        if op == "COMPARE":
            # 1 when |a - b| is within max(c, 1e-5).
            gap = self.expr("MaterialExpressionAbs", [self.sub(a, b)])
            limit = self.expr("MaterialExpressionMax", [c, self.const(1e-5)])
            return self.expr("MaterialExpressionIf", [gap, limit, self.const(0.0),
                                                      self.const(1.0), self.const(1.0)])
        if op == "LOGARITHM":
            return self.div(self.expr("MaterialExpressionLogarithm2", [a]),
                            self.expr("MaterialExpressionLogarithm2", [b]))
        # SMOOTH_MIN, SMOOTH_MAX: min(a, b) - h³ c / 6, h = max(c - |a - b|, 0) / c; the max
        # is minus the min of the negatives.
        if op == "SMOOTH_MAX":
            a, b = self.mul(a, self.const(-1.0)), self.mul(b, self.const(-1.0))
        width = self.expr("MaterialExpressionMax", [c, self.const(1e-6)])
        h = self.div(self.expr("MaterialExpressionMax", [
            self.sub(width, self.expr("MaterialExpressionAbs", [self.sub(a, b)])),
            self.const(0.0)]), width)
        found = self.sub(self.expr("MaterialExpressionMin", [a, b]),
                         self.mul(self.mul(self.mul(h, h), h), self.div(width, self.const(6.0))))
        return self.mul(found, self.const(-1.0)) if op == "SMOOTH_MAX" else found

    def _op_vmath(self, i, opt):
        op = opt.get("op")
        a, b = i.get("a"), i.get("b")
        simple = {"ADD": self.add, "SUBTRACT": self.sub, "MULTIPLY": self.mul,
                  "DIVIDE": self.div, "SCALE": self.mul}
        if op in simple:
            return simple[op](a, b)
        named = {"LENGTH": "MaterialExpressionLength", "NORMALIZE": "MaterialExpressionNormalize",
                 "ABSOLUTE": "MaterialExpressionAbs", "FLOOR": "MaterialExpressionFloor",
                 "FRACTION": "MaterialExpressionFrac"}
        if op in named:
            return self.expr(named[op], [a])
        if op in ("MINIMUM", "MAXIMUM"):
            return self.expr("MaterialExpressionMin" if op == "MINIMUM" else "MaterialExpressionMax",
                             [a, b])
        if op == "DOT_PRODUCT":
            return self.expr("MaterialExpressionDotProduct", [a, b])
        if op == "CROSS_PRODUCT":
            return self.expr("MaterialExpressionCrossProduct", [a, b])
        if op == "DISTANCE":
            return self.expr("MaterialExpressionDistance", [a, b])
        if op == "CEIL":
            return self.expr("MaterialExpressionCeil", [a])
        if op == "MODULO":
            return self.expr("MaterialExpressionFmod", [a, b])
        if op == "SNAP":
            return self.mul(self.expr("MaterialExpressionFloor", [self.div(a, b)]), b)
        if op in ("SINE", "COSINE"):
            return self.expr("MaterialExpressionSine" if op == "SINE" else "MaterialExpressionCosine",
                             [a], period=TWO_PI)
        if op == "MULTIPLY_ADD":
            return self.add(self.mul(a, b), i["c"])
        raise Unbuildable("vector math " + str(op))

    def _op_invert(self, i, opt):
        return self.lerp(i["a"], self.one_minus(i["a"]), i["fac"])

    def _op_map_range(self, i, opt):
        """Blender's Map Range, on a number or (component by component) a vector. Smooth and
        smoother steps are symmetric, so a range given high to low needs no case of its own."""
        t = self.div(self.sub(i["x"], i["from_min"]), self.sub(i["from_max"], i["from_min"]))
        mode = opt.get("mode") or ("smoothstep" if opt.get("smooth") else "linear")
        if mode == "smoothstep":
            t = self.saturate(t)
            t = self.mul(self.mul(t, t), self.sub(self.const(3.0), self.mul(t, self.const(2.0))))
        elif mode == "smootherstep":
            # t³ (t (6t - 15) + 10)
            t = self.saturate(t)
            inner = self.add(self.mul(t, self.sub(self.mul(t, self.const(6.0)),
                                                  self.const(15.0))), self.const(10.0))
            t = self.mul(self.mul(self.mul(t, t), t), inner)
        elif mode == "stepped" and "steps" in i:
            # floor(t (steps + 1)) / steps
            t = self.div(self.expr("MaterialExpressionFloor",
                                   [self.mul(t, self.add(i["steps"], self.const(1.0)))]),
                         i["steps"])
        result = self.add(i["to_min"], self.mul(t, self.sub(i["to_max"], i["to_min"])))
        if opt.get("clamp"):
            low = self.expr("MaterialExpressionMin", [i["to_min"], i["to_max"]])
            high = self.expr("MaterialExpressionMax", [i["to_min"], i["to_max"]])
            result = self.expr("MaterialExpressionClamp", [result, low, high])
        return result

    def _op_clamp(self, i, opt):
        low, high = i["min"], i["max"]
        if opt.get("range"):
            low, high = (self.expr("MaterialExpressionMin", [i["min"], i["max"]]),
                         self.expr("MaterialExpressionMax", [i["min"], i["max"]]))
        return self.expr("MaterialExpressionClamp", [i["x"], low, high])

    def _op_channel(self, i, opt):
        return self.mask(i["a"], opt.get("channel", "r"))

    def _op_combine(self, i, opt):
        return self.append(self.append(i["r"], i["g"]), i["b"])

    def _op_gamma(self, i, opt):
        return self.expr("MaterialExpressionPower",
                         [self.expr("MaterialExpressionMax", [i["a"], self.const(0.0)]), i["gamma"]])

    def _op_bright_contrast(self, i, opt):
        # Blender: max((1 + contrast) * colour + (bright - contrast / 2), 0).
        gain = self.add(self.const(1.0), i["contrast"])
        offset = self.sub(i["bright"], self.mul(i["contrast"], self.const(0.5)))
        return self.expr("MaterialExpressionMax",
                         [self.add(self.mul(i["a"], gain), offset), self.const(0.0)])

    def _op_hue_sat(self, i, opt):
        colour = i["a"]
        # Hue: a rotation about the grey axis by (hue - 0.5) turns — close to Blender's HSV shift.
        angle = self.mul(self.sub(i["hue"], self.const(0.5)), self.const(TWO_PI))
        axis = self.const(0.57735, 0.57735, 0.57735)
        cos = self.expr("MaterialExpressionCosine", [angle], period=TWO_PI)
        sin = self.expr("MaterialExpressionSine", [angle], period=TWO_PI)
        along = self.mul(axis, self.expr("MaterialExpressionDotProduct", [axis, colour]))
        turned = self.add(self.add(self.mul(colour, cos),
                                   self.mul(self.expr("MaterialExpressionCrossProduct", [axis, colour]), sin)),
                          self.mul(along, self.one_minus(cos)))
        # Saturation scales the distance from the brightest channel (HSV's value). Blender clamps
        # the new saturation to 0..1, so the scale stops where the dimmest channel reaches zero:
        # unclamped, a Saturation of 2 on an already pure blue drives red and green negative.
        r, g, b = self.mask(turned, "r"), self.mask(turned, "g"), self.mask(turned, "b")
        value = self.expr("MaterialExpressionMax", [self.expr("MaterialExpressionMax", [r, g]), b])
        lowest = self.expr("MaterialExpressionMin", [self.expr("MaterialExpressionMin", [r, g]), b])
        ceiling = self.div(value, self.expr("MaterialExpressionMax",
                                            [self.sub(value, lowest), self.const(1e-6)]))
        scale = self.expr("MaterialExpressionClamp", [i["sat"], self.const(0.0), ceiling])
        saturated = self.add(value, self.mul(self.sub(turned, value), scale))
        result = self.mul(saturated, i["val"])
        return self.lerp(colour, result, i["fac"])

    def _rotate_z(self, vector, angle):
        cos = self.expr("MaterialExpressionCosine", [angle], period=TWO_PI)
        sin = self.expr("MaterialExpressionSine", [angle], period=TWO_PI)
        x, y, z = self.mask(vector, "r"), self.mask(vector, "g"), self.mask(vector, "b")
        new_x = self.sub(self.mul(x, cos), self.mul(y, sin))
        new_y = self.add(self.mul(x, sin), self.mul(y, cos))
        return self.append(self.append(new_x, new_y), z)

    def _rotate_x(self, vector, angle):
        cos = self.expr("MaterialExpressionCosine", [angle], period=TWO_PI)
        sin = self.expr("MaterialExpressionSine", [angle], period=TWO_PI)
        x, y, z = self.mask(vector, "r"), self.mask(vector, "g"), self.mask(vector, "b")
        new_y = self.sub(self.mul(y, cos), self.mul(z, sin))
        new_z = self.add(self.mul(y, sin), self.mul(z, cos))
        return self.append(self.append(x, new_y), new_z)

    def _rotate_y(self, vector, angle):
        cos = self.expr("MaterialExpressionCosine", [angle], period=TWO_PI)
        sin = self.expr("MaterialExpressionSine", [angle], period=TWO_PI)
        x, y, z = self.mask(vector, "r"), self.mask(vector, "g"), self.mask(vector, "b")
        new_x = self.add(self.mul(x, cos), self.mul(z, sin))
        new_z = self.sub(self.mul(z, cos), self.mul(x, sin))
        return self.append(self.append(new_x, y), new_z)

    def _turn(self, vector, rotation, euler, inverse=False):
        """Mapping's rotation: Z alone, or with `euler` Blender's XYZ Euler (X, then Y, then Z:
        Cycles' `euler_to_transform`); `inverse` undoes it, as a Texture mapping does."""
        angles = [self.mask(rotation, axis) for axis in ("r", "g", "b")]
        if inverse:
            angles = [self.mul(angle, self.const(-1.0)) for angle in angles]
        if not euler:
            return self._rotate_z(vector, angles[2])
        turns = ((self._rotate_x, angles[0]), (self._rotate_y, angles[1]),
                 (self._rotate_z, angles[2]))
        for turn, angle in (reversed(turns) if inverse else turns):
            vector = turn(vector, angle)
        return vector

    def _op_mapping(self, i, opt):
        kind = opt.get("type", "POINT")
        euler = bool(opt.get("euler"))
        if kind == "TEXTURE":
            moved = self.sub(i["a"], i["location"])
            return self.div(self._turn(moved, i["rotation"], euler, inverse=True), i["scale"])
        turned = self._turn(self.mul(i["a"], i["scale"]), i["rotation"], euler)
        return self.add(turned, i["location"]) if kind == "POINT" else turned

    def _noise(self, position, opt, function):
        functions = self.unreal.NoiseFunction
        found = self._new("MaterialExpressionNoise", scale=1.0,
                          noise_function=getattr(functions, function),
                          levels=int(opt.get("levels", 2)), output_min=0.0, output_max=1.0,
                          level_scale=float(opt.get("lacunarity", 2.0)), turbulence=False)
        # Its first input, "World Position" in 5.8: read rather than named, as everywhere here.
        names = list(self.library.get_material_expression_input_names(found) or [])
        self._connect(position, found, names[0] if names else "Position")
        return (found, "")

    def _transform(self, vector, source, destination):
        """A vector from one space to another: "tangent", "world" or "local"."""
        unreal = self.unreal
        sources = {"tangent": unreal.MaterialVectorCoordTransformSource.TRANSFORMSOURCE_TANGENT,
                   "world": unreal.MaterialVectorCoordTransformSource.TRANSFORMSOURCE_WORLD}
        targets = {"tangent": unreal.MaterialVectorCoordTransform.TRANSFORM_TANGENT,
                   "world": unreal.MaterialVectorCoordTransform.TRANSFORM_WORLD,
                   "local": unreal.MaterialVectorCoordTransform.TRANSFORM_LOCAL}
        return self.expr("MaterialExpressionTransform", [vector],
                         transform_source_type=sources[source],
                         transform_type=targets[destination])

    def _height_slope(self, height_ref, width):
        """(dh/dx, dh/dy): the height evaluated again with every coordinate moved by its
        derivative times the filter width, minus the height, over the filter width.

        Blender's way (Cycles' bump offset, EEVEE's `dF_branch`). With a filter width of 1 it
        is close to ddx(height); a smaller width takes the slope over less than a pixel.
        """
        base = self.ref(height_ref)
        saved = self._variant
        slopes = []
        for axis in ("x", "y"):
            self._variant = (axis, width)
            try:
                moved = self.ref(height_ref)
            finally:
                self._variant = saved
            slopes.append(self.div(self.sub(moved, base),
                                   self.expr("MaterialExpressionMax", [width, self.const(1e-4)])))
        return slopes

    def _op_bump(self, i, opt):
        """Blender's Bump node, as EEVEE computes it, in world space and metres.

            N = normalize(normal under it)        dPdx, dPdy = ddx(P), ddy(P)
            Rx = cross(dPdy, N)   Ry = cross(N, dPdx)   det = dot(dPdx, Rx)
            g = dh/dx Rx + dh/dy Ry (`_height_slope`)   d = distance x (invert ? -1 : 1) x facing
            bumped = normalize(|det| N - d sign(det) g)
            result = normalize(lerp(N, bumped, max(strength, 0)))

        P is Unreal's world position in metres, as Blender's is: in centimetres the slope would
        be a hundred times too gentle. Unreal's mirrored Y and its downward screen Y each flip
        det and g together, so the result is the same surface. It goes back to tangent space for
        the material's Normal. In ray-traced reflections derivatives are 0, so the bump is flat
        there.
        """
        cross = "MaterialExpressionCrossProduct"
        dot = "MaterialExpressionDotProduct"
        normal = self.expr("MaterialExpressionNormalize",
                           [self._transform(i["normal"], "tangent", "world")])
        position = self.mul(self.expr("MaterialExpressionWorldPosition"), self.const(0.01))
        dpdx = self.expr("MaterialExpressionDDX", [position])
        dpdy = self.expr("MaterialExpressionDDY", [position])
        rx = self.expr(cross, [dpdy, normal])
        ry = self.expr(cross, [normal, dpdx])
        det = self.expr(dot, [dpdx, rx])
        spec_in = self._spec.get("in") or {}
        width = i.get("filter_width") or self.const(0.1)
        dhdx, dhdy = self._height_slope(spec_in["height"], width)
        gradient = self.add(self.mul(dhdx, rx), self.mul(dhdy, ry))
        distance = self.mul(i["distance"], self.expr("MaterialExpressionTwoSidedSign"))
        if opt.get("invert"):
            distance = self.mul(distance, self.const(-1.0))
        tilt = self.mul(self.mul(distance, self.expr("MaterialExpressionSign", [det])), gradient)
        bumped = self.expr("MaterialExpressionNormalize", [
            self.sub(self.mul(self.expr("MaterialExpressionAbs", [det]), normal), tilt)])
        strength = self.expr("MaterialExpressionMax", [i["strength"], self.const(0.0)])
        result = self.expr("MaterialExpressionNormalize", [self.lerp(normal, bumped, strength)])
        return self._transform(result, "world", "tangent")

    def _blender_noise(self, i, opt, colour):
        """Blender's own Noise Texture (`NOISE_HLSL`): (colour, value) as a float4 output."""
        unreal = self.unreal
        found = self._new("MaterialExpressionCustom",
                          code=noise_hlsl(opt.get("dims", 3), opt.get("type", "FBM"),
                                          opt.get("normalize", True), colour),
                          output_type=unreal.CustomMaterialOutputType.CMOT_FLOAT4,
                          description="Blender Noise",
                          inputs=[self._custom_input(name)
                                  for name, _key, _default in NOISE_INPUTS])
        for name, key, default in NOISE_INPUTS:
            source = i.get(key)
            if source is None:
                source = self.const(0.0, 0.0, 0.0) if default is None else self.const(default)
            self._connect(source, found, name)
        return (found, "")

    def _op_noise(self, i, opt):
        if "dims" in opt:
            found = self._blender_noise(i, opt, bool(opt.get("color")))
            return {"fac": self.mask(found, "a"), "color": self.mask3(found)}
        position = self.mul(i["a"], i["scale"])
        fac = self._noise(position, opt, "NOISEFUNCTION_GRADIENT_ALU")
        green = self._noise(self.add(position, self.const(37.1, 11.3, 5.7)), opt,
                            "NOISEFUNCTION_GRADIENT_ALU")
        blue = self._noise(self.add(position, self.const(-13.9, 29.4, 17.2)), opt,
                           "NOISEFUNCTION_GRADIENT_ALU")
        return {"fac": fac, "color": self.append(self.append(fac, green), blue)}

    VORONOI_INPUTS = (("Coord", "a", None), ("Scale", "scale", 5.0), ("Detail", "detail", 0.0),
                      ("Roughness", "roughness", 0.5), ("Lacunarity", "lacunarity", 2.0),
                      ("Smoothness", "smoothness", 1.0), ("Minkowski", "exponent", 0.5),
                      ("Randomness", "randomness", 1.0))

    def _op_voronoi(self, i, opt):
        if "feature" not in opt:  # an older Blender's message: Unreal's own cells
            return self._noise(self.mul(i["a"], i["scale"]), {"levels": 1},
                               "NOISEFUNCTION_VORONOI_ALU")
        unreal = self.unreal
        found = self._new("MaterialExpressionCustom",
                          code=voronoi_hlsl(opt.get("feature"), opt.get("metric"),
                                            opt.get("normalize"), opt.get("rgb")),
                          output_type=unreal.CustomMaterialOutputType.CMOT_FLOAT4,
                          description="Blender Voronoi",
                          inputs=[self._custom_input(name)
                                  for name, _key, _default in self.VORONOI_INPUTS])
        for name, key, default in self.VORONOI_INPUTS:
            source = i.get(key)
            if source is None:
                source = self._object() if default is None else self.const(default)
            self._connect(source, found, name)
        return {"": self.mask((found, ""), "a"), "rgb": self.mask3((found, ""))}

    def _custom_input(self, name):
        found = self.unreal.CustomInput()  # Unreal's struct takes no keywords
        found.set_editor_property("input_name", name)
        return found

    def _op_vector_rotate(self, i, opt):
        kind = opt.get("type", "AXIS_ANGLE")
        sign = -1.0 if opt.get("invert") else 1.0
        moved = self.sub(i["a"], i["center"])
        if kind == "EULER_XYZ":
            # Blender's Euler XYZ: X first, then Y, then Z; inverted, the reverse.
            turns = [("x", self.mask(i["rotation"], "r")), ("y", self.mask(i["rotation"], "g")),
                     ("z", self.mask(i["rotation"], "b"))]
            if sign < 0:
                turns.reverse()
            for axis, angle in turns:
                moved = self._rotate(moved, AXES[axis], self.mul(angle, self.const(sign)))
        else:
            if kind == "AXIS_ANGLE":
                axis = self.expr("MaterialExpressionNormalize", [i["axis"]])
            else:
                axis = AXES[kind[0].lower()]
            moved = self._rotate(moved, axis, self.mul(i["angle"], self.const(sign)))
        return self.add(moved, i["center"])

    def _rotate(self, vector, axis, angle):
        """Rodrigues' rotation of `vector` about the unit `axis` (an expression, or an (x, y, z)
        of numbers) by `angle` radians, right-handed: Cycles' `rotate_around_axis`."""
        if isinstance(axis, tuple) and all(isinstance(v, float) for v in axis):
            axis = self.const(*axis)
        cos = self.expr("MaterialExpressionCosine", [angle], period=TWO_PI)
        sin = self.expr("MaterialExpressionSine", [angle], period=TWO_PI)
        along = self.mul(axis, self.expr("MaterialExpressionDotProduct", [axis, vector]))
        return self.add(self.add(self.mul(vector, cos),
                                 self.mul(self.expr("MaterialExpressionCrossProduct", [axis, vector]), sin)),
                        self.mul(along, self.one_minus(cos)))

    WAVE_AXES = {"X": (1.0, 0.0, 0.0), "Y": (0.0, 1.0, 0.0), "Z": (0.0, 0.0, 1.0)}

    def _op_wave(self, i, opt):
        # Cycles' `svm_wave`: bands along an axis (or the diagonal) or rings about one (or a
        # point), 20 to the unit, then the phase, the distortion and the profile.
        p = self.mul(self.add(self.mul(i["a"], i["scale"]), self.const(1e-6)),
                     self.const(0.999999))
        direction = opt.get("direction", "X")
        if opt.get("type") == "RINGS":
            if direction in self.WAVE_AXES:
                keep = tuple(1.0 - v for v in self.WAVE_AXES[direction])
                p_ring = self.mul(p, self.const(*keep))
            else:  # SPHERICAL
                p_ring = p
            n = self.mul(self.expr("MaterialExpressionLength", [p_ring]), self.const(20.0))
        elif direction in self.WAVE_AXES:
            n = self.mul(self.expr("MaterialExpressionDotProduct",
                                   [p, self.const(*self.WAVE_AXES[direction])]), self.const(20.0))
        else:  # DIAGONAL
            n = self.mul(self.expr("MaterialExpressionDotProduct",
                                   [p, self.const(1.0, 1.0, 1.0)]), self.const(10.0))
        n = self.add(n, i["phase"])
        if "distortion" in i and "detail" in i:
            # Cycles: noise_fbm(p x Detail Scale, Detail, Detail Roughness, 2, normalized).
            noise = self.mask(self._blender_noise(
                {"a": self.mul(p, i["detail_scale"]), "detail": i["detail"],
                 "roughness": i.get("roughness"), "lacunarity": self.const(2.0),
                 "scale": self.const(1.0)}, {"dims": 3}, False), "a")
            n = self.add(n, self.mul(i["distortion"],
                                     self.sub(self.mul(noise, self.const(2.0)), self.const(1.0))))
        elif "distortion" in i:  # an older Blender's message: Unreal's noise
            noise = self._noise(self.mul(p, i["detail_scale"]), opt,
                                "NOISEFUNCTION_GRADIENT_ALU")
            n = self.add(n, self.mul(i["distortion"],
                                     self.sub(self.mul(noise, self.const(2.0)), self.const(1.0))))
        profile = opt.get("profile", "SIN")
        if profile == "SIN":
            fac = self.add(self.const(0.5), self.mul(self.const(0.5), self.expr(
                "MaterialExpressionSine", [self.sub(n, self.const(math.pi / 2.0))],
                period=TWO_PI)))
        else:
            n = self.mul(n, self.const(1.0 / TWO_PI))
            if profile == "SAW":
                fac = self.expr("MaterialExpressionFrac", [n])
            else:  # TRI
                fac = self.mul(self.expr("MaterialExpressionAbs", [self.sub(n, self.expr(
                    "MaterialExpressionFloor", [self.add(n, self.const(0.5))]))]),
                    self.const(2.0))
        return {"fac": fac, "color": self.append(self.append(fac, fac), fac)}

    def _op_checker(self, i, opt):
        cells = self.expr("MaterialExpressionFloor", [self.mul(i["a"], i["scale"])])
        total = self.expr("MaterialExpressionDotProduct", [cells, self.const(1.0, 1.0, 1.0)])
        # Colour 1 where the three cell indices sum to an odd number.
        fac = self.mul(self.expr("MaterialExpressionFrac", [self.mul(total, self.const(0.5))]),
                       self.const(2.0))
        return {"fac": fac, "color": self.lerp(i["c2"], i["c1"], fac)}

    def _op_gradient(self, i, opt):
        kind = opt.get("type", "LINEAR")
        x, y = self.mask(i["a"], "r"), self.mask(i["a"], "g")
        if kind == "LINEAR":
            result = x
        elif kind == "QUADRATIC":
            clipped = self.expr("MaterialExpressionMax", [x, self.const(0.0)])
            result = self.mul(clipped, clipped)
        elif kind == "EASING":
            t = self.saturate(x)
            result = self.mul(self.mul(t, t), self.sub(self.const(3.0), self.mul(t, self.const(2.0))))
        elif kind == "DIAGONAL":
            result = self.mul(self.add(x, y), self.const(0.5))
        elif kind in ("SPHERICAL", "QUADRATIC_SPHERE"):
            result = self.expr("MaterialExpressionMax", [
                self.one_minus(self.expr("MaterialExpressionLength", [i["a"]])), self.const(0.0)])
            if kind == "QUADRATIC_SPHERE":
                result = self.mul(result, result)
        elif kind == "RADIAL":
            angle = self.expr("MaterialExpressionArctangent2", [y, x])
            result = self.add(self.div(angle, self.const(TWO_PI)), self.const(0.5))
        else:
            raise Unbuildable("gradient " + kind)
        return self.saturate(result)


try:
    _PENDING  # noqa: B018 - survives importlib.reload on purpose
except NameError:
    # Wirings asked for but not built yet, oldest first, and those built since `take_built`.
    # Building one creates its expressions and compiles its shaders, seconds of the editor's
    # time and gigabytes of memory; a scene's first arrival asked for twenty in a row.
    _PENDING = {}  # (surface, key) -> spec
    _BUILT = []    # graph keys
    _FAILED = set()  # (surface, key) that could not be rebuilt: the master shows them
    _PACE = {"last": float("-inf"), "held": ""}
try:
    _UNSAVED  # noqa: B018
except NameError:
    _UNSAVED = {}  # asset path -> material built this session and not saved yet


def ensure(surface, spec, wait=False):
    """The compiled graph material for this surface and wiring, or None (use the master).

    One that was never built joins the queue `service` works through and is None for now, unless
    `wait` asks for it at once."""
    import unreal

    graph = spec.get("graph") or {}
    key = str(spec.get("graph_key") or "")
    if not graph.get("out") or not key:
        return None
    path = material_path(surface, key)
    bu_link_cache.note_used(material_name(surface, key))
    if unreal.EditorAssetLibrary.does_asset_exist(path.split(".")[0]):
        found = unreal.EditorAssetLibrary.load_asset(path)
        if found is not None:
            return found
    if (surface, key) in _FAILED:
        return None
    if not wait:
        _PENDING.setdefault((surface, key), spec)
        return None
    _PENDING.pop((surface, key), None)
    material = unreal.AssetToolsHelpers.get_asset_tools().create_asset(
        material_name(surface, key), PACKAGE, unreal.Material, unreal.MaterialFactoryNew())
    if material is None:
        _FAILED.add((surface, key))
        return None
    if surface == "fog":  # a fog volume's box (`bu_link_fog`)
        from . import bu_link_fog

        emitter = bu_link_fog.FogEmitter(unreal, material, graph)
        build = bu_link_fog.build
    else:
        emitter = Emitter(unreal, material, graph)

        def build(unreal, material, emitter):
            return bu_link_material._build(unreal, material, surface, emitter)
    try:
        failed = build(unreal, material, emitter)
    except Unbuildable as exc:
        failed = [str(exc)]
    except Exception as exc:  # noqa: BLE001 - shown with its values, not retried every tick
        failed = ["{0}: {1}".format(type(exc).__name__, exc)]
    failed = list(failed) + emitter.failed
    if failed:
        unreal.log_warning("BU: Blender's nodes for {0} could not be rebuilt ({1}); showing "
                           "their values instead".format(material_name(surface, key),
                                                         ", ".join(failed[:4])))
        unreal.EditorAssetLibrary.delete_loaded_asset(material)
        _FAILED.add((surface, key))
        return None
    bu_link_material.compile_material(unreal, material)
    # Saved later (`service_saves`, `save_materials`): 55-80 ms each, while a scene loads.
    _UNSAVED[material.get_path_name()] = material
    unreal.log("BU: compiled {0} from Blender's nodes".format(material_name(surface, key)))
    return material


def waiting():
    return len(_PENDING)


def held():
    """Why the next wiring is not being built: "memory", "busy" or ""."""
    return _PACE["held"] if _PENDING else ""


def forget_waiting():
    _PENDING.clear()
    del _BUILT[:]
    _PACE["held"] = ""


def service(now, gauge=None):
    """Build the next waiting wiring if Unreal has room. True when one was built: the materials
    using it are chosen again (`take_built`)."""
    if not _PENDING:
        return False
    from . import bu_link_pace

    shaders, memory = (gauge or bu_link_pace.shader_gauge)()
    why, ok = bu_link_pace.may_start(shaders, memory, now, _PACE["last"],
                                     limit=bu_link_pace.SHADER_JOB_LIMIT)
    _PACE["held"] = why
    if not ok:
        return False
    (surface, key), spec = next(iter(_PENDING.items()))
    _PACE["last"] = now
    built = ensure(surface, spec, wait=True)
    _PENDING.pop((surface, key), None)  # built, or failed and shown with the master: not again
    if built is None:
        return False
    _BUILT.append(key)
    return True


def service_saves(limit=1):
    """Save up to `limit` materials built this session. Returns how many were saved."""
    saved = 0
    while _UNSAVED and saved < limit:
        _path, material = _UNSAVED.popitem()
        try:
            import unreal

            unreal.EditorAssetLibrary.save_loaded_asset(material, only_if_is_dirty=False)
        except Exception:  # noqa: BLE001 - deleted or replaced since
            pass
        saved += 1
    return saved


def save_materials():
    """Save every material built this session: when Blender disconnects."""
    while service_saves(len(_UNSAVED) or 1):
        pass


def take_built():
    """The graph keys built since last asked."""
    keys = list(_BUILT)
    del _BUILT[:]
    return keys
