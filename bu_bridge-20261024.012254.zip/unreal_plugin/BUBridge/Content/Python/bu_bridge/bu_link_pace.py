# SPDX-License-Identifier: GPL-3.0-or-later
"""How fast the link may start work Unreal finishes in the background: texture imports and
materials built from Blender's nodes.

A big scene arriving for the first time used to import every texture in one tick. Each import
starts a background compression job (a 2K map's estimate is 300-500 MB, a 4K one's four times
that), and every one of them ran at once. Unreal grew from 1 GB to 20-40 GB in a few seconds and
Windows ran out of memory, RAM and page file together. Unreal said so as "out of video memory"
when the allocation that failed was a buffer for uploading to the graphics card, or as "the
paging file is too small" when it was its own.

Node materials (`bu_link_graph`) came in the same rush, twenty built in a row; the larger
cost there was each one compiling its half-built self once per node property
(`bu_link_material._quiet` has the story).

So the link imports one texture at a time, and only while Unreal is not already compressing a
couple; it builds one node material a tick; and neither while the machine is short of memory.
Until its texture is in, a material shows its plain colour, and until its node material is
built, the values Blender sent with it.
"""
import sys

# Background compiles (textures, meshes) Unreal may have going before another import starts,
# and how many with memory to spare (`compile_limit`): a 2K texture's build holds 300-500 MB.
COMPILE_LIMIT = 2
COMPILE_LIMIT_ROOMY = 6
ROOMY_COMMIT_FREE = 16 << 30
ROOMY_RAM_FREE = 8 << 30
# Shader jobs left before another node material is built. Its shaders compile in the background
# (`bu_link_graph.compile_material`), so this is what keeps a scene's dozens of node materials
# from all compiling at once; with Unreal's `recompile_material` they compiled before it returned.
SHADER_JOB_LIMIT = 50
# Free memory below which nothing new starts: Windows' commit headroom (RAM plus page file, what
# ran out), and RAM, whose lack makes Windows page and everything crawl first.
MIN_COMMIT_FREE = 4 << 30
MIN_RAM_FREE = 2 << 30
# An Unreal side whose native plugin predates the compile counter: one import this often.
FALLBACK_INTERVAL = 0.5


def compile_limit(memory):
    """How many background compiles may run together, from (RAM free, commit free). Pure.

    Two kept a scene of a few hundred textures loading for minutes on a machine with tens of
    gigabytes free; six when there is room for all of them at a 4K texture's size, two when not
    (or when it cannot be told).
    """
    if memory is None:
        return COMPILE_LIMIT
    ram_free, commit_free = memory
    if commit_free >= ROOMY_COMMIT_FREE and ram_free >= ROOMY_RAM_FREE:
        return COMPILE_LIMIT_ROOMY
    return COMPILE_LIMIT


def may_start(compiles, memory, now, last, limit=None):
    """("", True) if another import may start now, else (why not, False). Pure.

    `compiles` is how many background compiles (or shader jobs, against `limit`) Unreal has
    going, None when unknown; `memory` (RAM free, commit free) in bytes, None when unknown;
    `last` when the previous one started.
    """
    limit = COMPILE_LIMIT if limit is None else limit
    if memory is not None:
        ram_free, commit_free = memory
        if commit_free < MIN_COMMIT_FREE or ram_free < MIN_RAM_FREE:
            return "memory", False
    if compiles is None:
        return ("", True) if now - last >= FALLBACK_INTERVAL else ("busy", False)
    return ("", True) if compiles < limit else ("busy", False)


def memory_free():
    """(RAM free, commit free) in bytes, or None where it cannot be read."""
    if sys.platform != "win32":
        return None
    import ctypes

    class MemoryStatus(ctypes.Structure):
        _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong),
                    ("total_phys", ctypes.c_ulonglong), ("avail_phys", ctypes.c_ulonglong),
                    ("total_page_file", ctypes.c_ulonglong), ("avail_page_file", ctypes.c_ulonglong),
                    ("total_virtual", ctypes.c_ulonglong), ("avail_virtual", ctypes.c_ulonglong),
                    ("avail_extended_virtual", ctypes.c_ulonglong)]

    status = MemoryStatus()
    status.length = ctypes.sizeof(MemoryStatus)
    try:
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return None
    except (AttributeError, OSError):
        return None
    return int(status.avail_phys), int(status.avail_page_file)


def compiles_left(name="get_asset_compiles_remaining"):
    """Background asset compiles (or, by `name`, shader jobs) Unreal has not finished, or None
    without the native plugin."""
    try:
        import unreal
    except ImportError:
        return None
    library = getattr(unreal, "BULinkLibrary", None)
    count = getattr(library, name, None) if library is not None else None
    if count is None:
        return None
    try:
        return int(count())
    except Exception:  # noqa: BLE001 - an older plugin, or the call failing: fall back
        return None


def gauge():
    return compiles_left(), memory_free()


def shader_gauge():
    return compiles_left("get_shader_jobs_remaining"), memory_free()
