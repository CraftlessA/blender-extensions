# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender's lights, described for the real-time link.

Sent in Blender's own terms: watts, radians, metres. Unreal's `bu_link_light` converts them, in
one tested place. What is here is reading the light and the one geometric fact the two programs
disagree on: a Blender light shines down its local -Z, an Unreal light along its local +X. So the
matrix sent for a light is its world matrix turned a quarter turn about local Y, and without
scale (Unreal light actors do not scale; an area light's scale is folded into its size instead).
"""

import hashlib
import math
import os

import numpy as np

try:
    from . import link_mesh
except ImportError:  # loaded by path in the plain-CPython tests
    import link_mesh

PRECISION = 4
# A quarter turn about local Y: +X (Unreal's forward) onto -Z (where a Blender light points).
TO_FORWARD = np.array([[0.0, 0.0, 1.0, 0.0],
                       [0.0, 1.0, 0.0, 0.0],
                       [-1.0, 0.0, 0.0, 0.0],
                       [0.0, 0.0, 0.0, 1.0]])


def _round(value):
    return round(float(value), PRECISION)


def scale_of(matrix):
    """The length of each basis axis of a 4x4 matrix. Pure."""
    m = np.array([list(row) for row in matrix], dtype=np.float64).reshape(4, 4)
    return [float(np.linalg.norm(m[:3, axis])) for axis in range(3)]


def light_matrix(matrix):
    """A Blender light's world matrix -> 16 floats for Unreal's light actor. Pure."""
    m = np.array([list(row) for row in matrix], dtype=np.float64).reshape(4, 4)
    for axis in range(3):
        length = np.linalg.norm(m[:3, axis])
        if length > 1e-12:
            m[:3, axis] /= length
    return link_mesh.matrix_to_unreal(m @ TO_FORWARD)


def power(light, size_x=0.0, size_y=0.0):
    """The light's power in watts as Cycles emits it: Power x 2^Exposure, and, with Normalize
    off, x the light's area (m², its object's scale included: `size_x`, `size_y` for an area
    light), as Cycles' `invarea` is 1 then rather than 1 / area. A light at Exposure -8 (one in
    sq041, all but switched off) lit a whole cage in Unreal at full power."""
    found = float(light.energy) * 2.0 ** float(getattr(light, "exposure", 0.0))
    if getattr(light, "normalize", True):
        return found
    kind = str(light.type)
    if kind == "AREA":
        area = size_x * size_y
        if light.shape in ("DISK", "ELLIPSE"):
            area *= math.pi / 4.0
    elif kind == "SUN":
        area = math.pi * math.tan(float(light.angle) / 2.0) ** 2
    else:
        area = math.pi * float(light.shadow_soft_size) ** 2
    return found * area if area > 0.0 else found


# -- the light's own nodes -----------------------------------------------------------------------
#
# Cycles multiplies a light by its node tree: the Emission feeding its Light Output, colour times
# strength. An image in it is a gobo, projected across a spot's cone (its UVs span the square
# round the cone) or laid over an area light. Unreal has no per-light node tree: BU folds the
# tree's mean into the light's colour and power, so the light is as bright as Cycles' overall;
# a gobo's pattern itself is not drawn. sq020's god rays came from a 1278 W spot at Exposure 10
# shining through a leaf-pattern gobo (black outside its circle, 45% bright inside); without
# its mean the beam filled the fog at more than twice Cycles' brightness and hid the set
# behind it.

# Average a gobo over at most this many pixels a side (a 4K texture is read every 4th pixel).
GOBO_SAMPLES = 512
_TINTS = {}  # (`_gobo_key`, spot) -> mean (r, g, b): read once
_GOBOS = {}  # `_gobo_key` -> linear rgb rows (`_gobo_rgb`)
_GOBO_FILES = {}  # `_gobo_key` -> the `gobo` field (`gobo_file`)


def _ramp_table(ramp):
    """A Color Ramp as 256 (r, g, b) rows, positions 0..1, as Blender evaluates it."""
    return np.array([tuple(ramp.evaluate(i / 255.0))[:3] for i in range(256)], dtype=np.float64)


def _gobo_key(image, ramp):
    """What a gobo's pixels are known by: the image, its size and colour space, and the ramp's
    stops. None for an image with no size."""
    try:
        width, height = (int(v) for v in image.size)
    except (TypeError, ValueError, AttributeError):
        return None
    if width <= 0 or height <= 0:
        return None
    return (image.name_full, width, height, image.colorspace_settings.name,
            None if ramp is None else (ramp.interpolation, tuple(
                (round(e.position, 4),) + tuple(round(c, 4) for c in e.color)
                for e in ramp.elements)))


def _gobo_rgb(image, ramp):
    """An image as a light sees it: linear (r, g, b) rows, bottom row first as Blender keeps
    them, at most `GOBO_SAMPLES` a side, through `ramp` (a Color Ramp reading the image's
    luminance) if one maps it. None if it cannot be read. Read once per `_gobo_key`."""
    key = _gobo_key(image, ramp)
    if key is None:
        return None
    if key in _GOBOS:
        return _GOBOS[key]
    width, height = key[1], key[2]
    try:
        pixels = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(pixels)
    except (RuntimeError, ValueError, AttributeError):
        _GOBOS[key] = None
        return None
    rgb = pixels.reshape(height, width, 4)[:, :, :3].astype(np.float64)
    step = max(1, max(width, height) // GOBO_SAMPLES)
    rgb = rgb[::step, ::step]
    # A byte image's pixels read as stored (sRGB-encoded); a float one's are linear already.
    if (image.colorspace_settings.name in ("sRGB", "sRGB EOTF")
            and not getattr(image, "is_float", False)):
        rgb = np.where(rgb <= 0.04045, rgb / 12.92, ((rgb + 0.055) / 1.055) ** 2.4)
    if ramp is not None:
        value = np.clip(rgb @ np.array([0.2126, 0.7152, 0.0722]), 0.0, 1.0)
        table = _ramp_table(ramp)
        index = value * 255.0
        low = np.floor(index).astype(np.intp)
        high = np.minimum(low + 1, 255)
        t = (index - low)[..., None]
        rgb = table[low] * (1.0 - t) + table[high] * t
    _GOBOS[key] = rgb
    return rgb


def _inside_cone(rows, columns):
    """Which of a spot's gobo pixels fall inside its cone: the circle the image's square holds
    (Cycles spreads a spot's UVs over the square round its cone)."""
    y, x = np.mgrid[0:rows, 0:columns]
    return ((x + 0.5) / columns - 0.5) ** 2 + ((y + 0.5) / rows - 0.5) ** 2 <= 0.25


def _image_mean(image, ramp, spot):
    """The mean (r, g, b) an image gives a light (`_gobo_rgb`): over the circle inside the
    image for a spot (its cone), the whole image otherwise. None if it cannot be read."""
    key = (_gobo_key(image, ramp), spot)
    if key in _TINTS:
        return _TINTS[key]
    rgb = _gobo_rgb(image, ramp)
    if rgb is None:
        _TINTS[key] = None
        return None
    rows, columns = rgb.shape[:2]
    if spot:
        inside = _inside_cone(rows, columns)
        found = rgb[inside].mean(axis=0) if inside.any() else rgb.reshape(-1, 3).mean(axis=0)
    else:
        found = rgb.reshape(-1, 3).mean(axis=0)
    _TINTS[key] = tuple(float(c) for c in found)
    return _TINTS[key]


def _light_image(light):
    """(emission node, image, Color Ramp or None) when a light's colour comes from an image (through
    a ramp or not), the image read at the light's own coordinates; else (emission or None,
    None, None)."""
    tree = getattr(light, "node_tree", None)
    if tree is None or not getattr(light, "use_nodes", True):
        return None, None, None
    outputs = [n for n in tree.nodes if n.bl_idname == "ShaderNodeOutputLight"]
    active = [n for n in outputs if getattr(n, "is_active_output", False)] or outputs
    if not active or not active[0].inputs["Surface"].is_linked:
        return None, None, None
    emission = active[0].inputs["Surface"].links[0].from_node
    if emission.bl_idname != "ShaderNodeEmission":
        return None, None, None
    color_socket = emission.inputs["Color"]
    if not color_socket.is_linked:
        return emission, None, None
    source = color_socket.links[0].from_node
    ramp = None
    if source.bl_idname == "ShaderNodeValToRGB" and source.inputs[0].is_linked:
        ramp = source.color_ramp
        source = source.inputs[0].links[0].from_node
    if (source.bl_idname == "ShaderNodeTexImage" and source.image is not None
            and not any(socket.is_linked for socket in source.inputs)):
        return emission, source.image, ramp
    return emission, None, None


def gobo_blur(light, distance):
    """How far a spot's gobo is smeared, in the image's own units (its width 1), by the light's
    size `distance` metres away. Cycles reads the gobo from every point of the light, so a
    point lit sees it through a disk of angular radius radius / distance; across the image
    (the square round the cone) that is (radius / distance) / tan(half the cone) / 2. sq020's
    spots of radius 0.5 and 2 m, 15-20 m from the set, threw a soft dapple in Cycles where
    Unreal's light function, read from the light's centre, was sharp. Pure."""
    radius = float(getattr(light, "shadow_soft_size", 0.0))
    if radius <= 0.0 or not distance or distance <= 0.0:
        return 0.0
    tan_half = math.tan(min(max(float(light.spot_size) / 2.0, 1e-3), math.radians(89.0)))
    return min(0.5, (radius / distance) / tan_half / 2.0)


def _disk_blur(value, radius):
    """`value` (rows, columns) averaged over a disk of `radius` pixels, wrapping round as a
    repeating image does."""
    if radius < 0.5:
        return value
    rows, columns = value.shape
    y = np.fft.fftfreq(rows) * rows
    x = np.fft.fftfreq(columns) * columns
    disk = ((y[:, None] ** 2 + x[None, :] ** 2) <= radius * radius).astype(np.float64)
    disk /= disk.sum()
    return np.real(np.fft.ifft2(np.fft.fft2(value) * np.fft.fft2(disk)))


def gobo_file(light, blur=0.0):
    """A spot light's gobo for Unreal's light function, or None: {"path", "stamp", "mean"}.

    The image through its ramp, as its brightness over the brightest pixel (Unreal's light
    function is a 0-1 mask), written as an sRGB PNG with the top row first. Cycles' spot UVs
    are (u, v) = 0.5 + 0.5 (x, y) / (depth tan(half the cone)) in the light's own axes, and
    Unreal's light function UVs, after BU's light matrix, are (u, 1 - v): the row order every
    image already has in Unreal, so the picture goes as it is. `mean` is the mask's mean over
    the cone: the light's colour and power already carry the gobo's mean (`node_tint`), which
    Unreal divides by it once the light function is on (`bu_link_light.apply`). `blur`: the
    light's size smearing it (`gobo_blur`)."""
    if str(light.type) != "SPOT":
        return None
    _emission, image, ramp = _light_image(light)
    key = _gobo_key(image, ramp) if image is not None else None
    if key is None:
        return None
    # In steps of half a percent of the image: a spot moving over a shot gets a new file
    # (and Unreal a new import) only when its smear has changed by about a pixel.
    key = key + (round(float(blur) * 200.0) / 200.0,)
    if key in _GOBO_FILES:
        found = _GOBO_FILES[key]
        if found is None or os.path.isfile(found["path"]):
            return found
    rgb = _gobo_rgb(image, ramp)
    if rgb is None:
        _GOBO_FILES[key] = None
        return None
    value = np.clip(rgb @ np.array([0.2126, 0.7152, 0.0722]), 0.0, None)
    value = np.clip(_disk_blur(value, key[-1] * value.shape[1]), 0.0, None)
    peak = float(value.max())
    if peak <= 0.0:
        _GOBO_FILES[key] = None
        return None
    mask = value / peak
    inside = _inside_cone(*mask.shape)
    mean = float(mask[inside].mean() if inside.any() else mask.mean())
    encoded = np.where(mask <= 0.0031308, mask * 12.92, 1.055 * mask ** (1.0 / 2.4) - 0.055)
    grey = np.clip(np.round(encoded * 255.0), 0, 255).astype(np.uint8)[::-1]
    rgba = np.empty(grey.shape + (4,), dtype=np.uint8)
    rgba[..., :3] = grey[..., None]
    rgba[..., 3] = 255
    try:
        from . import link_material
    except ImportError:  # loaded by path in the plain-CPython tests
        import link_material
    data = link_material.png_bytes(rgba)
    stamp = hashlib.sha1(data).hexdigest()[:16]
    name = hashlib.sha1(repr(key[:4] + key[-1:]).encode("utf-8")).hexdigest()[:12]
    path = os.path.join(link_material.packed_folder(), "gobo_{0}.png".format(name))
    try:
        with open(path, "wb") as handle:
            handle.write(data)
    except OSError:
        _GOBO_FILES[key] = None
        return None
    _GOBO_FILES[key] = {"path": path, "stamp": stamp, "mean": _round(max(mean, 1e-4))}
    return _GOBO_FILES[key]


def node_tint(light):
    """What a light's node tree multiplies it by, as (r, g, b): the Emission feeding its Light
    Output, colour (a constant, or an image's mean, through a Color Ramp or not) times
    strength. (1, 1, 1) without nodes, and for any part that is not one of those."""
    emission, image, ramp = _light_image(light)
    if emission is None:
        return (1.0, 1.0, 1.0)
    strength_socket = emission.inputs["Strength"]
    strength = 1.0 if strength_socket.is_linked else float(strength_socket.default_value)
    color_socket = emission.inputs["Color"]
    color = (1.0, 1.0, 1.0)
    if not color_socket.is_linked:
        color = tuple(float(c) for c in tuple(color_socket.default_value)[:3])
    elif image is not None:
        found = _image_mean(image, ramp, str(light.type) == "SPOT")
        if found is not None:
            color = found
    return tuple(max(0.0, c * strength) for c in color)


def beam_distance(obj, depsgraph):
    """How far a spot shines before it meets a surface: along its axis, from where it is.
    None when nothing is in the way, or there is no scene to look in."""
    from mathutils import Vector

    try:
        scene = depsgraph.scene
        origin = obj.matrix_world.translation
        axis = (obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, -1.0))).normalized()
        hit, location = scene.ray_cast(depsgraph, origin, axis)[:2]
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return None
    return (location - origin).length if hit else None


def describe(obj, depsgraph=None):
    """A light object -> the dict sent to Unreal (without name and matrix). `depsgraph`, when
    given, is looked in for how far a spot's gobo is from what it lights (`gobo_blur`)."""
    light = obj.data
    kind = str(light.type)
    spec = {
        "light": kind,
        "color": [_round(c) for c in tuple(light.color)[:3]],
        "energy": _round(power(light)),
        "shadow": bool(getattr(light, "use_shadow", True)),
    }
    tint = node_tint(light)
    blur = 0.0
    if (depsgraph is not None and kind == "SPOT" and light.shadow_soft_size > 0.0
            and _light_image(light)[1] is not None):
        blur = gobo_blur(light, beam_distance(obj, depsgraph))
    gobo = gobo_file(light, blur)
    if gobo is not None:
        spec["gobo"] = dict(gobo)
    if tint != (1.0, 1.0, 1.0):
        # Folded into colour (kept at most 1) and power (`node_tint`).
        peak = max(tint)
        spec["color"] = [_round(c * t / peak) if peak > 0.0 else 0.0
                         for c, t in zip(tuple(light.color)[:3], tint)]
        spec["node_scale"] = _round(peak)
    if getattr(light, "use_temperature", False):
        spec["temperature"] = _round(light.temperature)
    if getattr(light, "use_custom_distance", False):
        spec["distance"] = _round(light.cutoff_distance)
    if kind == "SUN":
        spec["angle"] = _round(light.angle)
    elif kind == "AREA":
        sx, sy, _sz = scale_of(obj.matrix_world)
        wide = light.shape in ("RECTANGLE", "ELLIPSE")
        spec["shape"] = str(light.shape)
        spec["size_x"] = _round(light.size * sx)
        spec["size_y"] = _round((light.size_y if wide else light.size) * sy)
        spec["energy"] = _round(power(light, light.size * sx,
                                      (light.size_y if wide else light.size) * sy))
    if "node_scale" in spec:
        spec["energy"] = _round(spec["energy"] * spec.pop("node_scale"))
    if kind == "AREA":
        spec["spread"] = _round(getattr(light, "spread", 3.14159265))
    else:
        spec["radius"] = _round(light.shadow_soft_size)
        if kind == "SPOT":
            spec["spot_size"] = _round(light.spot_size)
            spec["spot_blend"] = _round(light.spot_blend)
    visibility = ray_visibility(obj)
    if visibility:
        spec["visibility"] = visibility
    if getattr(light, "bu_unreal", None) is not None:
        # What only Unreal has: units, scales, channels, IES… (BU's Unreal Light panel).
        from . import link_lighting

        spec["unreal"] = link_lighting.describe_light(light)
    return spec


# Blender's ways of keeping a light out of one kind of ray: the object's Ray Visibility box
# (Cycles) and the light's Influence factor (EEVEE). Unreal's `bu_link_light` turns each into its
# nearest setting: diffuse and specular scale, volumetric scattering.
# Not Transmission: in Blender that is light passing through glass and skin, which Unreal has no
# per-light scale for. Sent as Unreal's "Affect Translucent Lighting" it stopped every light
# lighting Blended surfaces at all; Toy Freddy's lights all had it at 0, and his eye whites
# went dark.
RAY_VISIBILITY = (("diffuse", "visible_diffuse", "diffuse_factor"),
                  ("glossy", "visible_glossy", "specular_factor"),
                  ("volume", "visible_volume_scatter", "volume_factor"))


def ray_visibility(obj):
    """{kind: how much of the light those rays see} for what is not fully seen, or {}."""
    light = obj.data
    found = {}
    for key, visible, factor in RAY_VISIBILITY:
        value = _round(getattr(light, factor, 1.0)) if getattr(obj, visible, True) else 0.0
        if value != 1.0:
            found[key] = max(0.0, value)
    return found
